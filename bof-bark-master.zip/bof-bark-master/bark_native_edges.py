"""Convert collected Entra PIM and Key Vault evidence to native AzureHound records.

Contract: AzureHound v3.1.0 and BloodHound v9.3.0. Raw evidence is retained
in the bundle; incomplete or unsupported semantics are reported, not guessed.
"""
from __future__ import annotations

from datetime import datetime, timezone
import copy
import json

ELIGIBILITY = "AZEntraRoleEligibilityScheduleInstance"
POLICY = "AZEntraRoleManagementPolicyAssignment"
BOOL_FIELDS = (
    "endUserAssignmentRequiresApproval",
    "endUserAssignmentRequiresCAPAuthenticationContext",
    "endUserAssignmentRequiresMFA",
    "endUserAssignmentRequiresJustification",
    "endUserAssignmentRequiresTicketInformation",
)
APPROVER_FIELDS = ("endUserAssignmentUserApprovers", "endUserAssignmentGroupApprovers")


def _id(value):
    return value.upper() if isinstance(value, str) else ""


def _date(value):
    if not isinstance(value, str):
        raise ValueError("invalid-date")
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("timezone-missing")
    return result.astimezone(timezone.utc)


def eligibility_record(raw, now):
    if not all(isinstance(raw.get(k), str) and raw[k] for k in
               ("principalId", "roleDefinitionId", "tenantId")):
        raise ValueError("missing-eligibility-endpoint")
    if raw.get("directoryScopeId") != "/" or raw.get("appScopeId"):
        raise ValueError("unsupported-scoped-eligibility")
    if not raw.get("startDateTime"):
        raise ValueError("missing-eligibility-start")
    if _date(raw["startDateTime"]) > now:
        raise ValueError("future-eligibility")
    if raw.get("endDateTime") and _date(raw["endDateTime"]) <= now:
        raise ValueError("expired-eligibility")
    result = copy.deepcopy(raw)
    for key in ("id", "principalId", "roleDefinitionId", "tenantId"):
        if key in result:
            result[key] = _id(result[key])
    return result


def policy_record(raw):
    if raw.get("scopeId") != "/" or raw.get("scopeType") != "Directory":
        raise ValueError("unsupported-scoped-policy")
    if not all(isinstance(raw.get(k), str) and raw[k] for k in
               ("policyId", "roleDefinitionId", "tenantId")):
        raise ValueError("missing-policy-endpoint")
    policy = raw.get("policy")
    if not isinstance(policy, dict) or not isinstance(policy.get("rules"), list):
        raise ValueError("missing-policy-rules")
    if policy.get("rules@odata.nextLink") or policy.get("@odata.nextLink"):
        raise ValueError("incomplete-policy-rules")
    rules = {}
    for rule in policy["rules"]:
        if not isinstance(rule, dict):
            raise ValueError("malformed-policy-rule")
        identifier = rule.get("id")
        if identifier in rules:
            raise ValueError("duplicate-policy-rule")
        rules[identifier] = rule
    required = {
        "Approval_EndUser_Assignment": "unifiedRoleManagementPolicyApprovalRule",
        "Enablement_EndUser_Assignment": "unifiedRoleManagementPolicyEnablementRule",
        "AuthenticationContext_EndUser_Assignment": "unifiedRoleManagementPolicyAuthenticationContextRule",
    }
    for identifier, kind in required.items():
        rule = rules.get(identifier, {})
        if rule.get("@odata.type") != "#microsoft.graph." + kind:
            raise ValueError("missing-activation-rule")
        target = rule.get("target", {})
        if not isinstance(target, dict):
            raise ValueError("invalid-activation-rule-target")
        if target.get("caller") != "EndUser" or target.get("level") != "Assignment":
            raise ValueError("invalid-activation-rule-target")
    approval = rules["Approval_EndUser_Assignment"].get("setting", {})
    enabled = rules["Enablement_EndUser_Assignment"].get("enabledRules")
    authentication = rules["AuthenticationContext_EndUser_Assignment"].get("isEnabled")
    if not isinstance(approval, dict):
        raise ValueError("missing-approval-setting")
    if not isinstance(approval.get("isApprovalRequired"), bool) or not isinstance(authentication, bool):
        raise ValueError("missing-activation-setting")
    if not isinstance(enabled, list) or not all(isinstance(v, str) for v in enabled):
        raise ValueError("missing-enablement-settings")
    users, groups = set(), set()
    if approval["isApprovalRequired"]:
        stages = approval.get("approvalStages")
        if not isinstance(stages, list) or len(stages) != 1:
            raise ValueError("unsupported-approval-stages")
        stage = stages[0]
        if not isinstance(stage, dict) or not isinstance(stage.get("primaryApprovers"), list):
            raise ValueError("missing-primary-approvers")
        if stage.get("isEscalationEnabled") or stage.get("escalationApprovers"):
            raise ValueError("unsupported-approval-escalation")
        for approver in stage["primaryApprovers"]:
            if not isinstance(approver, dict):
                raise ValueError("malformed-approver")
            kind = approver.get("@odata.type")
            key, destination = {
                "#microsoft.graph.singleUser": ("userId", users),
                "#microsoft.graph.groupMembers": ("groupId", groups),
            }.get(kind, ("", None))
            identifier = approver.get(key)
            if destination is None or not isinstance(identifier, str) or not identifier or approver.get("isBackup"):
                raise ValueError("unsupported-approver")
            destination.add(identifier.upper())
    result = copy.deepcopy(raw)
    for key in ("id", "roleDefinitionId", "tenantId"):
        if key in result:
            result[key] = _id(result[key])
    result.update(
        endUserAssignmentRequiresApproval=approval["isApprovalRequired"],
        endUserAssignmentRequiresCAPAuthenticationContext=authentication,
        endUserAssignmentRequiresMFA="MultiFactorAuthentication" in enabled,
        endUserAssignmentRequiresJustification="Justification" in enabled,
        endUserAssignmentRequiresTicketInformation="Ticketing" in enabled,
        endUserAssignmentUserApprovers=sorted(users),
        endUserAssignmentGroupApprovers=sorted(groups),
    )
    return result


def key_vault_records(raw):
    props = raw.get("properties")
    if not isinstance(props, dict):
        raise ValueError("missing-vault-properties")
    mode = props.get("enableRbacAuthorization", False)  # ARM default is false.
    if mode is True:
        return [], []
    if mode is not False:
        raise ValueError("invalid-vault-authorization-mode")
    policies = props.get("accessPolicies")
    if not isinstance(policies, list):
        raise ValueError("missing-vault-access-policies")
    vault_id = raw.get("id")
    if not isinstance(vault_id, str) or "/providers/microsoft.keyvault/vaults/" not in vault_id.lower():
        raise ValueError("invalid-vault-id")
    result, rejected = [], []
    for policy in policies:
        try:
            if not isinstance(policy, dict) or not isinstance(policy.get("objectId"), str) or not policy["objectId"]:
                raise ValueError("missing-policy-principal")
            if policy.get("applicationId"):
                raise ValueError("application-bound-access-policy")
            tenant = policy.get("tenantId")
            expected_tenant = props.get("tenantId") or raw.get("tenantId")
            if not isinstance(tenant, str) or not tenant or _id(tenant) != _id(expected_tenant):
                raise ValueError("access-policy-tenant-mismatch")
            permissions = policy.get("permissions")
            if not isinstance(permissions, dict):
                raise ValueError("missing-access-policy-permissions")
            normalized = {}
            for name in ("keys", "secrets", "certificates", "storage"):
                values = permissions.get(name, [])
                if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
                    raise ValueError("malformed-access-policy-permissions")
                # BloodHound 9.3 compares the literal "Get", although ARM returns "get".
                normalized[name] = ["Get" if v.lower() == "get" else v for v in values]
            result.append({"keyVaultId": vault_id.upper(), "objectId": policy["objectId"].upper(),
                           "tenantId": tenant.upper(), "permissions": normalized})
        except ValueError as exc:
            rejected.append({"id": policy.get("objectId", "") if isinstance(policy, dict) else "",
                             "reason": str(exc)})
    return result, rejected


def build_native_edge_records(parsed, now=None):
    """Produce native records and auditable exclusions from both collectors."""
    now = now or datetime.now(timezone.utc)
    output, excluded, seen = [], [], set()
    for document, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict):
                continue
            kind, raw = wrapper.get("kind"), wrapper.get("data")
            if kind not in {ELIGIBILITY, POLICY, "AZKeyVault"}:
                continue
            if not isinstance(raw, dict):
                excluded.append({"source": document.name, "kind": kind, "reason": "invalid-record"})
                continue
            try:
                if kind == ELIGIBILITY:
                    records = [("AZRoleEligibilityScheduleInstance", eligibility_record(raw, now))]
                elif kind == POLICY:
                    records = [("AZRoleManagementPolicyAssignment", policy_record(raw))]
                else:
                    rows, rejected = key_vault_records(raw)
                    records = [("AZKeyVaultAccessPolicy", row) for row in rows]
                    excluded.extend({"source": document.name, "kind": kind, **row} for row in rejected)
                for native_kind, row in records:
                    key = native_kind, json.dumps(row, sort_keys=True)
                    if key not in seen:
                        seen.add(key)
                        output.append({"kind": native_kind, "data": row})
            except (ValueError, TypeError) as exc:
                excluded.append({"source": document.name, "kind": kind,
                                 "id": raw.get("id", ""), "reason": str(exc)})
    return {"data": output, "meta": {"type": "azure", "version": 5, "count": len(output),
            "generator": "bark_native_edges.py", "bloodhoundVersion": "9.3.0",
            "azurehoundVersion": "3.1.0", "excludedRecords": excluded}}

def identity_index(parsed):
    result, conflicts = {}, set()
    for _, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for row in root["data"]:
            if not isinstance(row, dict) or row.get("kind") != "AZUserAssignedIdentity":
                continue
            raw = row.get("data")
            if not isinstance(raw, dict) or not isinstance(raw.get("id"), str):
                continue
            props = raw.get("properties")
            if not isinstance(props, dict) or not all(
                    isinstance(props.get(k), str) and props[k] for k in ("principalId", "clientId")):
                continue
            key = raw["id"].lower()
            normalized = {k: props[k].upper() for k in ("principalId", "clientId")}
            if key in result and result[key] != normalized:
                conflicts.add(key)
            result[key] = normalized
    for key in conflicts:
        result.pop(key, None)
    return result


def hydrate_managed_identities(record, identities):
    """Fill resource identity references using collected ARM identity objects."""
    raw = record.get("data", {})
    identity = raw.get("identity") if isinstance(raw, dict) else None
    attached = identity.get("userAssignedIdentities") if isinstance(identity, dict) else None
    if not isinstance(attached, dict):
        return record
    result = copy.deepcopy(record)
    for identifier, reference in result["data"]["identity"]["userAssignedIdentities"].items():
        resolved = identities.get(identifier.lower()) if isinstance(identifier, str) else None
        if not isinstance(reference, dict) or not resolved:
            continue
        if reference.get("principalId") and _id(reference["principalId"]) != _id(resolved["principalId"]):
            continue
        if reference.get("clientId") and _id(reference["clientId"]) != _id(resolved["clientId"]):
            continue
        reference["principalId"] = _id(resolved["principalId"])
        reference["clientId"] = _id(resolved["clientId"])
    return result
