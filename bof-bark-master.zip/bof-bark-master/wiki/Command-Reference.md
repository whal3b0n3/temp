# Command reference

[English](Command-Reference.md) | [日本語](ja/Command-Reference.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Commands

### Token scopes

| Token resource | BOFs that need it | Typical acquisition |
|---|---|---|
| `https://graph.microsoft.com/`         | `*_bh`, `get_entra_*`, `get_all_entra_*`, `get_intune_*`, `enable_entra_role`, `new_entra_*`, `set_entra_user_*`, `reset_entra_user_*`, `add_member_to_entra_group`, `get_tenant_information_bh`, `get_mg_app_roles`, `bark_get_entra_agents_opengraph` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://graph.microsoft.com`) |
| `https://management.azure.com/`        | `get_azurerm_*`, `get_all_azurerm_*`, `invoke_azurerm_*`, `new_azurerm_role_assignment`, `get_azure_function_*`, `get_azure_automation_*`, `new_azure_*`, `bark_get_azurerm_foundry_opengraph` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://management.azure.com`) |
| `https://api.powerplatform.com/`       | `bark_get_powerplatform_opengraph` | Power Platform API OAuth token for `api.powerplatform.com` |
| `https://storage.azure.com/`           | `bark_probe_storage_data_plane`, `bark_list_storage_containers`, `bark_list_storage_blobs`, `bark_download_storage_blob` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://storage.azure.com`) |
| `https://vault.azure.net/`             | `bark_probe_key_vault_data_plane`, `get_azurerm_key_vault_*` data-plane reads | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://vault.azure.net`) |
| `https://graph.windows.net/`           | `*_legacy_bh` (Azure AD Graph -- deprecated but still useful) | `bark_get_tokens_with_rt` with that resource |
| Portal delegation                      | `get_*_portal_rt`, `get_azure_portal_token_with_rt` | `bark_get_azure_portal_token_with_rt` |
| (none)                                 | `parse_jwt_token`, `new_nonce` | n/a |

Python equivalents and their options are listed in [Python token commands](Python-Tokens.md).

### Token Acquisition  (10 BOFs + unified loader aliases)

| Command | Args | Description |
|---|---|---|
| `bark_get_tokens_with_cc` | `tenantId` `clientId` `clientSecret` `resource` | Client credentials grant — get an access token for a resource URL; v2 scope is constructed internally (e.g. `https://graph.microsoft.com`, `https://management.azure.com`, `https://vault.azure.net`). |
| `bark_get_tokens_with_up` | `tenantId` `username` `password` `resource` `[clientId]` | Password grant (ROPC) — get an access token for a resource URL; v2 scope is constructed internally (e.g. `https://graph.microsoft.com`). Does not handle MFA or conditional access. When `clientId` is omitted, automatically tries 6 well-known client IDs (see [Client ID auto-detection](Authentication.md#authentication-with-client-id-auto-detection)). |
| `bark_get_tokens_with_rt` | `resource` `[clientId]` `refreshToken` `tenantId` | Exchange a refresh token for an access token against any resource (Graph, ARM, Storage, Key Vault, AAD Graph, etc.). When `clientId` is `""`, automatically tries 6 well-known client IDs (see [Client ID auto-detection](Authentication.md#authentication-with-client-id-auto-detection)). |
| `bark_get_tokens` | `rt\|up\|prt` plus resource, tenant, and credential | Unified entry point: `rt` uses a refresh token, `up` uses username/password, and `prt` uses a PRT cookie. The optional client ID is auto-detected. |
| `bark_get_tokens_for_arm` | `rt\|up\|prt` plus tenant and credential | Unified ARM token acquisition; the resource is fixed to `https://management.azure.com`. |
| `bark_get_tokens_for_msgraph` | `rt\|up\|prt` plus tenant and credential | Unified MS Graph token acquisition; the resource is fixed to `https://graph.microsoft.com`. |
| `bark_get_azure_portal_token_with_rt` | `tenantId` `refreshToken` | Supplies a refresh token to the STS, requesting an Azure Portal-scoped JWT |
| `bark_get_azurerm_token_with_portal_rt` | `tenantId` `portalAuthRefreshToken` `altPortalAuthRefreshToken` | Supplies a Portal Auth Refresh Token to the Azure Portal DelegationToken endpoint and requests an AzureRM-scoped JWT |
| `bark_get_azurerm_token_with_rt` | `tenantId` `refreshToken` | Supplies a refresh token to the STS, requesting an AzureRM-scoped JWT |
| `bark_get_entra_refresh_token_with_up` | `tenantId` `username` `password` `clientId` | Requests a JWT and refresh token from STS. This will not correctly handle conditional access prompts. |
| `bark_get_msgraph_token_with_portal_rt` | `tenantId` `portalAuthRefreshToken` `altPortalAuthRefreshToken` | Supplies a Portal Auth Refresh Token to the Azure Portal DelegationToken endpoint and requests an MS Graph-scoped JWT |
| `bark_get_msgraph_token_with_rt` | `tenantId` `refreshToken` | Supplies a refresh token to STS, requesting a token with MS Graph specified as the resource/intended resource |
| `bark_get_token_with_prt_cookie` | `prtToken` `resource` `tenantId` `[clientId]` `[redirectUri]` | Drive an interactive auth-code flow with an x-ms-RefreshTokenCredential PRT cookie and exchange the resulting authorization code for an access token. `redirectUri` defaults to `https://login.microsoftonline.com/common/oauth2/nativeclient`. When `clientId` is omitted, automatically tries 6 well-known client IDs (see [Client ID auto-detection](Authentication.md#authentication-with-client-id-auto-detection)). |
| `bark_new_nonce` | &mdash; | Creates a nonce from the Microsoft login endpoint. |

### Entra ID / MS Graph Read  (33 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_get_entra_agents_opengraph` | `graphToken` | Collects Entra Agent ID objects, ownership/control links, app-role assignments, delegated grants, directory roles, agent users, and service-principal mappings as a generic BloodHound OpenGraph JSON payload. Uses Graph control-plane reads only; it does not retrieve credentials, connection secrets, Key Vault data, or runtime data. |
| `bark_get_all_app_role_assignments_bh` | `token` | Retrieves user, group, and service-principal app-role assignments from every visible resource service principal. |
| `bark_get_all_entra_apps` | `token` | Retrieves all JSON-formatted Entra application registration objects using the MS Graph API |
| `bark_get_all_entra_apps_bh` | `token` | Retrieves all JSON-formatted Entra application registration objects using the MS Graph API |
| `bark_get_all_entra_groups` | `token` | Retrieves all JSON-formatted Entra groups objects using the MS Graph API |
| `bark_get_all_entra_roles` | `token` | Retrieves all active Entra ID admin roles |
| `bark_get_all_entra_roles_bh` | `token` | Retrieves all built-in and custom Entra directory role definitions, including definitions with no active assignment. |
| `bark_get_all_entra_service_principals` | `token` | Retrieves all JSON-formatted Entra service principal objects using the MS Graph API |
| `bark_get_all_entra_service_principals_bh` | `token` | Retrieves all JSON-formatted Entra service principal objects using the MS Graph API |
| `bark_get_all_entra_users` | `token` | Retrieves all JSON-formatted Entra users objects using the MS Graph API |
| `bark_get_all_role_assignments_bh` | `token` | Retrieves all active Entra ID role assignments |
| `bark_get_entra_app_owner` | `token` `appObjectId` | List the current owner(s) of an Entra App Registration |
| `bark_get_entra_app_owners_bh` | `token` `appObjectId` | List the current owner(s) of an Entra App Registration |
| `bark_get_entra_app_federated_identity_credentials` | `token` `appObjectId` | Get federated identity credentials of an app registration |
| `bark_get_entra_app_federated_identity_credentials_bh` | `token` `appObjectId` | Get federated identity credentials of an app registration (BH format) |
| `bark_get_entra_device_owners_bh` | `token` `deviceId` | Retrieves Entra device registered owners |
| `bark_get_entra_device_registered_users` | `token` `deviceId` | Get the JSON-formatted user(s) of a specified Entra device using the MS Graph API |
| `bark_get_entra_devices_bh` | `token` | Retrieves Entra device objects |
| `bark_get_entra_group_members` | `token` `groupId` | Get the list of members of an Entra group |
| `bark_get_entra_group_members_bh` | `token` `groupId` | Get the list of members of an Entra group |
| `bark_get_entra_group_owner` | `token` `groupId` | List the current owner(s) of an Entra Group |
| `bark_get_entra_group_owner_bh` | `token` `groupId` | List the current owner(s) of an Entra Group |
| `bark_get_entra_groups_bh` | `token` | Retrieves all JSON-formatted Entra groups objects using the MS Graph API |
| `bark_get_entra_role_templates` | `token` | Retrieves the available Entra ID admin role templates |
| `bark_get_entra_service_principal` | `token` `servicePrincipalId` | Retrieves the JSON-formatted Entra service principal objects specified by its object ID |
| `bark_get_entra_sp_owner` | `token` `servicePrincipalId` | List the current owner(s) of an Entra Service Principal |
| `bark_get_entra_sp_owners_bh` | `token` `servicePrincipalId` | List the current owner(s) of an Entra Service Principal |
| `bark_get_entra_users_bh` | `token` | Retrieves all JSON-formatted Entra users objects using the MS Graph API |
| `bark_get_intune_managed_devices` | `token` | Retrieves Intune-managed device objects |
| `bark_get_intune_role_definitions` | `token` | Retrieves the available Intune role definitions |
| `bark_get_mg_app_roles` | `token` `servicePrincipalId` | Finds the MS Graph Service Principal, then lists the available App Roles that can be scoped to Microsoft Graph |
| `bark_get_tenant_information_bh` | `token` | Gets tenant information by Tenant ID. |
| `bark_get_tenant_name_from_id` | `token` `tenantId` | Resolve a tenant GUID to its initial *.onmicrosoft.com domain via the unauthenticated /common/userrealm endpoint. |

### Power Platform Read  (1 BOF)

| Command | Args | Description |
|---|---|---|
| `bark_get_powerplatform_opengraph` | `powerPlatformToken` | Collects Power Platform environments, connections, Copilot Studio agents, cloud/agent/workflow flows, owners, Entra Agent ID mappings, connector-operation metadata, and defensible `AZAgent_CanInvoke`/`AZAgent_ActsAs` edges through the documented Power Platform inventory API, with a Cloud Flows fallback. It does not collect flow definitions/clientdata, run history, individual run-only principals, connection secrets, or credentials. |

### Azure Resource Manager Read  (74 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_get_azurerm_foundry_opengraph` | `token (ARM Bearer)` | Collects Foundry-capable Cognitive Services accounts, child projects, and account-scope Azure RBAC assignments as generic BloodHound OpenGraph JSON. It does not access Foundry data-plane content, keys, models, deployments, or secrets. |
| `bark_export_azurerm_deployment_template` | `token (ARM Bearer)` `deploymentPath` | Exports the ARM template for a named deployment. Pass the full ARM path starting with a slash, e.g. `/subscriptions/<subId>/resourcegroups/<rgName>/providers/Microsoft.Resources/deployments/<deploymentName>`. POSTs to the `/exportTemplate` action endpoint and returns the template JSON including parameters, variables, resources, and outputs. |
| `bark_get_all_azure_managed_identity_assignments` | `token (ARM Bearer)` `subscriptionId` | Scans all supported Azure resource types for managed identity assignments. Supported resource types |
| `bark_get_all_azurerm_acr` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure RM Container Registry objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_acr_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure RM Container Registry objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_aks_cluster_role_assignments_bh` | `token (ARM Bearer)` `aksClusterId (full ARM resource path)` | Retrieves all JSON-formatted Azure Kubernetes Service cluster role assignments across all subscriptions using the Azure management API |
| `bark_get_all_azurerm_aks_clusters` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure RM Azure Kubernetes Service cluster objects under a particular subscription |
| `bark_get_all_azurerm_aks_clusters_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure Kubernetes Service cluster objects under all subscriptions using the Azure management API, |
| `bark_get_all_azurerm_automation_account_role_assignments_bh` | `token (ARM Bearer)` `automationAccountId (full ARM resource path)` | Retrieves all JSON-formatted Azure RM Automation Account role assignments across all subscriptions using the Azure management API |
| `bark_get_all_azurerm_automation_accounts` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Automation Accounts under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_automation_accounts_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Automation Accounts under a particular subscription using the Azure management API |
| `bark_get_azurerm_automation_account_content` | `token (ARM Bearer)` `contentPath` | Fetches the raw content for a runbook or job. Pass the full ARM path including the terminal segment: `.../runbooks/<name>/content`, `.../jobs/<id>/output`, or `.../jobs/<id>/runbookContent`. API version: `2023-11-01`. |
| `bark_get_azurerm_automation_account_info` | `token (ARM Bearer)` `accountPath` `infoType` | Queries an automation account for one of four data types. `infoType`: `details` (account properties), `credentials` (stored credentials), `runbooks` (runbook list), `jobs` (job history). `accountPath` is the full ARM path to the automation account. |
| `bark_get_all_azurerm_container_app_role_assignments_bh` | `token` `containerAppId` | Retrieves role assignments for Container Apps across all subscriptions (BloodHound format) |
| `bark_get_all_azurerm_container_apps` | `token (ARM Bearer)` `subscriptionId` | Retrieves all Container Apps (`Microsoft.App/containerApps`) under a subscription |
| `bark_get_all_azurerm_container_apps_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all Container Apps under a subscription (BloodHound format). Auto-enumerates all subscriptions when `subscriptionId` is omitted. |
| `bark_get_azurerm_container_app_info` | `token (ARM Bearer)` `containerAppPath` `infoType` | Queries a Container App for secrets or exec auth. `infoType`: `secrets` (POST listSecrets — returns all secret names and values), `exec` (POST getAuthToken — returns auth token for websocket exec proxy). `containerAppPath` is the full ARM resource path. |
| `bark_get_all_azurerm_container_instance_role_assignments_bh` | `token` `containerGroupId` | Retrieves role assignments for Container Instances across all subscriptions (BloodHound format) |
| `bark_get_all_azurerm_container_instances` | `token (ARM Bearer)` `subscriptionId` | Retrieves all Container Instances (`Microsoft.ContainerInstance/containerGroups`) under a subscription |
| `bark_get_all_azurerm_container_instances_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all Container Instances under a subscription (BloodHound format). Auto-enumerates all subscriptions when `subscriptionId` is omitted. |
| `bark_get_azurerm_container_instance_info` | `token (ARM Bearer)` `containerGroupPath` `exec` `containerName` `[command]` | Executes a command in a Container Instance via the exec endpoint. Returns `webSocketUri` + `password` for interactive shell access. `command` defaults to `/bin/sh`. |
| `bark_get_all_azurerm_cosmos_db_role_assignments_bh` | `token (ARM Bearer)` `cosmosDbId (full ARM resource path)` | Retrieves all JSON-formatted Cosmos DB role assignments under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_cosmos_dbs` | `token (ARM Bearer)` `subscriptionId` `[resourceGroup]` | Retrieves all JSON-formatted Cosmos DB accounts under a subscription. When `resourceGroup` is provided, scopes the listing to that resource group only. |
| `bark_get_all_azurerm_cosmos_dbs_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Cosmos DB accounts under a subscription (BloodHound format) |
| `bark_get_azurerm_cosmos_db_info` | `token (ARM Bearer)` `cosmosDbPath` `infoType` | Queries a Cosmos DB account for details, keys, or restorable accounts. `infoType`: `details` (account properties including network rules, identity, and endpoints), `keys` (POST listKeys — access keys and connection strings), `restorable` (list restorable database accounts for the subscription). `cosmosDbPath` is the full ARM resource path. |
| `bark_get_all_azurerm_deployments` | `token (ARM Bearer)` `scope` | Lists ARM deployments (`Microsoft.Resources/deployments`) at any scope. Pass the URL path prefix as `scope`: `/subscriptions/<subId>/resourcegroups/<rgName>` (resource group), `/subscriptions/<subId>` (subscription), `/providers/Microsoft.Management/managementGroups/<groupId>` (management group), or `""` (tenant level). API version: `2025-04-01`. |
| `bark_get_all_azurerm_function_app_role_assignments_bh` | `token` `functionAppId` | Retrieves all JSON-formatted Azure RM Function App role assignments across all subscriptions using the Azure management API |
| `bark_get_all_azurerm_function_apps` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM Function App objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_function_apps_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM Function App objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_key_vault_role_assignments_bh` | `token` `keyVaultId` | Retrieves all JSON-formatted Key Vault role assignments under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_key_vaults` | `token` `subscriptionId` | Retrieves all JSON-formatted Key Vaults under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_key_vaults_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Key Vaults under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_logic_app_role_assignments_bh` | `token` `logicAppId` | Retrieves all JSON-formatted Azure RM Logic App role assignments across all subscriptions using the Azure management API |
| `bark_get_all_azurerm_logic_apps` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM Logic App objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_logic_apps_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM Logic App objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_management_group_descendants` | `token` `managementGroupId` | Lists descendants (child subscriptions and nested management groups) of a management group. Useful for discovering subscriptions when `/subscriptions` returns empty due to missing direct RBAC. |
| `bark_get_all_azurerm_management_groups` | `token` | Lists all Azure Management Groups the token has access to. Use with `bark_get_all_azurerm_management_group_descendants` to discover subscriptions via the management group hierarchy. |
| `bark_get_all_azurerm_resource_group_roles_bh` | `token` `subscriptionId` `resourceGroupName` | Retrieves all JSON-formatted Azure RM resource group objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_resource_groups` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM resource groups under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_resource_groups_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM resource groups under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_resource_role_assignments_bh` | `token` `[resourceId]` | Retrieves effective Azure RM role assignments at or above one ARM resource; when `resourceId` is omitted, enumerates every visible ARM resource. |
| `bark_get_all_azurerm_resources` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM resources under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_resources_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM resources under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_storage_account_role_assignments_bh` | `token` `storageAccountId` | Retrieves all JSON-formatted Azure RM storage account roles under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_storage_accounts` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM storage accounts under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_storage_accounts_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM storage accounts under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_subscription_role_assignments_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM subscription role assignment objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_subscriptions` | `token` | Retrieves all JSON-formatted Azure RM subscriptions using the Azure management API. Automatically falls back to management group hierarchy discovery when `/subscriptions` returns empty (see [Management group fallback](Discovery-and-Retries.md#management-group-fallback)). |
| `bark_get_all_azurerm_subscriptions_bh` | `token` | Retrieves all JSON-formatted Azure RM subscriptions using the Azure management API. Automatically falls back to management group hierarchy discovery when `/subscriptions` returns empty (see [Management group fallback](Discovery-and-Retries.md#management-group-fallback)). |
| `bark_get_all_azurerm_subscriptions_via_resource_graph` | `token` | Discovers subscriptions via Azure Resource Graph KQL query. Alternative to `/subscriptions` when direct RBAC is missing but Resource Graph access is available. |
| `bark_get_all_azurerm_vm_role_assignments_bh` | `token` `vmId` | Retrieves all JSON-formatted Azure RM virtual machine role assignments under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_vm_scale_sets` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure RM Virtual Machine Scale Set objects under a particular subscription |
| `bark_get_all_azurerm_vm_scale_sets_bh` | `token (ARM Bearer)` `subscriptionId` | Retrieves all JSON-formatted Azure RM Virtual Machine Scale Set objects under all subscriptions using the Azure management API, |
| `bark_get_all_azurerm_vm_scale_sets_vms` | `token (ARM Bearer)` `vmssId (full ARM path to scale set)` | Retrieves all JSON-formatted Virtual Machines under a specified Virtual Machine Scale Set |
| `bark_get_all_azurerm_vms` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM virtual machine objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_vms_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure RM virtual machine objects under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_web_app_role_assignments_bh` | `token` `webAppId` | Retrieves all JSON-formatted Azure App Service web app role assignments across all subscriptions using the Azure management API |
| `bark_get_all_azurerm_web_apps` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure App Service web apps under a particular subscription using the Azure management API |
| `bark_get_all_azurerm_web_apps_bh` | `token` `subscriptionId` | Retrieves all JSON-formatted Azure App Service web app objects under all subscriptions using the Azure management API, |
| `bark_get_azure_function_app_function_file` | `token` `functionId` | Retrieves the raw file (usually source code) of a function app function |
| `bark_get_azure_function_app_functions` | `token` `functionAppPath` | Retrieves all JSON-formatted Azure RM Function App functions under a particular function app |
| `bark_get_azure_function_app_master_keys` | `token` `functionAppPath` | Retrieves all JSON-formatted Azure RM Function App objects under a particular subscription using the Azure management API |
| `bark_get_azure_function_output` | `token` `functionUrl` | Retrieves the output of a specified Function App function |
| `bark_get_azurerm_key_vault_certificates` | `token (KV-scoped)` `keyVaultUrl` | Lists available key vault certificates from a specified key vault. Returns IDs of certificates but not the certificate itself. |
| `bark_get_azurerm_key_vault_certificates_revival` | `token (KV-scoped)` `keyVaultUrl` | This function lists deleted certificates from an Azure Key Vault and provides an option to recover a deleted certificate using its name. |
| `bark_get_azurerm_key_vault_key_versions` | `token (KV-scoped)` `secretId` | Gets all versions of a specified Key Vault key. |
| `bark_get_azurerm_key_vault_keys` | `token (KV-scoped)` `keyVaultUrl` | Lists available key vault keys from a specified key vault. Returns IDs of keys but not the key itself. |
| `bark_get_azurerm_key_vault_secret` | `token (KV-scoped)` `vaultName` `secretName` | Gets a Key Vault secret by vault name and secret name. Equivalent to `az keyvault secret show --vault-name <name> --name <secret>`. |
| `bark_get_azurerm_key_vault_secret_value` | `token (KV-scoped)` `secretId` | Gets the value of a specific Key Vault secret by its full secret ID URL. |
| `bark_get_azurerm_key_vault_secret_versions` | `token (KV-scoped)` `secretId` | Gets all versions of a specified Key Vault secret. You can retrieve historical secrets |
| `bark_get_azurerm_key_vault_secrets` | `token (KV-scoped)` `keyVaultUrl` | Lists available key vault secrets from a specified key vault. Returns IDs of secrets but not the secret itself. |
| `bark_get_azurerm_role_assignments` | `token` `targetObjectId` | Lists all AzureRM role assignments against a specified object |
| `bark_get_azurerm_role_definitions` | `token` `subscriptionId` | Collects all roles available in AzureRM at the subscription object level |
| `bark_get_azurerm_role_definitions_bh` | `token` `subscriptionId` | Collects all roles available in AzureRM at the subscription object level |
| `bark_get_azurerm_web_app` | `token` `webAppId` | Retrieves the specified JSON-formatted Azure App Service web app |

### Write / Modification  (14 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_add_member_to_entra_group` | `token` `principalId` `targetGroupId` | Attempts to add a principal to an existing Entra security group |
| `bark_enable_entra_role` | `token (Graph Bearer)` `roleId (roleTemplateId)` | Enables (or "activates") the Entra role by its provided ID |
| `bark_new_azure_key_vault_access_policy` | `token` `principalId` `tenantId` `targetObjectId` | Grant a principal the "Get" and "List" permissions across secrets, keys, and certificates on a particular key vault. |
| `bark_new_azurerm_role_assignment` | `token` `principalId` `azureRMRoleId` `subscriptionId` | Grants an AzureRM role assignment to an existing Entra principal. You must wait at least 2 minutes before using the role assignment: https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli#known-limits-and-performance |
| `bark_new_entra_app_owner` | `token` `appObjectId` `ownerObjectId` | Attempts to add a new owner to an Entra App Registration using the MS Graph API |
| `bark_new_entra_app_role_assignment` | `token` `principalId` `resourceId` `appRoleId` | Grants an App Role assignment to an existing Entra Service Principal |
| `bark_new_entra_app_secret` | `token` `appRegObjectId` | Creates a new secret for an Entra App Registration which can then be used to authenticate to Azure services as the associated Service Principal |
| `bark_new_entra_group_owner` | `token` `groupId` `ownerObjectId` | Attempts to add a new owner to an Entra Group using the MS Graph API |
| `bark_new_entra_role_assignment` | `token` `principalId` `roleDefinitionId` | Assigns an Entra admin role to a specified principal by its object id |
| `bark_new_entra_sp_owner` | `token` `servicePrincipalId` `ownerObjectId` | Attempts to add a new owner to an Entra Service Principal using the MS Graph API |
| `bark_new_entra_sp_secret` | `token` `servicePrincipalId [` `secretDisplayName]` | Creates a new secret for an Entra Service Principal which can then be used to authenticate to Azure services as the Service Principal |
| `bark_reset_entra_user_password` | `token (portal-scoped)` `targetUpn` | Attempts to reset an Entra user password. If successful, returns the new temporary password for the user. |
| `bark_set_entra_user_attribute` | `token` `userId` `attributeName` `attributeValue` | Updates a single writable attribute on an Entra user via the MS Graph |
| `bark_set_entra_user_password` | `token` `targetUserId` `newPassword` | Attempts to set an Entra user password to a provided value |

### Invoke / Execution  (8 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_get_azure_automation_account_runbook_output` | `token` `automationAccountPath` `runbookName` | Run an existing Automation Account runbook and retrieve its output |
| `bark_invoke_azure_vm_scaleset_run_command` | `token` `vmssVmId` `script` | Executes a command on the specified VM Scale Set Virtual Machine via its /runCommand endpoint |
| `bark_invoke_azurerm_aks_run_command` | `token` `aksClusterId` `command` | When you submit a command to the AKS /runCommand endpoint, the cluster will spin up |
| `bark_invoke_azurerm_vm_run_command` | `token` `targetVmId` `script` | Attempts to run a SYSTEM command on an Azure Virtual Machine via the runCommand endpoint |
| `bark_invoke_azurerm_web_app_shell_command` | `token` `webAppName` `command` | This function takes a provided JWT or Base64-encoded authentication string, then uses those to authenticate to a provided |
| `bark_new_azure_automation_account_runbook` | `token` `automationAccountPath` `runbookName` `script` | Add a runbook to an existing Automation Account |
| `bark_new_ps_function_app_function` | `token` `pathToFunctionApp` `functionName` `powerShellScript` | Create a new function in an existing Function App |
| `bark_start_azurerm_automation_account_runbook` | `token (ARM Bearer)` `accountPath` `runbookName` `hybridGroup` | Starts a published runbook as a real (non-test) job via a PUT to `{accountPath}/jobs/{guid}`. Pass `""` for `hybridGroup` to run in the cloud. Job GUID is timestamp-derived. |

### Legacy AAD Graph BH  (14 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_get_all_app_role_assignments_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `servicePrincipalId` | Retrieves all JSON-formatted app role assignment objects across all service principals using the AAD Graph API |
| `bark_get_all_entra_apps_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra application objects using the AAD Graph API |
| `bark_get_all_entra_roles_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra directory role objects using the AAD Graph API |
| `bark_get_all_entra_service_principals_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra service principal objects using the AAD Graph API |
| `bark_get_all_role_assignments_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra role assignment objects using the AAD Graph API |
| `bark_get_entra_app_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `appObjectId` | Retrieves all JSON-formatted owner objects for Entra applications using the AAD Graph API by iterating through all applications |
| `bark_get_entra_device_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `deviceId` | Retrieves all JSON-formatted registered owner objects for Entra devices using the AAD Graph API by iterating through all devices |
| `bark_get_entra_devices_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra device objects using the AAD Graph API |
| `bark_get_entra_group_members_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `groupId` | Retrieves all JSON-formatted Entra group member objects using the AAD Graph API by iterating through all groups |
| `bark_get_entra_group_owner_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `groupId` | Retrieves all JSON-formatted Entra group owner objects using the AAD Graph API by iterating through all groups |
| `bark_get_entra_groups_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra group objects using the AAD Graph API |
| `bark_get_entra_sp_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `servicePrincipalId` | Retrieves all JSON-formatted owner objects for Entra service principals using the AAD Graph API by iterating through all service principals |
| `bark_get_entra_users_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Retrieves all JSON-formatted Entra users objects using the AAD Graph API |
| `bark_get_tenant_information_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | Gets tenant information by Tenant ID. |

### Conditional Access Policy Analysis  (1 BOF)

| Command | Args | Description |
|---|---|---|
| `bark_get_conditional_access_policies` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `[tenantId]` | Enumerates Conditional Access Policies via the legacy AAD Graph internal API, identifies MFA/Block bypass opportunities, and writes a BloodHound graph JSON file. See [Conditional Access Policy analysis](Conditional-Access.md#conditional-access-policy-analysis) for details. |

### Utility  (3 BOFs)

| Command | Args | Description |
|---|---|---|
| `bark_convert_az_role_assignments_to_graph_bh` | `[pattern]` | Reads role assignment BH JSON files (or in-memory blob when download mode is on) and produces a BloodHound graph with nodes and edges. See [Diskless graph conversion](Downloads-and-Archives.md#diskless-graph-conversion). |
| `bark_parse_jwt_token` | `token (the JWT string to decode — this IS the target` `not a bearer for auth)` | Decodes a JWT token. |
| `bark_zip_collect` | `password` `[pattern]` | _no synopsis in BARKKAI.ps1_ |
