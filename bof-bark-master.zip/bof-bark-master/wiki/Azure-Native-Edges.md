# Azure native edge implementation and validation

[English](Azure-Native-Edges.md) | [日本語](ja/Azure-Native-Edges.md)

[Wiki home](Home.md) | [Coverage plan](Azure-Edge-Coverage-Plan.md) | [Operator workflow](../README.md)

## Implemented fixes

Python and the modern Graph BOF workflows now collect Entra PIM eligibility and role-management policy assignments. Policy rules are fetched separately when the expanded response is missing or paginated. The BOF role collector and core/parallel collectors include this work; legacy AAD Graph cannot provide these endpoints.

Key Vault collection fetches the individual vault when the list response lacks access policies. Both collectors preserve incomplete status if access is denied. User-assigned managed identities are also inventoried through ARM; their principal/client IDs fill missing references in resource records during bundle creation.

Run the existing collection and bundle commands. No new command arguments or upload phase are required. Python all-info bundles automatically; Beacon downloads use the current offline converter:

~~~bash
python3 bark_role_graph.py ./downloads --bundle-output ./bloodhound-upload
python3 bark_upload.py ./bloodhound-upload --dry-run
~~~

A denied PIM request means incomplete coverage, even when ordinary user/group collection succeeds. Review collection failures and the API permissions for [eligibility](https://learn.microsoft.com/en-us/graph/api/rbacapplication-list-roleeligibilityscheduleinstances?view=graph-rest-1.0) and [policy assignments](https://learn.microsoft.com/en-us/graph/api/policyroot-list-rolemanagementpolicyassignments?view=graph-rest-1.0). Existing snapshots can be converted again, but missing API evidence requires collection with the updated Python or BOF binaries.

## Native conversion

The shared converter is [bark_native_edges.py](../bark_native_edges.py). It runs during bundle creation for both Python and BOF snapshots.

| Collected evidence | Native record | Result in BloodHound |
| --- | --- | --- |
| AZEntraRoleEligibilityScheduleInstance | AZRoleEligibilityScheduleInstance | AZRoleEligible to an Entra role |
| AZEntraRoleManagementPolicyAssignment plus rules | AZRoleManagementPolicyAssignment | AZRoleApprover and role activation properties |
| AZKeyVault.properties.accessPolicies | AZKeyVaultAccessPolicy | AZGetSecrets, AZGetKeys, AZGetCertificates |
| AZUserAssignedIdentity plus resource identity references | Enriched resource records, such as AZVM | AZManagedIdentity to the service principal |

Entra eligibility and policy evidence use distinct raw kind names so they cannot be mistaken for ARM PIM or uploaded before conversion. Valid records are merged into 01-upload-native/azurehound_bark.json. AZNativeEdgeCoverage.json is a generated source/audit document under do-not-upload (in native-source when merged), not a separate upload step. BARK_UPLOAD_MANIFEST.json includes nativeEdgeConversion.records and excludedRecords with reasons.

Eligibility conversion requires a current, tenant-root directory assignment. Future, expired, app-scoped and administrative-unit-scoped records are retained as evidence but excluded from native conversion. Eligibility never becomes active AZHasRole membership.

Policy conversion uses the EndUser/Assignment approval, enablement and authentication-context rules. It separates single-user and group approvers and preserves MFA, justification, ticket and authentication-context requirements. Missing rules, unsupported approver types, escalation and multiple stages are excluded instead of being interpreted as approval-free activation. A valid single stage with an empty primary-approver list retains BloodHound's default Privileged Role Administrator fallback.

Key Vault access policies apply only when RBAC authorization is disabled. The converter normalizes ARM's lower-case get to the Get literal required by BloodHound 9.3. Application-bound policies and tenant mismatches are excluded because a direct principal-to-vault edge cannot represent those restrictions. These records do not claim RBAC data-action coverage or bypass network restrictions.

Managed-identity hydration fills only missing, consistent references. Conflicting inventory mappings are ignored, and source snapshots are unchanged. This describes an existing identity attachment; it is separate from permission to assign an identity.

The uploader now stops before OpenGraph when native ingestion reports failed_files or partial_failed_files, including jobs whose top-level status is Complete. Native node names, kinds and identity properties remain intact; BloodHound may advance collection timestamps.

## Validation scope

The compatibility contract is pinned to [AzureHound v3.1.0](https://github.com/SpecterOps/AzureHound/tree/v3.1.0) (23735c8af6b03a677a3c40e8d274316504ea07ab) and [BloodHound v9.3.0](https://github.com/SpecterOps/BloodHound/tree/v9.3.0) (1fe5e1d310087317f136c88c26bc2f153bff1bf6). Native conversion and graph post-processing belong to BloodHound; BARK does not recreate all of that analysis.

Offline regression tests cover Python collection/conversion, actual BOF C collector logic with HTTP/Beacon stubs, pagination and partial responses. The disposable BloodHound fixture checks seven expected edge triples across six edge kinds, then adds BARK application-role edges and checks native user properties. This is fixture validation, not a live-tenant or live-Beacon execution claim.

~~~bash
python3 -m unittest discover -s tests -q
~~~

The optional tests/test_native_import_integration.py requires BARK_TEST_BH_URL and BARK_TEST_BH_TOKEN for an empty disposable BloodHound instance. It refuses existing Azure nodes and leaves its synthetic graph in place. Keep the session token out of shell history; the ordinary test suite skips this integration unless explicitly configured.

## Edge coverage inventory

The table covers the 47 Azure/Entra names in the [edge overview](https://bloodhound.specterops.io/resources/edges/overview), reviewed on 2026-09-25. Verified means the specific synthetic case above, not every source/target combination or every permission path. Unverified is an explicit test gap, not proof that collection is missing.

| Edge | Status and evidence |
| --- | --- |
| AZAddMembers | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAddOwner | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAddSecret | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAKSContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAppAdmin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAuthenticatesTo | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAutomationContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZAvereContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZCloudAppAdmin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZContains | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZExecuteCommand | Gap: Intune execution is not covered by the BARK VM Run Command rule. |
| AZGetCertificates | Verified: user access-policy Get permission; RBAC/application-bound policies excluded by converter tests. |
| AZGetKeys | Verified: user access-policy Get permission; RBAC/application-bound policies excluded by converter tests. |
| AZGetSecrets | Verified: user access-policy Get permission; RBAC/application-bound policies excluded by converter tests. |
| AZGlobalAdmin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZHasRole | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZKeyVaultKVContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZLogicAppContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZManagedIdentity | Verified: VM reference hydrated from user-assigned identity inventory; other resource variants unverified. |
| AZMemberOf | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGAddMember | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGAddOwner | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGAddSecret | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGAppRoleAssignment_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGApplication_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGDirectory_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGGrantAppRoles | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGGrantRole | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGGroupMember_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGGroup_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGRoleManagement_ReadWrite_Directory | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZMGServicePrincipalEndpoint_ReadWrite_All | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZNodeResourceGroup | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZOwner | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZOwns | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZPrivilegedAuthAdmin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZPrivilegedRoleAdmin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZResetPassword | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZRoleApprover | Verified: direct user and group approvers; activation properties. |
| AZRoleEligible | Verified: current root-scope user eligibility; expired group eligibility excluded. |
| AZRunsAs | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZScopedTo | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZUserAccessAdministrator | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZVMAdminLogin | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZVMContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
| AZWebsiteContributor | Unverified: upstream edge/post-processing fixture comparison remains pending. |
