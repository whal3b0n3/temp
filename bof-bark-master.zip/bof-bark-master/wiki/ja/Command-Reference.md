# コマンド一覧

[English](../Command-Reference.md) | [日本語](Command-Reference.md)

[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## コマンド

### トークンの resource

| token resource | 使用する BOF | 主な取得方法 |
|---|---|---|
| `https://graph.microsoft.com/`         | `*_bh`, `get_entra_*`, `get_all_entra_*`, `get_intune_*`, `enable_entra_role`, `new_entra_*`, `set_entra_user_*`, `reset_entra_user_*`, `add_member_to_entra_group`, `get_tenant_information_bh`, `get_mg_app_roles`, `bark_get_entra_agents_opengraph` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://graph.microsoft.com`) |
| `https://management.azure.com/`        | `get_azurerm_*`, `get_all_azurerm_*`, `invoke_azurerm_*`, `new_azurerm_role_assignment`, `get_azure_function_*`, `get_azure_automation_*`, `new_azure_*`, `bark_get_azurerm_foundry_opengraph` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://management.azure.com`) |
| `https://api.powerplatform.com/`       | `bark_get_powerplatform_opengraph` | Power Platform API 用 OAuth token： `api.powerplatform.com` |
| `https://storage.azure.com/`           | `bark_probe_storage_data_plane`, `bark_list_storage_containers`, `bark_list_storage_blobs`, `bark_download_storage_blob` | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://storage.azure.com`) |
| `https://vault.azure.net/`             | `bark_probe_key_vault_data_plane`, `get_azurerm_key_vault_*` データプレーン読み取り | `bark_get_tokens_with_cc` / `bark_get_tokens_with_up` (resource: `https://vault.azure.net`) |
| `https://graph.windows.net/`           | `*_legacy_bh` (Azure AD Graph、非推奨の legacy API) | `bark_get_tokens_with_rt` に該当 resource を指定 |
| Portal 委任                      | `get_*_portal_rt`, `get_azure_portal_token_with_rt` | `bark_get_azure_portal_token_with_rt` |
| （不要）                                 | `parse_jwt_token`, `new_nonce` | n/a |

Python 版のコマンドとオプションは [Python トークンコマンド](Python-Tokens.md)を参照してください。

### トークン取得（10 BOF と統合 alias）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_tokens_with_cc` | `tenantId` `clientId` `clientSecret` `resource` | クライアント資格情報でリソース URL 用の access token を取得。v2 scope は内部生成します。 |
| `bark_get_tokens_with_up` | `tenantId` `username` `password` `resource` `[clientId]` | ユーザー名とパスワードによる ROPC。resource URL から v2 scope を生成します。MFA／条件付きアクセスの追加認証には対応せず、clientId 省略時は6種類の候補を試します。 |
| `bark_get_tokens_with_rt` | `resource` `[clientId]` `refreshToken` `tenantId` | refresh token を指定 resource 用の access token に交換。clientId が空文字の場合は6種類の候補を試します。 |
| `bark_get_tokens` | `rt\|up\|prt` plus resource, tenant, and credential | rt は refresh token、up はユーザー名／パスワード、prt は PRT cookie を使う統一入口。client ID は自動選択可能です。 |
| `bark_get_tokens_for_arm` | `rt\|up\|prt` plus tenant and credential | ARM 用の統一認証。resource は https://management.azure.com に固定します。 |
| `bark_get_tokens_for_msgraph` | `rt\|up\|prt` plus tenant and credential | MS Graph 用の統一認証。resource は https://graph.microsoft.com に固定します。 |
| `bark_get_azure_portal_token_with_rt` | `tenantId` `refreshToken` | refresh token を STS に渡し、Azure Portal 用 JWT を取得します。 |
| `bark_get_azurerm_token_with_portal_rt` | `tenantId` `portalAuthRefreshToken` `altPortalAuthRefreshToken` | Portal Auth Refresh Token を Azure Portal DelegationToken endpoint に渡し、AzureRM 用 JWT を取得します。 |
| `bark_get_azurerm_token_with_rt` | `tenantId` `refreshToken` | refresh token を STS に渡し、AzureRM 用 JWT を取得します。 |
| `bark_get_entra_refresh_token_with_up` | `tenantId` `username` `password` `clientId` | STS から JWT と refresh token を取得。条件付きアクセスの追加認証には対応しません。 |
| `bark_get_msgraph_token_with_portal_rt` | `tenantId` `portalAuthRefreshToken` `altPortalAuthRefreshToken` | Portal Auth Refresh Token を Azure Portal DelegationToken endpoint に渡し、MS Graph 用 JWT を取得します。 |
| `bark_get_msgraph_token_with_rt` | `tenantId` `refreshToken` | refresh token を STS に渡し、MS Graph 用 token を取得します。 |
| `bark_get_token_with_prt_cookie` | `prtToken` `resource` `tenantId` `[clientId]` `[redirectUri]` | x-ms-RefreshTokenCredential PRT cookie を使用した認可コードフローで token を取得。redirectUri の既定は https://login.microsoftonline.com/common/oauth2/nativeclient。clientId 省略時は6種類の候補を試します。 |
| `bark_new_nonce` | &mdash; | Microsoft の login endpoint から nonce を取得します。 |

### Entra ID / MS Graph の読み取り（33 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_entra_agents_opengraph` | `graphToken` | Entra Agent ID、所有／制御関係、アプリロール、委任 grant、ディレクトリロール、agent user、SP 対応を OpenGraph に出力。Graph の管理情報のみを読み、資格情報・接続シークレット・Key Vault データ・実行時データは取得しません。 |
| `bark_get_all_app_role_assignments_bh` | `token` | 参照可能な全リソース SP からユーザー・グループ・SP のアプリロール割り当てを取得します。 |
| `bark_get_all_entra_apps` | `token` | MS Graph から Entra アプリ登録を JSON で取得します。 |
| `bark_get_all_entra_apps_bh` | `token` | MS Graph から Entra アプリ登録を JSON で取得します。 |
| `bark_get_all_entra_groups` | `token` | MS Graph から Entra グループを JSON で取得します。 |
| `bark_get_all_entra_roles` | `token` | 有効な Entra ID 管理ロールを取得します。 |
| `bark_get_all_entra_roles_bh` | `token` | 有効な割り当てがない定義も含め、組み込み／カスタムの Entra ディレクトリロール定義を取得します。 |
| `bark_get_all_entra_service_principals` | `token` | MS Graph から Entra サービスプリンシパルを JSON で取得します。 |
| `bark_get_all_entra_service_principals_bh` | `token` | MS Graph から Entra サービスプリンシパルを JSON で取得します。 |
| `bark_get_all_entra_users` | `token` | MS Graph から Entra ユーザーを JSON で取得します。 |
| `bark_get_all_role_assignments_bh` | `token` | 有効な Entra ID ロール割り当てを取得します。 |
| `bark_get_entra_app_owner` | `token` `appObjectId` | アプリ登録の現在の所有者を取得します。 |
| `bark_get_entra_app_owners_bh` | `token` `appObjectId` | アプリ登録の現在の所有者を BH 形式で取得します。 |
| `bark_get_entra_app_federated_identity_credentials` | `token` `appObjectId` | アプリ登録の federated identity credentials を取得します。 |
| `bark_get_entra_app_federated_identity_credentials_bh` | `token` `appObjectId` | アプリ登録の federated identity credentials を取得します。 |
| `bark_get_entra_device_owners_bh` | `token` `deviceId` | Entra デバイスの登録所有者を取得します。 |
| `bark_get_entra_device_registered_users` | `token` `deviceId` | 指定 Entra デバイスの登録ユーザーを MS Graph から JSON で取得します。 |
| `bark_get_entra_devices_bh` | `token` | Entra デバイスを取得します。 |
| `bark_get_entra_group_members` | `token` `groupId` | Entra グループのメンバーを取得します。 |
| `bark_get_entra_group_members_bh` | `token` `groupId` | Entra グループのメンバーを取得します。 |
| `bark_get_entra_group_owner` | `token` `groupId` | Entra グループの現在の所有者を取得します。 |
| `bark_get_entra_group_owner_bh` | `token` `groupId` | Entra グループの現在の所有者を取得します。 |
| `bark_get_entra_groups_bh` | `token` | MS Graph から Entra グループを JSON で取得します。 |
| `bark_get_entra_role_templates` | `token` | 利用可能な Entra ID 管理ロールのテンプレートを取得します。 |
| `bark_get_entra_service_principal` | `token` `servicePrincipalId` | 指定 object ID の Entra サービスプリンシパルを JSON で取得します。 |
| `bark_get_entra_sp_owner` | `token` `servicePrincipalId` | Entra サービスプリンシパルの現在の所有者を取得します。 |
| `bark_get_entra_sp_owners_bh` | `token` `servicePrincipalId` | Entra サービスプリンシパルの現在の所有者を BH 形式で取得します。 |
| `bark_get_entra_users_bh` | `token` | MS Graph から Entra ユーザーを JSON で取得します。 |
| `bark_get_intune_managed_devices` | `token` | Intune 管理対象デバイスを取得します。 |
| `bark_get_intune_role_definitions` | `token` | 利用可能な Intune ロール定義を取得します。 |
| `bark_get_mg_app_roles` | `token` `servicePrincipalId` | MS Graph の SP を検索し、Microsoft Graph を対象とするアプリロールを列挙します。 |
| `bark_get_tenant_information_bh` | `token` | テナント情報を取得します。 |
| `bark_get_tenant_name_from_id` | `token` `tenantId` | 認証不要の /common/userrealm endpoint でテナント GUID を初期 *.onmicrosoft.com ドメインに解決します。 |

### Power Platform の読み取り（1 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_powerplatform_opengraph` | `powerPlatformToken` | Power Platform の環境・接続・Copilot Studio agent・flow・所有者・Entra Agent ID 対応・connector 操作情報と、根拠のある AZAgent_CanInvoke／AZAgent_ActsAs を収集。inventory API と Cloud Flows fallback を使用。flow 定義／clientdata、実行履歴、個別 run-only principal、接続シークレット、資格情報は収集しません。 |

### Azure Resource Manager の読み取り（74 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_azurerm_foundry_opengraph` | `token (ARM Bearer)` | Foundry 対応 Cognitive Services アカウント、子プロジェクト、アカウントスコープ RBAC を OpenGraph に出力。データプレーンの内容・キー・モデル・deployment・secret は取得しません。 |
| `bark_export_azurerm_deployment_template` | `token (ARM Bearer)` `deploymentPath` | 指定 deployment の完全 ARM パスに対して /exportTemplate を POST し、parameters・variables・resources・outputs を含むテンプレートを取得します。 |
| `bark_get_all_azure_managed_identity_assignments` | `token (ARM Bearer)` `subscriptionId` | 対応する Azure リソース種類を走査し、Managed Identity の割り当てを取得します。 |
| `bark_get_all_azurerm_acr` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Container Registry を JSON で取得します。 |
| `bark_get_all_azurerm_acr_bh` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Container Registry を JSON で取得します。 |
| `bark_get_all_azurerm_aks_cluster_role_assignments_bh` | `token (ARM Bearer)` `aksClusterId (full ARM resource path)` | AKS クラスターのロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_aks_clusters` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの AKS クラスターを JSON で取得します。 |
| `bark_get_all_azurerm_aks_clusters_bh` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの AKS クラスターを JSON で取得します。 |
| `bark_get_all_azurerm_automation_account_role_assignments_bh` | `token (ARM Bearer)` `automationAccountId (full ARM resource path)` | Automation Account のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_automation_accounts` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Automation Account を JSON で取得します。 |
| `bark_get_all_azurerm_automation_accounts_bh` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Automation Account を JSON で取得します。 |
| `bark_get_azurerm_automation_account_content` | `token (ARM Bearer)` `contentPath` | 完全 ARM パスの runbooks/<name>/content、jobs/<id>/output、jobs/<id>/runbookContent から内容を取得。API version は 2023-11-01 です。 |
| `bark_get_azurerm_automation_account_info` | `token (ARM Bearer)` `accountPath` `infoType` | Automation Account の details（属性）、credentials（保存資格情報）、runbooks（一覧）、jobs（履歴）を取得。accountPath は完全 ARM パスです。 |
| `bark_get_all_azurerm_container_app_role_assignments_bh` | `token` `containerAppId` | Container Apps のロール割り当てを BH 形式で取得します。 |
| `bark_get_all_azurerm_container_apps` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Microsoft.App/containerApps を取得します。 |
| `bark_get_all_azurerm_container_apps_bh` | `token (ARM Bearer)` `subscriptionId` | Container Apps を BH 形式で取得。subscriptionId 省略時は全サブスクリプションを列挙します。 |
| `bark_get_azurerm_container_app_info` | `token (ARM Bearer)` `containerAppPath` `infoType` | 完全 ARM パスの Container App に対し、secrets は POST listSecrets で名前と値、exec は POST getAuthToken で websocket exec proxy 用 token を取得します。 |
| `bark_get_all_azurerm_container_instance_role_assignments_bh` | `token` `containerGroupId` | Container Instances のロール割り当てを BH 形式で取得します。 |
| `bark_get_all_azurerm_container_instances` | `token (ARM Bearer)` `subscriptionId` | 指定サブスクリプションの Microsoft.ContainerInstance/containerGroups を取得します。 |
| `bark_get_all_azurerm_container_instances_bh` | `token (ARM Bearer)` `subscriptionId` | Container Instances を BH 形式で取得。subscriptionId 省略時は全サブスクリプションを列挙します。 |
| `bark_get_azurerm_container_instance_info` | `token (ARM Bearer)` `containerGroupPath` `exec` `containerName` `[command]` | Container Instance の exec endpoint を呼び、対話接続用 webSocketUri と password を取得。command の既定は /bin/sh です。 |
| `bark_get_all_azurerm_cosmos_db_role_assignments_bh` | `token (ARM Bearer)` `cosmosDbId (full ARM resource path)` | Cosmos DB のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_cosmos_dbs` | `token (ARM Bearer)` `subscriptionId` `[resourceGroup]` | サブスクリプション内の Cosmos DB アカウントを JSON で取得。resourceGroup 指定時は対象 RG に限定します。 |
| `bark_get_all_azurerm_cosmos_dbs_bh` | `token (ARM Bearer)` `subscriptionId` | サブスクリプション内の Cosmos DB アカウントを BH 形式で取得します。 |
| `bark_get_azurerm_cosmos_db_info` | `token (ARM Bearer)` `cosmosDbPath` `infoType` | Cosmos DB の details（ネットワーク規則・ID・endpoint を含む属性）、keys（POST listKeys によるキーと接続文字列）、restorable（復元可能アカウント）を取得します。 |
| `bark_get_all_azurerm_deployments` | `token (ARM Bearer)` `scope` | scope に RG／subscription／management group の ARM パス、またはテナント用の空文字を指定し、deployment を列挙。API version は 2025-04-01 です。 |
| `bark_get_all_azurerm_function_app_role_assignments_bh` | `token` `functionAppId` | Function App のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_function_apps` | `token` `subscriptionId` | 指定サブスクリプションの Function App を JSON で取得します。 |
| `bark_get_all_azurerm_function_apps_bh` | `token` `subscriptionId` | 指定サブスクリプションの Function App を JSON で取得します。 |
| `bark_get_all_azurerm_key_vault_role_assignments_bh` | `token` `keyVaultId` | Key Vault のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_key_vaults` | `token` `subscriptionId` | 指定サブスクリプションの Key Vault を JSON で取得します。 |
| `bark_get_all_azurerm_key_vaults_bh` | `token` `subscriptionId` | 指定サブスクリプションの Key Vault を JSON で取得します。 |
| `bark_get_all_azurerm_logic_app_role_assignments_bh` | `token` `logicAppId` | Logic App のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_logic_apps` | `token` `subscriptionId` | 指定サブスクリプションの Logic App を JSON で取得します。 |
| `bark_get_all_azurerm_logic_apps_bh` | `token` `subscriptionId` | 指定サブスクリプションの Logic App を JSON で取得します。 |
| `bark_get_all_azurerm_management_group_descendants` | `token` `managementGroupId` | 管理グループの子サブスクリプションと入れ子の管理グループを列挙。直接 RBAC がなく /subscriptions が空の場合の探索に使用します。 |
| `bark_get_all_azurerm_management_groups` | `token` | token で参照可能な管理グループを列挙。descendants と組み合わせてサブスクリプションを探索します。 |
| `bark_get_all_azurerm_resource_group_roles_bh` | `token` `subscriptionId` `resourceGroupName` | リソースグループのロール情報を BH 形式で取得します。 |
| `bark_get_all_azurerm_resource_groups` | `token` `subscriptionId` | 指定サブスクリプションのリソースグループを JSON で取得します。 |
| `bark_get_all_azurerm_resource_groups_bh` | `token` `subscriptionId` | 指定サブスクリプションのリソースグループを JSON で取得します。 |
| `bark_get_all_azurerm_resource_role_assignments_bh` | `token` `[resourceId]` | 指定 ARM リソースまたは上位スコープの有効なロール割り当てを取得。resourceId 省略時は参照可能な全リソースを列挙します。 |
| `bark_get_all_azurerm_resources` | `token` `subscriptionId` | 指定サブスクリプションの Azure リソースを JSON で取得します。 |
| `bark_get_all_azurerm_resources_bh` | `token` `subscriptionId` | 指定サブスクリプションの Azure リソースを JSON で取得します。 |
| `bark_get_all_azurerm_storage_account_role_assignments_bh` | `token` `storageAccountId` | Storage Account のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_storage_accounts` | `token` `subscriptionId` | 指定サブスクリプションの Storage Account を JSON で取得します。 |
| `bark_get_all_azurerm_storage_accounts_bh` | `token` `subscriptionId` | 指定サブスクリプションの Storage Account を JSON で取得します。 |
| `bark_get_all_azurerm_subscription_role_assignments_bh` | `token` `subscriptionId` | サブスクリプションのロール割り当てを取得します。 |
| `bark_get_all_azurerm_subscriptions` | `token` | 参照可能なサブスクリプションを JSON で取得。通常の列挙が失敗または空の場合は管理グループ階層からの探索に切り替えます。 |
| `bark_get_all_azurerm_subscriptions_bh` | `token` | 参照可能なサブスクリプションを JSON で取得。通常の列挙が失敗または空の場合は管理グループ階層からの探索に切り替えます。 |
| `bark_get_all_azurerm_subscriptions_via_resource_graph` | `token` | Azure Resource Graph の KQL でサブスクリプションを探索。直接 RBAC がなくても Resource Graph を参照できる場合の代替経路です。 |
| `bark_get_all_azurerm_vm_role_assignments_bh` | `token` `vmId` | 仮想マシンのロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_vm_scale_sets` | `token (ARM Bearer)` `subscriptionId` | Virtual Machine Scale Set を JSON で取得します。 |
| `bark_get_all_azurerm_vm_scale_sets_bh` | `token (ARM Bearer)` `subscriptionId` | Virtual Machine Scale Set を JSON で取得します。 |
| `bark_get_all_azurerm_vm_scale_sets_vms` | `token (ARM Bearer)` `vmssId (full ARM path to scale set)` | 指定 Virtual Machine Scale Set 内の仮想マシンを JSON で取得します。 |
| `bark_get_all_azurerm_vms` | `token` `subscriptionId` | 指定サブスクリプションの仮想マシンを JSON で取得します。 |
| `bark_get_all_azurerm_vms_bh` | `token` `subscriptionId` | 指定サブスクリプションの仮想マシンを JSON で取得します。 |
| `bark_get_all_azurerm_web_app_role_assignments_bh` | `token` `webAppId` | App Service Web App のロール割り当てを Azure 管理 API から取得します。 |
| `bark_get_all_azurerm_web_apps` | `token` `subscriptionId` | App Service Web App を JSON で取得します。 |
| `bark_get_all_azurerm_web_apps_bh` | `token` `subscriptionId` | App Service Web App を JSON で取得します。 |
| `bark_get_azure_function_app_function_file` | `token` `functionId` | Function App の関数ファイル（通常はソースコード）を取得します。 |
| `bark_get_azure_function_app_functions` | `token` `functionAppPath` | 指定 Function App の関数を JSON で取得します。 |
| `bark_get_azure_function_app_master_keys` | `token` `functionAppPath` | Function App の master key を取得します。 |
| `bark_get_azure_function_output` | `token` `functionUrl` | 指定 Function App 関数の出力を取得します。 |
| `bark_get_azurerm_key_vault_certificates` | `token (KV-scoped)` `keyVaultUrl` | Key Vault の証明書 ID を列挙。証明書本体は取得しません。 |
| `bark_get_azurerm_key_vault_certificates_revival` | `token (KV-scoped)` `keyVaultUrl` | Key Vault の削除済み証明書を列挙し、名前による復元機能を提供します。 |
| `bark_get_azurerm_key_vault_key_versions` | `token (KV-scoped)` `secretId` | 指定 Key Vault キーのバージョンを取得します。 |
| `bark_get_azurerm_key_vault_keys` | `token (KV-scoped)` `keyVaultUrl` | Key Vault のキー ID を列挙。キー本体は取得しません。 |
| `bark_get_azurerm_key_vault_secret` | `token (KV-scoped)` `vaultName` `secretName` | vault 名と secret 名で値を取得。az keyvault secret show に相当します。 |
| `bark_get_azurerm_key_vault_secret_value` | `token (KV-scoped)` `secretId` | 完全 secret ID URL を指定して Key Vault secret の値を取得します。 |
| `bark_get_azurerm_key_vault_secret_versions` | `token (KV-scoped)` `secretId` | 指定 Key Vault secret のバージョンを取得します。 |
| `bark_get_azurerm_key_vault_secrets` | `token (KV-scoped)` `keyVaultUrl` | Key Vault の secret ID を列挙。secret 値は取得しません。 |
| `bark_get_azurerm_role_assignments` | `token` `targetObjectId` | 指定オブジェクトに対する AzureRM ロール割り当てを列挙します。 |
| `bark_get_azurerm_role_definitions` | `token` `subscriptionId` | サブスクリプションレベルで利用可能な AzureRM ロール定義を収集します。 |
| `bark_get_azurerm_role_definitions_bh` | `token` `subscriptionId` | サブスクリプションレベルで利用可能な AzureRM ロール定義を収集します。 |
| `bark_get_azurerm_web_app` | `token` `webAppId` | 指定 App Service Web App を JSON で取得します。 |

### 書き込み／変更（14 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_add_member_to_entra_group` | `token` `principalId` `targetGroupId` | 既存の Entra セキュリティグループに principal を追加します。 |
| `bark_enable_entra_role` | `token (Graph Bearer)` `roleId (roleTemplateId)` | 指定 roleTemplateId に対応する Entra ディレクトリロールを有効にします。 |
| `bark_new_azure_key_vault_access_policy` | `token` `principalId` `tenantId` `targetObjectId` | 指定 principal に Key Vault の secrets・keys・certificates の Get／List 権限を付与します。 |
| `bark_new_azurerm_role_assignment` | `token` `principalId` `azureRMRoleId` `subscriptionId` | Entra principal に AzureRM ロールを割り当てます。権限反映まで待機が必要です。 |
| `bark_new_entra_app_owner` | `token` `appObjectId` `ownerObjectId` | MS Graph でアプリ登録の所有者を追加します。 |
| `bark_new_entra_app_role_assignment` | `token` `principalId` `resourceId` `appRoleId` | 既存の Entra サービスプリンシパルにアプリロールを割り当てます。 |
| `bark_new_entra_app_secret` | `token` `appRegObjectId` | アプリ登録に認証用 secret を作成します。 |
| `bark_new_entra_group_owner` | `token` `groupId` `ownerObjectId` | MS Graph で Entra グループの所有者を追加します。 |
| `bark_new_entra_role_assignment` | `token` `principalId` `roleDefinitionId` | object ID で指定した principal に Entra 管理ロールを割り当てます。 |
| `bark_new_entra_sp_owner` | `token` `servicePrincipalId` `ownerObjectId` | MS Graph で Entra サービスプリンシパルの所有者を追加します。 |
| `bark_new_entra_sp_secret` | `token` `servicePrincipalId [` `secretDisplayName]` | Entra サービスプリンシパルに認証用 secret を作成します。 |
| `bark_reset_entra_user_password` | `token (portal-scoped)` `targetUpn` | Entra ユーザーのパスワードをリセットし、成功時は新しい一時パスワードを返します。 |
| `bark_set_entra_user_attribute` | `token` `userId` `attributeName` `attributeValue` | MS Graph で Entra ユーザーの書き込み可能な属性を1つ更新します。 |
| `bark_set_entra_user_password` | `token` `targetUserId` `newPassword` | Entra ユーザーのパスワードを指定値に設定します。 |

### 呼び出し／実行（8 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_azure_automation_account_runbook_output` | `token` `automationAccountPath` `runbookName` | 既存 Automation Account runbook を実行して出力を取得します。 |
| `bark_invoke_azure_vm_scaleset_run_command` | `token` `vmssVmId` `script` | VM Scale Set 内の指定 VM で /runCommand を実行します。 |
| `bark_invoke_azurerm_aks_run_command` | `token` `aksClusterId` `command` | AKS の /runCommand endpoint へコマンドを送信します。 |
| `bark_invoke_azurerm_vm_run_command` | `token` `targetVmId` `script` | Azure VM の runCommand endpoint で SYSTEM 権限のコマンド実行を試みます。 |
| `bark_invoke_azurerm_web_app_shell_command` | `token` `webAppName` `command` | JWT または Base64 認証文字列を使用し、Web App でシェルコマンドを実行します。 |
| `bark_new_azure_automation_account_runbook` | `token` `automationAccountPath` `runbookName` `script` | 既存 Automation Account に runbook を追加します。 |
| `bark_new_ps_function_app_function` | `token` `pathToFunctionApp` `functionName` `powerShellScript` | 既存 Function App に PowerShell 関数を作成します。 |
| `bark_start_azurerm_automation_account_runbook` | `token (ARM Bearer)` `accountPath` `runbookName` `hybridGroup` | {accountPath}/jobs/{guid} への PUT で公開済み runbook を非テストジョブとして起動。hybridGroup が空文字ならクラウド実行。GUID は時刻から生成します。 |

### legacy AAD Graph の BH 出力（14 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_all_app_role_assignments_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `servicePrincipalId` | AAD Graph で全 SP のアプリロール割り当てを取得します。 |
| `bark_get_all_entra_apps_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra アプリを JSON で取得します。 |
| `bark_get_all_entra_roles_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra ディレクトリロールを JSON で取得します。 |
| `bark_get_all_entra_service_principals_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra サービスプリンシパルを JSON で取得します。 |
| `bark_get_all_role_assignments_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra ロール割り当てを JSON で取得します。 |
| `bark_get_entra_app_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `appObjectId` | AAD Graph でアプリを列挙し、各所有者を取得します。 |
| `bark_get_entra_device_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `deviceId` | AAD Graph でデバイスを列挙し、各登録所有者を取得します。 |
| `bark_get_entra_devices_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra デバイスを JSON で取得します。 |
| `bark_get_entra_group_members_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `groupId` | AAD Graph でグループを列挙し、各メンバーを取得します。 |
| `bark_get_entra_group_owner_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `groupId` | AAD Graph でグループを列挙し、各所有者を取得します。 |
| `bark_get_entra_groups_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra グループを JSON で取得します。 |
| `bark_get_entra_sp_owners_legacy_bh` | `token (AAD Graph Bearer)` `tenantId` `servicePrincipalId` | AAD Graph で SP を列挙し、各所有者を取得します。 |
| `bark_get_entra_users_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph で Entra ユーザーを JSON で取得します。 |
| `bark_get_tenant_information_legacy_bh` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `tenantId` | AAD Graph でテナント情報を取得します。 |

### 条件付きアクセスポリシー解析（1 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_get_conditional_access_policies` | `token (AAD Graph Bearer - scope: https://graph.windows.net/)` `[tenantId]` | legacy AAD Graph の内部 API で条件付きアクセスポリシーを列挙し、MFA／Block の除外をネイティブユーザー／グループの cap_policies に出力。[詳細](Conditional-Access.md#conditional-access-policy-analysis)を参照してください。 |

### ユーティリティ（3 BOF）

| コマンド | 引数 | 説明 |
|---|---|---|
| `bark_convert_az_role_assignments_to_graph_bh` | `[pattern]` | ロール割り当ての BH JSON（download mode 有効時はメモリ内データ）をグラフに変換。[ディスクレス変換](Downloads-and-Archives.md#diskless-graph-conversion)を参照してください。 |
| `bark_parse_jwt_token` | `token (the JWT string to decode — this IS the target` `not a bearer for auth)` | JWT をデコードします。 |
| `bark_zip_collect` | `password` `[pattern]` | 収集結果を指定パスワードの ZIP にまとめます。pattern で対象を絞り込みます。 |
