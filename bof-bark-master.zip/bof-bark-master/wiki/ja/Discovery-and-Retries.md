# 探索、ページング、再試行

[English](../Discovery-and-Retries.md) | [日本語](Discovery-and-Retries.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

<a id="management-group-fallback"></a>
## 管理グループによるフォールバック

ARM `/subscriptions` の一覧を取得できなくても、管理グループの子孫としてサブスクリプションを発見できる場合があります。RT、ROPC、PRT などで取得したトークンでは、Portal で見える範囲と一覧 API の結果が異なることがあります。

`bark_get_all_azurerm_subscriptions` と `bark_get_all_azurerm_subscriptions_bh` は、初回の結果が空または HTTP エラー・接続失敗の場合に次を実行します。

1. `GET /providers/Microsoft.Management/managementGroups` で管理グループを列挙。
2. 各グループの `GET .../managementGroups/{name}/descendants` を取得。
3. 種類が `microsoft.resources/subscriptions` の子孫を抽出。
4. `GET /subscriptions/{id}` で各サブスクリプションを個別取得。

通常出力・BH 出力の両方が対応しています。

| コマンド | 用途 |
| --- | --- |
| `bark_get_all_azurerm_management_groups` | 管理グループをページングして列挙 |
| `bark_get_all_azurerm_management_group_descendants` | 指定グループの子孫を列挙 |
| `bark_get_all_azurerm_subscriptions_via_resource_graph` | Azure Resource Graph の KQL で探索 |

BARK の ARM 向け自動選択は Azure CLI を優先します。明示する例です。成功可否はテナントと権限に依存します。

```text
beacon> bark_get_tokens_with_rt https://management.azure.com 04b07795-8ddb-461a-bbee-02f9e1bf7b46 <refreshToken> <tenantId>
```

## 全ページの取得

親となるグループ、アプリ、SP、デバイス、サブスクリプション、リソースの列挙は `@odata.nextLink` を追跡し、動的配列に保持します。旧実装の「最初の最大999件のページ」「固定256要素」の制約をなくしています。

管理グループ、子孫、その他の `BarkGet` ベースの単独読み取りも対応します。対象ヘルパーは `BarkGetBHGraphAutoEnum`、`BarkGetBHGraphGrouped`、`BarkGetBHGraphGroupedEx`、`BarkGetBHLegacyAutoEnum`、`BarkGetBHGraphGroupedLegacy`、`BarkGetBHAllSubscriptions`、`BarkGetBHAllResourceRoleAssignments`、`BarkGet`、単独の `get_entra_group_owner_bh` です。

## HTTP の再試行

HTTP 送信は全体で50 ms、Graph で最低100 ms の間隔を設けます。冪等なリクエストと OAuth 交換は `HttpRequestWithRetry` を使い、数値の `Retry-After` を尊重します。状態変更 POST / PATCH はペーシングと429の制御に参加しますが、自動再送しません。

| 状況 | 待機 | 最大再試行数 |
| --- | --- | --- |
| HTTP 429 | 10秒、20秒、30秒（Retry-After を考慮） | 3 |
| HTTP 5xx | 2秒、4秒、8秒 | 3 |
| 接続失敗 | 2秒、4秒、8秒 | 3 |

```text
[*] HTTP 429 — retrying in 10 seconds (attempt 1/3)
```

429 以外の通常の4xxは直ちに返します。OAuth も一時的な通信失敗・429・5xxのみ再試行し、通常の認証エラーは繰り返しません。
