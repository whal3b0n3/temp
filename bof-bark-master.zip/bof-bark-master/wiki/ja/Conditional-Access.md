# 条件付きアクセスの解析

[English](../Conditional-Access.md) | [日本語](Conditional-Access.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

<a id="conditional-access-policy-analysis"></a>
## 解析対象とファイル

`bark_get_conditional_access_policies` は legacy AAD Graph 内部 API
`graph.windows.net/{tenantId}/policies?api-version=1.61-internal` でポリシーを列挙し、`policyDetail` の MFA / Block 制御に関する除外を解析します。

既定の download mode ON では C2 経由で送信し、OFF では Beacon のカレントディレクトリに保存します。

| ファイル | 内容 |
| --- | --- |
| `AZConditionalAccessPolicy_yyyyMMdd_HHmmss.json` | 対象ユーザー／グループの CAP プロパティ更新用 BloodHound JSON |
| `AZConditionalAccessPolicyRaw_yyyyMMdd_HHmmss.json` | 手動確認用の API 生レスポンス |

これは個別ポリシーの除外に関する観測結果です。すべての有効なポリシーを回避してサインインできるという判定ではありません。旧形式の移行、未収集プリンシパル、既存プロパティの保護は [CAP プロパティとネイティブ ID の保護](OpenGraph-Node-Preservation.md)を参照してください。

## 検出内容

有効な `policyType: 18` のポリシーを対象に、次の2種類を調べます。

1. **ユーザー／グループの除外**：`Conditions.Users.Exclude` に含まれるプリンシパルは、そのポリシーの対象から除外されます。
2. **条件の除外**：アプリ、端末プラットフォーム、場所、デバイス条件の `Exclude` に一致すると、そのポリシーの要求が適用されない条件になります。

| 条件 | フィールド | 値の例 |
| --- | --- | --- |
| アプリ | `Applications.Exclude` | `MicrosoftAdminPortals`、アプリ GUID |
| 端末プラットフォーム | `DevicePlatforms.Exclude` | `Android`、`iOS`、`Windows_Phone` |
| 場所 | `Locations.Exclude` | 名前付き場所の ID |
| デバイス準拠 | `Devices.Exclude` | `device.isCompliant -eq True` |

MFA は `Control: ["Mfa"]`、または既知の認証強度 ID から識別します。

| AuthStrengthId | 意味 |
| --- | --- |
| `00000000-0000-0000-0000-000000000002` | MFA |
| `00000000-0000-0000-0000-000000000003` | パスワードレス MFA |
| `00000000-0000-0000-0000-000000000004` | フィッシング耐性 MFA |

## 出力形式

対象のネイティブユーザー／グループに `cap_policies` 配列を追加します。名前などの ID 関連フィールドは出力しません。ネイティブデータを先に取り込み、その後に CAP ファイルを送信してください。

```json
{
  "graph": {
    "nodes": [{
      "id": "ADE8CDCB-08E3-454A-9EC2-02E393ABDA69",
      "kinds": ["AZUser"],
      "properties": {
        "cap_policies": [
          "MFA Policy: Excluded from MFA for All Apps",
          "Sign-In Risk Policy: Excluded from MFA for All Apps (for sign-in risk: high,medium)",
          "Require MFA for X: no MFA for app: MicrosoftAdminPortals,797f4846-...; platform: Android,iOS"
        ]
      }
    }],
    "edges": []
  }
}
```

BOF のユーザー除外は `Excluded from MFA for ...`、条件除外は `no MFA for ...` という説明を含みます。Python 版は条件全体を JSON 文字列として記録します。どちらも新しい CAP エッジは作成しません。

## 実行例

```text
beacon> bark_get_tokens_with_rt https://graph.windows.net "" <refreshToken> <tenantId>
beacon> bark_get_conditional_access_policies <aadgraph_token> [tenantId]
```

トークンの resource は `https://graph.windows.net/` です。`tenantId` を省略すると JWT から取得します。
