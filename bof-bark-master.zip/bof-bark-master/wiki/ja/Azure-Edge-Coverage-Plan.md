# Azure エッジ対応範囲の拡張計画

[English](../Azure-Edge-Coverage-Plan.md) | [日本語](Azure-Edge-Coverage-Plan.md)

[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## 現状と対象範囲

このページは段階的な対応計画です。AzureHound と完全に同等という意味ではありません。[実装・検証結果と47種類の対応一覧](Azure-Native-Edges.md)も参照してください。現在のバンドルは、ネイティブ AzureHound 互換レコードと BARK OpenGraph の関係を組み合わせます。AZPermissionGraph の評価対象は[カタログ](../../data/azure_privilege_capabilities.json)にある6種類の capability です。レコード種類を受け付けることや、空の取り込みが成功することだけではエッジ対応を証明できません。

[BloodHound のエッジ一覧](https://bloodhound.specterops.io/resources/edges/overview)に掲載される Azure / Entra の関係を対象とします。オンプレミス AD は対象外です。比較時には AzureHound と BloodHound のバージョンを固定し、更新されるドキュメントと区別します。

今回の実装済み項目:
- Python / BOF の Entra PIM 適格性・ポリシー収集とネイティブ変換。
- Key Vault の詳細取得とアクセスポリシー変換。Get の表記と認可モードも確認。
- ユーザー割り当てマネージド ID の一覧収集と、整合性を確認したリソース参照の補完。
- ネイティブ取り込みに部分失敗がある場合の OpenGraph アップロード停止。

隔離した BloodHound 9.3 の合成データで6種類のネイティブエッジと、OpenGraph 取り込み後のユーザー属性保持を確認しました。他のエッジは対応一覧で未検証・未対応を区別しています。全後処理の同等性、Key Vault RBAC data action の capability 追加、リソース別の前提条件解析は未完了です。以下の表は、その広い対応範囲に対する完了条件として維持します。

## 実施順序

| 優先度 | 作業 | 完了の判断基準 |
| --- | --- | --- |
| 1 | 固定した upstream バージョンごとに対応表を作成。始点／終点、traversability、API、必須フィールド、Python／BOF 対応、変換処理、BloodHound 後処理を記録。実装済み・未対応・部分対応・未検証を区別する。 | Azure の全エッジに fixture または明確な不足事項があり、バージョンと根拠を追跡できる。 |
| 2 | Python と BOF の all-info に Entra PIM を追加。Graph の roleManagement/directory/roleEligibilityScheduleInstances と policies/roleManagementPolicyAssignments、および承認者の解決に必要な policy rules を収集。固定した AzureHound の形式に合わせる。 | AZRoleEligible / AZRoleApprover の生成／非生成、ページング、アクセス拒否、期限切れ、グループ承認者、ポリシー不足を検証。ARM PIM と分離し、eligible を有効化済みとは扱わない。 |
| 3 | Key Vault アクセス ポリシーをネイティブ形式に変換。一覧応答に不足する場合は vault の詳細を取得。enableRbacAuthorization を考慮し、アクセス ポリシーと RBAC data actions を別評価する。 | AZGetSecrets / AZGetKeys / AZGetCertificates の取り込みを確認。RBAC 有効 vault に誤ったアクセス ポリシーのエッジを作らず、取得不可と空を区別する。 |
| 4 | Managed Identity の principal ID、AKS node resource group、アプリ／SP、所有者、スコープ継承、ディレクトリロール、Graph 権限のネイティブ対応を監査。対応表で判明したフィールドや変換の不足を補う。 | BloodHound 後処理後のエッジ種類と始点／終点が upstream 基準と一致し、生成／非生成の両方を検証できる。 |
| 5 | ネイティブ処理を補う意義がある権限解析を追加。Key Vault data actions とリソース別の実行／制御権限を優先し、前提条件・条件式・不確実性を定義する。 | 各ルールに許可・拒否・不明の fixture がある。名前の似たエッジを同じ意味として扱わない。 |
| 6 | 一連の比較試験を実施し、検証済み対応表を英日で公開する。 | 同等の AzureHound／Python／BOF fixture を空の隔離 BloodHound に取り込み、未解決 endpoint と意図しないネイティブ属性変更がなく、探索可能なパスの差異を説明できる。 |

## 意味を混同しないための制約

- BARK_CanRunAzureVMCommand は Azure VM Run Command の権限です。[AZExecuteCommand](https://bloodhound.specterops.io/resources/edges/az-execute-command) は Intune 経由の実行を表すため、名称を置き換えて対応済みとはしません。
- BARK_CanAssignAzureManagedIdentity は割り当て権限、[AZManagedIdentity](https://bloodhound.specterops.io/resources/edges/az-managed-identity) は既存のリソースと ID の関係です。完全な割り当てパスを主張する前に、リソース更新権限と ID 側スコープなどの前提を評価します。
- [AZRoleEligible](https://bloodhound.specterops.io/resources/edges/az-role-eligible) と [AZRoleApprover](https://bloodhound.specterops.io/resources/edges/az-role-approver) は Entra PIM の関係であり、ARM の eligible 情報とは別です。
- アプリロールや RBAC の割り当ては観測事実です。探索可能な capability エッジには操作・スコープ・前提条件を裏付ける根拠が必要です。
- ネイティブノードの名前・型・属性を維持します。プロパティ照合、ネイティブ完了後の OpenGraph 取り込み、CAP の cap_policies のみの更新を継続します。

## 検証とリリース条件

リポジトリには合成または匿名化済み fixture を置き、実テナントの収集結果やトークンはローカルに残します。同等のスナップショットを共通 Python 変換処理と BOF の収集／出力境界で検証し、ページングと部分取得の報告も確認します。

統合試験では比較対象ごとに空の隔離 BloodHound を使い、取り込みと後処理の完了後に正規化したエッジの始点・種類・終点と関連属性を比較します。ネイティブと OpenGraph を同じ検証 DB に取り込む試験も実施し、ネイティブエンティティの保持を確認します。既存データの入った DB だけで endpoint の完全性を判断しません。

収集、シリアライズ、取り込み、グラフの意味がすべて検証された項目を完了とします。未対応バージョンや差異を明示し、一律の対応率で置き換えません。
