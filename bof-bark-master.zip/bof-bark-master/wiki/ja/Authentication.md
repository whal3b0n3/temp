# 認証

[English](../Authentication.md) | [日本語](Authentication.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## resource URL の指定

resource を受け取る認証コマンドには `https://graph.microsoft.com` や `https://management.azure.com` のような URL だけを渡します。パスワード認証とクライアント資格情報認証は v2 scope を内部で構築します。RT / PRT は resource 識別子を使用するため、`/.default` の入力は不要です。Beacon BOF は従来どおり明示的な v2 scope も受け付けます。

ローカルでの認証と refresh token のファイル保存は [Python トークンコマンド](Python-Tokens.md)を参照してください。

<a id="authentication-with-client-id-auto-detection"></a>
## クライアント ID の自動選択

次のコマンドでは `clientId` を省略、または `""` とすると既知の6クライアントを試行します。

- `bark_get_tokens`：RT、ユーザー名／パスワード、PRT の統一エントリーポイント
- `bark_get_tokens_with_rt`：refresh token
- `bark_get_tokens_with_up`：ROPC
- `bark_get_token_with_prt_cookie`：PRT cookie

対象 resource に応じた順序で試行します。

| 対象 | 試行順 |
| --- | --- |
| Microsoft Graph | Azure CLI → AAD PowerShell → Teams → Office → Azure PowerShell → SharePoint |
| legacy AAD Graph | AAD PowerShell → Azure CLI → Azure PowerShell → Office → Teams → SharePoint |
| ARM / Storage / Key Vault | Azure CLI → Azure PowerShell → AAD PowerShell → Office → Teams → SharePoint |
| Office / Outlook / SharePoint / Teams | Office → Teams → SharePoint → Azure CLI → Azure PowerShell → AAD PowerShell |

| クライアント | アプリケーション ID |
| --- | --- |
| Azure CLI | `04b07795-8ddb-461a-bbee-02f9e1bf7b46` |
| Azure PowerShell | `1950a258-227b-4e31-a9cf-717495945fc2` |
| AAD PowerShell | `1b730954-1685-4b74-9bfd-dac224a7b894` |
| SharePoint | `d326c1ce-6cc6-4de2-bebc-4591e5e13ef0` |
| Microsoft Office | `d3590ed6-52b3-4102-aeff-aad2292ab01c` |
| Microsoft Teams | `1fec8e78-bce4-4aaf-ab1b-5451cc387264` |

成功時はトークンとともに選択された `client_id` を表示します。

```text
[*] Trying 1/6: Microsoft Azure CLI (04b07795-...)...
[+] access_token: eyJ...
[+] refresh_token: eyJ...
[+] client_id: 04b07795-8ddb-461a-bbee-02f9e1bf7b46 (Microsoft Azure CLI)
```

特定のアプリケーションを使用する場合は `clientId` を明示します。

## 実行例

```text
# refresh token から MS Graph トークン。client ID は自動選択
beacon> bark_get_tokens_with_rt https://graph.microsoft.com "" <refreshToken> <tenantId>

# ユーザー名とパスワードから ARM トークン
beacon> bark_get_tokens_with_up <tenantId> <username> <password> https://management.azure.com

# PRT cookie
beacon> bark_get_token_with_prt_cookie <prtToken> https://graph.microsoft.com <tenantId>

# Azure CLI の client ID を明示
beacon> bark_get_tokens_with_rt https://graph.microsoft.com 04b07795-8ddb-461a-bbee-02f9e1bf7b46 <refreshToken> <tenantId>
```
