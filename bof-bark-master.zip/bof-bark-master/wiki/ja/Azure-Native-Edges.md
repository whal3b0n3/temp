# Azure ネイティブエッジの実装と検証

[English](../Azure-Native-Edges.md) | [日本語](Azure-Native-Edges.md)

[Wiki の目次](Home.md) | [対応計画](Azure-Edge-Coverage-Plan.md) | [実行手順](../../README.ja.md)

## 今回の修正

Python と modern Graph を使用する BOF は、Entra PIM の適格なロール割り当てとロール管理ポリシーを収集します。展開されたルールが不足している場合やページ分割されている場合は、ルール取得 API を追加で呼び出します。BOF のロール収集と core/parallel 収集に組み込んでいます。legacy AAD Graph では取得できません。

Key Vault の一覧にアクセスポリシーがない場合は、個別の Vault 情報を取得します。アクセス拒否は空の正常結果として扱わず、不完全な収集として記録します。また、ARM からユーザー割り当てマネージド ID を収集し、リソース内の参照に不足する principalId/clientId をバンドル生成時に補います。

既存の収集・バンドル生成コマンドを使えます。引数やアップロード段階の追加はありません。Python all-info は自動でバンドルを生成し、Beacon のダウンロード結果は次のように変換します。

~~~bash
python3 bark_role_graph.py ./downloads --bundle-output ./bloodhound-upload
python3 bark_upload.py ./bloodhound-upload --dry-run
~~~

PIM API が拒否された場合、ユーザーやグループの収集が成功していても PIM の対応範囲は不完全です。収集エラーと、[適格性 API](https://learn.microsoft.com/en-us/graph/api/rbacapplication-list-roleeligibilityscheduleinstances?view=graph-rest-1.0)、[ポリシー API](https://learn.microsoft.com/en-us/graph/api/policyroot-list-rolemanagementpolicyassignments?view=graph-rest-1.0) の必要権限を確認してください。古い結果は再変換できますが、不足する API データは更新後の Python または BOF で再収集する必要があります。

## ネイティブ形式への変換

両コレクターの結果を共通の [bark_native_edges.py](../../bark_native_edges.py) で変換します。

| 収集データ | ネイティブレコード | BloodHound 上の結果 |
| --- | --- | --- |
| AZEntraRoleEligibilityScheduleInstance | AZRoleEligibilityScheduleInstance | Entra ロールへの AZRoleEligible |
| AZEntraRoleManagementPolicyAssignment とルール | AZRoleManagementPolicyAssignment | AZRoleApprover とロール有効化条件のプロパティ |
| AZKeyVault.properties.accessPolicies | AZKeyVaultAccessPolicy | AZGetSecrets / AZGetKeys / AZGetCertificates |
| AZUserAssignedIdentity とリソース内の ID 参照 | AZVM などのリソースレコードを補完 | サービスプリンシパルへの AZManagedIdentity |

Entra PIM の未変換データは別の kind 名を使い、ARM PIM やネイティブ形式と混同しません。有効な変換結果は 01-upload-native/azurehound_bark.json に統合します。AZNativeEdgeCoverage.json は do-not-upload 配下（統合された場合は native-source 配下）の変換・監査用ファイルで、個別アップロードは不要です。BARK_UPLOAD_MANIFEST.json の nativeEdgeConversion に変換件数と除外理由を記録します。

適格な割り当ては、現在有効かつテナントルートのディレクトリスコープである場合のみ変換します。開始前、期限切れ、アプリスコープ、管理単位スコープのレコードは原本に残しますが、ネイティブ変換から除外します。適格性を有効な AZHasRole として扱いません。

ポリシーは EndUser/Assignment の承認・有効化・認証コンテキストのルールを使用します。ユーザー承認者とグループ承認者を区別し、MFA、理由、チケット、認証コンテキストの条件を保持します。不足するルール、未対応の承認者、エスカレーション、複数の承認段階は除外します。完全な単一段階で primaryApprovers が空の場合は、BloodHound の Privileged Role Administrator への既定フォールバックに従います。

Key Vault は RBAC 認可が無効な場合のみアクセスポリシーを変換します。ARM の get を BloodHound 9.3 が要求する Get に正規化します。applicationId による制限付きポリシーとテナント不一致は、直接のエッジでは条件を表せないため除外します。これは RBAC の data action やネットワーク制限を無視したアクセスの保証ではありません。

マネージド ID は不足する参照のみ整合性を確認して補います。競合する対応表は使用せず、入力ファイルも変更しません。既存の ID 接続関係であり、ID を割り当てる権限とは別です。

アップローダーは、ネイティブ取り込みに failed_files または partial_failed_files がある場合、状態が Complete でも OpenGraph のアップロードへ進みません。ネイティブノードの名前・種類・識別情報を維持します。BloodHound が収集時刻を更新する場合はあります。

## 検証範囲

比較対象は [AzureHound v3.1.0](https://github.com/SpecterOps/AzureHound/tree/v3.1.0)（23735c8af6b03a677a3c40e8d274316504ea07ab）と [BloodHound v9.3.0](https://github.com/SpecterOps/BloodHound/tree/v9.3.0)（1fe5e1d310087317f136c88c26bc2f153bff1bf6）です。ネイティブ取り込みと後処理は BloodHound が行い、BARK が全分析を再実装するわけではありません。

オフラインテストでは Python の収集・変換、HTTP/Beacon をスタブ化した実際の BOF C コード、ページ分割、不完全な応答を検証します。専用の BloodHound 環境では 6 種類・7 本の期待エッジを確認し、BARK のアプリロールエッジ追加後もユーザープロパティを維持することを検証します。実テナントや実 Beacon での実行を証明するテストではありません。

~~~bash
python3 -m unittest discover -s tests -q
~~~

任意の tests/test_native_import_integration.py は、空の検証専用 BloodHound を指定する BARK_TEST_BH_URL と BARK_TEST_BH_TOKEN が必要です。既存の Azure ノードがある環境を拒否し、作成した合成データは残します。トークンはシェル履歴に記録しないでください。通常のテストでは明示的な設定がない限りスキップします。

## エッジ対応一覧

2026-09-25 に確認した [公式一覧](https://bloodhound.specterops.io/resources/edges/overview) の Azure/Entra 47 種類を対象にします。「検証済み」は上記の合成データの範囲であり、すべてのノード種別や権限経路の保証ではありません。「未検証」は検証の不足を示し、収集機能がないことを意味しません。

| エッジ | 状態と根拠 |
| --- | --- |
| AZAddMembers | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAddOwner | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAddSecret | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAKSContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAppAdmin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAuthenticatesTo | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAutomationContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZAvereContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZCloudAppAdmin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZContains | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZExecuteCommand | 未対応: Intune の実行は BARK の VM Run Command ルールでは表現しません。 |
| AZGetCertificates | 検証済み: ユーザーのアクセスポリシー Get 権限。RBAC・applicationId 制限は変換テストで除外。 |
| AZGetKeys | 検証済み: ユーザーのアクセスポリシー Get 権限。RBAC・applicationId 制限は変換テストで除外。 |
| AZGetSecrets | 検証済み: ユーザーのアクセスポリシー Get 権限。RBAC・applicationId 制限は変換テストで除外。 |
| AZGlobalAdmin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZHasRole | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZKeyVaultKVContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZLogicAppContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZManagedIdentity | 検証済み: ID 一覧で補完した VM の参照。他のリソース種別は未検証。 |
| AZMemberOf | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGAddMember | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGAddOwner | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGAddSecret | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGAppRoleAssignment_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGApplication_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGDirectory_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGGrantAppRoles | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGGrantRole | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGGroupMember_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGGroup_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGRoleManagement_ReadWrite_Directory | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZMGServicePrincipalEndpoint_ReadWrite_All | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZNodeResourceGroup | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZOwner | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZOwns | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZPrivilegedAuthAdmin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZPrivilegedRoleAdmin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZResetPassword | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZRoleApprover | 検証済み: ユーザー・グループ承認者と有効化条件。 |
| AZRoleEligible | 検証済み: 現在有効なルートスコープのユーザー適格性。期限切れのグループ適格性は除外。 |
| AZRunsAs | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZScopedTo | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZUserAccessAdministrator | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZVMAdminLogin | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZVMContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
| AZWebsiteContributor | 未検証: upstream のエッジ・後処理とのフィクスチャ比較が必要。 |
