# Python トークンコマンド

[English](../Python-Tokens.md) | [日本語](Python-Tokens.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

`bark_tokens.py` は BARK 認証コマンドのローカル Python 版です。Python 3.10 以降と隣接する `bark_all_info.py` が必要です。外部パッケージは使用しません。

## resource URL

`https://graph.microsoft.com`、`https://management.azure.com`、`https://storage.azure.com`、`https://vault.azure.net` などを指定し、`/.default` は省略します。

password / client-credentials grant は v2 scope を内部構築し、RT / PRT は resource 識別子を直接使用します。`/.default` 付き入力も受け付けます。既知サービスの末尾スラッシュは正規化し、カスタム API の意味を持つ末尾スラッシュは保持します。ARM は末尾 `/` 付きの resource に正規化するため、生成 scope は `//.default` です。

[Microsoft の resource / scope と末尾スラッシュの規則](https://learn.microsoft.com/en-us/entra/identity-platform/scopes-oidc#trailing-slash-and-default)に従います。Beacon のパスワード／クライアント資格情報 BOF も対応し、明示的 scope の互換性を維持します。

## 使用例

```bash
python3 bark_tokens.py rt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com

python3 bark_tokens.py up --tenant <tenant-guid> \
  --username operator@example.com --resource https://graph.microsoft.com \
  --output ./tokens.json --refresh-token-output ./refresh-token.txt
python3 bark_all_info.py <tenant-guid-or-domain> --refresh-token-file ./refresh-token.txt

python3 bark_tokens.py cc --tenant <tenant-guid> --client-id <application-guid> \
  --resource https://management.azure.com --output ./app-token.json

python3 bark_tokens.py prt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com --prt-cookie-file ./prt-cookie.txt \
  --output ./prt-tokens.json
```

パスワードと client secret は非表示プロンプトで入力します。ROPC は MFA や対話型 CAP を満たせません。refresh token の返却はユーザー、クライアント、テナントポリシーに依存します。client credentials で得るのはアプリ用 access token で、`bark_all_info.py` が必要とするユーザーの refresh token ではありません。

PRT cookie はオペレーターが用意します。コマンドは抽出・作成しません。`--redirect-uri` はクライアント登録と一致させます。認可リダイレクトは追従せず捕捉し、戻り先 URI と state を検証してからコードを交換します。

## Beacon との対応

長い Beacon コマンド名も alias として使用できます。ただし位置引数ではなく Python のオプションを使用します。

| Beacon コマンド | Python サブコマンド | 必須の非秘密引数 |
| --- | --- | --- |
| `bark_get_tokens` | `get_tokens rt\|up\|cc\|prt` | `--tenant`、`--resource`。up は username、cc は client ID |
| `bark_get_tokens_with_rt` | `rt` | `--tenant`、`--resource` |
| `bark_get_tokens_with_up` | `up` | `--tenant`、`--resource`、`--username` |
| `bark_get_tokens_with_cc` | `cc` | `--tenant`、`--resource`、`--client-id` |
| `bark_get_token_with_prt_cookie` | `prt` | `--tenant`、`--resource` |
| `bark_get_tokens_for_arm` | `arm rt\|up\|cc\|prt` | `--tenant` と認証方式に必要な username / client ID |
| `bark_get_tokens_for_msgraph` | `msgraph rt\|up\|cc\|prt` | 同上 |
| `bark_get_azurerm_token_with_rt` | `arm-rt` | `--tenant` |
| `bark_get_msgraph_token_with_rt` | `msgraph-rt` | `--tenant` |
| `bark_get_entra_refresh_token_with_up` | `entra-refresh` | `--tenant`、`--username` |
| `bark_get_azure_portal_token_with_rt` | `portal-rt` | `--tenant` |
| `bark_get_azurerm_token_with_portal_rt` | `arm-portal` | `--tenant` |
| `bark_get_msgraph_token_with_portal_rt` | `msgraph-portal` | `--tenant` |
| `bark_new_nonce` | `nonce` | なし |

```bash
python3 bark_tokens.py bark_get_tokens_with_rt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com
python3 bark_tokens.py arm rt --tenant <tenant-guid>
python3 bark_tokens.py msgraph up --tenant <tenant-guid> --username operator@example.com
python3 bark_tokens.py portal-rt --tenant <tenant-guid> --output ./portal-tokens.json
python3 bark_tokens.py arm-portal --tenant <tenant-guid> \
  --portal-token-file ./portal-authorization.txt
python3 bark_tokens.py nonce
```

`arm-rt` / `msgraph-rt` は共通 v1 RT grant と client 順序を使用し、旧 BOF 固有の固定 client / endpoint を再現しません。統一 Python password モードは v2 password grant と `offline_access` を要求します。`entra-refresh` の既定は AAD PowerShell、`portal-rt` は Azure Portal client です。

Portal 委任は BOF と同じ endpoint・フィールドを使い、応答 envelope を保持します。入力ファイルは `portal-rt` の JSON 全体ではなく、生の Portal 認可値を入れます。サービス側の可用性と応答形式に依存します。

## 資格情報と出力

入力の優先順位は **ファイル → 環境変数 → 非表示プロンプト**です。

| 資格情報 | ファイル | 環境変数 |
| --- | --- | --- |
| refresh token | `--refresh-token-file` | `BARK_REFRESH_TOKEN` |
| パスワード | `--password-file` | `BARK_PASSWORD` |
| client secret | `--client-secret-file` | `BARK_CLIENT_SECRET` |
| PRT cookie | `--prt-cookie-file` | `BARK_PRT_COOKIE` |
| Portal 認可値 | `--portal-token-file` | `BARK_PORTAL_TOKEN` |
| 代替 Portal 認可値 | `--alt-portal-token-file` | `BARK_ALT_PORTAL_TOKEN` |

代替 Portal token は任意で、既定は空文字列です。各ファイルは UTF-8 で1つの生の資格情報を保存します。

成功 JSON はトークンを含め標準出力へ、診断は標準エラー出力へ送ります。`--output` は JSON を新規ファイルへ保存します。`--refresh-token-output` は返却された refresh token だけを別ファイルに保存し、返却がなければ失敗します。既存ファイルは上書きしません。POSIX は `0600`、Windows は通常の継承 ACL で作成します。内容は平文です。

`--client-id` を省略すると対応 grant で[resource 別試行順](Authentication.md#authentication-with-client-id-auto-detection)を使用します。`--timeout` / `--retries` は token POST を制御します。PRT 認可 GET はクライアントごとに1回で、リダイレクトを追従しません。

終了コードは `0`：応答取得、`1`：認証・入力・出力失敗、`2`：CLI 引数不正、`130`：中断です。`python3 bark_tokens.py <command> --help` で個別オプションを確認します。

## 検証

オフラインテストは alias、grant 本文、Python / C の resource 正規化、client fallback、PRT state / redirect、秘密情報入力、出力ファイル保護を対象とします。実テナントへの認証は行いません。Portal / PRT は使用環境での確認も必要です。
