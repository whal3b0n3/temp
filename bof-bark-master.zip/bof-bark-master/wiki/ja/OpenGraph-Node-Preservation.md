# CAP プロパティとネイティブ ID の保護

[English](../OpenGraph-Node-Preservation.md) | [日本語](OpenGraph-Node-Preservation.md)
[Wiki の目次](Home.md) | [BloodHound 取り込み](BloodHound-Import.md)

## 現在の出力

CAP の観測結果は `AZUser` / `AZGroup` の `cap_policies` 文字列配列に直接格納します。各値はポリシー除外や条件例外の観測であり、有効なサインイン要件全体の評価ではありません。

```json
{
  "graph": {
    "nodes": [{
      "id": "<NATIVE-OBJECT-ID>",
      "kinds": ["AZUser"],
      "properties": {
        "cap_policies": ["Policy name: observed exclusion"]
      }
    }],
    "edges": []
  }
}
```

CAP writer は `name`、`displayname`、`tenantid`、`enabled`、custom source kind を出力しません。BloodHound v9.3.0 の [converter](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/cmd/api/src/services/graphify/convertors.go) は先頭 kind を primarykind に設定し、[importer](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/cmd/api/src/services/graphify/ingestnodes.go) は ID を正規化して lastseen を更新します。このため、指定 kind は既存 user / group と一致する必要があります。未指定の identity property はこの patch から供給しません。

バンドルは native snapshot の kind を採用し、未収集プリンシパルの CAP 更新を省きます。観測は `meta.unmatchedConditionalAccessProperties`、manifest の ID 一覧は `unmatchedConditionalAccessPrincipals` に残します。uploader は native job の成功を待ちます。

CAP node payload は存在確認だけの lookup ではなく upsert です。ネイティブより先に送信すると部分ノードを作る可能性があるため、順序付きバンドルを使用してください。

更新対象の配列を置き換えることで、観測件数が減ったときに古い番号付きフィールドが残る問題を避けます。CAP payload に現れないプリンシパルの値は自動消去しません。観測されないことだけではポリシー削除を断定できません。

## 旧形式からの移行

Python / BOF ともプロパティ形式です。変換器は `MFA1`、`MFA2` などと `BARK_ConditionalAccessAnnotation` node の旧形式も受け付けます。観測だけを抽出し、identity field の書き込みを除き、一致した native principal の `cap_policies` を生成します。新 payload から `BARK_HasConditionalAccessAnnotation` edge を除きます。元ファイルは変更しません。

```bash
python3 bark_role_graph.py /path/to/collection --bundle-output ./cap-properties-bundle
python3 bark_upload.py ./cap-properties-bundle --username <bloodhound-user>
```

先に `00-install-schema/BARK_OpenGraph_Extension.json` を登録します。`01-upload-native/` の Complete 後に、別ジョブで `02-upload-opengraph/` を送信します。

```cypher
MATCH (u:AZUser)
WHERE u.cap_policies IS NOT NULL
RETURN u, u.cap_policies AS CAPPolicies
LIMIT 200
```

既に DB にある annotation node / edge や古い MFA番号プロパティは、新 payload のアップロードでは削除されません。ライブ DB の cleanup / reimport は実施していません。新ファイルは annotation node / edge を生成しません。

## 関係エンドポイントの保護

RoleGraph、AppRoleGraph、PermissionGraph は大文字 objectid の property matcher を使い、native kind を endpoint に指定しません。既存ノードが一意に一致する必要があります。standalone のコピーは `BARK_ENTITY_<original-id>` で衝突を防ぎます。

以前の CAP annotation node は native property 更新を避ける設計でしたが、オペレーターの希望に従い CAP だけを限定した property update に変更しました。関係 endpoint の存在必須 lookup は維持します。

<a id="confirmed-upload-ordering-failure"></a>
## 確認済みのアップロード順序問題

BloodHound v9.3.0 / Neo4j 4.4 の読み取り専用調査で、2026-09-25 の job 49 が次の順で処理したことを確認しました。時刻は UTC です。

| 完了時刻 | ファイル | 結果 |
| --- | --- | --- |
| 05:22:04.064 | `AZAppRoleGraph_20260925_141916.json` | native より先で endpoint 警告 |
| 05:22:04.077 | `AZPermissionGraph_20260925_141916.json` | native より先で endpoint 警告 |
| 05:22:04.709 | `azurehound_bark.json` | 同一ジョブの後段で処理 |
| 05:22:05.152 | `AZConditionalAccessPolicy_20260925_131924.json` | native 後に処理 |
| 05:22:05.738 | `AZRoleGraph_20260925_141916.json` | native 後に処理 |

後の DB 確認では、失敗した2ファイルが参照する20種類の native object ID はすべて1ノードに解決され、欠落・重複はありませんでした。property matching の非互換ではなく、必要ノードが利用可能になる前の処理が原因です。

native の成功を確認後、`bark-bofresult/BARK_BloodHound_Bundle_20260925_141916/02-upload-opengraph/` の失敗した2ファイルだけを再送できます。この順序問題のための再収集・再生成は不要です。以降は uploader または手動でジョブを2つに分け、両フェーズを同じ ZIP / job に入れないでください。

この調査は DB を変更していません。uploader は HTTP fixture で失敗・部分成功・timeout 時に後段を停止することを検証し、ライブ再試行の成功はオペレーター側で確認する必要があります。

## 検証結果

108件の Python 回帰テストが成功し、実 BOF JSON writer を組み込んだオフライン C harness も含みます。旧 CAP 2形式の変換、snapshot による除外、importer モデルでの identity 保護、新旧のフォルダー構成を検証します。C harness は transport を stub 化したもので、Beacon 実行テストではありません。この property format のライブ ingest は未検証です。

x64 / x86 BOF は再ビルド済みです。

- `bark-bofresult/BARK_BloodHound_Bundle_cap_properties/`
- `bark-results/BARK_20260922_084052_292957/BARK_BloodHound_Bundle_cap_properties/`

各バンドルの `CAP_PROPERTIES_VALIDATION.json` に結果を記録しています。BOF は101 principal / 176観測、Python は101 principal / 174観測で、Python の未一致2件は audit に保持します。BOF 1,108件、Python 1,943件の native record は変更していません。
