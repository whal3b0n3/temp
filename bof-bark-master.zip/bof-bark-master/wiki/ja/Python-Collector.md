# Python コレクター

[English](../Python-Collector.md) | [日本語](Python-Collector.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

[bark_all_info.py](../../bark_all_info.py) は CNA の `bark_get_all_info_bh_rt`（`bark_get_all_info_rt_bh` と呼ばれることもあります）に相当するローカルコレクターです。Python 3.10 以降の標準ライブラリを使用します。グラフ／権限解析ヘルパーと capability catalog を読むため、リポジトリ内で実行してください。

```bash
python3 bark_all_info.py <tenant-guid-or-domain> --output ./bark-results
```

refresh token は非表示プロンプト、UTF-8 ファイルを指定する `--refresh-token-file /path/to/token.txt`、または環境変数 `BARK_REFRESH_TOKEN` から入力します。トークン文字列そのものを CLI 引数には渡しません。access token と更新された refresh token はメモリ内に保持し、収集結果には保存しません。

テナントは GUID または `megabigtech.com` のような検証済みドメインです。ドメインは認証前に公開 OpenID 構成から GUID に解決し、以後の token 要求、legacy URL、BH 識別子、manifest に使います。対象は Azure public cloud です。`common` / `organizations` は収集テナントとして使用できません。

`--client-id <guid>` でクライアントを固定し、省略時は resource 別の試行順を使います。成功範囲は refresh token と委任権限に依存します。[Python トークンコマンド](Python-Tokens.md)の `--refresh-token-output` をそのまま入力ファイルに利用できます。

<a id="collection-coverage"></a>
## 収集範囲

| 段階 | 動作 |
| --- | --- |
| 認証 | v1 RT 交換、RT ローテーション、audience 別 access token キャッシュ、有効期限管理、401 後の1回の更新 |
| Entra | テナント、ユーザー、グループ、デバイス、ディレクトリロール定義／割り当て、アプリ、SP |
| 関連 | グループメンバー／所有者、デバイス登録所有者、アプリ／SP 所有者、federated identity credentials |
| アプリロール | 各リソース SP の `appRoleAssignedTo`。ユーザー・グループ・SP の割り当てをカスタム app-role 変換へ渡す |
| legacy fallback | modern identity / relationship が不完全な場合に AAD Graph を収集。`*_legacy.json` に別保存 |
| CAP | legacy policy endpoint、生ポリシー、有効な MFA / Block ポリシーの除外をネイティブ `cap_policies` プロパティに出力 |
| Azure inventory | サブスクリプション、管理グループと子孫、RG、リソース、VM / VMSS、vault、storage、Logic / Web / Function Apps、AKS / ACR、Automation、Container Apps / Instances、Cosmos DB |
| Azure 認可 | ロール定義、subscription / resource / management-group 割り当て、deny、PIM eligible / assignment instance、role-management policy と割り当て |
| データプレーン | Storage コンテナー名、Key Vault シークレットのメタデータをページング。blob 内容・secret 値は収集しない |
| 変換 | ネイティブ RBAC、AppRoleGraph、PermissionGraph / Findings、フェーズ別バンドル |

収集要求は GET、OAuth 交換だけ POST です。一時的障害と throttling を再試行し、最大5分の Retry-After を尊重します。リダイレクトと別ホストへのページングを拒否し、途中ページが失敗しても成功済みレコードは保持します。

## 並列収集

既定は `--workers 8`、範囲は1～32です。

```bash
python3 bark_all_info.py megabigtech.com --workers 8
python3 bark_all_info.py megabigtech.com --workers 1
```

独立した Entra エンティティ、親ごとの関連、アプリロール、ARM リソース種類／スコープ、データプレーンメタデータを並列実行します。探索と出力の依存順序は維持し、個々のクエリ内では逐次ページングします。

並列数は各ステージ全体に適用し、入れ子の pool で増幅しません。投入済みタスク数も最大で worker 数の2倍です。結果はメインスレッドで入力順に統合・保存し、JSON の決定性と部分収集範囲を維持します。manifest に worker 数を記録します。

各 worker は個別の HTTP handler を持ちます。共有 RT が audience 間でローテーションするため OAuth 交換は直列化します。同じ古い access token が並列に拒否された場合、他 worker が更新したキャッシュを再利用します。

調査時は `--workers 1`、429 が多い場合は並列数を下げてください。中断時は待機タスクと retry 待機を停止しますが、通信中の要求は設定 timeout まで戻らない場合があります。

44要求、各20 msの遅延を模擬した fixture は、1 worker で約0.90秒、8 workers で約0.30秒となり、同一 JSON を生成しました。これはオフラインの並列化測定で、実 Azure の速度保証ではありません。

## 出力と完全性

標準出力には、保存した Azure コレクションごとに `[+] AZUser: Found 123 objects` のような件数と、最終状態・出力先を表示します。所有者・メンバー・ディレクトリロール割り当ては親レコード数ではなく関係の合計数、フェデレーション資格情報は資格情報自体の数を表示します。件数は各コレクションの保存件数で、ファイル間で重複を除いたプリンシパル数ではありません。legacy の結果には `_legacy` を付けます。部分収集には `(incomplete collection)` を付けるため、取得失敗後の0件は対象が存在しないことを意味しません。個々のオブジェクトや親ごとの所有者・メンバー詳細は表示せず、エラーは stderr と manifest に残します。変換の stdout は `bundle_conversion.log`、変換エラーは stderr に出力します。

```text
bark-results/BARK_<UTC timestamp>/
  AZUser.json
  AZGroupMember.json
  AZAppRoleAssignment.json
  AZDenyAssignment.json
  ConditionalAccessPolicies.json
  AZConditionalAccessGraph.json
  DataPlaneProbes.json
  collection_manifest.json
  BARK_BloodHound_Bundle_<timestamp>/
```

バンドルの `UPLOAD_INSTRUCTIONS.txt` に従い、拡張登録 → ネイティブのジョブ完了 → 別ジョブで OpenGraph の順に取り込みます。元 JSON がすべて直接アップロード可能なわけではありません。カスタムアプリロールは `BARK_AssignedAppRole` で表現します。

`collection_manifest.json` は失敗、スキップ、変換状態を記録します。収集 envelope は `meta.collection.complete`、関連は親の取得範囲、認可スナップショットはスコープの取得範囲も記録します。403・失敗ページを「対象なし」と扱わず、fallback 成功でも先行失敗は消しません。任意の sign-in activity が取れなかったことも記録しますが、それだけでは legacy fallback を起動しません。

| 終了コード | 意味 |
| --- | --- |
| `0` | 要求した段階が失敗記録なく完了 |
| `2` | 部分結果、変換失敗、または CLI 引数不正 |
| `1` | ローカル設定・I/O・import 失敗 |
| `130` | 中断。完了 JSON と未完了 manifest を保持 |

主な指定は `--workers 8`、`--no-probes`、`--no-bundle`、`--no-legacy-fallback`、`--timeout 60`、`--retries 4` です。legacy fallback の無効化は独立した legacy CAP クエリを無効にしません。完全性は認証主体に見える要求範囲の応答を示し、テナント全体への可視性を証明しません。

## Beacon 版との違い

収集と変換をローカルで再現し、Cobalt Strike の転送は使いません。JSON は一時ファイルから atomic rename で保存します。BeaconDownload の 256 / 512 KB 問題とは無関係で、API ページングとローカルファイルサイズは独立です。書き出し前はメモリに蓄積するため、大規模環境では十分な RAM が必要です。

Python はステージごとに上限付き pool、BOF は親 worker pool と関連種類ごとのスレッドを使います。Python に C2 ダウンロード、一時 ZIP ステージング、パスワード付き ZIP オプションはなく、ローカルに生 JSON が残ります。

legacy API は CNA との対応のために試行しますが、テナントで可用性・権限が異なります。legacy ディレクトリロールは有効化済みロール、legacy SP app-role は outgoing assignment が範囲です。ユーザー／グループの割り当てを含む modern incoming assignment の代替にはなりません。federated credentials は modern Graph だけで収集します。

CAP はネイティブの `cap_policies` 配列へ出力し、名前や tenant ID は出力しません。Python は BOF の説明文を再現する代わりに条件全体を JSON 文字列として保持します。除外の観測であり、特定のサインインで MFA を回避できるという判定ではありません。[ノード保護](OpenGraph-Node-Preservation.md)も確認してください。

## オフライン検証

```bash
python3 -m unittest discover -s tests
```

fake HTTP tenant で token rotation / expiry、fallback、429、ページング、別ホスト拒否、部分取得、管理グループ探索、probe、中断、大きな JSON の完全性、実バンドル変換、並列数上限、同時 token refresh、cancel、逐次／並列結果の一致を検証します。実 Azure 認証や稼働中 BloodHound への ingest は行いません。
