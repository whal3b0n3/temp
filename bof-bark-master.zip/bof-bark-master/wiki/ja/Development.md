# 開発

[English](../Development.md) | [日本語](Development.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## ビルドと検証

リポジトリのルートで実行します。

```bash
bash build_all.sh
python3 -m unittest discover -s tests
```

BOF のビルドには[インストール](Installation.md#build)に記載した MinGW コンパイラーが必要です。Python の検証は収集 fixture とグラフ変換を含むオフラインテストです。

## ドキュメント構成

[README.ja.md](../../README.ja.md) はオペレーターの入口です。セットアップ、収集、アップロードの例を README に置き、詳細は wiki にまとめます。

英語は `README.md` と `wiki/*.md`、日本語は `README.ja.md` と `wiki/ja/*.md` です。更新時は両言語の内容・リンクを揃えてください。新しい項目を追加したら [Home](Home.md) と [_Sidebar](_Sidebar.md) も更新します。コマンド名、引数、JSON キー、API URL は翻訳せず、そのまま記載します。

旧 README にあった `audit_bofs.py`、`regen_cna.py`、`gen_readme.py` はこの checkout にはありません。README 再生成工程はなく、ドキュメントを直接編集します。

## PowerShell 版との違い

- BOF は Beacon プロセス内で動作します。既定の `bark_download_mode on` では対象ディスクに保存せず、`BeaconDownload()` で C2 経由送信します。
- `*_bh` は `BarkGetBH` で `@odata.nextLink` を追跡し、Graph の `value` を `{"kind":"AZ...","data":...}` に変換します。親オブジェクトは `BarkEnumEntityIds`、単独読み取りは `BarkGet` でページングします。旧来の固定配列件数制限はありませんが、実行環境のメモリなどの制約は残ります。
- 列挙、OAuth、PRT リダイレクト、ストリーミングダウンロードの対象リクエストは `HttpRequestWithRetry` により `Retry-After` を考慮して 429 / 5xx を再試行します。状態変更 POST / PATCH を無条件には再送しません。
- 汎用リソースのロール列挙は ARM `/resources` の全 `nextLink` を追跡します。all-info は検証済みスナップショットに収まる場合、既に取得した `AZResource` を再利用します。
- `/subscriptions` が空、403、接続失敗の場合は管理グループの子孫探索にフォールバックします。
- `bark_get_entra_info_bh`、`bark_get_entra_info_legacy_bh`、`bark_get_azurerm_info_bh` は Aggressor alias でサブ BOF を連結します。すべてを実行する単一の巨大 C BOF ではありません。
- RT all-info は15個の Entra コレクターの終了を順に待ちます。HTTP 処理の多いロール・関連収集は上限8ワーカーを使い、エンティティ／ダウンロード処理は1 BOF ずつ動作させます。これにより Beacon コールバックの入れ子と COFF メモリの急増を抑えます。
