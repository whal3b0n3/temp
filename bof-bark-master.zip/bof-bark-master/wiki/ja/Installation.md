# インストールとリポジトリ構成

[English](../Installation.md) | [日本語](Installation.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

<a id="build"></a>
## ビルド

リポジトリのルートで実行します。

```bash
bash build_all.sh
```

`x86_64-w64-mingw32-gcc` と `i686-w64-mingw32-gcc` が必要です。Debian / Ubuntu では `apt install mingw-w64` で導入できます。

## Cobalt Strike へのロード

**Cobalt Strike → Script Manager → Load** から `bark.cna` をロードします。コンパイル済みの `bofs/<category>/` を CNA と同じディレクトリに配置してください。Beacon で `bark_help` を実行すると分類別の一覧、`help bark_<name>` で引数を表示します。

## ディレクトリ構成

```text
bof-bark/
├── bark.cna                 # Cobalt Strike ローダー
├── build_all.sh             # 全 BOF のクロスコンパイル
├── include/                 # 共通 Beacon / HTTP ヘルパー
├── src/                     # 機能別の BOF C ソース
│   ├── token/               # トークン取得
│   ├── entra_read/          # Entra ID / MS Graph の読み取り
│   ├── arm_read/            # Azure Resource Manager の読み取り
│   ├── legacy_bh/           # legacy AAD Graph の BloodHound 出力
│   ├── legacy_cpa/          # 条件付きアクセス解析
│   ├── data_plane/          # Storage / Key Vault の確認
│   ├── write/               # ディレクトリ / RBAC の変更
│   ├── invoke/              # クラウドコマンド実行
│   └── util/                # 解析、変換、収集ヘルパー
└── bofs/                    # .x64.o / .x86.o
```

上流の PowerShell プロジェクトは `.gitmodules` に `BARKKAI` サブモジュールとして設定されています。
