# BloodHound の取り込みとグラフ変換

[English](../BloodHound-Import.md) | [日本語](BloodHound-Import.md)
[Wiki の目次](Home.md) | [実行手順](../../README.ja.md)

## 取り込み形式

`*_bh` BOF は `AZ<Kind>_yyyyMMdd_HHmmss.json` を出力します。ネイティブ envelope は次の形式です。

```json
{
  "data": [
    {"kind": "AZUser", "data": {"id": "<object-id>"}}
  ],
  "meta": {"type": "azure", "version": 5, "count": 1}
}
```

既定の download mode ON では `BeaconDownload()` で C2 経由送信し、対象ディスクには保存しません。OFF では Beacon のカレントディレクトリに書き込みます。[ダウンロードモード](Downloads-and-Archives.md#download-mode-diskless-operation)を参照してください。

256 KiB を超える JSON は一意なパート名で分割し、オペレーター側で再結合します。HTTPS / SMB とも256 KiBに制限し、大きい SMB 転送で先頭領域が繰り返される問題を避けます。後続のディスクレス処理には完了した JSON のパスだけを渡します。

元ディレクトリの全 JSON を送信せず、分類済みバンドルの `UPLOAD_INSTRUCTIONS.txt` に従って取り込みます。各 JSON の役割は [README](../../README.ja.md)の表を参照してください。

## 拡張登録と順序付きアップロード

Administrator で **Administration → OpenGraph Management → Upload File** を開き、`00-install-schema/BARK_OpenGraph_Extension.json` を登録します。メニューがない場合、**Early Access Features → OpenGraph Extension Management** を有効にして再読み込みします。拡張定義は File Ingest に送信しません。

登録後は次を実行します。

```bash
python3 bark_upload.py ./bloodhound-upload --dry-run
python3 bark_upload.py ./bloodhound-upload --username <bloodhound-user>
python3 bark_upload.py ./bloodhound-upload --url https://bloodhound.example --token-file ./bh-session.jwt
```

Python 3.10 以降、外部パッケージ不要です。既定 URL は `http://127.0.0.1:8080`。username 認証は非表示の password prompt を使います。SSO / MFA の場合などは既存の BloodHound session JWT を `--token-file`、`BARK_BH_TOKEN`、または認証オプション省略時の非表示 prompt で渡します。Entra access / refresh token や BloodHound API key pair は session JWT ではありません。

認証前に manifest の SHA-256 と各フェーズ配下のパスを確認します。統合ネイティブファイルを送信してジョブを終了し、失敗ファイル0件の **Complete** を待ってから、第2ジョブで OpenGraph を送信します。第2ジョブも完了まで待ちます。進捗は job ID、stdout は完了通知です。`--dry-run` は認証・接続なしのローカル確認です。拡張の自動登録は行いません。

`--wait-timeout` はジョブごとの秒数で既定1800です。部分成功、失敗、cancel、未知の状態、通信失敗、checksum 変更、timeout は終了コード1で停止します。中断は130です。送信済みジョブは継続する場合があるため、再試行前に File Ingest で ID を確認します。POST は受理済みか不明な場合の重複を避けるため自動再送しません。統合ネイティブフェーズのない standalone / OpenGraph-only バンドルは手動で取り込みます。

旧フォルダー `schema/`、`upload/01-azure-v5/`、`upload/02-opengraph/` にも対応します。ジョブを分ける順序は同じです。

HTTP 契約と状態値は BloodHound v9.3.0 の [upload API](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/packages/go/openapi/src/paths/collection-uploads.file-upload.yaml) と [status enum](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/packages/go/openapi/src/schemas/enum.job-status.yaml) に合わせています。認証、header、polling、2ジョブの順序はローカル HTTP fixture で検証し、そのテストではライブ再取り込みを行っていません。

## エンドポイント未解決の調査

`unable to resolve endpoint: "objectid" equals "..."` は、そのファイルの取り込み時点でネイティブ endpoint が解決できなかったことを示します。ネイティブと OpenGraph を同じジョブに混ぜると、後からノードが存在するようになっても先行する OpenGraph は失敗します。フォルダー名・ファイル名の番号でジョブ内の依存順は保証されません。

フェーズ1単独の **Complete** 後に、**新しいジョブ**でフェーズ2を送信します。既に混在ジョブが終わりネイティブ側が成功していれば、失敗した OpenGraph ファイルだけを再送します。順序問題なら再収集は不要です。

順序を守っても警告が残る場合は、object ID の欠落や重複を native snapshot と DB で確認します。警告を隠すための placeholder node は作りません。[確認済みの事例](OpenGraph-Node-Preservation.md#confirmed-upload-ordering-failure)も参照してください。

## オフライン変換

Cobalt Strike の自動変換がダウンロードを検出できない場合などは、ローカルヘルパーを使用します。

```bash
python3 bark_role_graph.py /path/to/bark/downloads
python3 bark_role_graph.py /path/to/bark/downloads --recursive
python3 bark_role_graph.py /path/to/bark/downloads \
  --bundle-output ./bloodhound-upload
python3 bark_role_graph.py /path/to/bark/downloads \
  --no-gather --graph-output ./AZRoleGraph.json \
  --native-output ./AZNativeRBAC.json
python3 bark_role_graph.py /path/to/bark/downloads --standalone
```

Windows / Linux の Python で使用できます。全パートが揃った `.json.partNNNofMMM` を再結合し、有効な ARM 割り当てを集約・重複排除します。近くの `AZRoleDefinition_*.json` から Unknown ロール名を解決します。

| 出力 | 用途 |
| --- | --- |
| `AZRoleAssignments_Gathered_<timestamp>.json` | 集約結果の確認・調査 |
| `AZRoleGraph_<timestamp>.json` | OpenGraph のロール割り当て |
| `AZNativeRBAC_<timestamp>.json` | ネイティブ RBAC。バンドルでは統合される |
| `AZAppRoleGraph_<timestamp>.json` | app-role assignment が存在する場合の型を考慮したグラフ |
| `BARK_BloodHound_Bundle_<timestamp>/` | 分類済みアップロード用バンドル |

```text
BARK_BloodHound_Bundle_<timestamp>/
├── 00-install-schema/   # 拡張登録
├── 01-upload-native/    # azurehound_bark.json を単独送信
├── 02-upload-opengraph/ # ネイティブ完了後の別ジョブ
├── do-not-upload/
│   ├── native-source/  # 統合に使った元ファイル
│   └── ...             # 生データ、診断、空、未対応の入力
├── BARK_UPLOAD_MANIFEST.json
└── UPLOAD_INSTRUCTIONS.txt
```

対応する種類を持つ空でない AzureHound v5 envelope だけを `azurehound_bark.json` に統合します。関係レコードを先、完全なエンティティを後、最後に SP と App の順に配置し、関係変換で作られた部分ノードが最後の状態にならないようにします。

元ネイティブファイルは `do-not-upload/native-source/` に保存し、別途送信しません。`.part*` は含めず、再結合された RoleDefinition、生の resource role assignments、Gathered、CAP 生レスポンス、空 envelope、未対応種類は確認用に分類します。変換入力が曖昧な `AZBase` ノードとして取り込まれることを防ぎます。

拡張定義は BARK の node / relationship kind を宣言し、解析で確認された capability edge だけを traversable にします。PIM eligibility と `BARK_Potential_*` は非 traversable です。

manifest には分類理由、統合先、元パート数、byte 数、SHA-256、統合レコード順を記録します。`--no-bundle` で graph / native / gather だけの動作にできます。

## ネイティブノードの保護と CAP

関係 endpoint は BloodHound 9.0 が対応する `objectid` の property matching を使います。CAP はネイティブ user / group の `cap_policies` 配列です。名前、表示名、tenant、enabled、custom source kind を出力しません。BloodHound 自体は通常の object ID、lastseen、primarykind を更新します。

バンドルは native snapshot から対象と kind を確認し、未一致分を audit metadata に残します。旧 annotation node / MFA番号プロパティはバンドルのコピー内で変換し、元ファイルは変更しません。CAP edge は生成しません。必ず native ingestion を先に完了させてください。[移行の詳細](OpenGraph-Node-Preservation.md)を参照してください。

## Entra アプリロール

ネイティブ `AZAppRoleAssignment` 変換は principalType を使わず、既知の Microsoft Graph permission ID だけを認識します。カスタムロールを表し、user / group に部分 SP ノードを作らないため、次を生成します。

```text
AZUser / AZGroup / AZServicePrincipal
    -[BARK_AssignedAppRole]-> BARK_AppRole
    -[BARK_AppRoleOf]-> AZServicePrincipal
```

`resourceId` と `appRoleId` を `AZServicePrincipal.appRoles` に照合し、Flag / User などの名前を解決します。ID は `BARK_APPROLE_<RESOURCE_OBJECT_ID>_<APP_ROLE_ID>` の形式から句読記号を除き、コロンを含めません。principal kind は収集済み user / group / SP から判定します。

ネイティブ統合には、BloodHound が認識する Microsoft Graph ロールへの SP 割り当てだけを保持します。user / group、custom role、Graph 以外への割り当ては OpenGraph で表し、除外理由・件数を manifest と metadata に記録します。

`appRoles` は利用可能なロールの定義で、割り当て先を示しません。`AZAppRoleAssignment_*.json` がなければエッジは復元できません。pull だけで旧収集データは変わらないため、必要なら新 BOF で Entra / all-info を再実行します。

## RBAC からの権限解析

`actions` / `dataActions` の wildcard を解決し、`notActions` / `notDataActions` を除外します。対応 ABAC 条件、deny、収集済み group membership を評価し、PIM eligibility と active access を分離します。管理グループの子孫 snapshot がある場合は既知の子孫 scope に継承を反映します。

deny snapshot がないことを「deny がない」と見なさず unknown にします。group 親列挙や途中ページの失敗も不完全として扱い、未観測の祖先グループ deny を含む可能性は confirmed edge にしません。

`AZPermissionGraph_<timestamp>.json` は権限エッジ、`AZPermissionFindings_<timestamp>.json` は confirmed / unknown、deny、ABAC、PIM metadata の audit 出力です。Findings はアップロードしません。PIM metadata は基本型プロパティへ平坦化し、生の ARM PIM / deny は対応 native model と完全一致する場合を除き変換入力として保持します。

未対応 ABAC、ロール定義不足、scope ancestry 不足、deny 不完全は unknown です。不確実な経路を確認する場合は `--include-potential-edges`、解析を無効化する場合は `--no-permission-analysis`、独自 catalog は `--capability-catalog <path>` を使用します。既定 catalog は RBAC 割り当て／昇格、custom role 定義更新、VM RunCommand、managed identity 割り当て、Storage key 取得を扱います。

既定 RoleGraph は既存ネイティブノードを property matching で参照し、endpoint kind や payload の `source_kind` を宣言しません。関係名は `BARK_*`、文字は `^[A-Za-z0-9_]+$` に正規化します。`--standalone` は `BARK_Azure*` のコピーを `BARK_ENTITY_<original-id>` で生成し、native ID との衝突を防ぎます。

ネイティブ RBAC はロール名から推測せず、組み込み definition ID と対応 wrapper を使います。Owner、Contributor、User Access Administrator、Key Vault Contributor、Avere Contributor、VM Administrator Login、Virtual Machine Contributor、対応する Storage / Automation / Logic / Function / Web / ACR / AKS / VMSS の割り当てを扱います。ローカル変換は entity から Function / Web App を識別し、対象側変換で曖昧な `Microsoft.Web/sites` は OpenGraph に残します。

## AzureHound プロパティ互換性

元 Graph / ARM 情報に加えて、次の別名・派生値を出力します。

| 元 | 互換プロパティ |
| --- | --- |
| `verifiedDomains` | tenant の `domains` / `defaultDomain` |
| `countryLetterCode` | `countryCode` |
| SP の `publishedPermissionScopes` | `oauth2PermissionScopes` |
| device の `extensionAttributes` | `onPremisesExtensionAttributes` |
| resource SP | app-role assignment の `appId` |

user は `mailboxSettings` / `signInActivity` の互換構造を持ちます。signInActivity が読めれば統合し、権限エラーは非致命的に扱って空構造を出力します。VM の `plan` / `extendedLocation` は実値を保持し、ARM が省略した場合は空オブジェクトにします。

独立した JSON 文書を `cat` で連結しないでください。`cat` を使えるのは同一ファイルの順序付き分割パートの再結合です。
