# BloodHound import and graph conversion

[English](BloodHound-Import.md) | [日本語](ja/BloodHound-Import.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## BloodHound import

The `*_bh` BOFs emit a BloodHound-compatible JSON envelope:

```json
{
  "data": [
    {"kind": "AZUser", "data": { ... }},
    ...
  ],
  "meta": {"type": "azure", "version": 5, "count": 42}
}
```

Each `*_bh` BOF produces an `AZ<Kind>_yyyyMMdd_HHmmss.json` result. Download
mode is enabled by default, so results are sent through the C2 channel via
`BeaconDownload()` and no files touch the target disk. With download mode OFF,
the files are written to the Beacon's current working directory. See
[Download mode](Downloads-and-Archives.md#download-mode-diskless-operation).

JSON results larger than 256 KiB are sent as uniquely named parts and
automatically reassembled on the operator side. The 256 KiB limit is kept for
both HTTPS and SMB-linked Beacons because larger SMB transfers can repeat the
first part and produce invalid JSON. Later
diskless processing receives only the completed `.json` path.

Prepare the classified upload bundle using the offline helper below. Install its schema,
then ingest phase 1 and phase 2 in order through BloodHound's
`Administration -> File Ingest`. Follow the bundle's `UPLOAD_INSTRUCTIONS.txt`;
do not upload every source JSON file.

### Ordered upload with Python

Install the bundle's OpenGraph extension first, then run:

```bash
python3 bark_upload.py ./bloodhound-upload --dry-run
python3 bark_upload.py ./bloodhound-upload --username <bloodhound-user>
# Remote BloodHound, or an existing BloodHound session JWT:
python3 bark_upload.py ./bloodhound-upload --url https://bloodhound.example --token-file ./bh-session.jwt
```

Python 3.10+ is required; no third-party packages are needed. The default
address is `http://127.0.0.1:8080`. Username authentication prompts for the
password without echoing it. For SSO/MFA accounts, supply an existing session
JWT with `--token-file`, `BARK_BH_TOKEN`, or the hidden prompt shown when
neither authentication option is given. Entra access/refresh tokens and
BloodHound API-key pairs are not session JWTs.

New bundles place `00-install-schema/`, `01-upload-native/`, and
`02-upload-opengraph/` directly at the bundle root. The uploader also accepts
older bundles with `schema/`, `upload/01-azure-v5/`, and
`upload/02-opengraph/`; their two-job upload order is unchanged.

The uploader checks manifest SHA-256 values and confines input paths to the
bundle's phase directories before authentication. It submits the merged
native file, ends that job, and waits for status Complete with no failed files.
Only then does it submit OpenGraph files in a second job. It also waits for
that job to complete. Progress shows job IDs; stdout reports completion.
`--dry-run` checks local inputs without connecting or requesting credentials.
The extension must already be installed; the uploader does not install it.

`--wait-timeout` sets the wait limit per job in seconds (default 1800).
Partial success, failed/cancelled jobs, unknown status, connection errors,
checksum changes, or timeouts stop the workflow with exit code 1.
An interruption exits with 130. Already submitted jobs may continue running;
inspect their IDs in File Ingest before retrying. Upload POSTs are not
automatically retried because an uncertain response can hide an accepted
request. The helper requires a bundle containing a merged native phase;
standalone or OpenGraph-only bundles use manual import.

The HTTP contract and status values follow BloodHound v9.3.0's
[upload API](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/packages/go/openapi/src/paths/collection-uploads.file-upload.yaml)
and [job status enum](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/packages/go/openapi/src/schemas/enum.job-status.yaml).
A local HTTP fixture tests authentication, file headers, polling, and the
two-job sequence; no live reimport was performed as part of that test.

### Troubleshooting unresolved endpoints

`unable to resolve endpoint: "objectid" equals "..."` means an edge's
native endpoint could not be resolved when that graph file was ingested.
Submitting native and OpenGraph files together can produce this warning even
if the native nodes appear in the database later. A filename prefix or
directory ordering does not force dependency ordering inside one upload job.

Submit phase 1 alone and wait for **Complete**, then submit phase 2 as a
**new job**. If a mixed job already finished and native ingestion succeeded,
retry just the failed OpenGraph files from `02-upload-opengraph/`.
No recollection is needed for an ordering failure. If warnings persist after
ordered ingestion, check the reported object IDs against the native snapshot
and database; missing collection data or duplicate object IDs require their
own diagnosis. Do not replace lookups with native placeholder nodes to hide
the warning. See the [confirmed ordering incident](OpenGraph-Node-Preservation.md#confirmed-upload-ordering-failure).

### Rebuilding ARM role assignments and RoleGraph offline

If the Cobalt Strike client downloads the ARM role-assignment files but the
automatic RoleGraph conversion cannot observe those downloads, run the bundled
client-side helper against the download directory:

```bash
# Windows or Linux; Python 3 only, with no third-party packages
python3 bark_role_graph.py /path/to/bark/downloads

# Scan nested Cobalt Strike download directories
python3 bark_role_graph.py /path/to/bark/downloads --recursive

# Choose the classified upload-bundle directory
python3 bark_role_graph.py /path/to/bark/downloads \
  --bundle-output ./bloodhound-upload

# Choose the BloodHound OpenGraph and native RBAC output paths
python3 bark_role_graph.py /path/to/bark/downloads \
  --no-gather --graph-output ./AZRoleGraph.json \
  --native-output ./AZNativeRBAC.json

# Build an isolated graph if the native Azure entity files are not imported
python3 bark_role_graph.py /path/to/bark/downloads --standalone
```

The helper safely reassembles every complete `.json.partNNNofMMM` group,
including large `AZServicePrincipal_*.json` results. It gathers and
deduplicates effective ARM assignments, resolves `Unknown` roles from a nearby
`AZRoleDefinition_*.json`, and writes:

- `AZRoleAssignments_Gathered_<timestamp>.json` for review and troubleshooting.
- `AZRoleGraph_<timestamp>.json` for BloodHound OpenGraph import.
- `AZNativeRBAC_<timestamp>.json` for AzureHound-compatible native RBAC ingest.
- `AZAppRoleGraph_<timestamp>.json` for type-safe Entra app-role OpenGraph
  import when `AZAppRoleAssignment` data is present.
- `BARK_BloodHound_Bundle_<timestamp>/`, a classified import directory.

The bundle makes the upload decision explicit:

```text
BARK_BloodHound_Bundle_<timestamp>/
├── schema/                 # install the Structured OpenGraph extension first
├── 01-upload-native/   # upload only azurehound_bark.json first
├── 02-upload-opengraph/  # upload after phase 1 has finished ingesting
├── do-not-upload/
│   ├── native-source/    # native source copies already included in the merge
│   └── ...               # raw, diagnostic, empty, or unsupported inputs
├── BARK_UPLOAD_MANIFEST.json
└── UPLOAD_INSTRUCTIONS.txt
```

Only non-empty AzureHound v5 envelopes whose kinds are supported by the
current AzureHound ingestion model are included in the single phase-1 file,
`azurehound_bark.json`. Relationship records are ordered before complete entity
records, with `AZServicePrincipal` followed by `AZApp` at the end. This prevents
partial nodes created while BloodHound converts app-role assignments and
service-principal links from becoming the final version of a node and leaving
its name equal to the Object ID. The individual native source files are kept
under `do-not-upload/native-source` for auditing and must not be uploaded
separately. Valid OpenGraph payloads are placed in phase 2. Original `.part*`
chunks are never copied into the bundle. Reassembled `AZRoleDefinition_*.json`, raw
`*RoleAssignments_Resource_*.json`, `AZRoleAssignments_Gathered_*.json`, raw
Conditional Access responses, empty envelopes, and unsupported native kinds
are retained under `do-not-upload` for conversion or troubleshooting. This
prevents conversion inputs from appearing as ambiguous `AZBase` nodes.

Install `00-install-schema/BARK_OpenGraph_Extension.json` before uploading either data
phase. The extension declares BARK node and relationship kinds and marks only
confirmed permission relationships as traversable. PIM eligibility and
`BARK_Potential_*` relationships remain non-traversable. The schema file is an
extension definition and must not be uploaded as graph data.

### Native node preservation

Native references require property-based OpenGraph endpoint matching (supported
by BloodHound 9.0). CAP observations are stored directly in the native user's
or group's `cap_policies` string-array property. CAP files emit only that
property, the principal ID, and its native kind; they contain no name,
display name, tenant, enabled-state, or custom source-kind updates.
BloodHound also writes its usual object ID, last-seen, and primary-kind fields.
The bundler matches the principal against the collected native snapshot and
uses that snapshot's kind. Unmatched observations remain in audit metadata.
Older annotation nodes and MFA-numbered properties are converted in bundle
copies; the originals are unchanged. No annotation edge is emitted.
Always ingest the native phase completely before CAP data.
See [node preservation and migration](OpenGraph-Node-Preservation.md) for the
cause, validation results, and handling previously imported data.

### Entra app-role assignments

BloodHound's native `AZAppRoleAssignment` conversion does not use
`principalType` and recognizes only its built-in Microsoft Graph permission
IDs. To preserve custom roles and avoid creating partial service-principal
nodes for User or Group principals, the helper produces this OpenGraph path:

```text
AZUser / AZGroup / AZServicePrincipal
    -[BARK_AssignedAppRole]-> BARK_AppRole
    -[BARK_AppRoleOf]-> AZServicePrincipal (resource application)
```

Role names such as `Flag` or `User` are resolved by matching the assignment's
`resourceId` and `appRoleId` to `AZServicePrincipal.appRoles`. App-role node IDs
use the collision-resistant form
`BARK_APPROLE_<RESOURCE_OBJECT_ID>_<APP_ROLE_ID>` with punctuation removed;
they contain no colon. The principal kind is resolved from collected AZUser,
AZGroup, and AZServicePrincipal entities instead of trusting a missing or
incorrect `principalType` value.

The merged native upload retains only service-principal assignments to one of
BloodHound's recognized Microsoft Graph roles. User/Group assignments, custom
roles, and assignments to non-Microsoft Graph resources are excluded from the
native payload after being represented in OpenGraph. Exclusion counts and
reasons are recorded in `BARK_UPLOAD_MANIFEST.json` and the merged envelope's
metadata.

`AZServicePrincipal.appRoles` defines available roles but does not identify
who is assigned to them. If the input directory has no
`AZAppRoleAssignment_*.json`, the helper cannot reconstruct those edges. Data
collected by an older BOF is not changed by pulling this repository; rerun
`bark_get_entra_info_bh` (or the corresponding all-info collector) with the
newly built BOFs, then run `bark_role_graph.py` against that new download.

The manifest records the merge target or classification reason, source part
count, byte size, and SHA-256 for every bundled JSON file, plus the checksum and
record ordering of the merged upload. Use `--no-bundle` to retain the older
graph/native/gather-only behavior.

### Permission analysis and privilege-derived edges

The same helper also analyzes the collected Azure RBAC snapshot. It resolves
wildcards against `actions`/`dataActions`, subtracts `notActions` and
`notDataActions`, evaluates supported Azure ABAC conditions, applies deny
assignments, expands collected group membership, and keeps PIM eligibility
separate from active access. Management-group role assignments are collected
by the all-info workflow and are propagated to known descendant scopes when
the management-group descendant snapshot is present. A missing deny-assignment
snapshot is treated as `unknown`, not as proof that no deny assignment exists.
A Group Member collection that failed parent enumeration or any paginated
member request is also marked incomplete; possible unobserved ancestor-group
denies remain `unknown` instead of becoming confirmed permission edges.

When findings or confirmed edges exist, it writes:

- `AZPermissionGraph_<timestamp>.json` — OpenGraph `BARK_*` permission edges.
- `AZPermissionFindings_<timestamp>.json` — audit output, including
  `confirmed`, `unknown`, deny decisions, ABAC decisions, and PIM policy
  metadata. This file is classified as do-not-upload. PIM policy metadata is
  flattened to primitive OpenGraph properties; raw ARM PIM/deny records are
  retained as conversion inputs and are not uploaded as native AzureHound
  records unless their shape matches the AzureHound model exactly.

The default analyzer is conservative: unsupported ABAC syntax, missing role
definitions, incomplete scope ancestry, or incomplete deny-assignment data are
reported as `unknown` and never become confirmed edges. Use
`--include-potential-edges` only when reviewing those uncertain paths. Use
`--no-permission-analysis` to disable the layer, or
`--capability-catalog <path>` to provide an organization-specific capability
catalog. The bundled catalog covers RBAC assignment/escalation, custom role
definition writes, VM RunCommand, managed-identity assignment, and storage
account key retrieval.

The default RoleGraph is a native-link payload: import the normal BARK Entra
and ARM entity JSON from phase 1 first, then import phase 2. It declares no
custom copies of BloodHound's built-in `AZ*` node kinds and instead references
those existing nodes by canonical Azure object ID using property matching.
It does not assert native endpoint kinds. Relationship kinds are
namespaced as `BARK_*` and sanitized to BloodHound's required
`^[A-Za-z0-9_]+$` form. The payload intentionally has no OpenGraph
`source_kind`, because it links to native Azure nodes. Use `--standalone` to
emit importable `BARK_Azure*` endpoint nodes when a native Azure graph is not
already present. These copies use `BARK_ENTITY_<original-id>` IDs so that they
cannot collide with native Azure entities.

The native output follows AzureHound's supported ARM surface rather than
guessing from role names. Built-in role-definition IDs are used for native
Owner, Contributor, User Access Administrator, Key Vault Contributor, Avere
Contributor, VM Administrator Login, and Virtual Machine Contributor records.
Storage Account, Automation Account, Logic App, Function App, Web App,
Container Registry, Managed Cluster, and VM Scale Set assignments use their
native AzureHound role-assignment wrappers. The offline helper uses the nearby
resource entity files to distinguish Function Apps from Web Apps; the
target-side converter leaves an ambiguous `Microsoft.Web/sites` assignment in
OpenGraph instead of assigning the wrong native kind.

### AzureHound property compatibility

BARK preserves its broader Graph/ARM properties and adds AzureHound-compatible
output aliases and derived fields. Tenant `domains` and `defaultDomain` are
derived from `verifiedDomains`; `countryCode` comes from `countryLetterCode`.
Service-principal `publishedPermissionScopes` is emitted as
`oauth2PermissionScopes`, device `extensionAttributes` as
`onPremisesExtensionAttributes`, and app-role assignments are enriched with
the resource service principal's `appId`. Users include AzureHound-compatible
`mailboxSettings` and `signInActivity` shapes. When the token can read
`signInActivity`, its real value is merged; an authorization failure is
non-fatal and produces the empty compatibility shape. VM `plan` and
`extendedLocation` are preserved when present and emitted as empty objects
when ARM omits them.

Do not concatenate independent role-assignment JSON files with `cat`; that
creates adjacent JSON documents rather than one valid JSON document. `cat` is
only valid for ordered parts of one split file.
