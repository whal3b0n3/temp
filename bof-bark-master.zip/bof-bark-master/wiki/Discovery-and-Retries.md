# Discovery, pagination, and retries

[English](Discovery-and-Retries.md) | [日本語](ja/Discovery-and-Retries.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Management group fallback

The ARM `/subscriptions` endpoint requires the caller to have Reader (or
higher) RBAC at the subscription scope.  Tokens obtained outside the
Azure Portal (e.g. via refresh token, ROPC, or PRT cookie flows) often
lack this implicit grant, causing `/subscriptions` to return an empty
list even though the user **can** see subscriptions in the Portal.

`bark_get_all_azurerm_subscriptions` and
`bark_get_all_azurerm_subscriptions_bh` now include a **transparent
fallback**: when the initial `/subscriptions` call returns zero results
**or an HTTP error** (e.g. 403 Forbidden due to missing direct RBAC),
the BOF automatically:

1. Enumerates management groups via
   `GET /providers/Microsoft.Management/managementGroups`
2. For each group, fetches descendants via
   `GET .../managementGroups/{name}/descendants`
3. Filters descendants of type `microsoft.resources/subscriptions`
4. Fetches each discovered subscription individually via
   `GET /subscriptions/{id}`

This mirrors how AzureHound discovers subscriptions through management
groups, but goes further by falling back to per-subscription GET
requests rather than relying on the list endpoint.  Both the raw
(`bark_get_all_azurerm_subscriptions`) and BH-format
(`bark_get_all_azurerm_subscriptions_bh`) variants trigger the fallback
on any failure — empty results, HTTP 403, or connection errors.

### Additional discovery BOFs

Three standalone BOFs are available for manual discovery when the
automatic fallback isn't enough or when you want to inspect the
hierarchy directly:

| Command | Description |
|---|---|
| `bark_get_all_azurerm_management_groups` | List all management groups (paginated) |
| `bark_get_all_azurerm_management_group_descendants` | List descendants of a specific management group (paginated) |
| `bark_get_all_azurerm_subscriptions_via_resource_graph` | Discover subscriptions via Azure Resource Graph KQL query |

### Recommended client ID for ARM tokens

When acquiring tokens for ARM collection, prefer the **Azure CLI**
client ID (`04b07795-8ddb-461a-bbee-02f9e1bf7b46`) — it has broader
pre-consented ARM scopes than Azure PowerShell and is more likely to
have the Management.Read permission needed for the fallback path.

```
beacon> bark_get_tokens_with_rt https://management.azure.com 04b07795-8ddb-461a-bbee-02f9e1bf7b46 <refreshToken> <tenantId>
```

## Pagination and rate-limit handling

### Full pagination

BOFs that auto-enumerate parent entities (groups, apps, service
principals, devices, subscriptions, resources) before fetching their
children now **follow `@odata.nextLink` on the parent listing** and
store results in a dynamically growing array.  Previously, parent
enumeration was limited to a single page of up to 999 results, further
capped by a static 256-element array -- tenants with more than 256
groups/apps/service principals would silently miss entities.

Standalone read BOFs (management groups, management group descendants,
and all other `BarkGet`-based BOFs) also follow `@odata.nextLink`
pagination, so large result sets are fetched completely.

Affected helpers: `BarkGetBHGraphAutoEnum`, `BarkGetBHGraphGrouped`,
`BarkGetBHGraphGroupedEx`, `BarkGetBHLegacyAutoEnum`,
`BarkGetBHGraphGroupedLegacy`, `BarkGetBHAllSubscriptions`,
`BarkGetBHAllResourceRoleAssignments`, `BarkGet`, and the standalone
`get_entra_group_owner_bh` BOF.

### HTTP retry with backoff

All outgoing HTTP paths apply proactive pacing (50 ms globally and at least
100 ms for Graph). Idempotent requests and OAuth token exchanges use
`HttpRequestWithRetry`, which honors numeric `Retry-After` and automatically
retries transient errors. State-changing POST/PATCH requests are paced and
feed 429 guidance into the limiter, but are not automatically replayed:

| Status | Backoff | Max retries |
|---|---|---|
| HTTP 429 (throttled) | 10 s, 20 s, 30 s | 3 |
| HTTP 5xx (server error) | 2 s, 4 s, 8 s (exponential) | 3 |
| Connection failure | 2 s, 4 s, 8 s (exponential) | 3 |

Each retry is logged to the beacon console so the operator can see
throttling in progress:

```
[*] HTTP 429 — retrying in 10 seconds (attempt 1/3)
```

Non-retryable errors (4xx other than 429) are returned immediately. OAuth
token requests retry only transient transport, 429, and 5xx failures; normal
authentication failures remain visible immediately.
