# Python collector

[English](Python-Collector.md) | [日本語](ja/Python-Collector.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

[bark_all_info.py](../bark_all_info.py) is the local Python counterpart of
the registered CNA command `bark_get_all_info_bh_rt`
(sometimes referred to as `bark_get_all_info_rt_bh`).
It needs Python 3.10 or later and uses the standard library. Keep the script
in this checkout: bundle generation imports the existing graph and permission
analysis helpers and uses the repository's capability catalog.

Run it from the repository:

```bash
python3 bark_all_info.py <tenant-guid-or-domain> --output ./bark-results
```

Enter the refresh token at the hidden prompt. Alternatively, supply a UTF-8
token file using `--refresh-token-file /path/to/token.txt`, or set
`BARK_REFRESH_TOKEN` in the process environment. There is deliberately no
command-line argument containing the token itself. Tokens and rotated refresh
tokens stay in memory and are not written to the output.

The tenant can be a GUID or a verified domain, such as `megabigtech.com`.
Domains are resolved through Microsoft's public OpenID configuration before
authentication. The resolved GUID is used for token requests, legacy URLs,
BloodHound identifiers, and the collection manifest. This version targets
the public Azure cloud; `common` and `organizations` are not collection tenants.
Use `--client-id <guid>` to select one OAuth client; otherwise it uses
BARK's audience-specific ranking. The supplied refresh token and its delegated
permissions determine which requests can succeed.

To obtain tokens locally, use [Python token commands](Python-Tokens.md).
The token CLI's `--refresh-token-output` file can be passed directly to this
collector's `--refresh-token-file` option.

## Collection coverage

| Stage | Python behavior |
| --- | --- |
| Authentication | v1 refresh-token exchange, refresh-token rotation, access-token cache per audience, expiry handling, one refresh after HTTP 401 |
| Entra | Tenant, users, groups, devices, directory role definitions and assignments, applications, service principals |
| Relationships | Group membership and ownership, registered device owners, application and service-principal owners, federated identity credentials |
| App roles | Every collected resource service principal's `appRoleAssignedTo`; user, group, and service-principal assignments feed the existing custom app-role graph converter |
| Legacy fallback | AAD Graph identity collection if modern identity or relationship collection is incomplete; retained separately in `*_legacy.json` |
| Conditional Access | The same legacy policies endpoint, original policy documents, and native user/group `cap_policies` properties for enabled MFA/block policies' exclusions |
| Azure inventory | Subscriptions, management groups and descendants, resource groups, resources, VMs, VM scale sets, vaults, storage, Logic Apps, Web/Function Apps, AKS, ACR, Automation, Container Apps/Instances, Cosmos DB |
| Azure authorization | Role definitions, subscription/resource/management-group role assignments, deny assignments, PIM eligibility/assignment instances, role-management policy assignments and policies |
| Data plane | Storage container names and Key Vault secret metadata, with pagination; no blob contents or secret values |
| Conversion | Existing native RBAC, app-role OpenGraph, permission findings/graph, and phased BloodHound upload bundle |

All collection requests are GETs; only OAuth exchanges use POST.
The HTTP layer retries transient failures and throttling, honors Retry-After
(up to five minutes), rejects redirects and foreign pagination hosts, and
retains records from successful pages when a later page fails.

## Concurrent collection

The default is `--workers 8`, matching the BOF's parent-worker count. Set
between 1 and 32 workers:

```bash
python3 bark_all_info.py megabigtech.com --workers 8
python3 bark_all_info.py megabigtech.com --workers 1
```

Independent Entra entity queries, parent relationships, application-role
assignments, ARM resource families/scopes, and data-plane metadata probes
run concurrently. Discovery and output dependencies remain ordered.
Each individual query follows its own pagination sequentially.

The worker limit applies across each stage; nested pools do not multiply it.
At most twice the worker count is submitted at a time. Results are merged
and written on the main thread in input order, preserving deterministic JSON
and explicit partial-collection coverage. The manifest records the worker count.

Each worker has its own HTTP handlers. OAuth exchanges are serialized because
the refresh token is shared and may rotate between audiences. Concurrent
rejections of an old access token reuse a refreshed cached token when another
worker has already replaced it.

Use `--workers 1` for sequential troubleshooting, or lower the worker count
if throttling increases. Retry-After handling still applies per request.
On interruption, queued jobs are cancelled and retry waits are interrupted;
an in-flight network call can take up to its configured timeout to return.

An offline fixture with 44 requests and 20 ms simulated latency per request
took about 0.90 seconds with one worker and 0.30 seconds with eight, producing
identical JSON. This measures scheduling overhead and concurrency, not live
Azure performance.

## Outputs and completeness

Standard output shows one summary per saved Azure collection, such as
`[+] AZUser: Found 123 objects`, and a final completion line with the output directory.
Grouped owner/member and directory role-assignment files report the number of
relationships, rather than the number of parent wrappers. Federated identity
credentials count the credentials themselves. Counts cover the records saved in
that collection, not unique principals across files; legacy collections have a
`_legacy` suffix. Partial collections include `(incomplete collection)`, so a zero
count after a failed request does not imply the tenant contains no objects.
Individual objects and per-parent owner/member results remain suppressed. Errors still appear
on standard error and collection failures remain in the manifest. When bundle
conversion runs, its standard output is saved to `bundle_conversion.log`
in the collection directory; converter errors remain on standard error.

Each run creates a new directory beneath `--output`, for example:

```text
bark-results/BARK_<UTC timestamp>/
  AZUser.json
  AZGroupMember.json
  AZAppRoleAssignment.json
  AZDenyAssignment.json
  ConditionalAccessPolicies.json
  AZConditionalAccessGraph.json
  DataPlaneProbes.json
  collection_manifest.json
  BARK_BloodHound_Bundle_<timestamp>/
```

Follow the generated bundle's `UPLOAD_INSTRUCTIONS.txt`: install its OpenGraph schema, ingest
phase 1 native JSON, and then phase 2 OpenGraph JSON. Source/support files
are not all directly ingestible. Custom application roles appear through
the generated `BARK_AssignedAppRole` relationships.

`collection_manifest.json` lists failures, skipped stages, and conversion
status. Collection envelopes contain `meta.collection.complete`; relationship
snapshots also record parent coverage, and authorization snapshots record
scope coverage. A 403 or failed page is not an authoritative empty result.
A successful fallback does not erase an earlier failure. Missing optional
sign-in activity is also reported, although it does not trigger legacy fallback.

Exit codes:

- `0`: requested stages completed without recorded failures.
- `2`: partial results or unsuccessful bundle conversion; also used for invalid CLI arguments.
- `1`: local setup/I/O/import failure.
- `130`: interrupted; completed JSON files and an incomplete manifest remain.

Useful options: `--workers 8`, `--no-probes`, `--no-bundle`,
`--no-legacy-fallback`, `--timeout 60`, and `--retries 4`.
Skipping legacy fallback does not skip the separate legacy Conditional Access
query. Completeness describes responses for the requested scope visible to
the authenticated principal; it does not prove tenant-wide visibility.

## Differences from the Beacon workflow

This reproduces collection and conversion locally, not Cobalt Strike transport.
JSON is encoded to temporary files and atomically renamed. It does not use
BeaconDownload, so its 256/512 KB transfer behavior is not involved. API paging
is independent of local file size. A collection is currently accumulated in
memory before writing; allow sufficient RAM for large tenants.

The Python collector defaults to eight concurrent jobs across independent
queries. The BOF uses eight-worker parent pools and separate relationship-family
threads; Python uses one bounded pool per collection stage. There is no C2
download, temporary ZIP staging, or password-protected ZIP option.
The raw JSON remains on the local machine.

The legacy APIs are attempted to match the CNA workflow; their availability
and permission support can differ by tenant. Legacy directory roles cover
activated roles, and legacy service-principal app-role collection has the
same outgoing-assignment scope as the BOF; it cannot replace the modern
incoming assignments for user/group coverage. Federated credentials are
collected through modern Graph only.

Conditional Access observations use the native principal's `cap_policies`
array. The CAP payload omits identity fields such as names and tenant IDs.
See [node preservation](OpenGraph-Node-Preservation.md) for import compatibility.

Conditional Access annotations retain full policy conditions as JSON text
rather than duplicating the BOF's property wording. They describe exclusions,
not a finding that a particular sign-in can bypass MFA. Policy evaluation
and effective authorization still depend on runtime context.

## Offline verification

```bash
python3 -m unittest discover -s tests
```

Collector tests use a fake HTTP tenant. They exercise token rotation and
expiry, client fallback, throttling, API pagination, cross-host rejection,
partial-result coverage, legacy fallback, management-group subscription
discovery, metadata probes, interruption, multi-megabyte JSON integrity,
conversion into a real upload bundle, bounded concurrency, concurrent token
refresh, cancellation, and serial/parallel output equivalence. They do not authenticate to a
live Azure tenant or validate ingestion in a running BloodHound instance.
