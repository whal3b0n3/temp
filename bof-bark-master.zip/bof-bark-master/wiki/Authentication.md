# Authentication

[English](Authentication.md) | [日本語](ja/Authentication.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Resource URL input

For authentication commands that take a resource, pass only the URL, such as
`https://graph.microsoft.com` or `https://management.azure.com`.
Password and client-credentials commands construct the v2 scope internally;
RT and PRT commands already use resource identifiers. You do not need to type
`/.default`. Existing explicit v2 scopes remain accepted by the Beacon BOFs.

Use [Python token commands](Python-Tokens.md) to perform the same authentication
tasks locally and save refresh tokens for `bark_all_info.py`.

### Authentication with Client ID auto-detection

The token BOFs support automatic client ID fallback when `clientId`
is omitted or passed as `""`:

- `bark_get_tokens` -- unified refresh-token, username/password, or PRT flow
- `bark_get_tokens_with_rt` -- refresh token grant
- `bark_get_tokens_with_up` -- username/password (ROPC) grant
- `bark_get_token_with_prt_cookie` -- PRT cookie flow

When no `clientId` is provided, the BOF tries all six known first-party
clients in a resource-aware capability order. Broader directory clients lead
Graph requests, management clients lead Azure resource/data-plane requests,
and Microsoft 365 clients lead service-specific requests:

| Requested resource | Client attempt order |
|---|---|
| Microsoft Graph | Azure CLI → AAD PowerShell → Teams → Office → Azure PowerShell → SharePoint |
| Legacy AAD Graph | AAD PowerShell → Azure CLI → Azure PowerShell → Office → Teams → SharePoint |
| ARM, Storage, or Key Vault | Azure CLI → Azure PowerShell → AAD PowerShell → Office → Teams → SharePoint |
| Office, Outlook, SharePoint, or Teams | Office → Teams → SharePoint → Azure CLI → Azure PowerShell → AAD PowerShell |

The known application IDs are Azure CLI
`04b07795-8ddb-461a-bbee-02f9e1bf7b46`, Azure PowerShell
`1950a258-227b-4e31-a9cf-717495945fc2`, AAD PowerShell
`1b730954-1685-4b74-9bfd-dac224a7b894`, SharePoint
`d326c1ce-6cc6-4de2-bebc-4591e5e13ef0`, Microsoft Office
`d3590ed6-52b3-4102-aeff-aad2292ab01c`, and Microsoft Teams
`1fec8e78-bce4-4aaf-ab1b-5451cc387264`.

On success the output includes the winning `client_id` alongside the
token:

```
[*] Trying 1/6: Microsoft Azure CLI (04b07795-...)...
[+] access_token: eyJ...
[+] refresh_token: eyJ...
[+] client_id: 04b07795-8ddb-461a-bbee-02f9e1bf7b46 (Microsoft Azure CLI)
```

Pass an explicit `clientId` to skip auto-detection and use a specific
application.

### Examples

**Get an MS Graph token with a refresh token (auto-detect client ID):**

```
beacon> bark_get_tokens_with_rt https://graph.microsoft.com "" <refreshToken> <tenantId>
```

**Get an ARM token with username/password (auto-detect client ID):**

```
beacon> bark_get_tokens_with_up <tenantId> <username> <password> https://management.azure.com
```

**Get a token via PRT cookie (auto-detect client ID):**

```
beacon> bark_get_token_with_prt_cookie <prtToken> https://graph.microsoft.com <tenantId>
```

**Get an MS Graph token with a specific client ID:**

```
beacon> bark_get_tokens_with_rt https://graph.microsoft.com 04b07795-8ddb-461a-bbee-02f9e1bf7b46 <refreshToken> <tenantId>
```
