# Conditional Access analysis

[English](Conditional-Access.md) | [日本語](ja/Conditional-Access.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Conditional Access Policy analysis

`bark_get_conditional_access_policies` queries the legacy AAD Graph
internal API (`graph.windows.net/{tenantId}/policies?api-version=1.61-internal`)
to enumerate all Conditional Access Policies. It parses each policy's
`policyDetail` JSON to find MFA and Block bypass opportunities, then
emits two JSON files. With download mode on (the default), they are sent
through C2; with download mode off, they are written to the Beacon's current
working directory:

| File | Contents |
|---|---|
| `AZConditionalAccessPolicy_yyyyMMdd_HHmmss.json` | Analysis output -- BloodHound graph format with nodes for each affected user/group |
| `AZConditionalAccessPolicyRaw_yyyyMMdd_HHmmss.json` | Raw API response for manual review |

These observations describe individual policy exclusions, not proof that a
sign-in bypasses all effective policies. See [CAP property migration](OpenGraph-Node-Preservation.md)
for legacy files, unmatched principals, and preservation of native properties.

### What it detects

The BOF scans every enabled `policyType: 18` policy and reports two
types of MFA bypass:

**1. User exclusions** -- users or groups listed in
`Conditions.Users.Exclude` are completely excluded from the policy.
They bypass MFA for all apps and conditions the policy covers.

**2. Condition exclusions** -- apps, device platforms, locations, or
device compliance rules listed in `Exclude` blocks within the policy's
conditions. The included users don't need MFA under those specific
excluded conditions.

Detected exclusion conditions:

| Condition | Policy field | Example value |
|---|---|---|
| Application | `Applications.Exclude` | `MicrosoftAdminPortals`, app GUIDs |
| Device platform | `DevicePlatforms.Exclude` | `Android`, `iOS`, `Windows_Phone` |
| Location | `Locations.Exclude` | Named location IDs |
| Device compliance | `Devices.Exclude` | `device.isCompliant -eq True` |

MFA controls are identified by the `Control: ["Mfa"]` field or by
`AuthStrengthIds` matching the well-known Microsoft authentication
strength GUIDs:

| AuthStrengthId | Meaning |
|---|---|
| `00000000-0000-0000-0000-000000000002` | MFA |
| `00000000-0000-0000-0000-000000000003` | Passwordless MFA |
| `00000000-0000-0000-0000-000000000004` | Phishing-resistant MFA |

### Output format

The analysis file uses a BloodHound graph/nodes/edges JSON structure.
Each affected native user or group receives a `cap_policies` array. The
payload writes only CAP observations and its native ID/kind, not names or
other identity fields. Ingest native data first, then this file:

```json
{
  "graph": {
    "nodes": [
      {
        "id": "ade8cdcb-08e3-454a-9ec2-02e393abda69",
        "kinds": ["AZUser"],
        "properties": {
          "cap_policies": [
            "MFA Policy: Excluded from MFA for All Apps",
            "Sign-In Risk Policy: Excluded from MFA for All Apps (for sign-in risk: high,medium)",
            "Require MFA for X: no MFA for app: MicrosoftAdminPortals,797f4846-...; platform: Android,iOS"
          ]
        }
      }
    ],
    "edges": []
  }
}
```

- **User exclusion** values start with `Excluded from MFA for ...`
  followed by the apps and conditions the policy enforces.
- **Condition exclusion** values start with `no MFA for ...` followed
  by the specific excluded conditions (apps, platforms, locations,
  device rules).

### Usage

```
beacon> bark_get_conditional_access_policies <aadgraph_token> [tenantId]
```

The token must be scoped to `https://graph.windows.net/`. If
`tenantId` is omitted it is auto-extracted from the JWT. Acquire a
suitable token with:

```
beacon> bark_get_tokens_with_rt https://graph.windows.net "" <refreshToken> <tenantId>
```
