# Development

[English](Development.md) | [日本語](ja/Development.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Build and verification

Run these commands from the repository root:

```bash
bash build_all.sh
python3 -m unittest discover -s tests
```

The BOF build requires the MinGW compilers listed in
[Installation](Installation.md#build). Python verification runs offline tests,
including collection fixtures and graph conversion.

## Documentation layout

[README.md](../README.md) is the operator entry point. Keep setup, collection,
and upload examples there; maintain detailed explanations in this wiki.
English documentation lives in `README.md` and `wiki/*.md`; Japanese
documentation lives in `README.ja.md` and `wiki/ja/*.md`. Keep the two
languages aligned, including upload paths and CAP output. Preserve command
names, arguments, JSON keys, and API URLs when translating.
Update both versions of [Home](Home.md) and [_Sidebar](_Sidebar.md) when adding a topic.

The previous README referenced `audit_bofs.py`, `regen_cna.py`, and
`gen_readme.py`. Those scripts are not present in this checkout.
Edit the documentation directly; there is no README regeneration step here.

## Notes on differences from the PowerShell version

- BOFs run inside the beacon process. With the default `bark_download_mode on`,
  no files are written to the target disk — all output is streamed
  back through the C2 channel via `BeaconDownload()`.
- `*_bh` BOFs use a shared `BarkGetBH` helper that paginates
  `@odata.nextLink`, unwraps the Graph `value` array, and
  wraps each item in the `{"kind": "AZ...", "data": ...}`
  shape that BloodHound expects.  Parent-entity enumeration
  also paginates via `BarkEnumEntityIds`, and standalone
  read BOFs paginate via `BarkGet`, so there is no upper
  bound on tenant size.
- HTTP 429 and 5xx responses are retried automatically with
  `Retry-After`-aware backoff via `HttpRequestWithRetry` across
  enumeration, OAuth, PRT redirect, and streaming download paths.
- Generic resource role-assignment discovery follows every ARM
  `/resources` `nextLink`; all-info reuses the already-paginated
  AZResource inventory when it fits in the validated snapshot.
- Subscription discovery falls back to management group
  descendants on any `/subscriptions` failure (empty, 403,
  connection error), not just empty results.
- The umbrella collectors (`bark_get_entra_info_bh`,
  `bark_get_entra_info_legacy_bh`,
  `bark_get_azurerm_info_bh`) are implemented as
  Aggressor aliases that chain the underlying sub-BOFs --
  there is no monolithic C BOF that does everything.
- The RT all-info workflow return-gates 15 Entra leaf collectors. HTTP-heavy
  role and relationship collectors retain a bounded eight-worker pool, while
  entity/download collectors run one BOF at a time. This avoids nested Beacon
  callbacks and the COFF-memory spike of wrapper-level parallelism.
