# Python token commands

[English](Python-Tokens.md) | [日本語](ja/Python-Tokens.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

`bark_tokens.py` provides local Python equivalents of BARK's authentication
commands. It requires Python 3.10+ and the adjacent `bark_all_info.py` module;
no third-party Python packages are needed.

## Resource URLs

Supply the resource URL, for example `https://graph.microsoft.com`,
`https://management.azure.com`, `https://storage.azure.com`, or
`https://vault.azure.net`. You do not need to append `/.default`.

The Python CLI constructs v2 scopes internally for password and
client-credentials grants. Refresh-token and PRT grants use the resource
identifier directly. Existing `/.default` inputs are accepted too.
Known service URLs accept a trailing slash; custom API identifiers retain
their significant trailing slash. ARM identifiers are canonicalized with
a trailing slash, so the generated v2 scope contains `//.default`.

This follows Microsoft's
[resource-to-scope and trailing-slash rules](https://learn.microsoft.com/en-us/entra/identity-platform/scopes-oidc#trailing-slash-and-default).
The Beacon password and client-credentials BOFs now perform this conversion
as well; existing explicit scopes remain accepted by those BOFs.

## Examples

Exchange a refresh token for a Graph token:

```bash
python3 bark_tokens.py rt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com
```

Obtain tokens with a username and password:

```bash
python3 bark_tokens.py up --tenant <tenant-guid> \
  --username operator@example.com --resource https://graph.microsoft.com \
  --output ./tokens.json --refresh-token-output ./refresh-token.txt
python3 bark_all_info.py <tenant-guid-or-domain> --refresh-token-file ./refresh-token.txt
```

The password is requested at a hidden prompt. ROPC cannot satisfy MFA or
interactive Conditional Access requirements. The identity, client, and
tenant policy determine whether a refresh token is returned.

Use client credentials:

```bash
python3 bark_tokens.py cc --tenant <tenant-guid> --client-id <application-guid> \
  --resource https://management.azure.com --output ./app-token.json
```

The client secret is requested at a hidden prompt. Client credentials produce
application access tokens, not user refresh tokens, so they do not supply the
refresh token required by `bark_all_info.py`.

Use a PRT cookie with its authorization-code flow:

```bash
python3 bark_tokens.py prt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com --prt-cookie-file ./prt-cookie.txt \
  --output ./prt-tokens.json
```

The PRT cookie must be supplied; this command does not extract or create one.
The optional `--redirect-uri` must match the client registration. The
authorization redirect is captured without following it, and the returned
redirect URI and state are checked before exchanging the code.

## Command mapping

The long Beacon command names are accepted as Python subcommand aliases.
They use the Python options below, not Beacon positional argument order.

| Beacon command | Python subcommand | Required non-secret arguments |
| --- | --- | --- |
| `bark_get_tokens` | `get_tokens rt\|up\|cc\|prt` | `--tenant`, `--resource`; username for `up`, client ID for `cc` |
| `bark_get_tokens_with_rt` | `rt` | `--tenant`, `--resource` |
| `bark_get_tokens_with_up` | `up` | `--tenant`, `--resource`, `--username` |
| `bark_get_tokens_with_cc` | `cc` | `--tenant`, `--resource`, `--client-id` |
| `bark_get_token_with_prt_cookie` | `prt` | `--tenant`, `--resource` |
| `bark_get_tokens_for_arm` | `arm rt\|up\|cc\|prt` | `--tenant`; username/client ID according to grant |
| `bark_get_tokens_for_msgraph` | `msgraph rt\|up\|cc\|prt` | `--tenant`; username/client ID according to grant |
| `bark_get_azurerm_token_with_rt` | `arm-rt` | `--tenant` |
| `bark_get_msgraph_token_with_rt` | `msgraph-rt` | `--tenant` |
| `bark_get_entra_refresh_token_with_up` | `entra-refresh` | `--tenant`, `--username` |
| `bark_get_azure_portal_token_with_rt` | `portal-rt` | `--tenant` |
| `bark_get_azurerm_token_with_portal_rt` | `arm-portal` | `--tenant` |
| `bark_get_msgraph_token_with_portal_rt` | `msgraph-portal` | `--tenant` |
| `bark_new_nonce` | `nonce` | None |

For example:

```bash
python3 bark_tokens.py bark_get_tokens_with_rt --tenant <tenant-guid> \
  --resource https://graph.microsoft.com
python3 bark_tokens.py arm rt --tenant <tenant-guid>
python3 bark_tokens.py msgraph up --tenant <tenant-guid> --username operator@example.com
python3 bark_tokens.py portal-rt --tenant <tenant-guid> --output ./portal-tokens.json
python3 bark_tokens.py arm-portal --tenant <tenant-guid> \
  --portal-token-file ./portal-authorization.txt
python3 bark_tokens.py nonce
```

`arm-rt` and `msgraph-rt` select a resource and use the shared v1 refresh-token
grant and client ranking. They do not duplicate the older BOFs' hard-coded
client/endpoint choices. The unified Python password modes use the v2 password
grant and request `offline_access`. `entra-refresh` defaults to the AAD
PowerShell client, while `portal-rt` uses the Azure Portal client.

Portal delegation uses the same portal endpoint and request fields as the
BOFs, preserving its response envelope. Its input files contain the raw portal
authorization values, not the entire JSON response from `portal-rt`.
Endpoint availability and response formats depend on the service.

## Credentials and outputs

Secrets are read from the matching file option, environment variable, or
hidden prompt, in that order:

| Credential | File option | Environment variable |
| --- | --- | --- |
| Refresh token | `--refresh-token-file` | `BARK_REFRESH_TOKEN` |
| Password | `--password-file` | `BARK_PASSWORD` |
| Client secret | `--client-secret-file` | `BARK_CLIENT_SECRET` |
| PRT cookie | `--prt-cookie-file` | `BARK_PRT_COOKIE` |
| Portal authorization | `--portal-token-file` | `BARK_PORTAL_TOKEN` |
| Alternate portal authorization | `--alt-portal-token-file` | `BARK_ALT_PORTAL_TOKEN` |

The alternate portal token is optional and defaults to an empty string.
File inputs are UTF-8 text; each contains one raw credential.

Successful JSON, including tokens, goes to stdout by default. Diagnostics
go to stderr. `--output` writes the JSON to a new file instead.
`--refresh-token-output` additionally writes just the returned refresh token,
ready for the collector's `--refresh-token-file` option. It fails if no
refresh token was returned. Existing files are never overwritten; new files
are created with mode `0600` on POSIX systems and normal inherited ACLs on
Windows. These are plain-text credential files.

Use `--client-id` to select one client. Otherwise supported grants use the
[resource-aware client ranking](Authentication.md#authentication-with-client-id-auto-detection).
Use `--timeout` and `--retries` to control token POST requests. The PRT
authorization GET is a single request per client, without redirect following.

Exit codes are `0` for a response, `1` for an authentication/input/output
failure, `2` for invalid CLI arguments, and `130` for interruption.
Run `python3 bark_tokens.py <command> --help` for mode-specific options.

## Validation

Offline tests cover all command aliases, grant request bodies, resource
normalization in Python and compiled C, client fallback, PRT state/redirect
checks, secret input, and output file protection. They do not authenticate
against a live tenant. Portal and PRT flows also require live validation in
the operator's environment.
