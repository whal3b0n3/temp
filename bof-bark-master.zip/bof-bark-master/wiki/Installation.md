# Installation and repository layout

[English](Installation.md) | [日本語](ja/Installation.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Installation and repository layout

### Build

```bash
bash build_all.sh
```

Requires `x86_64-w64-mingw32-gcc` and `i686-w64-mingw32-gcc`
(`apt install mingw-w64` on Debian/Ubuntu).

### Load in Cobalt Strike

Load `bark.cna` through `Cobalt Strike -> Script Manager -> Load`.
The compiled objects under `bofs/<category>/` must sit beside the CNA.
After loading, run `bark_help` from a beacon prompt for categorized
commands, or `help bark_<name>` for per-command argument details.

### Repository layout

```text
bof-bark/
├── bark.cna                 # Cobalt Strike loader
├── build_all.sh             # cross-compiles every BOF
├── include/                 # shared Beacon/HTTP helpers
├── src/                     # BOF C sources by capability
│   ├── token/               # token acquisition
│   ├── entra_read/          # Entra ID / MS Graph reads
│   ├── arm_read/            # Azure Resource Manager reads
│   ├── legacy_bh/           # legacy AAD Graph BloodHound reads
│   ├── legacy_cpa/          # Conditional Access analysis
│   ├── data_plane/          # Storage and Key Vault probes
│   ├── write/               # directory/RBAC modifications
│   ├── invoke/              # cloud command execution
│   └── util/                # parsing, conversion, collection helpers
└── bofs/                    # compiled .x64.o/.x86.o objects
```

The upstream PowerShell project is configured as the `BARKKAI` submodule in `.gitmodules`.
