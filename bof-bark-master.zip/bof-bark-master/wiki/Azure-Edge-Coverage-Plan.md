# Azure edge coverage plan

[English](Azure-Edge-Coverage-Plan.md) | [日本語](ja/Azure-Edge-Coverage-Plan.md)

[Wiki home](Home.md) | [Operator workflow](../README.md)

## Status and scope

This plan tracks incremental work; it is not a claim of complete AzureHound parity. See the [implementation, validation and 47-edge inventory](Azure-Native-Edges.md). The current bundle combines native AzureHound-compatible records with BARK OpenGraph relationships. AZPermissionGraph currently evaluates six capability rules in [the catalog](../data/azure_privilege_capabilities.json). A supported native record kind or an empty successful import does not establish edge coverage.

Target Azure and Entra relationships documented in the [BloodHound edge reference](https://bloodhound.specterops.io/resources/edges/overview). On-premises AD relationships are outside this plan. Pin AzureHound and BloodHound versions for each comparison; the documentation can change.

Implemented in the current change:
- Python and BOF Entra PIM eligibility/policy collection and native conversion.
- Key Vault detail fallback and native access-policy conversion, including Get casing and authorization-mode checks.
- User-assigned managed-identity inventory and consistent resource reference hydration.
- Upload jobs with partially failed native files block OpenGraph ingestion.

An isolated BloodHound 9.3 fixture verifies six native edge kinds and native user preservation after OpenGraph ingestion. The detailed matrix identifies the other edge comparisons as unverified or missing; broad post-processing parity, Key Vault RBAC data-action capability rules and full resource-specific prerequisite analysis remain open. The delivery table below retains the acceptance criteria for that broader work.

## Delivery order

| Priority | Work | Completion evidence |
| --- | --- | --- |
| 1 | Build an edge-by-edge coverage matrix for the pinned upstream versions. Record source/target kinds, traversability, collection API, required fields, Python/BOF support, converter and BloodHound post-processing. Distinguish implemented, missing, partial and unverified. | Each documented Azure edge has a traceable fixture or an explicit gap; record the version and evidence. |
| 2 | Add Entra PIM eligibility and policy collection to Python and BOF all-info workflows. Use Graph roleManagement/directory/roleEligibilityScheduleInstances and policies/roleManagementPolicyAssignments, including the policy rules needed to resolve approvers. Follow the pinned AzureHound record shape. | Positive and negative AZRoleEligible / AZRoleApprover fixtures, pagination, denied access, expired eligibility, group approvers and incomplete policy data. Keep ARM PIM separate and never infer active membership from eligibility. |
| 3 | Convert Key Vault access policies into native records. Fetch vault details where the list response lacks policies. Respect enableRbacAuthorization and model access policies separately from RBAC data actions. | AZGetSecrets / AZGetKeys / AZGetCertificates ingestion fixtures; RBAC-enabled vaults do not gain false access-policy edges. Distinguish unreadable policies from empty policies. |
| 4 | Audit native resource and directory mappings: managed identity principal IDs, AKS node resource groups, app/SP links, ownership, scope inheritance, directory roles and Microsoft Graph permissions. Close missing fields and converters identified by the matrix. | Expected native edge endpoints and kinds match the upstream baseline after BloodHound post-processing. Test both positive and negative cases. |
| 5 | Expand BARK capability analysis only where the matrix identifies useful permission-based coverage beyond native processing. Prioritize Key Vault data actions and resource-specific execution/control permissions. Document prerequisites, conditions and uncertainty for each rule. | Rules have positive, denied and unknown fixtures; similar names are not treated as equivalent semantics. |
| 6 | Run end-to-end comparisons and publish the verified matrix in English and Japanese. | Clean isolated BloodHound imports for equivalent AzureHound/Python/BOF fixtures; zero unresolved endpoints and unintended native property changes; documented differences in traversable paths. |

## Semantic constraints

- BARK_CanRunAzureVMCommand covers Azure VM Run Command. BloodHound [AZExecuteCommand](https://bloodhound.specterops.io/resources/edges/az-execute-command) concerns Intune-managed execution; do not rename one to the other.
- BARK_CanAssignAzureManagedIdentity concerns an assignment permission. [AZManagedIdentity](https://bloodhound.specterops.io/resources/edges/az-managed-identity) describes an existing resource-to-identity relationship. Evaluate resource-write and identity-scope prerequisites before claiming a complete assignment path.
- [AZRoleEligible](https://bloodhound.specterops.io/resources/edges/az-role-eligible) and [AZRoleApprover](https://bloodhound.specterops.io/resources/edges/az-role-approver) concern Entra PIM; ARM eligibility is separate.
- An app-role or RBAC assignment is an observation. Traversable capability edges require evidence supporting their operation, scope and prerequisites.
- Preserve native node names, types and other properties. Continue property-based endpoint matching, native-before-OpenGraph ingestion and cap_policies-only Conditional Access updates.

## Validation and release gates

Use synthetic or sanitized fixtures in the repository; keep tenant captures and tokens local. Test equivalent input snapshots through the shared Python converter and the BOF collection/output boundary. Validate pagination and partial-access reporting independently of edge existence.

For integration, import each baseline into a fresh isolated BloodHound database, wait for ingestion and post-processing, then compare normalized edge triples and relevant properties. Also import native plus OpenGraph into the same test database to check that BARK relationships preserve native entities. Do not use an existing populated graph to prove endpoint completeness.

A coverage item is complete only after collection, serialization, ingestion and graph semantics pass. Record unsupported versions and unresolved differences instead of assigning a blanket parity percentage.
