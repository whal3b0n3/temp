# CAP properties and native identity preservation

[English](OpenGraph-Node-Preservation.md) | [日本語](ja/OpenGraph-Node-Preservation.md)

[Wiki home](Home.md) | [BloodHound import](BloodHound-Import.md)

## Current output

CAP observations appear directly on `AZUser`/`AZGroup` nodes as a
`cap_policies` string array. Each value describes a collected policy
exclusion or conditional exception; these observations are not a complete
evaluation of effective sign-in requirements.

```json
{
  "graph": {
    "nodes": [{
      "id": "<NATIVE-OBJECT-ID>",
      "kinds": ["AZUser"],
      "properties": {
        "cap_policies": ["Policy name: observed exclusion"]
      }
    }],
    "edges": []
  }
}
```

The CAP writer emits no `name`, `displayname`, `tenantid`, `enabled`,
or custom source kind. BloodHound v9.3.0's
[node converter](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/cmd/api/src/services/graphify/convertors.go)
sets `primarykind` to the first supplied kind; its
[node importer](https://github.com/SpecterOps/BloodHound/blob/v9.3.0/cmd/api/src/services/graphify/ingestnodes.go)
normalizes the ID and updates `lastseen`. The supplied native kind therefore
must match the user/group already present. Unspecified identity properties
are not supplied by this patch.

The bundle builder takes principal kinds from its native snapshot and omits
CAP updates for uncollected principals. Their observations remain in
`meta.unmatchedConditionalAccessProperties`; the manifest lists
`unmatchedConditionalAccessPrincipals`. The data uploader waits for the native
job to complete before importing the CAP updates. A CAP node payload is an
upsert, not an existence-only lookup, so uploading it without its native
phase can still create an incomplete principal. Use the ordered bundle.

A string array replaces the previous observations for an updated principal,
avoiding stale numbered fields when the number of observations decreases.
Principals absent from a CAP payload are not cleared automatically; a missing
observation alone does not prove a policy was removed.

## Migration

Both Python and BOF output now use the property format. The converter also
accepts older files containing `MFA1`, `MFA2`, etc. or
`BARK_ConditionalAccessAnnotation` nodes. It extracts the observations,
drops identity-field writes, and emits `cap_policies` on matched native
principals. It removes `BARK_HasConditionalAccessAnnotation` edges from the
new upload payload. Original capture files remain unchanged.

Generate a new bundle and follow the numbered directories:

```bash
python3 bark_role_graph.py /path/to/collection --bundle-output ./cap-properties-bundle
python3 bark_upload.py ./cap-properties-bundle --username <bloodhound-user>
```

Install `00-install-schema/BARK_OpenGraph_Extension.json` first.
Upload `01-upload-native/`, wait for Complete, then submit
`02-upload-opengraph/` as a separate job. Inspect a user under Explore,
or query:

```cypher
MATCH (u:AZUser)
WHERE u.cap_policies IS NOT NULL
RETURN u, u.cap_policies AS CAPPolicies
LIMIT 200
```

Already imported annotation nodes/edges and old MFA-numbered properties are
not deleted by uploading a new payload. No live database cleanup or reimport
has been performed. New files emit no annotation nodes or edges.

## Relationship preservation

Role, app-role, and permission edges continue to resolve native endpoints by
an uppercase `objectid` property matcher, without asserting endpoint kinds.
This requires a unique existing node. Standalone custom copies retain
`BARK_ENTITY_<original-id>` IDs to avoid native-ID collisions.

The earlier CAP annotation-node design avoided native property updates, but
the operator now prefers CAP details on the native principal. Only the CAP
writer changes to this restricted property update; relationship endpoints
keep their existence-only lookups.

## Confirmed upload ordering failure

Read-only inspection of the local BloodHound v9.3.0 instance (Neo4j 4.4)
identified the cause of the reported partial import. Upload job 49 processed
the native and OpenGraph files in this order on 2026-09-25 (UTC):

| Completed at | File | Observation |
| --- | --- | --- |
| 05:22:04.064 | `AZAppRoleGraph_20260925_141916.json` | Endpoint warnings before native import |
| 05:22:04.077 | `AZPermissionGraph_20260925_141916.json` | Endpoint warnings before native import |
| 05:22:04.709 | `azurehound_bark.json` | Native file processed later in the same job |
| 05:22:05.152 | `AZConditionalAccessPolicy_20260925_131924.json` | Processed after the native file |
| 05:22:05.738 | `AZRoleGraph_20260925_141916.json` | Processed after the native file |

The logs contain the reported object IDs. Read-only Neo4j queries after the
job found sampled IDs with their expected native labels and properties.
A subsequent check of every native endpoint referenced by the two failed
files resolved all 20 distinct object IDs to exactly one node each; none were
missing or duplicated. The AppRoleGraph/PermissionGraph errors occurred before
those endpoints were available. This is an upload ordering failure, not evidence that the property
matcher is incompatible with this instance. Retain the property lookups that
protect native nodes.

The two failed graph files can be retried from
`bark-bofresult/BARK_BloodHound_Bundle_20260925_141916/02-upload-opengraph/`
after confirming the native job finished. No recollection or graph regeneration
is needed for this incident. For subsequent bundles, use
`bark_upload.py` to wait for native-job success before starting the OpenGraph
job, or follow the same two-job sequence manually. Do not select both phase
directories in one job or ZIP.

This inspection did not modify the database or perform a live reimport.
The new uploader is tested against a local HTTP fixture, including stopping
before phase 2 on partial success, failures, and timeouts. A successful live
retry remains to be confirmed by the operator.

## Validation

108 Python regression tests pass, including the compiled offline C JSON writer.
The tests cover conversion from both earlier CAP formats, native snapshot
filtering, preservation of identity properties in a model of the importer,
and both upload-folder layouts. The C harness exercises the real BOF writer
with stubbed transport; it is not a Beacon runtime test. Live ingest behavior
has not been tested for this property-format change.

Both CAP BOFs were rebuilt for x64 and x86. Updated bundles are available at:

- `bark-bofresult/BARK_BloodHound_Bundle_cap_properties/`
- `bark-results/BARK_20260922_084052_292957/BARK_BloodHound_Bundle_cap_properties/`

Each bundle contains `CAP_PROPERTIES_VALIDATION.json`. The BOF bundle has
101 CAP principals and 176 observations; the Python bundle has 101 principals
and 174 observations, with two unmatched principals retained as audit data.
The 1,108 BOF and 1,943 Python native records are unchanged. No new annotation
nodes or edges appear in either bundle.
