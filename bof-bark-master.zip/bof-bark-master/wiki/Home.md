# BARK wiki

[English](Home.md) | [日本語](ja/Home.md)

Start with the [operator workflow](../README.md) to collect data through
Python or Beacon and prepare a BloodHound upload. This directory contains
the detailed documentation maintained alongside the code.

## Topics

| Page | Contents |
| --- | --- |
| [Python token commands](Python-Tokens.md) | Grants, resource URLs, credential input, and token output. |
| [Python collector](Python-Collector.md) | Requirements, options, coverage, output, and differences from Beacon. |
| [Installation](Installation.md) | Build prerequisites, loading the CNA, and repository layout. |
| [Authentication](Authentication.md) | Token audiences, client ID ranking, and grant examples. |
| [Beacon collection workflow](Collection-Workflow.md) | Credential entry points, umbrella collectors, fallback, job recovery, and runtime estimates. |
| [BloodHound import](BloodHound-Import.md) | Upload order, app-role graphs, permission analysis, and property compatibility. |
| [Downloads and archives](Downloads-and-Archives.md) | Diskless output, transfer parts, ZIP extraction, and graph conversion. |
| [Conditional Access](Conditional-Access.md) | Policy analysis, native cap_policies properties, and output format. |
| [Discovery and retries](Discovery-and-Retries.md) | Management-group fallback, pagination, and HTTP retry behavior. |
| [Additional collectors](Additional-Collectors.md) | Entra agents, Foundry, Power Platform, and data-plane commands. |
| [Command reference](Command-Reference.md) | Commands, arguments, token scopes, and descriptions. |
| [Development](Development.md) | Build, verification, documentation maintenance, and differences from PowerShell. |

- [OpenGraph node preservation](OpenGraph-Node-Preservation.md)

- [Azure edge coverage plan](Azure-Edge-Coverage-Plan.md)

- [Native Azure edge fixes and validation](Azure-Native-Edges.md)
