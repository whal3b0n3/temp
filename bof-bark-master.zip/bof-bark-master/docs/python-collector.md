# Python collector

The detailed documentation has moved to the [Python collector wiki](../wiki/Python-Collector.md).

For the end-to-end workflow, see the [README](../README.md).
