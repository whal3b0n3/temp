"""Native CAP property enrichment and non-mutating relationship references."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

import bark_opengraph as og
import bark_permission_analysis as permissions
import bark_role_graph as roles


class NativeNodePreservationTests(unittest.TestCase):
    def old_payload(self):
        return {"graph": {
            "nodes": [{"id": "user-1", "kinds": ["AZUser"], "properties": {
                "name": "stale@example.test", "displayname": "Stale", "MFA1": "Observed exclusion",
            }}],
            "edges": [{"kind": "BARK_CanRunAzureVMCommand",
                       "start": {"value": "user-1", "kind": "AZUser", "match_by": "id"},
                       "end": {"value": "/vm/1", "kind": "AZVM", "match_by": "id"},
                       "properties": {"confidence": "confirmed"}}],
        }}

    def test_legacy_bundle_only_changes_cap_properties_on_existing_users(self):
        source = self.old_payload()
        before = deepcopy(source)
        native_source = {"data": [{"kind": "AZUser", "data": {
            "id": "user-1", "userPrincipalName": "current@example.test", "accountEnabled": True}}],
            "meta": {"type": "azure", "version": 5, "count": 1}}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            parsed = [(roles.JsonDocument(name, json.dumps(data).encode()), data)
                      for name, data in [("old.json", source), ("users.json", native_source)]]
            roles.create_upload_bundle(root / "bundle", parsed, root, roles.Reporter(), 0)
            path = root / "bundle/02-upload-opengraph/old.json"
            payload = json.loads(path.read_text())
            schema = json.loads((root / "bundle/00-install-schema/BARK_OpenGraph_Extension.json").read_text())
            merged = json.loads((root / "bundle/01-upload-native/azurehound_bark.json").read_text())
            self.assertEqual(merged["data"], native_source["data"])
            self.assertEqual(schema["node_kinds"], [])
            self.assertNotIn("BARK_HasConditionalAccessAnnotation",
                             {r["name"] for r in schema["relationship_kinds"]})
        self.assertEqual(source, before)
        self.assertEqual(payload["graph"]["edges"][0]["properties"], before["graph"]["edges"][0]["properties"])
        self.assertEqual(og.preserve_native_nodes(payload), payload)
        # Model v9.3.0 ConvertGenericNode + property merge: only emitted keys
        # and primarykind/objectid/lastseen are written, not identity fields.
        native = {"objectid": "USER-1", "name": "CURRENT@EXAMPLE.TEST", "displayname": "Current",
                  "enabled": True, "tenantid": "TENANT", "primarykind": "AZUser"}
        snapshot = deepcopy(native)
        patch = payload["graph"]["nodes"][0]
        self.assertEqual(patch["id"], "USER-1")
        self.assertEqual(patch["kinds"], ["AZUser"])
        self.assertEqual(set(patch["properties"]), {"cap_policies"})
        native.update(patch["properties"], primarykind=patch["kinds"][0])
        self.assertEqual({key: native[key] for key in snapshot}, snapshot)
        self.assertEqual(native["cap_policies"], ["Observed exclusion"])
        for endpoint in (payload["graph"]["edges"][0]["start"], payload["graph"]["edges"][0]["end"]):
            self.assertEqual(endpoint["match_by"], "property")
            self.assertNotIn("kind", endpoint)

    def test_uncollected_cap_principal_is_audit_only(self):
        payload = og.preserve_native_nodes(self.old_payload(), {"OTHER-USER"})
        self.assertEqual(payload["meta"]["unmatchedConditionalAccessPrincipals"], ["USER-1"])
        self.assertEqual(payload["graph"]["nodes"], [])
        observation = payload["meta"]["unmatchedConditionalAccessProperties"][0]
        self.assertEqual(observation["properties"], {"cap_policies": ["Observed exclusion"]})
        self.assertEqual(len(payload["graph"]["edges"]), 1)

    def test_all_unmatched_cap_data_is_audited_and_not_uploadable(self):
        payload = self.old_payload()
        payload["graph"]["edges"] = []
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            parsed = [(roles.JsonDocument("cap.json", json.dumps(payload).encode()), payload)]
            roles.create_upload_bundle(root / "bundle", parsed, root, roles.Reporter(), 0)
            manifest = json.loads((root / "bundle/BARK_UPLOAD_MANIFEST.json").read_text())
            entry = manifest["files"][0]
            self.assertEqual(entry["action"], "do-not-upload")
            self.assertEqual(entry["unmatchedConditionalAccessPrincipals"], ["USER-1"])
            audit = json.loads((root / "bundle" / entry["output"]).read_text())
            self.assertEqual(audit["meta"]["unmatchedConditionalAccessProperties"][0]["properties"],
                             {"cap_policies": ["Observed exclusion"]})

    def test_annotation_nodes_migrate_to_native_properties_without_edges(self):
        old = {"graph": {"nodes": [{
            "id": "BARK_CA_USER-1", "kinds": ["BARK_ConditionalAccessAnnotation"],
            "properties": {"principalid": "USER-1", "principalkind": "AZUser",
                           "name": "Conditional Access observations: old", "MFA2": "second", "MFA1": "first"},
        }], "edges": [{"kind": "BARK_HasConditionalAccessAnnotation",
                       "start": og.native_endpoint("user-1"),
                       "end": {"match_by": "id", "value": "BARK_CA_USER-1"}}]}}
        graph = og.preserve_native_nodes(old, {"USER-1": "AZUser"})["graph"]
        self.assertEqual(graph, {"nodes": [{"id": "USER-1", "kinds": ["AZUser"],
                                          "properties": {"cap_policies": ["first", "second"]}}], "edges": []})

    def test_snapshot_kind_wins_and_empty_snapshot_cannot_create_principals(self):
        node = og.preserve_native_nodes(self.old_payload(), {"USER-1": "AZGroup"})["graph"]["nodes"][0]
        self.assertEqual(node["kinds"], ["AZGroup"])
        self.assertEqual(og.preserve_native_nodes(self.old_payload(), {})["graph"]["nodes"], [])

    def test_repeated_findings_merge_and_array_updates_replace_old_values(self):
        nodes = self.old_payload()["graph"]["nodes"]
        nodes.append({"id": "USER-1", "kinds": ["AZUser"],
                      "properties": {"MFA1": "Observed exclusion", "MFA2": "Another policy"}})
        graph = og.conditional_access_graph(nodes)["graph"]
        self.assertEqual(len(graph["nodes"]), 1)
        props = graph["nodes"][0]["properties"]
        self.assertEqual(props["cap_policies"], ["Observed exclusion", "Another policy"])
        props.update(og.conditional_access_graph(nodes[:1])["graph"]["nodes"][0]["properties"])
        self.assertEqual(props["cap_policies"], ["Observed exclusion"])

    def test_references_require_an_existing_unique_object_id(self):
        self.assertEqual(og.native_endpoint("user-1"), {
            "match_by": "property",
            "property_matchers": [{"key": "objectid", "operator": "equals", "value": "USER-1"}]})

    def test_other_native_writes_and_source_kind_are_rejected(self):
        for payload in (
            {"graph": {"nodes": [{"id": "USER", "kinds": ["AZUser"]}], "edges": []}},
            {"graph": {"nodes": [{"id": "VM", "kinds": ["AZVM"], "properties": {"MFA1": "bad"}}]}},
            dict(self.old_payload(), metadata={"source_kind": "BARK"}),
        ):
            with self.assertRaises(ValueError):
                og.preserve_native_nodes(payload)

    def test_standalone_role_and_permission_nodes_cannot_collide_with_native_ids(self):
        assignment = roles.Assignment("Owner", "role", "user-1", "User", "/subscriptions/sub",
                                      "/subscriptions/sub", "assignment", "fixture", {})
        graph = roles.make_graph([assignment], standalone=True)["graph"]
        capability = permissions.Capability("test", "BARK_Test", "test", (("test",),), ("AZSubscription",), "test")
        edge, payload = permissions._make_edge(capability, "user-1", "User", "/subscriptions/sub",
                                              "AZSubscription", {}, True, roles.principal_kind)
        self.assertEqual({n["id"]: n for n in graph["nodes"]}, {n["id"]: n for n in payload["nodes"]})
        self.assertTrue(all(n["id"].startswith("BARK_ENTITY_") for n in graph["nodes"]))
        self.assertEqual(edge["start"], graph["edges"][0]["start"])
        self.assertEqual(edge["end"], graph["edges"][0]["end"])


if __name__ == "__main__":
    unittest.main()
