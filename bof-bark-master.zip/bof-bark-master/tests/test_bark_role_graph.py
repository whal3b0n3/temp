import json
import tempfile
import unittest
from pathlib import Path

import bark_role_graph as role_graph


def azure_payload(kind: str, records: list[dict]) -> dict:
    return {
        "data": [{"kind": kind, "data": record} for record in records],
        "meta": {"type": "azure", "version": 5, "count": len(records)},
    }


def encoded(payload: dict) -> bytes:
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def write_split(directory: Path, base: str, data: bytes, count: int = 2) -> None:
    step = (len(data) + count - 1) // count
    for index in range(count):
        part = data[index * step : (index + 1) * step]
        (directory / f"{base}.part{index:03d}of{count:03d}").write_bytes(part)


class BundleClassificationTests(unittest.TestCase):
    def test_native_opengraph_and_support_classification(self) -> None:
        service_principal = azure_payload(
            "AZServicePrincipal", [{"id": "SP-1", "displayName": "Example SP"}]
        )
        native = role_graph.classify_for_bundle(service_principal)
        self.assertEqual(native.action, "upload")
        self.assertEqual(native.directory, "01-upload-native")

        role_definition = azure_payload(
            "AZRoleDefinition", [{"id": "ROLE-1", "properties": {}}]
        )
        support = role_graph.classify_for_bundle(role_definition)
        self.assertEqual(support.action, "do-not-upload")
        self.assertIn("AZRoleDefinition", support.reason)

        graph = {"graph": {"nodes": [], "edges": [{"kind": "BARK_Owner"}]}}
        open_graph = role_graph.classify_for_bundle(graph)
        self.assertEqual(open_graph.action, "upload")
        self.assertEqual(open_graph.directory, "02-upload-opengraph")

        gathered = {"roleAssignments": [{}], "meta": {"type": "azure"}}
        diagnostic = role_graph.classify_for_bundle(gathered)
        self.assertEqual(diagnostic.action, "do-not-upload")

    def test_raw_arm_management_group_record_is_not_native_upload(self) -> None:
        raw = azure_payload(
            "AZManagementGroupRoleAssignment",
            [{"id": "RA-1", "properties": {"principalId": "USER-1"}}],
        )
        classification = role_graph.classify_for_bundle(raw)
        self.assertEqual(classification.action, "do-not-upload")
        self.assertIn("non-AzureHound", classification.reason)


class UploadBundleTests(unittest.TestCase):
    def test_management_group_native_wrapper_is_gathered(self) -> None:
        role_id = (
            "/providers/Microsoft.Management/managementGroups/MG-1/providers/"
            "Microsoft.Authorization/roleDefinitions/ROLE-1"
        )
        payload = {
            "data": [
                {
                    "kind": "AZManagementGroupRoleAssignment",
                    "data": {
                        "managementGroupId": "MG-1",
                        "roleAssignments": [
                            {
                                "managementGroupId": "MG-1",
                                "roleAssignment": {
                                    "id": "RA-1",
                                    "type": "Microsoft.Authorization/roleAssignments",
                                    "properties": {
                                        "principalId": "USER-1",
                                        "principalType": "User",
                                        "roleDefinitionId": role_id,
                                        "scope": "/providers/Microsoft.Management/managementGroups/MG-1",
                                    },
                                },
                            }
                        ],
                    },
                }
            ],
            "meta": {"type": "azure", "version": 5, "count": 1},
        }
        document = role_graph.JsonDocument("AZManagementGroupRoleAssignment.json", encoded(payload))
        parsed = role_graph.parse_documents([document], role_graph.Reporter())
        assignments = role_graph.gather_assignments(parsed, {}, role_graph.Reporter())
        self.assertEqual(len(assignments), 1)
        self.assertEqual(assignments[0].principal_id, "USER-1")
        self.assertEqual(assignments[0].effective_scope, "/providers/Microsoft.Management/managementGroups/MG-1")

    def test_bundle_is_created_without_arm_role_assignments(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inputs = root / "inputs"
            inputs.mkdir()
            service_principal = azure_payload(
                "AZServicePrincipal",
                [{"id": "SP-ONLY", "displayName": "Split Only"}],
            )
            write_split(
                inputs,
                "AZServicePrincipal_20260901_000000.json",
                encoded(service_principal),
            )

            bundle = root / "bundle"
            result = role_graph.main(
                [str(inputs), "--bundle-output", str(bundle)]
            )
            self.assertEqual(result, 0)
            merged_path = (
                bundle / "01-upload-native" / role_graph.MERGED_NATIVE_FILENAME
            )
            self.assertTrue(merged_path.is_file())
            self.assertEqual(
                json.loads(merged_path.read_text(encoding="utf-8"))["data"],
                service_principal["data"],
            )
            self.assertTrue(
                (
                    bundle
                    / "do-not-upload/native-source/"
                    "AZServicePrincipal_20260901_000000.json"
                ).is_file()
            )
            self.assertFalse(any(root.glob("AZRoleGraph*.json")))

    def test_main_reassembles_parts_and_separates_upload_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inputs = root / "inputs"
            inputs.mkdir()

            service_principal = azure_payload(
                "AZServicePrincipal",
                [{"id": "SP-1", "displayName": "Example Service Principal"}],
            )
            write_split(
                inputs,
                "AZServicePrincipal_20260901_010101.json",
                encoded(service_principal),
            )

            role_definition_id = (
                "/subscriptions/SUB-1/providers/Microsoft.Authorization/"
                f"roleDefinitions/{role_graph.OWNER_ROLE_ID}"
            )
            role_definition = azure_payload(
                "AZRoleDefinition",
                [
                    {
                        "id": role_definition_id,
                        "properties": {"roleName": "Owner"},
                    }
                ],
            )
            write_split(
                inputs,
                "AZRoleDefinition_20260901_010102.json",
                encoded(role_definition),
            )

            user = azure_payload(
                "AZUser", [{"id": "USER-1", "displayName": "Example User"}]
            )
            (inputs / "AZUser_20260901_010103.json").write_bytes(encoded(user))

            assignment_id = (
                "/subscriptions/SUB-1/providers/Microsoft.Authorization/"
                "roleAssignments/ASSIGNMENT-1"
            )
            raw_assignments = {
                "kind": "AZOwner",
                "data": [
                    {
                        "Owner": {
                            "id": assignment_id,
                            "name": "ASSIGNMENT-1",
                            "type": "Microsoft.Authorization/roleAssignments",
                            "properties": {
                                "roleDefinitionId": role_definition_id,
                                "principalId": "USER-1",
                                "principalType": "User",
                                "scope": "/subscriptions/SUB-1",
                            },
                        },
                        "id": "/subscriptions/SUB-1",
                    }
                ],
            }
            raw_name = "AZOwnerRoleAssignments_Resource_20260901_010104.json"
            (inputs / raw_name).write_bytes(encoded(raw_assignments))

            bundle = root / "bundle"
            result = role_graph.main(
                [
                    str(inputs),
                    "--graph-output",
                    str(root / "AZRoleGraph.json"),
                    "--native-output",
                    str(root / "AZNativeRBAC.json"),
                    "--gather-output",
                    str(root / "AZRoleAssignments_Gathered.json"),
                    "--bundle-output",
                    str(bundle),
                    "--strict",
                ]
            )
            self.assertEqual(result, 0)

            native_uploads = list((bundle / "01-upload-native").glob("*.json"))
            self.assertEqual(len(native_uploads), 1)
            self.assertEqual(native_uploads[0].name, role_graph.MERGED_NATIVE_FILENAME)
            merged_native = json.loads(
                native_uploads[0].read_text(encoding="utf-8")
            )
            self.assertEqual(
                [
                    item
                    for item in merged_native["data"]
                    if item["kind"] == "AZServicePrincipal"
                ],
                service_principal["data"],
            )
            self.assertEqual(
                merged_native["meta"]["count"], len(merged_native["data"])
            )
            self.assertTrue(
                (
                    bundle
                    / "do-not-upload/native-source/"
                    "AZServicePrincipal_20260901_010101.json"
                ).is_file()
            )
            self.assertTrue(
                (bundle / "do-not-upload/native-source/AZNativeRBAC.json").is_file()
            )
            self.assertTrue((bundle / "02-upload-opengraph/AZRoleGraph.json").is_file())
            self.assertTrue(
                (bundle / "do-not-upload/AZRoleDefinition_20260901_010102.json").is_file()
            )
            self.assertTrue((bundle / "do-not-upload" / raw_name).is_file())
            self.assertTrue(
                (bundle / "do-not-upload/AZRoleAssignments_Gathered.json").is_file()
            )
            self.assertFalse(any(bundle.rglob("*.part*")))

            manifest = json.loads(
                (bundle / "BARK_UPLOAD_MANIFEST.json").read_text(encoding="utf-8")
            )
            entries = {entry["source"]: entry for entry in manifest["files"]}
            service_entry = entries["AZServicePrincipal_20260901_010101.json"]
            self.assertEqual(service_entry["action"], "merged")
            self.assertEqual(
                service_entry["mergedInto"],
                f"01-upload-native/{role_graph.MERGED_NATIVE_FILENAME}",
            )
            self.assertTrue(service_entry["reassembled"])
            self.assertEqual(service_entry["partCount"], 2)
            role_entry = entries["AZRoleDefinition_20260901_010102.json"]
            self.assertEqual(role_entry["action"], "do-not-upload")
            self.assertEqual(manifest["schemaVersion"], 3)
            self.assertTrue(
                (bundle / "00-install-schema" / role_graph.OPEN_GRAPH_EXTENSION_FILENAME).is_file()
            )
            self.assertEqual(manifest["mergedNative"]["count"], 3)
            self.assertEqual(manifest["nativeSourceFilesMerged"], 3)
            self.assertEqual(manifest["sourcePartFilesExcluded"], 4)

    def test_native_merge_puts_complete_service_principals_after_placeholders(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inputs = root / "inputs"
            inputs.mkdir()
            payloads = [
                (
                    "00-app.json",
                    azure_payload(
                        "AZApp", [{"appId": "APP-1", "displayName": "App"}]
                    ),
                ),
                (
                    "01-service-principal.json",
                    azure_payload(
                        "AZServicePrincipal",
                        [{"id": "SP-1", "displayName": "Service Principal"}],
                    ),
                ),
                (
                    "99-app-role-assignment.json",
                    azure_payload(
                        "AZAppRoleAssignment",
                        [
                            {
                                "principalId": "SP-1",
                                "principalType": "ServicePrincipal",
                                "resourceId": "SP-2",
                                "principalDisplayName": "Service Principal",
                                "appId": role_graph.MS_GRAPH_APP_ID,
                                "appRoleId": "1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9",
                            }
                        ],
                    ),
                ),
            ]
            parsed = []
            for name, payload in payloads:
                data = encoded(payload)
                parsed.append((role_graph.JsonDocument(name, data), payload))

            bundle = root / "bundle"
            role_graph.create_upload_bundle(
                bundle, parsed, inputs, role_graph.Reporter(), 0
            )

            merged = json.loads(
                (
                    bundle
                    / "01-upload-native"
                    / role_graph.MERGED_NATIVE_FILENAME
                ).read_text(encoding="utf-8")
            )
            self.assertEqual(
                [record["kind"] for record in merged["data"]],
                ["AZAppRoleAssignment", "AZServicePrincipal", "AZApp"],
            )
            self.assertEqual(merged["meta"]["count"], 3)
            self.assertEqual(
                len(list((bundle / "01-upload-native").glob("*.json"))), 1
            )

    def test_app_role_graph_resolves_custom_roles_and_principal_kinds(self) -> None:
        resource_id = "db2921c3-79b4-469b-88b7-54699e72bdbc"
        role_id = "8c5e2b1a-3d4f-4a6e-9b8c-7d6e5f4a3b2c"
        payloads = [
            azure_payload("AZUser", [{"id": "USER-1", "displayName": "Alice"}]),
            azure_payload("AZGroup", [{"id": "GROUP-1", "displayName": "Operators"}]),
            azure_payload(
                "AZServicePrincipal",
                [
                    {"id": "CLIENT-SP-1", "displayName": "automation-client"},
                    {
                        "id": resource_id,
                        "appId": "c93df98a-5276-4ba0-ac6a-385b4e92766c",
                        "displayName": "app-cosmolink",
                        "appRoles": [
                            {
                                "id": role_id,
                                "displayName": "Flag",
                                "value": "Flag",
                                "description": "Classified access",
                                "allowedMemberTypes": ["User"],
                                "isEnabled": True,
                            }
                        ],
                    }
                ],
            ),
            azure_payload(
                "AZAppRoleAssignment",
                [
                    {
                        "id": "ASSIGN-U",
                        "principalId": "USER-1",
                        "principalType": "User",
                        "resourceId": resource_id,
                        "appRoleId": role_id,
                        "resourceDisplayName": "app-cosmolink",
                    },
                    {
                        "id": "ASSIGN-G",
                        "principalId": "GROUP-1",
                        "principalType": "Group",
                        "resourceId": resource_id,
                        "appRoleId": role_id,
                        "resourceDisplayName": "app-cosmolink",
                    },
                    {
                        "id": "ASSIGN-SP",
                        "principalId": "CLIENT-SP-1",
                        "principalType": "ServicePrincipal",
                        "resourceId": resource_id,
                        "appRoleId": role_id,
                        "resourceDisplayName": "app-cosmolink",
                    },
                ],
            ),
        ]
        parsed = [
            (role_graph.JsonDocument(f"{index}.json", encoded(payload)), payload)
            for index, payload in enumerate(payloads)
        ]
        graph = role_graph.make_app_role_graph(parsed)
        role_nodes = [
            node for node in graph["graph"]["nodes"]
            if "BARK_AppRole" in node["kinds"]
        ]
        self.assertEqual(len(role_nodes), 1)
        self.assertEqual(role_nodes[0]["properties"]["displayname"], "Flag")
        self.assertNotIn(":", role_nodes[0]["id"])
        self.assertEqual(
            role_nodes[0]["id"],
            "BARK_APPROLE_DB2921C379B4469B88B754699E72BDBC_"
            "8C5E2B1A3D4F4A6E9B8C7D6E5F4A3B2C",
        )
        assigned = [
            edge for edge in graph["graph"]["edges"]
            if edge["kind"] == "BARK_AssignedAppRole"
        ]
        self.assertEqual(
            {edge["properties"]["principaltype"] for edge in assigned},
            {"User", "Group", "ServicePrincipal"},
        )
        self.assertTrue(all(edge["start"]["match_by"] == "property" for edge in assigned))
        self.assertTrue(all("kind" not in edge["start"] for edge in assigned))
        self.assertTrue(all(edge["end"]["value"] == role_nodes[0]["id"] for edge in assigned))

    def test_default_access_app_role_has_a_stable_display_name(self) -> None:
        payloads = [
            azure_payload(
                "AZServicePrincipal",
                [{"id": "RESOURCE-SP", "displayName": "resource"}],
            ),
            azure_payload(
                "AZUser", [{"id": "USER-1", "displayName": "Alice"}]
            ),
            azure_payload(
                "AZAppRoleAssignment",
                [
                    {
                        "id": "ASSIGN-DEFAULT",
                        "principalId": "USER-1",
                        "principalType": "User",
                        "resourceId": "RESOURCE-SP",
                        "appRoleId": role_graph.DEFAULT_APP_ROLE_ID,
                    }
                ],
            ),
        ]
        parsed = [
            (role_graph.JsonDocument(f"{index}.json", encoded(payload)), payload)
            for index, payload in enumerate(payloads)
        ]
        graph = role_graph.make_app_role_graph(parsed)
        role_nodes = [
            node for node in graph["graph"]["nodes"]
            if "BARK_AppRole" in node["kinds"]
        ]
        self.assertEqual(role_nodes[0]["properties"]["displayname"], "Default Access")
        self.assertEqual(graph["meta"]["unresolvedRoles"], 0)

    def test_native_merge_filters_unsafe_app_role_assignments(self) -> None:
        records = azure_payload(
            "AZAppRoleAssignment",
            [
                {
                    "principalId": "USER-1",
                    "principalType": "User",
                    "resourceId": "SP-GRAPH",
                    "appId": role_graph.MS_GRAPH_APP_ID,
                    "appRoleId": "1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9",
                },
                {
                    "principalId": "SP-1",
                    "principalType": "ServicePrincipal",
                    "resourceId": "SP-CUSTOM",
                    "appId": "CUSTOM-APP",
                    "appRoleId": "CUSTOM-ROLE",
                },
                {
                    "principalId": "SP-1",
                    "principalType": "ServicePrincipal",
                    "resourceId": "SP-GRAPH",
                    "appId": role_graph.MS_GRAPH_APP_ID,
                    "appRoleId": "1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9",
                },
            ],
        )
        principals = azure_payload(
            "AZServicePrincipal", [{"id": "SP-1", "displayName": "client"}]
        )
        documents = []
        for name, payload in (("roles.json", records), ("sp.json", principals)):
            documents.append(
                (
                    role_graph.JsonDocument(name, encoded(payload)),
                    payload,
                    role_graph.classify_for_bundle(payload),
                )
            )
        merged, _ = role_graph.merge_native_documents(documents)
        retained = [
            record for record in merged["data"]
            if record["kind"] == "AZAppRoleAssignment"
        ]
        self.assertEqual(len(retained), 1)
        self.assertEqual(retained[0]["data"]["principalId"], "SP-1")
        self.assertEqual(merged["meta"]["appRoleAssignmentsExcluded"], 2)

    def test_management_group_descendants_resolve_to_entity_kinds(self) -> None:
        payload = azure_payload(
            "AZManagementGroupDescendant",
            [
                {
                    "id": "/subscriptions/SUB-1",
                    "type": "Microsoft.Management/managementGroups/subscriptions",
                },
                {
                    "id": "/providers/Microsoft.Management/managementGroups/CHILD",
                    "type": "Microsoft.Management/managementGroups",
                },
            ],
        )
        lookup = role_graph.build_resource_kind_lookup(
            [(role_graph.JsonDocument("descendants.json", encoded(payload)), payload)]
        )
        self.assertEqual(lookup["/subscriptions/sub-1"], "AZSubscription")
        self.assertEqual(
            lookup["/providers/microsoft.management/managementgroups/child"],
            "AZManagementGroup",
        )

    def test_management_group_role_graph_uses_full_concrete_target(self) -> None:
        management_group = (
            "/providers/Microsoft.Management/managementGroups/MG-1"
        )
        assignment = role_graph.Assignment(
            role_name="Owner",
            role_definition_id=(
                f"{management_group}/providers/Microsoft.Authorization/"
                "roleDefinitions/ROLE-1"
            ),
            principal_id="USER-1",
            principal_type="User",
            authored_scope=management_group,
            effective_scope=management_group,
            assignment_id=(
                f"{management_group}/providers/Microsoft.Authorization/"
                "roleAssignments/RA-1"
            ),
            source="test",
            raw={},
        )
        graph = role_graph.make_graph(
            [assignment],
            resource_kinds={management_group.lower(): "AZManagementGroup"},
        )
        edge = graph["graph"]["edges"][0]
        self.assertEqual(edge["end"], role_graph.native_endpoint(management_group))

    def test_structured_schema_marks_only_confirmed_edges_traversable(self) -> None:
        payload = {
            "graph": {
                "nodes": [{"id": "ROLE", "kinds": ["BARK_AppRole"]}],
                "edges": [
                    {"kind": "BARK_AssignedAppRole"},
                    {"kind": "BARK_SubscriptionReader"},
                    {"kind": "BARK_AppRoleOf"},
                    {
                        "kind": "BARK_CanAssignAzureRole",
                        "properties": {
                            "capability": "azure.rbac.role_assignment_write",
                            "confidence": "confirmed",
                        },
                    },
                    {"kind": "BARK_EligibleForAzureRole"},
                    {"kind": "BARK_Potential_CanAssignAzureRole"},
                ],
            }
        }
        schema = role_graph.make_opengraph_extension(
            [(role_graph.JsonDocument("graph.json", encoded(payload)), payload)]
        )
        self.assertIsNotNone(schema)
        self.assertEqual(schema["schema"]["version"], "v1.0.0")
        relationships = {
            item["name"]: item["is_traversable"]
            for item in schema["relationship_kinds"]
        }
        self.assertFalse(relationships["BARK_AssignedAppRole"])
        self.assertFalse(relationships["BARK_SubscriptionReader"])
        self.assertFalse(relationships["BARK_AppRoleOf"])
        self.assertTrue(relationships["BARK_CanAssignAzureRole"])
        self.assertFalse(relationships["BARK_EligibleForAzureRole"])
        self.assertFalse(relationships["BARK_Potential_CanAssignAzureRole"])


if __name__ == "__main__":
    unittest.main()
