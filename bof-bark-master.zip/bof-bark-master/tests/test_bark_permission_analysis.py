import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import bark_abac
import bark_permission_analysis as analysis
import bark_role_graph as role_graph


def envelope(
    kind: str,
    records: list[dict],
    collection: dict | None = None,
) -> tuple[role_graph.JsonDocument, dict]:
    payload = {
        "data": [{"kind": kind, "data": record} for record in records],
        "meta": {"type": "azure", "version": 5, "count": len(records)},
    }
    if collection is not None:
        payload["meta"]["collection"] = collection
    data = json.dumps(payload).encode("utf-8")
    return role_graph.JsonDocument(f"{kind}.json", data), payload


def role_definition(role_id: str, name: str, actions: list[str], not_actions=None) -> dict:
    return {
        "id": f"/subscriptions/SUB-1/providers/Microsoft.Authorization/roleDefinitions/{role_id}",
        "name": role_id,
        "properties": {
            "roleName": name,
            "type": "CustomRole",
            "assignableScopes": ["/subscriptions/SUB-1"],
            "permissions": [
                {
                    "actions": actions,
                    "notActions": not_actions or [],
                    "dataActions": [],
                    "notDataActions": [],
                }
            ],
        },
    }


def assignment(role_id: str, condition: str | None = None) -> dict:
    properties = {
        "roleDefinitionId": f"/subscriptions/SUB-1/providers/Microsoft.Authorization/roleDefinitions/{role_id}",
        "principalId": "USER-1",
        "principalType": "User",
        "scope": "/subscriptions/SUB-1",
    }
    if condition is not None:
        properties["condition"] = condition
        properties["conditionVersion"] = "2.0"
    return {
        "roleName": "Unknown",
        "role_definition_id": properties["roleDefinitionId"],
        "principal_id": "USER-1",
        "principal_type": "User",
        "authored_scope": "/subscriptions/SUB-1",
        "effective_scope": "/subscriptions/SUB-1",
        "assignment_id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/roleAssignments/A-1",
        "raw": {"properties": properties},
    }


def as_assignment(value: dict):
    return role_graph.Assignment(
        role_name=value["roleName"],
        role_definition_id=value["role_definition_id"],
        principal_id=value["principal_id"],
        principal_type=value["principal_type"],
        authored_scope=value["authored_scope"],
        effective_scope=value["effective_scope"],
        assignment_id=value["assignment_id"],
        source="test",
        raw=value["raw"],
    )


class AbacTests(unittest.TestCase):
    def test_role_assignment_condition_allows_only_selected_role(self) -> None:
        condition = (
            "(!(ActionMatches{'Microsoft.Authorization/roleAssignments/write'})) "
            "OR (@Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId] "
            "ForAnyOfAnyValues:GuidEquals {11111111-1111-1111-1111-111111111111})"
        )
        allowed = bark_abac.request_context(
            "Microsoft.Authorization/roleAssignments/write",
            "USER-1",
            "User",
            "11111111-1111-1111-1111-111111111111",
        )
        blocked = bark_abac.request_context(
            "Microsoft.Authorization/roleAssignments/write",
            "USER-1",
            "User",
            "22222222-2222-2222-2222-222222222222",
        )
        self.assertIs(bark_abac.evaluate_condition(condition, allowed), bark_abac.TriState.TRUE)
        self.assertIs(bark_abac.evaluate_condition(condition, blocked), bark_abac.TriState.FALSE)

    def test_unknown_attribute_is_not_allowed(self) -> None:
        state = bark_abac.evaluate_condition(
            "@Resource[Microsoft.Storage/storageAccounts:name] StringEquals 'vault'",
            bark_abac.request_context("Microsoft.Storage/storageAccounts/listkeys/action"),
        )
        self.assertIs(state, bark_abac.TriState.UNKNOWN)


class PermissionAnalysisTests(unittest.TestCase):
    def _parsed(self, definitions: list[dict], extras: list[tuple[str, dict]] = []):
        parsed = [envelope("AZRoleDefinition", definitions)]
        for kind, value in extras:
            parsed.append(envelope(kind, [value]))
        return parsed

    def test_wildcard_and_not_actions_are_resolved(self) -> None:
        role = role_definition(
            "ROLE-1",
            "Wildcard Role",
            ["Microsoft.Authorization/*"],
            ["Microsoft.Authorization/roleAssignments/write"],
        )
        definitions = analysis.parse_role_definitions(self._parsed([role]))
        record = definitions["role-1"]
        context = bark_abac.request_context("Microsoft.Authorization/roleAssignments/delete")
        self.assertIs(analysis._role_allows(record, "Microsoft.Authorization/roleAssignments/delete", context), bark_abac.TriState.TRUE)
        context = bark_abac.request_context("Microsoft.Authorization/roleAssignments/write")
        self.assertIs(analysis._role_allows(record, "Microsoft.Authorization/roleAssignments/write", context), bark_abac.TriState.FALSE)

    def test_condition_and_deny_prevent_confirmed_edges(self) -> None:
        owner_id = "OWNER-1"
        constrained_id = "CONSTRAINED-1"
        allowed_target = "11111111-1111-1111-1111-111111111111"
        definitions = [
            role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"]),
            role_definition(constrained_id, "Constrained RBAC", ["Microsoft.Authorization/roleAssignments/write"]),
            role_definition(allowed_target, "Reader", ["Microsoft.Resources/subscriptions/read"]),
        ]
        condition = (
            "(!(ActionMatches{'Microsoft.Authorization/roleAssignments/write'})) OR "
            "(@Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId] "
            "GuidEquals '" + allowed_target + "')"
        )
        constrained = as_assignment(assignment(constrained_id, condition))
        parsed = self._parsed(
            definitions,
            [
                (
                    "AZDenyAssignment",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/denyAssignments/D-1",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "principals": [{"id": "USER-1", "type": "User"}],
                            "excludePrincipals": [],
                            "permissions": [{"actions": ["Microsoft.Authorization/roleAssignments/write"], "notActions": []}],
                        },
                    },
                )
            ],
        )
        graph, findings = analysis.analyze(
            [constrained],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
            now=datetime(2026, 9, 4, tzinfo=timezone.utc),
        )
        self.assertFalse(
            any(edge["kind"] == "BARK_CanEscalateAzureRBAC" for edge in graph["graph"]["edges"])
        )
        self.assertTrue(any(item["denyDecision"] == "true" for item in findings["permissionFindings"]))

    def test_eligible_pim_is_not_an_active_permission(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZRoleEligibilityScheduleInstance",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/roleEligibilityScheduleInstances/E-1",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "roleDefinitionId": f"/subscriptions/SUB-1/providers/Microsoft.Authorization/roleDefinitions/{owner_id}",
                            "principalId": "USER-1",
                            "principalType": "User",
                            "status": "Provisioned",
                            "startDateTime": "2026-01-01T00:00:00Z",
                        },
                    },
                )
            ],
        )
        graph, findings = analysis.analyze(
            [],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
            now=datetime(2026, 9, 4, tzinfo=timezone.utc),
        )
        self.assertTrue(any(edge["kind"] == "BARK_EligibleForAzureRole" for edge in graph["graph"]["edges"]))
        self.assertEqual(findings["meta"]["eligible"], 1)
        self.assertFalse(any(edge["kind"] == "BARK_CanAssignAzureRole" for edge in graph["graph"]["edges"]))

    def test_missing_deny_snapshot_is_unknown_and_not_confirmed(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed([role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])])
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertTrue(any(item["denyDecision"] == "unknown" for item in findings["permissionFindings"]))

    def test_all_principals_deny_uses_zero_guid_sentinel(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZDenyAssignment",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/denyAssignments/D-1",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "principals": [{"id": "00000000-0000-0000-0000-000000000000", "type": "SystemDefined"}],
                            "excludePrincipals": [],
                            "permissions": [{"actions": ["Microsoft.Authorization/*"], "notActions": []}],
                        },
                    },
                )
            ],
        )
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertTrue(any(item["denyDecision"] == "true" for item in findings["permissionFindings"]))

    def test_expired_pim_eligibility_is_not_emitted(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZRoleEligibilityScheduleInstance",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/roleEligibilityScheduleInstances/E-1",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "roleDefinitionId": f"/subscriptions/SUB-1/providers/Microsoft.Authorization/roleDefinitions/{owner_id}",
                            "principalId": "USER-1",
                            "principalType": "User",
                            "status": "Revoked",
                            "startDateTime": "2026-01-01T00:00:00Z",
                            "endDateTime": "2026-02-01T00:00:00Z",
                        },
                    },
                )
            ],
        )
        graph, findings = analysis.analyze(
            [],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
            now=datetime(2026, 9, 4, tzinfo=timezone.utc),
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertEqual(findings["meta"]["eligible"], 0)

    def test_pim_edge_properties_are_flat_primitives(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZRoleEligibilityScheduleInstance",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/roleEligibilityScheduleInstances/E-1",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "roleDefinitionId": f"/subscriptions/SUB-1/providers/Microsoft.Authorization/roleDefinitions/{owner_id}",
                            "principalId": "USER-1",
                            "principalType": "User",
                            "status": "Provisioned",
                            "startDateTime": "2026-01-01T00:00:00Z",
                        },
                    },
                )
            ],
        )
        graph, _ = analysis.analyze(
            [], parsed, role_graph.scope_kind, role_graph.principal_kind,
            now=datetime(2026, 9, 4, tzinfo=timezone.utc),
        )
        properties = graph["graph"]["edges"][0]["properties"]
        self.assertNotIsInstance(properties.get("pimpolicy"), dict)
        self.assertIsInstance(properties["pimactivationrequirementsunknown"], bool)

    def test_deny_snapshot_completeness_is_scoped_and_failure_safe(self) -> None:
        owner_id = "OWNER-1"
        base = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])]
        )
        completed = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": True,
                "requestedScopes": ["/subscriptions/SUB-1"],
                "successfulScopes": ["/subscriptions/SUB-1"],
                "failedScopes": [],
            },
        )
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            base + [completed],
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertTrue(graph["graph"]["edges"])
        self.assertTrue(findings["meta"]["denySnapshotComplete"])

        failed = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": False,
                "requestedScopes": ["/subscriptions/SUB-1"],
                "successfulScopes": [],
                "failedScopes": ["/subscriptions/SUB-1"],
            },
        )
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            base + [failed],
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertTrue(
            all(
                item.get("denyDecision") == "unknown"
                for item in findings["permissionFindings"]
                if "denyDecision" in item
            )
        )

    def test_failed_child_scope_overrides_successful_parent_scope(self) -> None:
        coverage = analysis.DenySnapshotCoverage(
            successful_scopes=frozenset(
                {"/providers/microsoft.management/managementgroups/mg-1"}
            ),
            failed_scopes=frozenset({"/subscriptions/sub-1"}),
            requested_scopes=frozenset(
                {
                    "/providers/microsoft.management/managementgroups/mg-1",
                    "/subscriptions/sub-1",
                }
            ),
            metadata_files=2,
        )
        parents = {
            "/subscriptions/sub-1":
                "/providers/microsoft.management/managementgroups/mg-1"
        }
        self.assertFalse(
            coverage.covers(
                "/subscriptions/sub-1/resourcegroups/rg-1", parents
            )
        )

    def test_failed_duplicate_snapshot_is_not_erased_by_another_success(self) -> None:
        scope = "/subscriptions/SUB-1"
        successful = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": True,
                "requestedScopes": [scope],
                "successfulScopes": [scope],
                "failedScopes": [],
            },
        )
        failed = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": False,
                "requestedScopes": [scope],
                "successfulScopes": [],
            },
        )
        coverage = analysis.collect_deny_snapshot_coverage(
            [successful, failed]
        )
        self.assertFalse(coverage.covers(scope))
        self.assertIn(scope.lower(), coverage.failed_scopes)

    def test_incomplete_parent_enumeration_is_not_globally_complete(self) -> None:
        scope = "/subscriptions/SUB-1"
        snapshot = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": False,
                "requestedScopes": [scope],
                "successfulScopes": [scope],
                "failedScopes": [],
            },
        )
        coverage = analysis.collect_deny_snapshot_coverage([snapshot])
        # The explicitly queried subscription remains authoritative, while
        # the tenant-wide collection correctly remains partial.
        self.assertTrue(coverage.covers(scope))
        self.assertFalse(coverage.complete)

    def test_recursive_deny_filename_keeps_collection_metadata(self) -> None:
        scope = "/subscriptions/SUB-1"
        document, payload = envelope(
            "AZDenyAssignment",
            [],
            {
                "complete": True,
                "requestedScopes": [scope],
                "successfulScopes": [scope],
                "failedScopes": [],
            },
        )
        nested_document = role_graph.JsonDocument(
            f"nested/{document.name}", document.data
        )
        coverage = analysis.collect_deny_snapshot_coverage(
            [(nested_document, payload)]
        )
        self.assertTrue(coverage.covers(scope))

    def test_resource_scope_follows_subscription_to_management_group(self) -> None:
        management_group = (
            "/providers/Microsoft.Management/managementGroups/MG-1"
        )
        subscription = "/subscriptions/SUB-1"
        resource = (
            f"{subscription}/resourceGroups/RG-1/providers/"
            "Microsoft.Compute/virtualMachines/VM-1"
        )
        self.assertTrue(
            analysis._scope_within(
                resource,
                management_group,
                {subscription.lower(): management_group.lower()},
            )
        )

    def test_direct_user_is_denied_through_transitive_group_membership(self) -> None:
        owner_id = "OWNER-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZGroupMember",
                    {
                        "groupId": "GROUP-PARENT",
                        "members": [
                            {
                                "member": {
                                    "id": "GROUP-CHILD",
                                    "@odata.type": "#microsoft.graph.group",
                                }
                            }
                        ],
                    },
                ),
                (
                    "AZGroupMember",
                    {
                        "groupId": "GROUP-CHILD",
                        "members": [
                            {
                                "member": {
                                    "id": "USER-1",
                                    "@odata.type": "#microsoft.graph.user",
                                }
                            }
                        ],
                    },
                ),
                (
                    "AZDenyAssignment",
                    {
                        "id": "/subscriptions/SUB-1/providers/Microsoft.Authorization/denyAssignments/D-GROUP",
                        "properties": {
                            "scope": "/subscriptions/SUB-1",
                            "principals": [{"id": "GROUP-PARENT", "type": "Group"}],
                            "excludePrincipals": [],
                            "permissions": [
                                {
                                    "actions": ["Microsoft.Authorization/*"],
                                    "notActions": [],
                                }
                            ],
                        },
                    },
                ),
            ],
        )
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertTrue(
            any(item.get("denyDecision") == "true" for item in findings["permissionFindings"])
        )

    def test_partial_group_membership_prevents_false_confirmed_allow(self) -> None:
        owner_id = "OWNER-1"
        scope = "/subscriptions/SUB-1"
        parsed = self._parsed(
            [role_definition(owner_id, "Owner", ["Microsoft.Authorization/*"])],
            [
                (
                    "AZDenyAssignment",
                    {
                        "id": f"{scope}/providers/Microsoft.Authorization/denyAssignments/D-HIDDEN",
                        "properties": {
                            "scope": scope,
                            "principals": [{"id": "GROUP-HIDDEN", "type": "Group"}],
                            "excludePrincipals": [],
                            "permissions": [
                                {
                                    "actions": ["Microsoft.Authorization/*"],
                                    "notActions": [],
                                }
                            ],
                        },
                    },
                ),
            ],
        )
        # Make deny enumeration authoritative while explicitly recording that
        # the group-parent/member walk failed before it could prove ancestry.
        parsed.extend(
            [
                envelope(
                    "AZDenyAssignment",
                    [],
                    {
                        "complete": True,
                        "requestedScopes": [scope],
                        "successfulScopes": [scope],
                        "failedScopes": [],
                    },
                ),
                envelope(
                    "AZGroupMember",
                    [],
                    {
                        "complete": False,
                        "requestedParents": 2,
                        "successfulParents": 1,
                        "failedParents": 1,
                    },
                ),
            ]
        )
        graph, findings = analysis.analyze(
            [as_assignment(assignment(owner_id))],
            parsed,
            role_graph.scope_kind,
            role_graph.principal_kind,
        )
        self.assertFalse(graph["graph"]["edges"])
        self.assertTrue(
            any(
                item.get("denyDecision") == "unknown"
                for item in findings["permissionFindings"]
            )
        )
        self.assertFalse(findings["meta"]["groupMembershipSnapshotComplete"])

    def test_pending_admin_decision_is_not_an_active_pim_record(self) -> None:
        self.assertFalse(
            analysis._now_active(
                {
                    "state": "active",
                    "status": "PendingAdminDecision",
                    "startDateTime": "2026-01-01T00:00:00Z",
                },
                datetime(2026, 9, 4, tzinfo=timezone.utc),
            )
        )

    def test_pim_policy_joins_exact_policy_id_and_role(self) -> None:
        role_id = "ROLE-1"
        scope = "/subscriptions/SUB-1"
        assignment_extra = analysis.AuthorizationExtra(
            "AZRoleManagementPolicyAssignment",
            {"id": "PA-1"},
            {
                "scope": scope,
                "roleDefinitionId": f"{scope}/providers/Microsoft.Authorization/roleDefinitions/{role_id}",
                "policyId": f"{scope}/providers/Microsoft.Authorization/roleManagementPolicies/POLICY-1",
            },
            "policy-assignment.json",
        )
        exact_policy = analysis.AuthorizationExtra(
            "AZRoleManagementPolicy",
            {"id": f"{scope}/providers/Microsoft.Authorization/roleManagementPolicies/POLICY-1"},
            {
                "rules": [
                    {
                        "ruleType": "RoleManagementPolicyEnablementRule",
                        "enabledRules": ["MultiFactorAuthentication", "Justification"],
                        "target": {"caller": "EndUser", "level": "Assignment", "operations": ["All"]},
                    }
                ]
            },
            "policy.json",
        )
        unrelated_policy = analysis.AuthorizationExtra(
            "AZRoleManagementPolicy",
            {"id": f"{scope}/providers/Microsoft.Authorization/roleManagementPolicies/POLICY-2"},
            {
                "rules": [
                    {
                        "ruleType": "RoleManagementPolicyAuthenticationContextRule",
                        "isEnabled": True,
                        "target": {"caller": "EndUser", "level": "Assignment", "operations": ["All"]},
                    }
                ]
            },
            "unrelated.json",
        )
        summary = analysis._pim_policy_summary(
            [assignment_extra, exact_policy, unrelated_policy], scope, role_id
        )
        self.assertEqual(
            summary["activationControls"], ["justification", "mfa"]
        )
        self.assertFalse(summary["activationRequirementsUnknown"])

    def test_pim_policy_does_not_join_same_name_from_another_scope(self) -> None:
        role_id = "ROLE-1"
        assignment_scope = "/subscriptions/SUB-1"
        other_scope = "/subscriptions/SUB-2"
        assignment_extra = analysis.AuthorizationExtra(
            "AZRoleManagementPolicyAssignment",
            {"id": "PA-1"},
            {
                "scope": assignment_scope,
                "roleDefinitionId": (
                    f"{assignment_scope}/providers/Microsoft.Authorization/"
                    f"roleDefinitions/{role_id}"
                ),
                "policyId": (
                    f"{assignment_scope}/providers/Microsoft.Authorization/"
                    "roleManagementPolicies/POLICY-SHARED"
                ),
            },
            "policy-assignment.json",
        )
        wrong_scope_policy = analysis.AuthorizationExtra(
            "AZRoleManagementPolicy",
            {
                "id": (
                    f"{other_scope}/providers/Microsoft.Authorization/"
                    "roleManagementPolicies/POLICY-SHARED"
                ),
                "name": "POLICY-SHARED",
            },
            {
                "rules": [
                    {
                        "ruleType": "RoleManagementPolicyEnablementRule",
                        "enabledRules": ["MultiFactorAuthentication"],
                        "target": {
                            "caller": "EndUser",
                            "level": "Assignment",
                            "operations": ["All"],
                        },
                    }
                ]
            },
            "other-scope-policy.json",
        )
        summary = analysis._pim_policy_summary(
            [assignment_extra, wrong_scope_policy], assignment_scope, role_id
        )
        self.assertEqual(summary["activationControls"], [])
        self.assertTrue(summary["activationRequirementsUnknown"])

    def test_data_actions_do_not_imply_control_plane_rbac_escalation(self) -> None:
        role = role_definition("ROLE-DATA", "Data Writer", [])
        role["properties"]["permissions"][0]["dataActions"] = [
            "Microsoft.Authorization/roleAssignments/write"
        ]
        parsed = analysis.parse_role_definitions(self._parsed([role]))
        self.assertFalse(analysis._privileged_role(parsed["role-data"]))


if __name__ == "__main__":
    unittest.main()
