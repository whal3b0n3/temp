"""Native edge contract and collector regressions (no live tenant required)."""
import copy
import io
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

import bark_all_info as collector
import bark_native_edges as native
import bark_role_graph as bundle
from test_bark_all_info import FixtureHttp, FakeTokens, TENANT, USER, GROUP, ROLE, SCOPE, encoded

NOW = datetime(2026, 9, 25, tzinfo=timezone.utc)
VAULT = SCOPE + "/resourceGroups/lab/providers/Microsoft.KeyVault/vaults/barkvault"


def eligibility(**values):
    return {"id": "eligibility-1", "tenantId": TENANT, "principalId": USER,
            "roleDefinitionId": ROLE, "directoryScopeId": "/",
            "startDateTime": "2026-01-01T00:00:00Z", "endDateTime": "2099-01-01T00:00:00Z", **values}


def policy():
    target = {"caller": "EndUser", "level": "Assignment", "operations": ["all"]}
    def rule(prefix, kind, **extra):
        return {"id": prefix + "_EndUser_Assignment",
                "@odata.type": "#microsoft.graph.unifiedRoleManagementPolicy" + kind + "Rule",
                "target": dict(target), **extra}
    return {"id": "assignment-1", "tenantId": TENANT, "policyId": "policy-1",
            "roleDefinitionId": ROLE, "scopeId": "/", "scopeType": "Directory",
            "policy": {"rules": [
                rule("Approval", "Approval", setting={"isApprovalRequired": True, "approvalStages": [
                    {"primaryApprovers": [
                        {"@odata.type": "#microsoft.graph.singleUser", "userId": USER},
                        {"@odata.type": "#microsoft.graph.groupMembers", "groupId": GROUP}],
                     "isEscalationEnabled": False, "escalationApprovers": []}]}),
                rule("Enablement", "Enablement", enabledRules=["MultiFactorAuthentication", "Justification", "Ticketing"]),
                rule("AuthenticationContext", "AuthenticationContext", isEnabled=False),
            ]}}


def vault(**properties):
    return {"id": VAULT, "name": "barkvault", "tenantId": TENANT,
            "properties": {"tenantId": TENANT, "enableRbacAuthorization": False,
                           "accessPolicies": [{"objectId": USER, "tenantId": TENANT,
                                               "permissions": {"secrets": ["get", "list"],
                                                               "keys": ["Get"], "certificates": ["GET"]}}],
                           **properties}}


def document(kind, *rows):
    root = {"data": [{"kind": kind, "data": row} for row in rows],
            "meta": {"type": "azure", "version": 5, "count": len(rows)}}
    return bundle.JsonDocument(kind + ".json", json.dumps(root).encode()), root


class NativeContractTests(unittest.TestCase):
    def test_eligibility_requires_current_root_directory_scope(self):
        self.assertEqual(native.eligibility_record(eligibility(), NOW)["principalId"], USER.upper())
        for values in [
            {"startDateTime": "2099-01-01T00:00:00Z"},
            {"endDateTime": "2020-01-01T00:00:00Z"},
            {"startDateTime": "broken"}, {"startDateTime": "2026-01-01"},
            {"directoryScopeId": "/administrativeUnits/unit"}, {"appScopeId": "app"},
            {"principalId": ""}, {"tenantId": ""},
        ]:
            with self.subTest(values=values), self.assertRaises(ValueError):
                native.eligibility_record(eligibility(**values), NOW)

    def test_policy_uses_activation_rules_and_preserves_group_approvers(self):
        raw = policy()
        admin = copy.deepcopy(raw["policy"]["rules"][0])
        admin["id"] = "Approval_Admin_Assignment"
        admin["target"]["caller"] = "Admin"
        admin["setting"] = {"isApprovalRequired": False}
        raw["policy"]["rules"].append(admin)
        result = native.policy_record(raw)
        self.assertTrue(result["endUserAssignmentRequiresApproval"])
        self.assertTrue(result["endUserAssignmentRequiresMFA"])
        self.assertTrue(result["endUserAssignmentRequiresJustification"])
        self.assertTrue(result["endUserAssignmentRequiresTicketInformation"])
        self.assertFalse(result["endUserAssignmentRequiresCAPAuthenticationContext"])
        self.assertEqual(result["endUserAssignmentUserApprovers"], [USER.upper()])
        self.assertEqual(result["endUserAssignmentGroupApprovers"], [GROUP.upper()])
        self.assertNotIn("name", result)

    def test_partial_or_unsupported_policy_never_becomes_empty_approver_fallback(self):
        variants = []
        raw = policy();raw["policy"]["rules"] = [];variants.append(raw)
        raw = policy();raw["policy"]["rules@odata.nextLink"] = "next";variants.append(raw)
        raw = policy();raw["policy"]["rules"][0]["setting"]["approvalStages"] = [];variants.append(raw)
        raw = policy();raw["policy"]["rules"][0]["setting"]["approvalStages"][0]["primaryApprovers"] = [
            {"@odata.type": "#microsoft.graph.requestorManager"}];variants.append(raw)
        raw = policy();raw["policy"]["rules"][0]["setting"]["approvalStages"][0]["isEscalationEnabled"] = True;variants.append(raw)
        raw = policy();raw["scopeId"] = "/group";variants.append(raw)
        for raw in variants:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                native.policy_record(raw)

    def test_disabled_approval_does_not_emit_configured_approvers(self):
        raw = policy();raw["policy"]["rules"][0]["setting"]["isApprovalRequired"] = False
        result = native.policy_record(raw)
        self.assertFalse(result["endUserAssignmentRequiresApproval"])
        self.assertEqual(result["endUserAssignmentUserApprovers"], [])
        self.assertEqual(result["endUserAssignmentGroupApprovers"], [])

    def test_vault_permissions_match_native_case_sensitive_get(self):
        rows, excluded = native.key_vault_records(vault())
        self.assertEqual(excluded, [])
        self.assertEqual(rows[0]["objectId"], USER.upper())
        self.assertEqual(rows[0]["keyVaultId"], VAULT.upper())
        for key in ("secrets", "keys", "certificates"):
            self.assertIn("Get", rows[0]["permissions"][key])
        self.assertNotIn("get", rows[0]["permissions"]["secrets"])

    def test_rbac_and_application_restrictions_do_not_create_false_access(self):
        self.assertEqual(native.key_vault_records(vault(enableRbacAuthorization=True)), ([], []))
        raw = vault();raw["properties"]["accessPolicies"][0]["applicationId"] = "restricted-client"
        rows, audit = native.key_vault_records(raw)
        self.assertEqual(rows, [])
        self.assertEqual(audit[0]["reason"], "application-bound-access-policy")
        raw = vault();raw["properties"].pop("accessPolicies")
        with self.assertRaisesRegex(ValueError, "missing-vault-access-policies"):
            native.key_vault_records(raw)

    def test_bundle_converts_raw_pim_and_vaults_but_retains_arm_pim_as_evidence(self):
        parsed = [document(native.ELIGIBILITY, eligibility()), document(native.POLICY, policy()),
                  document("AZKeyVault", vault()),
                  document("AZRoleEligibilityScheduleInstance", {"id": "arm-eligible",
                           "properties": {"principalId": USER, "scope": SCOPE}})]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bundle.create_upload_bundle(root / "bundle", parsed, root, bundle.Reporter(), 0)
            merged = json.loads((root / "bundle/01-upload-native/azurehound_bark.json").read_text())
            kinds = [row["kind"] for row in merged["data"]]
            self.assertEqual(kinds.count("AZRoleEligibilityScheduleInstance"), 1)
            self.assertEqual(kinds.count("AZRoleManagementPolicyAssignment"), 1)
            self.assertEqual(kinds.count("AZKeyVaultAccessPolicy"), 1)
            self.assertTrue((root / "bundle/do-not-upload/AZEntraRoleManagementPolicyAssignment.json").exists())

    def test_raw_graph_policy_is_not_a_native_upload(self):
        _, raw = document(native.POLICY, policy())
        self.assertEqual(bundle.classify_for_bundle(raw).action, "do-not-upload")
        # AzureHound omits false boolean fields; retain compatibility with it.
        self.assertTrue(bundle._native_shape_supported(
            [{"kind": "AZRoleManagementPolicyAssignment", "data": {
                "policyId": "policy", "roleDefinitionId": ROLE, "tenantId": TENANT}}],
            "AZRoleManagementPolicyAssignment"))

    def test_managed_identity_mapping_preserves_original_and_rejects_conflicts(self):
        identifier = SCOPE + "/providers/Microsoft.ManagedIdentity/userAssignedIdentities/test"
        record = {"kind": "AZVM", "data": {"id": "vm", "identity": {"userAssignedIdentities": {identifier: {}}}}}
        index = {identifier.lower(): {"principalId": USER, "clientId": GROUP}}
        result = native.hydrate_managed_identities(record, index)
        self.assertEqual(result["data"]["identity"]["userAssignedIdentities"][identifier]["principalId"], USER.upper())
        self.assertEqual(record["data"]["identity"]["userAssignedIdentities"][identifier], {})
        record["data"]["identity"]["userAssignedIdentities"][identifier]["principalId"] = "different"
        self.assertEqual(native.hydrate_managed_identities(record, index), record)

    def test_identity_inventory_rejects_invalid_or_conflicting_principals(self):
        identifier = SCOPE + "/providers/Microsoft.ManagedIdentity/userAssignedIdentities/test"
        def row(principal):
            return {"id": identifier, "properties": {"principalId": principal, "clientId": GROUP}}
        self.assertEqual(native.identity_index([document("AZUserAssignedIdentity", row(USER))])[
            identifier.lower()]["principalId"], USER.upper())
        self.assertEqual(native.identity_index([document("AZUserAssignedIdentity", row({}))]), {})
        self.assertEqual(native.identity_index([document("AZUserAssignedIdentity", row(USER), row(GROUP))]), {})

    def test_exclusions_are_auditable_and_valid_records_survive(self):
        payload = native.build_native_edge_records([
            document(native.ELIGIBILITY, eligibility(endDateTime="2000-01-01T00:00:00Z"), eligibility()),
            document(native.POLICY, {"policyId": "incomplete"}),
        ], NOW)
        self.assertEqual(len(payload["data"]), 1)
        self.assertEqual(len(payload["meta"]["excludedRecords"]), 2)


class EdgeHttp(FixtureHttp):
    def __init__(self, fail_rules=False, fail_vault=False):
        super().__init__()
        self.fail_rules, self.fail_vault = fail_rules, fail_vault

    def send(self, method, url, headers=None, data=None):
        parts = urlsplit(url)
        path = parts.path.lower()
        if path.endswith("/roleeligibilityscheduleinstances") and parts.netloc == "graph.microsoft.com":
            self.calls.append((method, url, headers, data))
            if not parts.query:
                return encoded({"value": [eligibility()], "@odata.nextLink": url + "?page=2"})
            return encoded({"value": [eligibility(id="eligibility-2", principalId=GROUP)]})
        if path == "/v1.0/policies/rolemanagementpolicyassignments":
            self.calls.append((method, url, headers, data))
            raw = policy();raw["policy"]["rules"] = [];raw["policy"]["rules@odata.nextLink"] = "partial"
            return encoded({"value": [raw]})
        if path == "/v1.0/policies/rolemanagementpolicies/policy-1/rules":
            self.calls.append((method, url, headers, data))
            if self.fail_rules:
                raise collector.CollectionError("HTTP 403", 403)
            rows = policy()["policy"]["rules"]
            return encoded({"value": rows[1:]} if parts.query else
                           {"value": rows[:1], "@odata.nextLink": url + "?page=2"})
        if path == VAULT.lower():
            self.calls.append((method, url, headers, data))
            if self.fail_vault:
                raise collector.CollectionError("HTTP 403", 403)
            return encoded(vault())
        result = super().send(method, url, headers, data)
        if path.endswith("/vaults"):
            raw = json.loads(result)
            raw["value"][0]["properties"].pop("accessPolicies")
            return encoded(raw)
        return result


class CollectorEdgeTests(unittest.TestCase):
    def test_pim_pagination_and_vault_detail_fetch_reach_native_converter(self):
        with tempfile.TemporaryDirectory() as tmp:
            http = EdgeHttp()
            c = collector.Collector(collector.Api(http, FakeTokens()), TENANT, Path(tmp))
            c.entra_pim();c.arm()
            self.assertFalse(c.api.failures)
            raw = json.loads((Path(tmp) / (native.POLICY + ".json")).read_text())
            self.assertEqual(len(raw["data"][0]["data"]["policy"]["rules"]), 3)
            self.assertNotIn("rules@odata.nextLink", raw["data"][0]["data"]["policy"])
            native.policy_record(raw["data"][0]["data"])
            rows = json.loads((Path(tmp) / (native.ELIGIBILITY + ".json")).read_text())["data"]
            self.assertEqual(len(rows), 2)
            raw = json.loads((Path(tmp) / "AZKeyVault.json").read_text())["data"][0]["data"]
            self.assertEqual(len(native.key_vault_records(raw)[0]), 1)

    def test_failed_detail_and_policy_requests_preserve_partial_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            c = collector.Collector(collector.Api(EdgeHttp(True, True), FakeTokens()), TENANT, Path(tmp))
            c.entra_pim();c.arm()
            for kind in (native.POLICY, "AZKeyVault"):
                raw = json.loads((Path(tmp) / (kind + ".json")).read_text())
                self.assertFalse(raw["meta"]["collection"]["complete"])
                converted = native.build_native_edge_records([(SimpleNamespace(name=kind), raw)], NOW)
                self.assertEqual(converted["data"], [])
                self.assertTrue(converted["meta"]["excludedRecords"])
