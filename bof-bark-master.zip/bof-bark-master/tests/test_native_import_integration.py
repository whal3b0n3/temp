"""Opt-in native/OpenGraph import regression against an EMPTY disposable BloodHound 9.3 instance.

Set BARK_TEST_BH_URL and BARK_TEST_BH_TOKEN (session token). This test writes
synthetic data and refuses a database containing Azure nodes; it does not delete data.
"""
import json
import os
from pathlib import Path
import tempfile
import unittest

import bark_role_graph as bundle
import bark_upload as upload
from test_bark_native_edges import document, eligibility, policy, vault, TENANT, USER, GROUP, ROLE, SCOPE, VAULT
from test_bark_all_info import SP, APPID


def fixture():
    rg = SCOPE + "/resourceGroups/lab"
    identity = rg + "/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fixture"
    vm = rg + "/providers/Microsoft.Compute/virtualMachines/fixture"
    rows = [
        document("AZTenant", {"id": "/tenants/" + TENANT, "tenantId": TENANT,
                             "displayName": "Fixture", "defaultDomain": "fixture.test"}),
        document("AZSubscription", {"id": SCOPE, "subscriptionId": SCOPE, "tenantId": TENANT, "displayName": "Fixture"}),
        document("AZResourceGroup", {"id": rg, "name": "lab", "subscriptionId": SCOPE, "tenantId": TENANT}),
        document("AZUser", {"id": USER, "tenantId": TENANT, "displayName": "Fixture User",
                           "userPrincipalName": "user@fixture.test", "accountEnabled": True}),
        document("AZGroup", {"id": GROUP, "tenantId": TENANT, "displayName": "Fixture Group", "securityEnabled": True}),
        document("AZRole", {"id": ROLE, "tenantId": TENANT, "tenantName": "fixture.test", "displayName": "Fixture Role"}),
        document("AZServicePrincipal", {"id": SP, "tenantId": TENANT, "displayName": "Fixture SP",
                                       "appId": APPID, "servicePrincipalType": "ManagedIdentity",
                                       "appRoles": [{"id": ROLE, "displayName": "Fixture App Role", "value": "Fixture.Read"}]}),
        document("AZUserAssignedIdentity", {"id": identity, "tenantId": TENANT,
                                            "properties": {"principalId": SP, "clientId": APPID}}),
        document("AZVM", {"id": vm, "name": "fixture", "tenantId": TENANT, "resourceGroupId": rg,
                          "plan": {}, "extendedLocation": {}, "properties": {"vmId": "vm-fixture-id"},
                          "identity": {"type": "UserAssigned", "userAssignedIdentities": {identity: {}}}}),
        document("AZEntraRoleEligibilityScheduleInstance", eligibility(), eligibility(endDateTime="2000-01-01T00:00:00Z", principalId=GROUP)),
        document("AZEntraRoleManagementPolicyAssignment", policy()),
        document("AZKeyVault", {**vault(), "resourceGroup": rg}),
        document("AZAppRoleAssignment", {"id": "fixture-app-assignment", "tenantId": TENANT,
                                         "principalId": USER, "principalType": "User",
                                         "resourceId": SP, "appRoleId": ROLE, "appId": APPID}),
    ]
    graph = bundle.make_app_role_graph(rows)
    rows.append((bundle.JsonDocument("AZAppRoleGraph.json", bundle.json_bytes(graph, False), generated=True), graph))
    return rows, vm


@unittest.skipUnless(os.environ.get("BARK_TEST_BH_URL") and os.environ.get("BARK_TEST_BH_TOKEN"),
                     "requires an explicitly configured disposable BloodHound instance")
class NativeImportTests(unittest.TestCase):
    def test_native_edges_and_opengraph_preserve_endpoints(self):
        api = upload.BloodHound(os.environ["BARK_TEST_BH_URL"], os.environ["BARK_TEST_BH_TOKEN"])
        def query(cypher):
            try:
                return api.call("POST", "/api/v2/graphs/cypher",
                                {"query": cypher, "include_properties": True}).get("data", {})
            except upload.UploadError as exc:
                if "HTTP 404" in str(exc):
                    return {}
                raise

        self.assertFalse(query("MATCH (n:AZBase) RETURN n LIMIT 1").get("nodes"),
                         "Use an EMPTY disposable graph; existing Azure data found")
        rows, vm = fixture()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bundle.create_upload_bundle(root / "bundle", rows, root, bundle.Reporter(), 0)
            phases = upload.bundle_plan(root / "bundle")
            jobs = upload.upload_bundle(api, [phases[0]], wait_seconds=600)
            before = query("MATCH p=()-[r]->() RETURN p")
            def triples(graph):
                nodes = graph["nodes"]
                return {(nodes[str(e["source"])]["objectId"], e["kind"],
                         nodes[str(e["target"])]["objectId"]) for e in graph["edges"]}
            observed = triples(before)
            role = (ROLE + "@" + TENANT).upper()
            expected = {(USER.upper(), "AZRoleEligible", role),
                        (USER.upper(), "AZRoleApprover", role), (GROUP.upper(), "AZRoleApprover", role),
                        (vm.upper(), "AZManagedIdentity", SP.upper())}
            expected.update((USER.upper(), kind, VAULT.upper()) for kind in
                            ("AZGetSecrets", "AZGetKeys", "AZGetCertificates"))
            self.assertTrue(expected <= observed, expected - observed)
            self.assertNotIn((GROUP.upper(), "AZRoleEligible", role), observed)
            def user(graph):
                return next(n for n in graph["nodes"].values() if n["objectId"] == USER.upper())
            native_user = user(before)
            self.assertEqual(native_user["properties"]["name"], "USER@FIXTURE.TEST")
            self.assertEqual(native_user["properties"]["displayname"], "Fixture User")
            self.assertTrue(native_user["properties"]["enabled"])
            jobs += upload.upload_bundle(api, [[], phases[1]], wait_seconds=600)
            after = query("MATCH p=()-[r]->() RETURN p")
            self.assertTrue(any(e["kind"] == "BARK_AssignedAppRole" for e in after["edges"]))
            updated_user = user(after)
            self.assertEqual(updated_user["kind"], native_user["kind"])
            # BloodHound advances collection/ingest timestamps when resolving endpoints.
            def stable_properties(node):
                return {k: v for k, v in node["properties"].items()
                        if k not in {"lastseen", "lastcollected"}}
            self.assertEqual(stable_properties(updated_user), stable_properties(native_user))
            self.assertTrue(expected <= triples(after))
            for job in jobs:
                status = api.call("GET", f"/api/v2/file-upload?id=eq:{job}&limit=1")["data"][0]
                self.assertEqual(status["status"], 2)
                self.assertEqual(status.get("failed_files", 0), 0)
                self.assertEqual(status.get("partial_failed_files", 0), 0)
