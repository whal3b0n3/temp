import threading
import time
from concurrent.futures import ThreadPoolExecutor
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
from urllib import error, parse

import bark_all_info as collector
import bark_role_graph

TENANT = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
USER = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
GROUP = "cccccccc-cccc-cccc-cccc-cccccccccccc"
SP = "dddddddd-dddd-dddd-dddd-dddddddddddd"
APP = "eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee"
APPID = "ffffffff-ffff-ffff-ffff-ffffffffffff"
ROLE = "11111111-1111-1111-1111-111111111111"
SUB = "22222222-2222-2222-2222-222222222222"
SCOPE = "/subscriptions/" + SUB
RESOURCE = SCOPE + "/resourceGroups/lab/providers/Microsoft.Storage/storageAccounts/barktest"
OWNER = "8e3af657-a8ff-443c-a75c-2fe8c4bcb635"


def encoded(value):
    return json.dumps(value).encode()


class FakeTokens:
    def __init__(self):
        self.calls = []

    def get(self, audience, force=False):
        self.calls.append((audience, force))
        return "fake-access"


class QueueHttp:
    def __init__(self, replies):
        self.replies = iter(replies)
        self.calls = []

    def send(self, method, url, headers=None, data=None):
        self.calls.append((method, url, headers, data))
        result = next(self.replies)
        if isinstance(result, Exception):
            raise result
        return encoded(result)


class TransportTests(unittest.TestCase):
    def test_rotated_refresh_token_is_used_for_other_audience_and_cached(self):
        http = QueueHttp([
            {"access_token": "graph", "refresh_token": "rotated", "expires_in": 3600},
            {"access_token": "arm", "expires_in": 3600},
        ])
        tokens = collector.Tokens(TENANT, "original", http)
        self.assertEqual(tokens.get(collector.GRAPH), "graph")
        self.assertEqual(tokens.get(collector.GRAPH), "graph")
        self.assertEqual(tokens.get(collector.ARM), "arm")
        self.assertEqual(len(http.calls), 2)
        form = parse.parse_qs(http.calls[1][3].decode())
        self.assertEqual(form["refresh_token"], ["rotated"])
        self.assertEqual(form["resource"], [collector.ARM])

    def test_client_fallback_and_token_expiry(self):
        now = [0]
        http = QueueHttp([
            collector.CollectionError("HTTP 400", 400),
            {"access_token": "first", "expires_in": 120},
            {"access_token": "second", "expires_in": 120},
        ])
        tokens = collector.Tokens(TENANT, "rt", http, clock=lambda: now[0])
        self.assertEqual(tokens.get(collector.LEGACY), "first")
        first = parse.parse_qs(http.calls[0][3].decode())
        second = parse.parse_qs(http.calls[1][3].decode())
        self.assertEqual(first["client_id"], [collector.CLIENTS[2]])
        self.assertEqual(second["client_id"], [collector.CLIENTS[0]])
        now[0] = 61
        self.assertEqual(tokens.get(collector.LEGACY), "second")

    def test_401_refreshes_once(self):
        http = QueueHttp([collector.CollectionError("HTTP 401", 401), {"value": []}])
        tokens = FakeTokens()
        api = collector.Api(http, tokens)
        result = api.listing("/v1.0/users", collector.GRAPH, "users")
        self.assertTrue(result.complete)
        self.assertEqual(tokens.calls, [(collector.GRAPH, False), (collector.GRAPH, True)])

    def test_pagination_retains_partial_records_on_failure(self):
        http = QueueHttp([
            {"value": [{"id": "one"}], "@odata.nextLink": collector.GRAPH + "/v1.0/users?page=2"},
            collector.CollectionError("HTTP 403", 403),
        ])
        api = collector.Api(http, FakeTokens())
        result = api.listing("/v1.0/users", collector.GRAPH, "users")
        self.assertEqual(result.items, [{"id": "one"}])
        self.assertFalse(result.complete)
        self.assertEqual(len(api.failures), 1)

    def test_graph_legacy_and_arm_paging(self):
        for key in ("@odata.nextLink", "odata.nextLink", "nextLink"):
            http = QueueHttp([{"value": [{"id": "one"}], key: "?page=2"}, {"value": [{"id": "two"}]}])
            api = collector.Api(http, FakeTokens())
            result = api.listing("/v1.0/users", collector.GRAPH, "users")
            self.assertTrue(result.complete)
            self.assertEqual([r["id"] for r in result.items], ["one", "two"])
            self.assertEqual(http.calls[1][1], collector.GRAPH + "/v1.0/users?page=2")

    def test_foreign_and_cyclic_links_never_receive_a_token(self):
        for link in ("https://evil.invalid/page", collector.GRAPH + "/v1.0/users"):
            http = QueueHttp([{"value": [], "@odata.nextLink": link}])
            tokens = FakeTokens()
            result = collector.Api(http, tokens).listing("/v1.0/users", collector.GRAPH, "users")
            self.assertFalse(result.complete)
            self.assertEqual(len(tokens.calls), 1)
            self.assertEqual(len(http.calls), 1)

    def test_missing_value_is_not_an_authoritative_empty_collection(self):
        api = collector.Api(QueueHttp([{"error": {"message": "secret"}}]), FakeTokens())
        self.assertFalse(api.listing("/v1.0/users", collector.GRAPH, "users").complete)
        self.assertNotIn("secret", json.dumps(api.failures))

    def test_retry_after_and_no_retry_on_403(self):
        response = mock.MagicMock()
        response.__enter__.return_value.read.return_value = b'{"value":[]}'
        http = collector.Http(sleep=mock.Mock())
        http.opener = mock.Mock()
        http.opener.open.side_effect = [
            error.HTTPError("https://example.invalid", 429, "throttle", {"Retry-After": "3"}, io.BytesIO(b"")),
            response,
        ]
        self.assertEqual(http.send("GET", "https://example.invalid"), b'{"value":[]}')
        http.sleep.assert_called_once_with(3)
        http.opener.open.side_effect = error.HTTPError("https://example.invalid", 403, "secret", {}, io.BytesIO(b"secret"))
        with self.assertRaisesRegex(collector.CollectionError, "^HTTP 403$"):
            http.send("GET", "https://example.invalid")

    def test_no_redirect_handler_refuses_forwarding(self):
        self.assertIsNone(collector.NoRedirect().redirect_request(None, None, 302, "", {}, "https://evil.invalid"))


class FixtureHttp:
    """Offline tenant: every unexpected endpoint fails the test."""
    def __init__(self, fail_members=False, fail_deny=False):
        self.calls = []
        self.fail_members, self.fail_deny = fail_members, fail_deny

    def send(self, method, url, headers=None, data=None):
        self.calls.append((method, url, headers, data))
        if method == "POST":
            return encoded({"access_token": "fixture", "refresh_token": "rotated"})
        parts = parse.urlsplit(url)
        path = parts.path.lower()
        query = parse.parse_qs(parts.query)
        value = []
        if parts.netloc == "graph.microsoft.com":
            if path == "/v1.0/organization":
                value = [{"id": TENANT, "displayName": "Lab", "verifiedDomains": [{"name": "lab.test", "isDefault": True}]}]
            elif path in ("/beta/users", "/v1.0/users"):
                value = [{"id": USER, "displayName": "User", "userPrincipalName": "user@lab.test"}]
            elif path == "/beta/groups":
                value = [{"id": GROUP, "displayName": "Group"}]
            elif path == "/beta/devices":
                value = []
            elif path == "/beta/applications":
                value = [{"id": APP, "appId": APPID, "displayName": "Resource"}]
            elif path == "/beta/serviceprincipals":
                value = [{"id": SP, "appId": APPID, "displayName": "Resource",
                          "appRoles": [{"id": ROLE, "displayName": "Read", "value": "Read", "allowedMemberTypes": ["User"]}]}]
            elif path == "/v1.0/rolemanagement/directory/roledefinitions":
                value = [{"id": ROLE, "displayName": "Test role"}]
            elif path in ("/v1.0/rolemanagement/directory/roleeligibilityscheduleinstances",
                          "/v1.0/policies/rolemanagementpolicyassignments"):
                value = []
            elif path == "/v1.0/rolemanagement/directory/roleassignments":
                value = [{"principalId": USER, "roleDefinitionId": ROLE, "directoryScopeId": "/"}]
            elif path == f"/v1.0/groups/{GROUP}/members":
                if self.fail_members:
                    raise collector.CollectionError("HTTP 403", 403)
                value = [{"id": USER, "@odata.type": "#microsoft.graph.user"}]
            elif path == f"/v1.0/serviceprincipals/{SP}/approleassignedto":
                value = [{"id": "assignment", "principalId": USER, "principalType": "User",
                          "resourceId": SP, "appRoleId": ROLE}]
            elif path.endswith(("/owners", "/federatedidentitycredentials")):
                value = []
            else:
                raise AssertionError("Unexpected Graph endpoint: " + url)
        elif parts.netloc == "graph.windows.net":
            if not path.endswith("/policies"):
                raise AssertionError("Unexpected legacy endpoint: " + url)
            value = [{"policyType": 18, "displayName": "MFA", "policyDetail": [json.dumps({
                "State": "Enabled", "Controls": [{"Control": ["Mfa"]}],
                "Conditions": {"Users": {"Exclude": [{"Users": [USER]}]}}})]}]
        elif parts.netloc == "management.azure.com":
            if path == "/subscriptions":
                value = [{"id": SCOPE, "subscriptionId": SUB, "displayName": "Lab"}]
            elif path.endswith("/managementgroups"):
                value = []
            elif path.endswith("/roledefinitions"):
                value = [{"id": SCOPE + "/providers/Microsoft.Authorization/roleDefinitions/" + OWNER,
                          "properties": {"roleName": "Owner", "permissions": [{"actions": ["*"], "notActions": []}]}}]
            elif path.endswith("/resources"):
                value = [{"id": RESOURCE, "name": "barktest", "type": "Microsoft.Storage/storageAccounts"}]
            elif path.endswith("/storageaccounts"):
                value = [{"id": RESOURCE, "name": "barktest"}]
            elif path.endswith("/vaults"):
                value = [{"id": SCOPE + "/resourceGroups/lab/providers/Microsoft.KeyVault/vaults/barkvault",
                          "name": "barkvault", "properties": {"vaultUri": "https://barkvault.vault.azure.net/", "accessPolicies": [], "enableRbacAuthorization": False}}]
            elif path.endswith("/roleassignments"):
                value = [{"id": SCOPE + "/providers/Microsoft.Authorization/roleAssignments/one",
                          "type": "Microsoft.Authorization/roleAssignments",
                          "properties": {"scope": SCOPE, "principalId": USER, "principalType": "User",
                                         "roleDefinitionId": SCOPE + "/providers/Microsoft.Authorization/roleDefinitions/" + OWNER}}]
            elif path.endswith("/denyassignments") and self.fail_deny:
                raise collector.CollectionError("HTTP 403", 403)
            elif any(path.endswith("/" + relative.lower()) for _, relative, _ in collector.ARM_COLLECTIONS + collector.EXTRAS):
                value = []
            else:
                raise AssertionError("Unexpected ARM endpoint: " + url)
        elif parts.netloc == "barktest.blob.core.windows.net":
            if not query.get("marker"):
                return b"<EnumerationResults><Containers><Container><Name>first</Name></Container></Containers><NextMarker>next</NextMarker></EnumerationResults>"
            return b"<EnumerationResults><Containers><Container><Name>second</Name></Container></Containers><NextMarker/></EnumerationResults>"
        elif parts.netloc == "barkvault.vault.azure.net":
            self.assert_metadata_path(path)
            value = [{"id": "https://barkvault.vault.azure.net/secrets/name", "attributes": {"enabled": True}}]
        else:
            raise AssertionError("Unexpected host: " + url)
        return encoded({"value": value})

    @staticmethod
    def assert_metadata_path(path):
        if path != "/secrets":
            raise AssertionError("A probe attempted to read a secret value")


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.logs = io.StringIO()
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(contextlib.redirect_stdout(self.logs))
        self.stack.enter_context(contextlib.redirect_stderr(self.logs))

    def make_collector(self, **kwargs):
        http = FixtureHttp(**kwargs)
        return collector.Collector(collector.Api(http, FakeTokens()), TENANT, self.root)

    def test_end_to_end_builds_native_and_app_role_graph_bundle(self):
        c = self.make_collector()
        self.assertTrue(c.identity())
        c.conditional_access()
        c.arm()
        c.probes()
        self.assertEqual(c.api.failures, [])
        self.assertEqual(bark_role_graph.main([str(self.root)]), 0)
        graph = json.loads(next(self.root.glob("AZAppRoleGraph_*.json")).read_text())
        self.assertTrue(any(e["kind"] == "BARK_AssignedAppRole" for e in graph["graph"]["edges"]))
        self.assertTrue(any(self.root.glob("BARK_BloodHound_Bundle_*")))
        raw = json.loads((self.root / "AZAppRoleAssignment.json").read_text())
        self.assertEqual(raw["data"][0]["data"]["principalId"], USER.upper())
        self.assertEqual(raw["data"][0]["data"]["id"], "assignment")
        raw = json.loads((self.root / "AZAppOwner.json").read_text())
        self.assertEqual(raw["data"][0]["data"]["appId"], APPID.upper())
        tenant = json.loads((self.root / "AZTenant.json").read_text())["data"][0]["data"]
        self.assertEqual(tenant["defaultDomain"], "lab.test")
        probes = json.loads((self.root / "DataPlaneProbes.json").read_text())["probes"]
        self.assertEqual(next(p["items"] for p in probes if p["kind"] == "containers"), ["first", "second"])
        ca = json.loads((self.root / "AZConditionalAccessGraph.json").read_text())
        self.assertEqual(ca["graph"]["nodes"][0]["id"], USER.upper())
        self.assertEqual(ca["graph"]["nodes"][0]["kinds"], ["AZUser"])
        self.assertEqual(ca["graph"]["edges"], [])
        self.assertEqual(set(ca["graph"]["nodes"][0]["properties"]), {"cap_policies"})

    def test_failed_group_and_deny_queries_are_marked_incomplete(self):
        c = self.make_collector(fail_members=True, fail_deny=True)
        self.assertFalse(c.identity())
        c.arm()
        member = json.loads((self.root / "AZGroupMember.json").read_text())["meta"]["collection"]
        deny = json.loads((self.root / "AZDenyAssignment.json").read_text())["meta"]["collection"]
        self.assertFalse(member["complete"])
        self.assertEqual(member["failedParents"], [GROUP.upper()])
        self.assertFalse(deny["complete"])
        self.assertEqual(deny["failedScopes"], [SCOPE.upper()])

    def test_multi_megabyte_output_keeps_distinct_data_past_chunk_boundaries(self):
        rows = [{"offset": i, "text": str(i) + "x" * 1024} for i in range(6000)]
        c = self.make_collector()
        c.save("AZUser", rows)
        path = self.root / "AZUser.json"
        self.assertGreater(path.stat().st_size, 5 * 1024 * 1024)
        result = json.loads(path.read_text())
        self.assertEqual([r["data"] for r in result["data"]], rows)
        self.assertFalse(list(self.root.glob("*.tmp")))

    def test_main_reports_success_and_retains_no_tokens(self):
        with mock.patch.object(collector, "Http", return_value=FixtureHttp()), mock.patch.dict(
                "os.environ", {"BARK_REFRESH_TOKEN": "input-refresh"}):
            self.assertEqual(collector.main([TENANT, "--output", str(self.root)]), 0)
        output = next(self.root.glob("BARK_*"))
        manifest = json.loads((output / "collection_manifest.json").read_text())
        self.assertTrue(manifest["complete"])
        for path in output.rglob("*.json"):
            self.assertNotIn("input-refresh", path.read_text())
            self.assertNotIn('"rotated"', path.read_text())

    def test_main_reports_partial_and_can_skip_legacy(self):
        with mock.patch.object(collector, "Http", return_value=FixtureHttp(fail_members=True)), mock.patch.dict(
                "os.environ", {"BARK_REFRESH_TOKEN": "input-refresh"}):
            status = collector.main([TENANT, "--output", str(self.root), "--no-legacy-fallback", "--no-bundle"])
        self.assertEqual(status, 2)
        manifest = json.loads(next(self.root.glob("BARK_*/collection_manifest.json")).read_text())
        self.assertFalse(manifest["complete"])
        self.assertTrue(manifest["failures"])




class LegacyFixture(FixtureHttp):
    def send(self, method, url, headers=None, data=None):
        parts = parse.urlsplit(url)
        if parts.netloc != "graph.windows.net" or parts.path.endswith("/policies"):
            return super().send(method, url, headers, data)
        path = parts.path.split("/", 2)[2]
        if path == "tenantDetails":
            mapped = "/v1.0/organization"
        elif path == "directoryRoles":
            mapped = "/v1.0/roleManagement/directory/roleDefinitions"
        elif path.startswith("directoryRoles/"):
            return encoded({"value": [{"objectId": USER, "objectType": "User"}]})
        elif "/" in path:
            mapped = "/v1.0/" + path.replace("appRoleAssignments", "appRoleAssignedTo")
        else:
            mapped = "/beta/" + path
        # Legacy route is successful even if MS Graph members are denied.
        old = self.fail_members
        self.fail_members = False
        try:
            raw = json.loads(super().send(method, collector.GRAPH + mapped, headers, data))
        finally:
            self.fail_members = old
        for row in raw["value"]:
            if "id" in row:
                row["objectId"] = row.pop("id")
            if path == "directoryRoles":
                row["roleTemplateId"] = ROLE
            elif path.endswith("appRoleAssignments"):
                row["id"] = row.pop("appRoleId")
            elif path.endswith("/members"):
                row["objectType"] = "User"
                row.pop("@odata.type", None)
        return encoded(raw)


class FallbackTests(unittest.TestCase):
    def test_legacy_fallback_preserves_modern_snapshot_and_maps_role_ids(self):
        with tempfile.TemporaryDirectory() as temporary, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            root = Path(temporary)
            with mock.patch.object(collector, "Http", return_value=LegacyFixture(fail_members=True)), mock.patch.dict(
                    "os.environ", {"BARK_REFRESH_TOKEN": "test"}):
                status = collector.main([TENANT, "--output", str(root), "--no-bundle"])
            self.assertEqual(status, 2)  # Original failure remains visible after fallback.
            output = next(root.glob("BARK_*"))
            modern = json.loads((output / "AZGroupMember.json").read_text())
            legacy = json.loads((output / "AZGroupMember_legacy.json").read_text())
            self.assertFalse(modern["meta"]["collection"]["complete"])
            self.assertTrue(legacy["meta"]["collection"]["complete"])
            member = legacy["data"][0]["data"]["members"][0]["member"]
            self.assertEqual(member["@odata.type"], "#microsoft.graph.user")
            assignment = json.loads((output / "AZAppRoleAssignment_legacy.json").read_text())["data"][0]["data"]
            self.assertEqual(assignment["appRoleId"], ROLE)
            self.assertEqual(assignment["resourceId"], SP.upper())

    def test_interrupted_run_writes_incomplete_manifest(self):
        with tempfile.TemporaryDirectory() as temporary, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            with mock.patch.object(collector.Collector, "identity", side_effect=KeyboardInterrupt), mock.patch.dict(
                    "os.environ", {"BARK_REFRESH_TOKEN": "test"}):
                status = collector.main([TENANT, "--output", temporary])
            self.assertEqual(status, 130)
            manifest = json.loads(next(Path(temporary).glob("BARK_*/collection_manifest.json")).read_text())
            self.assertFalse(manifest["complete"])
            self.assertTrue(manifest["interrupted"])

    def test_sign_in_activity_uses_supported_page_size(self):
        with tempfile.TemporaryDirectory() as temporary, contextlib.redirect_stdout(io.StringIO()):
            http = FixtureHttp()
            c = collector.Collector(collector.Api(http, FakeTokens()), TENANT, Path(temporary))
            c.identity()
            url = next(call[1] for call in http.calls if "signInActivity" in call[1])
            self.assertEqual(parse.parse_qs(parse.urlsplit(url).query)["$top"], ["500"])

    def test_management_descendants_recover_subscription_and_query_nested_group(self):
        class DescendantFixture(FixtureHttp):
            def send(self, method, url, headers=None, data=None):
                path = parse.urlsplit(url).path.lower()
                group = "/providers/Microsoft.Management/managementGroups/root"
                if path == "/subscriptions":
                    return encoded({"value": []})
                if path == "/providers/microsoft.management/managementgroups":
                    return encoded({"value": [{"id": group, "name": "root"}]})
                if path == group.lower() + "/descendants":
                    return encoded({"value": [
                        {"id": SCOPE, "name": SUB, "type": "Microsoft.Management/managementGroups/subscriptions"},
                        {"id": group.replace("/root", "/child"), "name": "child", "type": "Microsoft.Management/managementGroups"},
                    ]})
                if path == SCOPE:
                    return encoded({"id": SCOPE, "subscriptionId": SUB})
                return super().send(method, url, headers, data)

        with tempfile.TemporaryDirectory() as temporary, contextlib.redirect_stdout(io.StringIO()):
            http = DescendantFixture()
            c = collector.Collector(collector.Api(http, FakeTokens()), TENANT, Path(temporary))
            c.arm()
            subs = json.loads((Path(temporary) / "AZSubscription.json").read_text())
            self.assertEqual(subs["meta"]["count"], 1)
            self.assertTrue(any("/child/providers/Microsoft.Authorization/denyAssignments" in call[1] for call in http.calls))



class TenantResolutionTests(unittest.TestCase):
    def test_guid_skips_discovery_and_domain_is_normalized(self):
        http = mock.Mock()
        self.assertEqual(collector.resolve_tenant_id(TENANT.upper(), http), TENANT)
        http.send.assert_not_called()
        self.assertEqual(collector.tenant_identifier("MegaBigTech.com"), "megabigtech.com")

    def test_domain_discovery_uses_fixed_authority_without_credentials(self):
        http = QueueHttp([{"issuer": "https://login.microsoftonline.com/" + TENANT + "/v2.0"}])
        self.assertEqual(collector.resolve_tenant_id("megabigtech.com", http), TENANT)
        self.assertEqual(http.calls[0], (
            "GET", "https://login.microsoftonline.com/megabigtech.com/v2.0/.well-known/openid-configuration",
            {"Accept": "application/json"}, None))

    def test_invalid_identifiers_are_rejected(self):
        import argparse
        for value in ("common", "organizations", "https://megabigtech.com", "../tenant",
                      "a..com", "-bad.com", "a.com?x=1", "u@a.com", "a.123"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                collector.tenant_identifier(value)

    def test_bad_discovery_response_is_not_used_as_an_identifier(self):
        for issuer in (None, "https://foreign.invalid/" + TENANT + "/v2.0",
                       "https://login.microsoftonline.com/{tenantid}/v2.0",
                       "https://login.microsoftonline.com/not-a-guid/v2.0"):
            with self.subTest(issuer=issuer), self.assertRaises(collector.CollectionError):
                collector.resolve_tenant_id("megabigtech.com", QueueHttp([{"issuer": issuer}]))

    def test_failed_discovery_stops_before_prompt_or_token_exchange(self):
        with mock.patch.object(collector, "Http", return_value=QueueHttp([
                collector.CollectionError("HTTP 400", 400)])), \
                mock.patch.object(collector.getpass, "getpass") as prompt, \
                contextlib.redirect_stderr(io.StringIO()) as messages:
            self.assertEqual(collector.main(["megabigtech.com"]), 1)
            prompt.assert_not_called()
            self.assertIn("tenant discovery failed", messages.getvalue())

    def test_domain_run_uses_guid_for_tokens_records_and_manifest(self):
        class DomainHttp(FixtureHttp):
            def send(self, method, url, headers=None, data=None):
                if url.endswith("/.well-known/openid-configuration"):
                    return encoded({"issuer": "https://login.microsoftonline.com/" + TENANT + "/v2.0"})
                if method == "POST":
                    if not url.startswith("https://login.microsoftonline.com/" + TENANT + "/"):
                        raise AssertionError("Token request did not use the resolved GUID")
                return super().send(method, url, headers, data)
        with tempfile.TemporaryDirectory() as temporary, \
                mock.patch.object(collector, "Http", return_value=DomainHttp()), \
                mock.patch.dict("os.environ", {"BARK_REFRESH_TOKEN": "fake-token"}), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(collector.main(["megabigtech.com", "--output", temporary, "--no-bundle"]), 0)
            output = next(Path(temporary).glob("BARK_*"))
            manifest = json.loads((output / "collection_manifest.json").read_text())
            self.assertEqual(manifest["tenantId"], TENANT.upper())
            self.assertEqual(manifest["tenantInput"], "megabigtech.com")
            tenant = json.loads((output / "AZTenant.json").read_text())["data"][0]["data"]
            self.assertEqual(tenant["id"], "/tenants/" + TENANT.upper())



class ConcurrencyTests(unittest.TestCase):
    def test_parallel_jobs_overlap_without_exceeding_worker_limit(self):
        lock = threading.Lock()
        barrier = threading.Barrier(4)
        active = peak = 0

        def job(number):
            nonlocal active, peak
            with lock:
                active += 1
                peak = max(peak, active)
            try:
                if number < 4:
                    barrier.wait(timeout=3)
                time.sleep(0.002)
                return number
            finally:
                with lock:
                    active -= 1

        self.assertEqual(list(collector.parallel_results(job, range(24), 4)), list(range(24)))
        self.assertEqual(peak, 4)

    def test_submission_is_bounded_and_cancellation_signals_transport(self):
        produced = []
        ready = threading.Event()
        release = threading.Event()
        cancelled = threading.Event()

        def jobs():
            for number in range(10000):
                produced.append(number)
                if number == 7:
                    ready.set()
                yield number

        def job(number):
            release.wait(timeout=3)
            return number

        results = collector.parallel_results(job, jobs(), 4, cancelled.set)
        with ThreadPoolExecutor(max_workers=1) as consumer:
            first = consumer.submit(next, results)
            try:
                self.assertTrue(ready.wait(timeout=3))
                self.assertEqual(len(produced), 8)
            finally:
                release.set()
            self.assertEqual(first.result(timeout=3), 0)
        results.close()
        self.assertTrue(cancelled.is_set())
        self.assertEqual(len(produced), 8)

    def test_refresh_rotation_is_serialized_across_audiences(self):
        class RotatingHttp:
            def __init__(self):
                self.lock = threading.Lock()
                self.calls = []
                self.active = self.peak = 0

            def send(self, method, url, headers=None, data=None):
                form = parse.parse_qs(data.decode())
                with self.lock:
                    self.active += 1
                    self.peak = max(self.peak, self.active)
                    number = len(self.calls)
                    self.calls.append(form)
                try:
                    time.sleep(0.003)
                    return encoded({"access_token": form["resource"][0], "refresh_token": f"rotated-{number}",
                                    "expires_in": 3600})
                finally:
                    with self.lock:
                        self.active -= 1

        http = RotatingHttp()
        tokens = collector.Tokens(TENANT, "initial", http, collector.CLIENTS[0])
        audiences = [collector.GRAPH, collector.ARM, collector.STORAGE] * 8
        with ThreadPoolExecutor(max_workers=8) as pool:
            self.assertEqual(list(pool.map(tokens.get, audiences)), audiences)
        self.assertEqual(len(http.calls), 3)
        self.assertEqual(http.peak, 1)
        self.assertEqual([f["refresh_token"][0] for f in http.calls], ["initial", "rotated-0", "rotated-1"])

    def test_concurrent_401s_share_one_refresh(self):
        class ExpiredHttp:
            def __init__(self):
                self.posts = 0
                self.barrier = threading.Barrier(8)

            def send(self, method, url, headers=None, data=None):
                if method == "POST":
                    self.posts += 1
                    return encoded({"access_token": "old" if self.posts == 1 else "new", "expires_in": 3600})
                if headers["Authorization"] == "Bearer old":
                    self.barrier.wait(timeout=3)
                    raise collector.CollectionError("HTTP 401", 401)
                return encoded({"value": []})

        http = ExpiredHttp()
        tokens = collector.Tokens(TENANT, "refresh", http, collector.CLIENTS[0])
        tokens.get(collector.GRAPH)
        api = collector.Api(http, tokens)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: api.raw("/v1.0/users", collector.GRAPH), range(8)))
        self.assertEqual(http.posts, 2)
        self.assertTrue(all(json.loads(r) == {"value": []} for r in results))

    def test_http_opener_is_local_to_each_worker(self):
        http = collector.Http()
        barrier = threading.Barrier(4)

        def handler(_):
            opener = http.opener
            barrier.wait(timeout=3)
            self.assertIs(http.opener, opener)
            return opener

        with ThreadPoolExecutor(max_workers=4) as pool:
            openers = list(pool.map(handler, range(4)))
        self.assertEqual(len({id(opener) for opener in openers}), 4)

    def test_cancellation_interrupts_retry_after_wait(self):
        http = collector.Http(retries=1)
        attempted = threading.Event()

        def reject(*args, **kwargs):
            attempted.set()
            raise error.HTTPError("https://example.invalid", 429, "throttle",
                                  {"Retry-After": "300"}, io.BytesIO(b""))

        def run():
            http.opener = mock.Mock()
            http.opener.open.side_effect = reject
            with self.assertRaisesRegex(collector.CollectionError, "cancelled"):
                http.send("GET", "https://example.invalid")

        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(run)
            self.assertTrue(attempted.wait(timeout=3))
            http.cancelled.set()
            future.result(timeout=3)

    def test_parallel_and_serial_files_match_including_partial_coverage(self):
        class TrackingHttp(FixtureHttp):
            def __init__(self):
                super().__init__(fail_members=True, fail_deny=True)
                self.lock = threading.Lock()
                self.active = self.peak = 0

            def send(self, *args, **kwargs):
                with self.lock:
                    self.active += 1
                    self.peak = max(self.peak, self.active)
                try:
                    time.sleep(0.003)
                    return super().send(*args, **kwargs)
                finally:
                    with self.lock:
                        self.active -= 1

        outputs = []
        peaks = []
        with tempfile.TemporaryDirectory() as temporary, \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            for workers in (1, 8):
                root = Path(temporary) / str(workers)
                root.mkdir()
                http = TrackingHttp()
                c = collector.Collector(collector.Api(http, FakeTokens()), TENANT, root, workers=workers)
                self.assertFalse(c.identity())
                c.conditional_access()
                c.arm()
                c.probes()
                outputs.append({p.name: json.loads(p.read_text()) for p in root.glob("*.json")})
                peaks.append(http.peak)
        self.assertEqual(outputs[0], outputs[1])
        self.assertEqual(peaks[0], 1)
        self.assertGreater(peaks[1], 1)
        self.assertLessEqual(peaks[1], 8)

    def test_worker_option_bounds_fail_before_authentication(self):
        with mock.patch.object(collector.getpass, "getpass") as prompt, \
                contextlib.redirect_stderr(io.StringIO()):
            for workers in ("0", "-1", "33"):
                with self.assertRaises(SystemExit):
                    collector.main([TENANT, "--workers", workers])
            prompt.assert_not_called()



if __name__ == "__main__":
    unittest.main()
