"""Execute the BOF's real JSON writer with offline transport/allocation stubs."""
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which("gcc"), "host gcc is required for the BOF output harness")
class ConditionalAccessWriterTests(unittest.TestCase):
    def test_writer_emits_cap_properties_on_native_principals(self):
        source = (ROOT / "src/legacy_cpa/get_conditional_access_policies.c").read_text()
        start = source.index("static void WriteOutputFile(void)")
        writer = source[start:source.index("\n}", start) + 2]
        harness = r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdarg.h>
typedef size_t SIZE_T;
typedef unsigned long DWORD;
typedef struct { unsigned wYear,wMonth,wDay,wHour,wMinute,wSecond; } SYSTEMTIME;
typedef struct { char *buf; SIZE_T len,cap; int ok; } BarkBuf;
#define CAP_OBJECTID 64
#define CAP_USER_UPN_LEN 128
#define CAP_USER_DISPLAY_LEN 128
#define CAP_PROPVAL 1024
#define ENTITY_USER 1
#define CALLBACK_ERROR 1
#define CALLBACK_OUTPUT 0
#define HAlloc malloc
#define HFree free
#define MSVCRT$memset memset
#define MSVCRT$strlen strlen
#define MSVCRT$sprintf_s snprintf
#define BeaconPrintf(...) ((void)0)
#define KERNEL32$GetLocalTime(p) memset(p,0,sizeof(*(p)))
typedef struct { char *objectId; int kind; char *policyName; char *propValue; } ExcludedEntity;
static ExcludedEntity g_entities[] = {
    {"user-1",1,"Policy A","first"}, {"USER-1",1,"Policy B","second"},
    {"group-1",2,"Policy C","group"}, {"stale-user",1,"Policy D","deleted"}
};
static int g_entityCount=4,g_allUserCount=1;
static char *g_allUserDisplayNames="Example User", *g_allUserPrincipalNames="user@example.test";
static int FindAllUserIndex(const char *id) { return strcasecmp(id,"user-1") ? -1 : 0; }
static int AsciiEqualsIgnoreCase(const char *a,const char *b) { return !strcasecmp(a,b); }
static void EscapeJsonString(const char *src,char *dst,size_t cap) { snprintf(dst,cap,"%s",src); }
static void BarkBufAppend(BarkBuf *b,const char *src,SIZE_T n) {
    char *p=realloc(b->buf,b->len+n+1);
    if (!p) { b->ok=0; return; }
    b->buf=p; memcpy(p+b->len,src,n); b->len+=n; p[b->len]=0;
}
static void BarkBufAppendAsciiUpper(BarkBuf *b,const char *src,SIZE_T n) {
    for (SIZE_T i=0;i<n;i++) { char c=toupper((unsigned char)src[i]); BarkBufAppend(b,&c,1); }
}
static void BarkBufFree(BarkBuf *b) { free(b->buf); b->buf=NULL; }
static void BarkWriteOutput(const char *name,const char *buf,DWORD len) { fwrite(buf,1,len,stdout); }
'''
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path / "writer.c").write_text(harness + writer + "\nint main(void) { WriteOutputFile(); }\n")
            subprocess.run(["gcc", "-o", str(path / "writer"), str(path / "writer.c")],
                           check=True, capture_output=True)
            result = subprocess.run([str(path / "writer")], check=True, capture_output=True)
        graph = json.loads(result.stdout)["graph"]
        self.assertEqual(len(graph["nodes"]), 2)
        self.assertEqual(graph["edges"], [])
        self.assertEqual({n["id"] for n in graph["nodes"]}, {"USER-1", "GROUP-1"})
        user = next(n for n in graph["nodes"] if n["id"] == "USER-1")
        self.assertEqual(user["kinds"], ["AZUser"])
        self.assertEqual(user["properties"], {"cap_policies": ["Policy A: first", "Policy B: second"]})
        self.assertTrue(all(set(n["properties"]) == {"cap_policies"} for n in graph["nodes"]))



if __name__ == "__main__":
    unittest.main()
