import base64
import contextlib
import ctypes
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock
from urllib import parse, error

import bark_tokens as tokens

TENANT = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
CLIENT = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
COOKIE = "header." + base64.urlsafe_b64encode(b'{"request_nonce":"test nonce"}').decode().rstrip("=") + ".signature"
ROOT = Path(__file__).resolve().parents[1]


class FakeHttp:
    def __init__(self, responses=None):
        self.responses = list(responses or [{"access_token": "access", "refresh_token": "refresh"}])
        self.calls = []
        self.redirect_change = None

    def send(self, method, url, headers=None, data=None):
        self.calls.append((method, url, headers, data))
        result = self.responses.pop(0)
        if isinstance(result, Exception):
            raise result
        return json.dumps(result).encode()

    def authorization_redirect(self, url, cookie):
        self.calls.append(("AUTHORIZE", url, {"cookie": cookie}, None))
        query = parse.parse_qs(parse.urlsplit(url).query)
        location = query["redirect_uri"][0] + "?" + parse.urlencode({
            "code": "code +&/", "state": query["state"][0]})
        return self.redirect_change(location) if self.redirect_change else location

    def form(self, index=0):
        return parse.parse_qs(self.calls[index][3].decode())


SCOPE_CASES = [
    ("https://graph.microsoft.com", "https://graph.microsoft.com/.default"),
    ("https://graph.microsoft.com/", "https://graph.microsoft.com/.default"),
    ("https://graph.windows.net", "https://graph.windows.net/.default"),
    ("https://storage.azure.com", "https://storage.azure.com/.default"),
    ("https://vault.azure.net/", "https://vault.azure.net/.default"),
    ("https://api.powerplatform.com", "https://api.powerplatform.com/.default"),
    ("https://management.azure.com", "https://management.azure.com//.default"),
    ("https://management.azure.com/", "https://management.azure.com//.default"),
    ("https://management.core.windows.net", "https://management.core.windows.net//.default"),
    ("https://tenant.sharepoint.com", "https://tenant.sharepoint.com/.default"),
    ("api://custom-api", "api://custom-api/.default"),
    ("https://custom.example/api/", "https://custom.example/api//.default"),
    ("https://graph.microsoft.com/.default", "https://graph.microsoft.com/.default"),
    ("https://management.azure.com//.default", "https://management.azure.com//.default"),
]


class ScopeTests(unittest.TestCase):
    def test_resource_urls_and_existing_scopes(self):
        for resource, expected in SCOPE_CASES:
            with self.subTest(resource=resource):
                self.assertEqual(tokens.default_scope(resource), expected)

    def test_rejects_invalid_resources(self):
        for resource in ("", "User.Read", "https://host/a b", "http://graph.microsoft.com",
                         "https://user:pass@host", "https://host?scope=secret",
                         "https://host/#fragment", "https://host:invalid"):
            with self.subTest(resource=resource), self.assertRaises(ValueError):
                tokens.resource_url(resource)

    def test_client_rankings(self):
        self.assertEqual(tokens.clients_for(tokens.GRAPH)[0], tokens.CLIENTS[0])
        self.assertEqual(tokens.clients_for(tokens.LEGACY)[0], tokens.CLIENTS[2])
        self.assertEqual(tokens.clients_for("https://tenant.sharepoint.com")[0], tokens.CLIENTS[3])
        self.assertEqual(tokens.clients_for(tokens.ARM, CLIENT), [CLIENT])


@unittest.skipUnless(shutil.which("gcc"), "native C scope test needs gcc")
class NativeScopeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.tmp.cleanup)
        source = Path(cls.tmp.name) / "scope.c"
        source.write_text('#include "oauth_scope.h"\n'
                          'int normalize(const char *s, char *out, size_t size) { return BarkNormalizeV2Scope(s,out,size); }\n')
        library = Path(cls.tmp.name) / "scope.so"
        subprocess.run(["gcc", "-shared", "-fPIC", "-Wall", "-Werror", "-I", str(ROOT / "include"),
                        str(source), "-o", str(library)], check=True, capture_output=True)
        cls.library = ctypes.CDLL(str(library))
        cls.library.normalize.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t]
        cls.library.normalize.restype = ctypes.c_int

    def test_native_resource_conversion_matches_python(self):
        for resource, expected in SCOPE_CASES:
            with self.subTest(resource=resource):
                buf = ctypes.create_string_buffer(1024)
                self.assertEqual(self.library.normalize(resource.encode(), buf, len(buf)), 1)
                self.assertEqual(buf.value.decode(), expected)

    def test_legacy_explicit_scopes_are_preserved(self):
        for scope in ("https://management.azure.com/.default",
                      "https://graph.microsoft.com/User.Read offline_access", "openid offline_access"):
            buf = ctypes.create_string_buffer(1024)
            self.assertEqual(self.library.normalize(scope.encode(), buf, len(buf)), 1)
            self.assertEqual(buf.value.decode(), scope)

    def test_capacity_boundary_and_empty_input(self):
        source = b"https://graph.microsoft.com"
        expected = b"https://graph.microsoft.com/.default"
        for capacity in (0, 1, len(expected), len(expected) + 1):
            buf = ctypes.create_string_buffer(100)
            result = self.library.normalize(source, buf, capacity)
            self.assertEqual(result, int(capacity > len(expected)))
        buf = ctypes.create_string_buffer(50)
        self.assertEqual(self.library.normalize(b"", buf, len(buf)), 0)


class GrantTests(unittest.TestCase):
    def test_refresh_token_uses_resource_without_default_scope(self):
        http = FakeHttp()
        result = tokens.Auth(http).grant("rt", TENANT, tokens.GRAPH + "/.default", "rt +&/", client=CLIENT)
        self.assertEqual(http.form()["resource"], [tokens.GRAPH])
        self.assertEqual(http.form()["refresh_token"], ["rt +&/"])
        self.assertNotIn("scope", http.form())
        self.assertTrue(http.calls[0][1].endswith("/oauth2/token"))
        self.assertEqual(result["refresh_token"], "refresh")

    def test_password_and_client_credentials_generate_v2_scope(self):
        for grant in ("up", "cc"):
            http = FakeHttp()
            tokens.Auth(http).grant(grant, TENANT, tokens.ARM, "pass +&/", "person+lab@example.test", CLIENT)
            form = http.form()
            self.assertEqual(form["scope"], ["https://management.azure.com//.default" +
                                            (" offline_access" if grant == "up" else "")])
            self.assertEqual(form["password" if grant == "up" else "client_secret"], ["pass +&/"])
            if grant == "up":
                self.assertEqual(form["username"], ["person+lab@example.test"])
            self.assertTrue(http.calls[0][1].endswith("/oauth2/v2.0/token"))

    def test_client_fallback_and_explicit_client(self):
        http = FakeHttp([tokens.CollectionError("HTTP 400", 400), {"access_token": "ok"}])
        result = tokens.Auth(http).grant("rt", TENANT, tokens.GRAPH, "rt")
        self.assertEqual(result["client_id"], tokens.CLIENTS[2])
        http = FakeHttp([tokens.CollectionError("HTTP 400", 400)])
        with self.assertRaises(tokens.CollectionError):
            tokens.Auth(http).grant("rt", TENANT, tokens.GRAPH, "rt", client=CLIENT)
        self.assertEqual(len(http.calls), 1)

    def test_entra_refresh_and_portal_refresh(self):
        http = FakeHttp()
        tokens.Auth(http).entra_refresh(TENANT, "u", "p")
        self.assertEqual(http.form()["scope"], ["openid offline_access"])
        http = FakeHttp()
        tokens.Auth(http).portal_refresh(TENANT, "rt")
        self.assertEqual(http.form()["client_id"], [tokens.PORTAL_CLIENT])
        self.assertEqual(http.form()["scope"], ["https://management.core.windows.net//.default openid profile offline_access"])

    def test_portal_delegation_preserves_json_encoding_and_response(self):
        for target, resource in (("arm", ""), ("msgraph", "microsoft.graph")):
            http = FakeHttp([{"authHeader": "Bearer portal-token"}])
            result = tokens.Auth(http).portal_delegate(target, TENANT, 'token"+\\', "alt")
            body = json.loads(http.calls[0][3])
            self.assertEqual(body["portalAuthorization"], 'token"+\\')
            self.assertEqual(body["resourceName"], resource)
            self.assertEqual(result["authHeader"], "Bearer portal-token")

    def test_nonce(self):
        http = FakeHttp([{"Nonce": "nonce"}])
        self.assertEqual(tokens.Auth(http).nonce(), {"Nonce": "nonce"})
        self.assertEqual(http.form(), {"grant_type": ["srv_challenge"]})

    def test_error_response_never_echoes_error_description(self):
        auth = tokens.Auth(FakeHttp([{"error": "invalid_grant", "error_description": "private-token"}]))
        with self.assertRaises(tokens.CollectionError) as raised:
            auth.grant("rt", TENANT, tokens.GRAPH, "private-token", client=CLIENT)
        self.assertNotIn("private-token", str(raised.exception))


class PrtTests(unittest.TestCase):
    def test_prt_nonce_redirect_state_and_code_exchange(self):
        http = FakeHttp()
        tokens.Auth(http).prt(TENANT, tokens.GRAPH, COOKIE, CLIENT)
        query = parse.parse_qs(parse.urlsplit(http.calls[0][1]).query)
        self.assertEqual(query["sso_nonce"], ["test nonce"])
        self.assertEqual(query["resource"], [tokens.GRAPH])
        self.assertEqual(http.calls[0][2]["cookie"], COOKIE)
        self.assertEqual(http.form(1)["code"], ["code +&/"])
        self.assertTrue(http.calls[1][1].endswith("/common/oauth2/token"))

    def test_foreign_redirect_and_mismatched_state_do_not_exchange_code(self):
        for mutation in (lambda url: url.replace("login.microsoftonline.com", "foreign.invalid"),
                         lambda url: url + "&state=wrong"):
            http = FakeHttp()
            http.redirect_change = mutation
            with self.assertRaises(tokens.CollectionError):
                tokens.Auth(http).prt(TENANT, tokens.GRAPH, COOKIE, CLIENT)
            self.assertEqual(len(http.calls), 1)

    def test_authorize_302_is_captured_without_following(self):
        http = tokens.AuthHttp()
        http.opener = mock.Mock()
        http.opener.open.side_effect = error.HTTPError("https://login.microsoftonline.com/authorize",
            302, "redirect", {"Location": tokens.NATIVE_REDIRECT + "?code=x"}, io.BytesIO(b""))
        location = http.authorization_redirect("https://login.microsoftonline.com/authorize", COOKIE)
        self.assertEqual(location, tokens.NATIVE_REDIRECT + "?code=x")
        self.assertEqual(http.opener.open.call_count, 1)


class CliTests(unittest.TestCase):
    def run_cli(self, args, http, env=None):
        out, err = io.StringIO(), io.StringIO()
        with mock.patch.object(tokens, "AuthHttp", return_value=http), mock.patch.dict(
                os.environ, env or {"BARK_REFRESH_TOKEN": "input-rt"}, clear=True), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            status = tokens.main(args)
        return status, out.getvalue(), err.getvalue()

    def test_alias_commands_and_fixed_resource_shortcuts(self):
        cases = [
            ("rt", [], tokens.GRAPH), ("bark_get_tokens_with_rt", [], tokens.GRAPH),
            ("get_tokens", ["rt"], tokens.GRAPH), ("bark_get_tokens", ["rt"], tokens.GRAPH),
            ("arm", ["rt"], tokens.ARM + "/"), ("bark_get_tokens_for_arm", ["rt"], tokens.ARM + "/"),
            ("msgraph", ["rt"], tokens.GRAPH), ("bark_get_tokens_for_msgraph", ["rt"], tokens.GRAPH),
            ("arm-rt", [], tokens.ARM + "/"), ("bark_get_azurerm_token_with_rt", [], tokens.ARM + "/"),
            ("msgraph-rt", [], tokens.GRAPH), ("bark_get_msgraph_token_with_rt", [], tokens.GRAPH),
        ]
        for command, extra, audience in cases:
            with self.subTest(command=command):
                http = FakeHttp()
                args = [command, *extra, "--tenant", TENANT, "--client-id", CLIENT]
                if command in {"rt", "bark_get_tokens_with_rt", "get_tokens", "bark_get_tokens"}:
                    args.extend(["--resource", tokens.GRAPH])
                status, out, err = self.run_cli(args, http)
                self.assertEqual(status, 0, err)
                self.assertEqual(json.loads(out)["access_token"], "access")
                self.assertEqual(http.form()["resource"], [audience])

    def test_other_authentication_command_aliases(self):
        cases = [
            ("bark_get_tokens_with_up", ["--resource", tokens.GRAPH, "--username", "u"], {"BARK_PASSWORD": "pw"}),
            ("bark_get_tokens_with_cc", ["--resource", tokens.GRAPH, "--client-id", CLIENT], {"BARK_CLIENT_SECRET": "secret"}),
            ("bark_get_token_with_prt_cookie", ["--resource", tokens.GRAPH], {"BARK_PRT_COOKIE": COOKIE}),
            ("bark_get_entra_refresh_token_with_up", ["--username", "u"], {"BARK_PASSWORD": "pw"}),
            ("bark_get_azure_portal_token_with_rt", [], {"BARK_REFRESH_TOKEN": "rt"}),
            ("bark_get_azurerm_token_with_portal_rt", [], {"BARK_PORTAL_TOKEN": "portal"}),
            ("bark_get_msgraph_token_with_portal_rt", [], {"BARK_PORTAL_TOKEN": "portal"}),
        ]
        for command, extra, env in cases:
            with self.subTest(command=command):
                status, out, err = self.run_cli([command, "--tenant", TENANT, *extra], FakeHttp(), env)
                self.assertEqual(status, 0, err)
                self.assertTrue(json.loads(out))
        self.assertEqual(self.run_cli(["bark_new_nonce"], FakeHttp([{"Nonce": "test"}]))[0], 0)

    def test_token_output_and_collector_refresh_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            response, refresh = Path(tmp) / "tokens.json", Path(tmp) / "refresh.txt"
            status, out, err = self.run_cli(["rt", "--tenant", TENANT, "--resource", tokens.GRAPH,
                                            "--output", str(response), "--refresh-token-output", str(refresh)], FakeHttp())
            self.assertEqual(status, 0, err)
            self.assertEqual(out, "")
            self.assertEqual(refresh.read_text().strip(), "refresh")
            self.assertEqual(json.loads(response.read_text())["access_token"], "access")
            if os.name != "nt":
                self.assertEqual(response.stat().st_mode & 0o777, 0o600)
            http = FakeHttp()
            status, out, err = self.run_cli(["rt", "--tenant", TENANT, "--resource", tokens.GRAPH,
                                            "--output", str(response)], http)
            self.assertEqual(status, 1)
            self.assertEqual(http.calls, [])

    def test_secret_from_file_and_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rt.txt"
            path.write_text("file-secret\n")
            http = FakeHttp()
            self.run_cli(["rt", "--tenant", TENANT, "--resource", tokens.GRAPH,
                          "--refresh-token-file", str(path)], http)
            self.assertEqual(http.form()["refresh_token"], ["file-secret"])
        with mock.patch.object(tokens.getpass, "getpass", return_value="prompt-password") as prompt:
            http = FakeHttp()
            status, _, _ = self.run_cli(["up", "--tenant", TENANT, "--resource", tokens.GRAPH, "--username", "u"], http)
            self.assertEqual(status, 0)
            prompt.assert_called_once()
            self.assertEqual(http.form()["password"], ["prompt-password"])

    def test_password_file_preserves_significant_spaces(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "password.txt"
            path.write_text("  spaced password  \n")
            http = FakeHttp()
            status, _, err = self.run_cli(["up", "--tenant", TENANT, "--resource", tokens.GRAPH,
                                           "--username", "u", "--password-file", str(path)], http)
            self.assertEqual(status, 0, err)
            self.assertEqual(http.form()["password"], ["  spaced password  "])

    def test_cli_validation_happens_before_network(self):
        with mock.patch.object(tokens, "AuthHttp") as http, contextlib.redirect_stderr(io.StringIO()):
            for args in (["cc", "--tenant", TENANT, "--resource", tokens.GRAPH],
                         ["get_tokens", "up", "--tenant", TENANT, "--resource", tokens.GRAPH]):
                with self.assertRaises(SystemExit):
                    tokens.main(args)
            http.assert_not_called()


if __name__ == "__main__":
    unittest.main()
