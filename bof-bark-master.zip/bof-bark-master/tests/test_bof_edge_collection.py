"""Run the BOF edge collection code with offline WinHTTP/Beacon stubs."""
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from test_bark_native_edges import policy, eligibility, vault, TENANT

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which("gcc"), "host gcc required")
class BofEdgeCollectionTests(unittest.TestCase):
    def test_real_c_collectors_paginate_and_fetch_missing_details(self):
        # Keep actual JSON scanning and the new collector logic in this harness.
        helpers = (ROOT / "include/http_utils.h").read_text()
        a = helpers.index("static const char *JsonSkipString(")
        b = helpers.index("\n}", helpers.index("static char *JsonExtractNextLink(", a)) + 2
        scanners = helpers[a:b]
        raw_policy = policy()
        raw_policy["policy"].pop("rules")
        responses = [
            json.dumps({"value": [eligibility()], "@odata.nextLink": "https://graph.microsoft.com/eligibility-page-2"}),
            json.dumps({"value": []}),
            json.dumps({"value": [raw_policy]}),
            json.dumps({"value": policy()["policy"]["rules"][:1], "@odata.nextLink": "https://graph.microsoft.com/rules-page-2"}),
            json.dumps({"value": policy()["policy"]["rules"][1:]}),
            json.dumps({"value": [{"id": vault()["id"], "name": "barkvault", "properties": {}}]}),
            json.dumps(vault()),
        ]
        literals = ",\n".join(json.dumps(s) for s in responses)
        stub = r'''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <wchar.h>
#include <stdarg.h>
typedef size_t SIZE_T;
typedef unsigned long DWORD;
typedef const wchar_t *LPCWSTR;
typedef wchar_t *LPWSTR;
typedef struct { unsigned wYear,wMonth,wDay,wHour,wMinute,wSecond; } SYSTEMTIME;
typedef struct { char *buf; SIZE_T len,cap; int ok; } BarkBuf;
typedef struct { char **ids; int count; } BarkIdList;
typedef int datap;
static int g_use_download, argindex, responseindex, testmode;
#define HAlloc malloc
#define HFree free
#define MSVCRT$strlen strlen
#define MSVCRT$strcpy strcpy
#define MSVCRT$strncmp strncmp
#define MSVCRT$strcmp strcmp
#define MSVCRT$_stricmp strcasecmp
#define MSVCRT$strchr strchr
#define MSVCRT$memcpy memcpy
#define MSVCRT$sprintf_s snprintf
#define SAFE_STR(p) ((p)?(p):"")
#define CALLBACK_ERROR 1
#define BeaconPrintf(...) ((void)0)
#define KERNEL32$GetLocalTime(p) memset(p,0,sizeof(*(p)))
static void BarkBufAppend(BarkBuf *b,const char *s,SIZE_T n) {
    char *v=realloc(b->buf,b->len+n+1);
    if (!v) {b->ok=0;return;}
    b->buf=v;memcpy(v+b->len,s,n);b->len+=n;v[b->len]=0;
}
static void BarkBufFree(BarkBuf *b) {free(b->buf);b->buf=NULL;}
static void BarkIdListInit(BarkIdList *l) {l->ids=NULL;l->count=0;}
static int BarkIdListAppend(BarkIdList *l,char *id) {
    char **p=realloc(l->ids,(l->count+1)*sizeof(char *));
    if (!p) return -1;
    l->ids=p;p[l->count++]=id;return 0;
}
static void BarkIdListFree(BarkIdList *l) {
    for(int i=0;i<l->count;i++)free(l->ids[i]);
    free(l->ids);BarkIdListInit(l);
}
static LPWSTR MbsToWcs(const char *s) {
    size_t n=strlen(s);LPWSTR w=calloc(n+1,sizeof(wchar_t));
    if(w)mbstowcs(w,s,n+1);return w;
}
static LPWSTR BarkResolveNextLink(const char *s,LPCWSTR host,const char *base) {
    (void)host;(void)base;
    if (strncmp(s,"https://graph.microsoft.com/",28)==0) s+=27;
    else if (strncmp(s,"https://management.azure.com/",29)==0) s+=28;
    else if (*s!='/') return NULL;
    return MbsToWcs(s);
}
static LPWSTR BarkMakeAuthHeader(const char *token,const char *extra) {return MbsToWcs("fixture");}
static const char *responses[] = { RESPONSES };
static char *HttpRequestWithRetry(LPCWSTR method,LPCWSTR host,LPCWSTR path,
    LPWSTR headers,void *data,int length,DWORD *status) {
    if (testmode) {
        responseindex++;
        *status=testmode==5?403:200;
        const char *cases[]={NULL,
            "{\"value\":[{\"id\":\"fixture\"}],\"@odata.nextLink\":\"/cycle\"}",
            "{\"value\":[{\"id\":\"fixture\",\"nested\":{\"@odata.nextLink\":\"https://invalid.example/\"}}]}",
            "{\"value\":[{\"id\":\"fixture\"}],\"@odata.nextLink\":\"https://invalid.example/\"}",
            "{\"value\":[{\"id\":\"fixture\"},]}", "{}"};
        return strdup(cases[testmode]);
    }
    if (responseindex>=7) {*status=500;return NULL;}
    *status=200;return strdup(responses[responseindex++]);
}
static void BarkWriteOutput(const char *name,const char *body,DWORD n) {
    fwrite(body,1,n,stdout);putchar('\n');
}
static void BarkBufPrintBHItem(BarkBuf *b,const char *kind,const char *s,
    const char *end,int first,const char *suffix,int alias) {
    char prefix[256];int n=snprintf(prefix,sizeof(prefix),"%s{\"kind\":\"%s\",\"data\":",first?"":",",kind);
    BarkBufAppend(b,prefix,n);
    BarkBufAppend(b,s,end-s-1);
    if(suffix){BarkBufAppend(b,",",1);BarkBufAppend(b,suffix,strlen(suffix));}
    BarkBufAppend(b,"}}",2);
}
static void BarkBufPrintBHItemArm(BarkBuf *b,const char *kind,const char *s,
    const char *end,int first,const char *tenant,const char *rg) {
    char suffix[256];snprintf(suffix,sizeof(suffix),"\"tenantId\":\"%s\"",tenant);
    BarkBufPrintBHItem(b,kind,s,end,first,suffix,0);
}
static void BeaconDataParse(datap *p,char *a,int n) {argindex=0;}
static char *BeaconDataExtract(datap *p,void *n) {
    static char *args[]={"fixture","subscription",NULL};
    return args[argindex++];
}
static int BeaconDataInt(datap *p) {return 1;}
static char *BarkExtractTidFromJWT(const char *t) {return strdup("TENANT");}
static BarkIdList BarkParseSubscriptionSnapshot(const char *s) {BarkIdList l={NULL,0};return l;}
static BarkIdList BarkEnumEntityIdsWithStatus(LPCWSTR h,const char *p,const char *t,const char *k,int *ok) {
    BarkIdList l={NULL,0};*ok=1;return l;
}
static BarkIdList BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(const char *t,int *ok) {
    BarkIdList l={NULL,0};*ok=1;return l;
}
static void BarkEmitAllInfoArmMarker(const char *kind) {}
'''
        stub = stub.replace("RESPONSES", literals)
        vault_source = (ROOT / "src/arm_read/get_all_azurerm_key_vaults_bh.c").read_text()
        vault_source = "\n".join(l for l in vault_source.splitlines() if not l.startswith("#include"))
        main = r'''
int main(int argc,char **argv) {
    if (argc>1) {
        testmode=atoi(argv[1]);
        BarkEdgeOutput out={{NULL,0,0,1},0,1,"AZEntraRoleEligibilityScheduleInstance","TENANT","fixture"};
        BarkBufAppend(&out.output,"{\"data\":[",9);
        out.complete=BarkEdgeList(L"graph.microsoft.com","/cycle","fixture",BarkEdgeRawItem,&out);
        BarkEdgeFinish(&out);return responseindex==1?0:4;
    }
    BarkCollectEntraPIM("fixture","TENANT");go(NULL,0);return responseindex==7?0:3;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "test.c").write_text(stub + scanners + '\n#include "edge_collection.h"\n' + vault_source + main)
            build = subprocess.run(["gcc", "-std=gnu11", "-I", str(ROOT / "include"),
                                    str(root / "test.c"), "-o", str(root / "test")], capture_output=True, text=True)
            self.assertEqual(build.returncode, 0, build.stderr)
            run = subprocess.run([str(root / "test")], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stderr + run.stdout)
            for mode, complete in [(1, False), (2, True), (3, False), (4, False), (5, False)]:
                with self.subTest(mode=mode):
                    partial = subprocess.run([str(root / "test"), str(mode)], capture_output=True, text=True)
                    self.assertEqual(partial.returncode, 0, partial.stderr + partial.stdout)
                    payload = json.loads(partial.stdout)
                    self.assertEqual(payload["meta"]["collection"]["complete"], complete)
                    self.assertEqual(len(payload["data"]), 0 if mode == 5 else 1)
        payloads = [json.loads(line) for line in run.stdout.splitlines()]
        self.assertEqual(len(payloads), 3)
        self.assertTrue(all(p["meta"]["collection"]["complete"] for p in payloads))
        self.assertEqual(payloads[0]["data"][0]["kind"], "AZEntraRoleEligibilityScheduleInstance")
        self.assertEqual(len(payloads[1]["data"][0]["data"]["policy"]["rules"]), 3)
        self.assertEqual(payloads[2]["data"][0]["data"]["properties"]["accessPolicies"], vault()["properties"]["accessPolicies"])
