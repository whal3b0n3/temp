"""Ordered upload regression tests; no live BloodHound instance is modified."""
import contextlib
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import bark_upload as upload


class UploadTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.manifest = {"files": []}
        for phase, name, payload in [
            ("01-upload-native", "azurehound_bark.json", {"data": [], "meta": {"type": "azure", "version": 5}}),
            ("02-upload-opengraph", "AZPermissionGraph.json", {"graph": {"nodes": [], "edges": []}}),
        ]:
            relative = f"{phase}/{name}"
            path = self.root / relative
            path.parent.mkdir(parents=True)
            path.write_bytes(json.dumps(payload).encode())
            entry = {"output": relative, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                     "action": "upload", "format": "azure-v5" if phase.startswith("01") else "open-graph"}
            if phase.startswith("01"):
                self.manifest["mergedNative"] = entry
            else:
                self.manifest["files"].append(entry)
        self.write_manifest()

    def write_manifest(self):
        (self.root / "BARK_UPLOAD_MANIFEST.json").write_text(json.dumps(self.manifest))

    def test_dry_run_never_authenticates_or_connects(self):
        with patch.object(upload, "BloodHound") as api, patch.object(upload.getpass, "getpass") as prompt:
            with contextlib.redirect_stdout(io.StringIO()) as output:
                result = upload.main([str(self.root), "--dry-run"])
        self.assertEqual(result, 0)
        api.assert_not_called()
        prompt.assert_not_called()
        self.assertIn("Phase 1: 1 file(s)", output.getvalue())
        self.assertIn("Phase 2: 1 file(s)", output.getvalue())

    def test_bad_checksum_is_rejected_before_authentication(self):
        (self.root / self.manifest["files"][0]["output"]).write_text("{}")
        with patch.object(upload, "BloodHound") as api, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(upload.main([str(self.root)]), 1)
        api.assert_not_called()

    def test_escaped_phase_paths_and_duplicates_are_rejected(self):
        for value in ["../../outside.json", self.manifest["mergedNative"]["output"]]:
            with self.subTest(value=value):
                self.manifest["files"][0]["output"] = value
                self.write_manifest()
                with self.assertRaisesRegex(upload.UploadError, "escapes"):
                    upload.bundle_plan(self.root)
        self.manifest["files"][0]["output"] = "02-upload-opengraph/AZPermissionGraph.json"
        self.manifest["files"].append(dict(self.manifest["files"][0]))
        self.write_manifest()
        with self.assertRaisesRegex(upload.UploadError, "Duplicate"):
            upload.bundle_plan(self.root)

    def test_symlink_cannot_escape_bundle(self):
        outside = self.root / "other.json"
        outside.write_text("{}")
        path = self.root / self.manifest["files"][0]["output"]
        path.unlink()
        path.symlink_to(outside)
        with self.assertRaisesRegex(upload.UploadError, "escapes"):
            upload.bundle_plan(self.root)

    def test_legacy_nested_layout_remains_supported(self):
        for entry, old_directory in [
            (self.manifest["mergedNative"], "upload/01-azure-v5"),
            (self.manifest["files"][0], "upload/02-opengraph"),
        ]:
            source = self.root / entry["output"]
            target = self.root / old_directory / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            source.rename(target)
            entry["output"] = target.relative_to(self.root).as_posix()
        self.write_manifest()
        phases = upload.bundle_plan(self.root)
        self.assertEqual([len(phase) for phase in phases], [1, 1])
        self.assertEqual(phases[0][0][0].parent.name, "01-azure-v5")
        self.assertEqual(phases[1][0][0].parent.name, "02-opengraph")

    def test_native_phase_is_required(self):
        self.manifest["mergedNative"] = None
        self.write_manifest()
        with self.assertRaisesRegex(upload.UploadError, "no merged native"):
            upload.bundle_plan(self.root)

    def test_partial_failure_or_timeout_never_starts_phase_two(self):
        phases = upload.bundle_plan(self.root)
        for status, failed in [(-1, 0), (3, 0), (4, 0), (5, 0), (8, 0), (2, 1), (99, 0), (6, 0)]:
            with self.subTest(status=status):
                api = FakeAPI(status, failed)
                with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(upload.UploadError):
                    upload.upload_bundle(api, phases, wait_seconds=0)
                self.assertEqual(api.jobs, 1)
                self.assertEqual(len(api.uploads), 1)

    def test_complete_job_with_partial_files_never_starts_phase_two(self):
        api = FakeAPI(partial=1)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(upload.UploadError):
            upload.upload_bundle(api, upload.bundle_plan(self.root), wait_seconds=0)
        self.assertEqual(api.jobs, 1)
        self.assertEqual(len(api.uploads), 1)

    def test_changed_file_or_http_failure_never_starts_phase_two(self):
        phases = upload.bundle_plan(self.root)
        phases[0][0][0].write_text("{}")
        api = FakeAPI()
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaisesRegex(upload.UploadError, "changed"):
            upload.upload_bundle(api, phases)
        self.assertEqual(api.jobs, 1)
        self.assertEqual(api.uploads, [])

        phases = [[(phases[0][0][0], hashlib.sha256(b"{}").hexdigest())], phases[1]]
        api.call = lambda *args, **kwargs: (_ for _ in ()).throw(upload.UploadError("HTTP 403"))
        with self.assertRaisesRegex(upload.UploadError, "HTTP 403"):
            upload.upload_bundle(api, phases)

    def test_polling_ignores_other_jobs_and_waits_through_analysis(self):
        api = FakeAPI()
        responses = iter([
            {"data": [{"id": 999, "status": 2}]},
            {"data": [{"id": 1, "status": 6}]},
            {"data": [{"id": 1, "status": 7}]},
            {"data": [{"id": 1, "status": 2, "failed_files": 0}]},
        ])
        api.call = lambda *args: next(responses)
        now = [0]
        def sleep(seconds):
            now[0] += seconds
        upload.wait_for_job(api, 1, 10, interval=1, clock=lambda: now[0], sleep=sleep)
        self.assertEqual(now[0], 3)

    def test_http_login_upload_headers_and_separate_jobs(self):
        events = []
        state = {"job": 0, "complete": set()}

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def respond(self, code, payload=None):
                body = json.dumps(payload).encode() if payload is not None else b""
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                events.append(("POST", self.path, dict(self.headers), body))
                if self.path == "/api/v2/login":
                    self.respond(200, {"data": {"session_token": "test-session", "auth_expired": False}})
                elif self.headers.get("Authorization") != "Bearer test-session":
                    self.respond(401)
                elif self.path.endswith("/start"):
                    if state["job"] and state["job"] not in state["complete"]:
                        self.respond(409)
                        return
                    state["job"] += 1
                    self.respond(201, {"data": {"id": state["job"]}})
                else:
                    self.respond(200 if self.path.endswith("/end") else 202)

            def do_GET(self):
                events.append(("GET", self.path, dict(self.headers), b""))
                state["complete"].add(state["job"])
                self.respond(200, {"data": [{"id": state["job"], "status": 2, "failed_files": 0}]})

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            api = upload.BloodHound(f"http://127.0.0.1:{server.server_port}")
            # Keep local fixture independent of operator proxy configuration.
            api.opener = upload.request.build_opener(upload.request.ProxyHandler({}), upload.NoRedirect())
            api.login("fixture-user", "fixture-password")
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(upload.upload_bundle(api, upload.bundle_plan(self.root)), [1, 2])
        finally:
            server.shutdown()
            server.server_close()
            worker.join()
        self.assertEqual(json.loads(events[0][3]), {
            "login_method": "secret", "username": "fixture-user", "secret": "fixture-password"})
        self.assertEqual([(method, path) for method, path, _, _ in events], [
            ("POST", "/api/v2/login"),
            ("POST", "/api/v2/file-upload/start"),
            ("POST", "/api/v2/file-upload/1"),
            ("POST", "/api/v2/file-upload/1/end"),
            ("GET", "/api/v2/file-upload?id=eq:1&limit=1"),
            ("POST", "/api/v2/file-upload/start"),
            ("POST", "/api/v2/file-upload/2"),
            ("POST", "/api/v2/file-upload/2/end"),
            ("GET", "/api/v2/file-upload?id=eq:2&limit=1"),
        ])
        for event, expected in [(events[2], "azurehound_bark.json"), (events[6], "AZPermissionGraph.json")]:
            headers = {k.lower(): v for k, v in event[2].items()}
            self.assertEqual(headers["x-file-upload-name"], expected)
            self.assertEqual(headers["content-type"], "application/json")
            json.loads(event[3])

    def test_login_rejects_expired_session(self):
        api = upload.BloodHound("http://localhost:8080")
        with patch.object(api, "call", return_value={"data": {"auth_expired": True, "session_token": "expired"}}):
            with self.assertRaises(upload.UploadError):
                api.login("user", "password")
        self.assertEqual(api.token, "")


class FakeAPI:
    def __init__(self, status=2, failed=0, partial=0):
        self.jobs, self.uploads = 0, []
        self.status, self.failed, self.partial = status, failed, partial

    def call(self, method, path, data=None, headers=None):
        if path.endswith("/start"):
            self.jobs += 1
            return {"data": {"id": self.jobs}}
        if method == "GET":
            return {"data": [{"id": self.jobs, "status": self.status, "failed_files": self.failed, "partial_failed_files": self.partial}]}
        if not path.endswith("/end"):
            self.uploads.append((path, data, headers))
        return {}


if __name__ == "__main__":
    unittest.main()
