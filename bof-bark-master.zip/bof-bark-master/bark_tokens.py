#!/usr/bin/env python3
"""Acquire BARK authentication tokens locally (Python 3.10+, standard library).

Pass resource URLs, not scopes. Successful responses contain credentials and
are written to stdout unless --output is supplied. Diagnostics go to stderr.
"""
from __future__ import annotations

import argparse
import base64
import getpass
import json
import os
from pathlib import Path
import re
import secrets
import sys
from urllib import error, parse, request
import uuid

from bark_all_info import Http, CollectionError, decode_json, CLIENTS, GRAPH, LEGACY, ARM

LOGIN = "https://login.microsoftonline.com"
PORTAL_CLIENT = "c44b4083-3bb0-49c1-b47d-974e53cbdf3c"
NATIVE_REDIRECT = LOGIN + "/common/oauth2/nativeclient"
CANONICAL = {
    GRAPH.lower(): GRAPH,
    LEGACY.lower(): LEGACY,
    ARM.lower(): ARM + "/",
    "https://management.core.windows.net": "https://management.core.windows.net/",
    "https://storage.azure.com": "https://storage.azure.com",
    "https://vault.azure.net": "https://vault.azure.net",
    "https://api.powerplatform.com": "https://api.powerplatform.com",
}


def resource_url(value):
    """Accept old /.default inputs too; preserve meaningful custom URI slashes."""
    value = value.strip()
    if value.endswith("/.default"):
        value = value[:-9]
    if not value or any(c.isspace() or ord(c) < 32 for c in value):
        raise ValueError("resource must be a single HTTPS or api:// URL")
    try:
        parts = parse.urlsplit(value)
        invalid = (parts.scheme not in {"https", "api"} or not parts.netloc
                   or parts.username or parts.password or parts.query or parts.fragment)
        parts.port
    except ValueError:
        invalid = True
    if invalid:
        raise ValueError("resource must be a single HTTPS or api:// URL without credentials, query, or fragment")
    return CANONICAL.get(value.rstrip("/").lower(), value)


def default_scope(value):
    return resource_url(value) + "/.default"


def tenant_id(value):
    try:
        return str(uuid.UUID(value))
    except ValueError:
        if re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", value) and ".." not in value:
            return value
        raise argparse.ArgumentTypeError("tenant must be a GUID, tenant domain, or authority name") from None


def client_id(value):
    try:
        return str(uuid.UUID(value))
    except ValueError:
        raise argparse.ArgumentTypeError("client ID must be a GUID") from None


def clients_for(resource, explicit=None):
    if explicit:
        return [explicit]
    name = resource.lower()
    if "graph.microsoft.com" in name:
        rank = (0, 2, 4, 3, 1, 5)
    elif "graph.windows.net" in name:
        rank = (2, 0, 1, 3, 4, 5)
    elif any(word in name for word in ("office", "outlook", "sharepoint", "teams")):
        rank = (3, 4, 5, 0, 1, 2)
    else:
        rank = (0, 1, 2, 3, 4, 5)
    return [CLIENTS[i] for i in rank]


class AuthHttp(Http):
    def authorization_redirect(self, url, cookie):
        # The cookie goes only to this fixed authority; never follow Location.
        if (parse.urlsplit(url).scheme != "https" or
                parse.urlsplit(url).netloc != "login.microsoftonline.com"):
            raise CollectionError("invalid authorization host")
        req = request.Request(url, headers={"x-ms-RefreshTokenCredential": cookie})
        try:
            with self.opener.open(req, timeout=self.timeout):
                raise CollectionError("authorization requires interaction or returned no redirect")
        except error.HTTPError as exc:
            location = exc.headers.get("Location")
            status = exc.code
            exc.close()
            if status in (302, 303) and location:
                return location
            raise CollectionError(f"authorization failed (HTTP {status})", status) from None
        except (error.URLError, TimeoutError, OSError):
            raise CollectionError("authorization network request failed") from None


class Auth:
    def __init__(self, http=None):
        self.http = http or AuthHttp()

    def post(self, tenant, form, version=1):
        endpoint = "/oauth2/v2.0/token" if version == 2 else "/oauth2/token"
        return decode_json(self.http.send(
            "POST", LOGIN + "/" + tenant_id(tenant) + endpoint,
            {"Content-Type": "application/x-www-form-urlencoded"},
            parse.urlencode(form).encode()))

    @staticmethod
    def require_token(response, required=None):
        keys = [required] if required else ["access_token", "refresh_token", "id_token"]
        if "error" in response or not any(isinstance(response.get(k), str) and response[k] for k in keys):
            raise CollectionError("authentication returned no usable token")
        return response

    def grant(self, mode, tenant, resource, credential, username=None, client=None):
        audience = resource_url(resource)
        last = CollectionError("authentication failed")
        for candidate in clients_for(audience, client):
            form = {"client_id": candidate}
            if mode == "rt":
                form.update(grant_type="refresh_token", refresh_token=credential, resource=audience)
            elif mode == "up":
                if not username:
                    raise ValueError("username is required for password authentication")
                form.update(grant_type="password", username=username, password=credential,
                            scope=default_scope(audience) + " offline_access")
            elif mode == "cc":
                if not client:
                    raise ValueError("client ID is required for client credentials")
                form.update(grant_type="client_credentials", client_secret=credential,
                            scope=default_scope(audience))
            else:
                raise ValueError("unsupported grant type")
            try:
                result = self.require_token(self.post(tenant, form, 1 if mode == "rt" else 2))
                return {**result, "client_id": candidate}
            except CollectionError as exc:
                last = exc
        raise CollectionError(f"authentication failed for all selected clients ({last})", last.status)

    def prt(self, tenant, resource, cookie, client=None, redirect=NATIVE_REDIRECT):
        if any(c.isspace() or ord(c) < 32 for c in cookie):
            raise ValueError("PRT cookie must not contain whitespace")
        parts = parse.urlsplit(redirect)
        if not parts.scheme or parts.fragment or parts.query or parts.username or parts.password:
            raise ValueError("redirect URI must have a scheme and no credentials, query, or fragment")
        audience = resource_url(resource)
        nonce = ""
        try:
            payload = cookie.split(".")[1]
            claims = decode_json(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            nonce = claims.get("request_nonce") or claims.get("nonce") or ""
        except (IndexError, ValueError, CollectionError):
            raise ValueError("PRT cookie must contain a JSON JWT payload") from None
        if not isinstance(nonce, str):
            raise ValueError("PRT cookie nonce must be a string")
        last = CollectionError("PRT authentication failed")
        for candidate in clients_for(audience, client):
            state = secrets.token_urlsafe(24)
            params = {"response_type": "code", "client_id": candidate, "resource": audience,
                      "redirect_uri": redirect, "state": state}
            if nonce:
                params["sso_nonce"] = nonce
            url = LOGIN + "/" + tenant_id(tenant) + "/oauth2/authorize?" + parse.urlencode(params)
            try:
                location = self.http.authorization_redirect(url, cookie)
                actual = parse.urlsplit(location)
                if (actual.scheme, actual.netloc, actual.path) != (parts.scheme, parts.netloc, parts.path) or actual.fragment:
                    raise CollectionError("authorization returned an unexpected redirect")
                query = parse.parse_qs(actual.query)
                if query.get("state") != [state] or "error" in query or len(query.get("code", [])) != 1:
                    raise CollectionError("authorization returned an error, missing code, or mismatched state")
                result = self.require_token(self.post("common", {
                    "grant_type": "authorization_code", "client_id": candidate,
                    "redirect_uri": redirect, "code": query["code"][0]}))
                return {**result, "client_id": candidate}
            except CollectionError as exc:
                last = exc
        raise CollectionError(f"PRT authentication failed for all selected clients ({last})", last.status)

    def entra_refresh(self, tenant, username, password, client=None):
        chosen = client or CLIENTS[2]
        result = self.require_token(self.post(tenant, {
            "grant_type": "password", "client_id": chosen, "username": username,
            "password": password, "scope": "openid offline_access"}, 2), "refresh_token")
        return {**result, "client_id": chosen}

    def portal_refresh(self, tenant, refresh_token):
        result = self.require_token(self.post(tenant, {
            "grant_type": "refresh_token", "client_id": PORTAL_CLIENT, "refresh_token": refresh_token,
            "scope": default_scope("https://management.core.windows.net") + " openid profile offline_access"}, 2))
        return {**result, "client_id": PORTAL_CLIENT}

    def portal_delegate(self, target, tenant, portal_token, alt_token=""):
        body = {"tenant": tenant_id(tenant), "portalAuthorization": portal_token,
                "altPortalAuthorization": alt_token,
                "extensionName": "Microsoft_Azure_PIMCommon" if target == "arm" else "Microsoft_AAD_UsersAndTenants",
                "resourceName": "" if target == "arm" else "microsoft.graph"}
        result = decode_json(self.http.send(
            "POST", "https://portal.azure.com/api/DelegationToken?feature.cacheextensionapp=false"
            "&feature.internalgraphapiversion=true&feature.tokencaching=false",
            {"Content-Type": "application/json"}, json.dumps(body).encode()))
        if "error" in result:
            raise CollectionError("portal delegation returned an error")
        # The portal uses a different response envelope; preserve it like the BOF.
        if not result:
            raise CollectionError("portal delegation returned an empty response")
        return result

    def nonce(self):
        result = self.post("common", {"grant_type": "srv_challenge"})
        if not isinstance(result.get("Nonce") or result.get("nonce"), str):
            raise CollectionError("server challenge returned no nonce")
        return result


def read_secret(args, field, label, optional=False):
    path = getattr(args, field + "_file", None)
    value = (path.read_text(encoding="utf-8-sig").rstrip("\r\n") if path else
             os.environ.get("BARK_" + field.upper()))
    if value is None and not optional:
        value = getpass.getpass(label + ": ")
    if not value and not optional:
        raise ValueError(label + " is empty")
    return value or ""


def save_secret(path, text):
    # Exclusive creation protects existing credentials and rejects symlink targets.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(text)
        stream.write("\n")


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    sub = cli.add_subparsers(dest="command", required=True)
    modes = [
        ("rt", ["bark_get_tokens_with_rt"], "Refresh-token grant"),
        ("up", ["bark_get_tokens_with_up"], "Username/password grant"),
        ("cc", ["bark_get_tokens_with_cc"], "Client credentials"),
        ("prt", ["bark_get_token_with_prt_cookie"], "PRT-cookie authorization code flow"),
        ("get_tokens", ["bark_get_tokens"], "Unified rt/up/cc/prt grant"),
        ("arm", ["bark_get_tokens_for_arm"], "Unified grant for ARM"),
        ("msgraph", ["bark_get_tokens_for_msgraph"], "Unified grant for Microsoft Graph"),
        ("arm-rt", ["bark_get_azurerm_token_with_rt"], "Refresh token for ARM"),
        ("msgraph-rt", ["bark_get_msgraph_token_with_rt"], "Refresh token for Microsoft Graph"),
        ("entra-refresh", ["bark_get_entra_refresh_token_with_up"], "Obtain an Entra refresh token"),
        ("portal-rt", ["bark_get_azure_portal_token_with_rt"], "Refresh token for Azure Portal"),
        ("arm-portal", ["bark_get_azurerm_token_with_portal_rt"], "Portal delegation for ARM"),
        ("msgraph-portal", ["bark_get_msgraph_token_with_portal_rt"], "Portal delegation for Microsoft Graph"),
        ("nonce", ["bark_new_nonce"], "Request a server challenge nonce"),
    ]
    for mode, aliases, help_text in modes:
        cmd = sub.add_parser(mode, aliases=aliases, help=help_text)
        cmd.set_defaults(mode=mode)
        if mode in {"get_tokens", "arm", "msgraph"}:
            cmd.add_argument("grant", choices=("rt", "up", "cc", "prt"))
        if mode != "nonce":
            cmd.add_argument("--tenant", required=True, type=tenant_id)
        if mode in {"rt", "up", "cc", "prt", "get_tokens"}:
            cmd.add_argument("--resource", required=True, type=resource_url, help="resource URL; /.default is added internally for v2")
        if mode not in {"nonce", "portal-rt", "arm-portal", "msgraph-portal"}:
            cmd.add_argument("--client-id", type=client_id)
        if mode in {"up", "entra-refresh", "get_tokens", "arm", "msgraph"}:
            cmd.add_argument("--username", required=mode in {"up", "entra-refresh"})
        secret_fields = {
            "rt": ["refresh_token"], "up": ["password"], "cc": ["client_secret"],
            "prt": ["prt_cookie"], "entra-refresh": ["password"],
            "portal-rt": ["refresh_token"], "arm-rt": ["refresh_token"],
            "msgraph-rt": ["refresh_token"], "arm-portal": ["portal_token", "alt_portal_token"],
            "msgraph-portal": ["portal_token", "alt_portal_token"],
        }.get(mode, [] if mode == "nonce" else ["refresh_token", "password", "client_secret", "prt_cookie"])
        for field in secret_fields:
            cmd.add_argument("--" + field.replace("_", "-") + "-file", type=Path,
                             help="read from file instead of BARK_" + field.upper() + " or a hidden prompt")
        if mode in {"prt", "get_tokens", "arm", "msgraph"}:
            cmd.add_argument("--redirect-uri", default=NATIVE_REDIRECT)
        cmd.add_argument("--output", type=Path, help="write response JSON to a NEW file instead of stdout")
        if mode not in {"nonce", "cc", "arm-portal", "msgraph-portal"}:
            cmd.add_argument("--refresh-token-output", type=Path, help="also save the returned refresh token in a NEW plain-text file")
        cmd.add_argument("--timeout", type=int, default=60)
        cmd.add_argument("--retries", type=int, default=4)
    return cli


def main(argv=None):
    cli = parser()
    args = cli.parse_args(argv)
    if args.timeout < 1 or not 0 <= args.retries <= 10:
        cli.error("timeout must be positive and retries must be between 0 and 10")
    mode = args.mode
    grant = getattr(args, "grant", None) or mode
    client = getattr(args, "client_id", None)
    if grant == "cc" and not client:
        cli.error("--client-id is required for client credentials")
    if grant == "up" and not getattr(args, "username", None):
        cli.error("--username is required for password authentication")
    try:
        outputs = [p.expanduser().absolute() for p in
                   (args.output, getattr(args, "refresh_token_output", None)) if p]
        if len(set(outputs)) != len(outputs):
            raise ValueError("output files must be different")
        if any(p.exists() or p.is_symlink() for p in outputs):
            raise ValueError("output file already exists; choose a new path")
        auth = Auth(AuthHttp(args.timeout, args.retries))
        if mode == "nonce":
            result = auth.nonce()
        elif mode == "entra-refresh":
            result = auth.entra_refresh(args.tenant, args.username, read_secret(args, "password", "Password"), client)
        elif mode == "portal-rt":
            result = auth.portal_refresh(args.tenant, read_secret(args, "refresh_token", "Refresh token"))
        elif mode in {"arm-portal", "msgraph-portal"}:
            result = auth.portal_delegate(mode.split("-")[0], args.tenant,
                                          read_secret(args, "portal_token", "Portal authorization token"),
                                          read_secret(args, "alt_portal_token", "Alternate portal token", optional=True))
        else:
            resource = ARM if mode.startswith("arm") else GRAPH if mode.startswith("msgraph") else args.resource
            if mode.endswith("-rt"):
                grant = "rt"
            field, label = {"rt": ("refresh_token", "Refresh token"), "up": ("password", "Password"),
                            "cc": ("client_secret", "Client secret"), "prt": ("prt_cookie", "PRT cookie")}[grant]
            credential = read_secret(args, field, label)
            if grant == "prt":
                result = auth.prt(args.tenant, resource, credential, client, args.redirect_uri)
            else:
                result = auth.grant(grant, args.tenant, resource, credential, getattr(args, "username", None), client)
        refresh_output = getattr(args, "refresh_token_output", None)
        if refresh_output:
            if not result.get("refresh_token"):
                raise CollectionError("no refresh token returned; cannot write --refresh-token-output")
            save_secret(refresh_output.expanduser(), result["refresh_token"])
        rendered = json.dumps(result, ensure_ascii=False, indent=2)
        if args.output:
            save_secret(args.output.expanduser(), rendered)
            print("[+] Token response saved.", file=sys.stderr)
        else:
            print(rendered)
        return 0
    except CollectionError as exc:
        print(f"[!] {exc}", file=sys.stderr)
    except ValueError as exc:
        print(f"[!] {exc}", file=sys.stderr)
    except (OSError, EOFError):
        print("[!] Could not read credentials, write output, or obtain interactive input.", file=sys.stderr)
    except KeyboardInterrupt:
        print("[!] Interrupted.", file=sys.stderr)
        return 130
    return 1


if __name__ == "__main__":
    sys.exit(main())
