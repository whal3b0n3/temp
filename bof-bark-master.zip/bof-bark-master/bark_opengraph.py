"""OpenGraph references that preserve native Azure nodes during enrichment."""
from __future__ import annotations

from copy import deepcopy
import re


def native_endpoint(identifier: str) -> dict:
    """Resolve an existing node without asserting or adding native kind labels.

    BloodHound passes endpoint kind through to a node upsert; with ID matching
    it is not an existence/type check. Property matching requires a unique
    existing objectid. Omit source_kind on payloads linking native entities.
    """
    return {
        "match_by": "property",
        "property_matchers": [
            {"key": "objectid", "operator": "equals", "value": identifier.upper()}
        ],
    }


def endpoint_id(endpoint: dict) -> str:
    if endpoint.get("match_by", "id") == "property":
        return next(m["value"] for m in endpoint["property_matchers"] if m["key"] == "objectid")
    return endpoint["value"]


def standalone_id(identifier: str) -> str:
    # Custom copies must never collide with native object IDs in a sourceless
    # OpenGraph import. Keep all standalone graph families on the same IDs.
    return "BARK_ENTITY_" + identifier.upper()


def _cap_properties(properties: dict) -> dict:
    """Only CAP observations may be written to a native principal."""
    observations = properties.get("cap_policies", [])
    if not isinstance(observations, list) or any(not isinstance(v, str) for v in observations):
        raise ValueError("cap_policies must be a list of strings")
    observations = list(observations)
    for key in sorted((key for key in properties if re.fullmatch(r"MFA\d+", key)),
                      key=lambda key: int(key[3:])):
        value = properties[key]
        if not isinstance(value, str):
            raise ValueError("legacy CAP observations must be strings")
        observations.append(value)
    return {"cap_policies": list(dict.fromkeys(observations))}


def conditional_access_graph(nodes: list[dict]) -> dict:
    """Write CAP observations on native users/groups without identity fields.

    Import after native data. BloodHound merges these properties and sets
    primarykind to the supplied native kind; no custom labels/source are used.
    The bundler filters references against the collected native snapshot.
    """
    merged = {}
    for node in nodes:
        kinds = node["kinds"]
        if len(kinds) != 1 or kinds[0] not in {"AZUser", "AZGroup"}:
            raise ValueError("CAP properties require one native user or group kind")
        principal = node["id"].upper()
        props = _cap_properties(node.get("properties", {}))
        if principal in merged:
            previous = merged[principal]
            if previous["kinds"] != kinds:
                raise ValueError("conflicting CAP principal kinds")
            props["cap_policies"] = list(dict.fromkeys(
                previous["properties"]["cap_policies"] + props["cap_policies"]))
        merged[principal] = {"id": principal, "kinds": list(kinds), "properties": props}
    return {"graph": {"nodes": list(merged.values()), "edges": []}}


def preserve_native_nodes(payload: dict, native_principal_ids: set[str] | dict[str, str] | None = None) -> dict:
    """Limit native-node writes to CAP properties and upgrade legacy payloads."""
    result = deepcopy(payload)
    graph = result.get("graph")
    if not isinstance(graph, dict):
        return result
    native_links = False
    retained, cap_nodes, unmatched = [], [], []
    for node in graph.get("nodes", []):
        kinds = node.get("kinds", [])
        props = node.get("properties", {})
        if kinds == ["BARK_ConditionalAccessAnnotation"]:
            node = {"id": props.get("principalid") or node["id"].removeprefix("BARK_CA_"),
                    "kinds": [props.get("principalkind")], "properties": props}
            kinds = node["kinds"]
        if any(str(k).startswith("AZ") for k in kinds):
            if (kinds not in (["AZUser"], ["AZGroup"])
                    or not ("cap_policies" in props or any(re.fullmatch(r"MFA\d+", k) for k in props))):
                raise ValueError("OpenGraph must not redefine native Azure nodes; only CAP properties are allowed")
            native_links = True
            principal = node["id"].upper()
            if native_principal_ids is not None and principal not in native_principal_ids:
                unmatched.append({"id": principal, "kinds": kinds, "properties": _cap_properties(props)})
                continue
            if isinstance(native_principal_ids, dict):
                kinds = [native_principal_ids[principal]]
            cap_nodes.append({"id": principal, "kinds": kinds, "properties": props})
        elif kinds == [None]:
            raise ValueError("legacy CAP annotation has no native principal kind")
        else:
            retained.append(node)
    graph["nodes"] = retained + conditional_access_graph(cap_nodes)["graph"]["nodes"]
    graph["edges"] = [edge for edge in graph.get("edges", [])
                      if edge.get("kind") != "BARK_HasConditionalAccessAnnotation"]
    for edge in graph["edges"]:
        for side in ("start", "end"):
            endpoint = edge.get(side, {})
            if str(endpoint.get("kind", "")).startswith("AZ"):
                if endpoint.get("match_by", "id") != "id" or not endpoint.get("value"):
                    raise ValueError("unsupported native endpoint in legacy OpenGraph payload")
                edge[side] = native_endpoint(endpoint["value"])
                native_links = True
            elif endpoint.get("match_by") == "property":
                native_links = True
    result.get("meta", {}).pop("unlinkedConditionalAccessPrincipals", None)
    if unmatched:
        result.setdefault("meta", {})["unmatchedConditionalAccessPrincipals"] = sorted(
            {node["id"] for node in unmatched})
        result["meta"]["unmatchedConditionalAccessProperties"] = unmatched
    if native_links and result.get("metadata", {}).get("source_kind"):
        raise ValueError("native references must not inherit an OpenGraph source_kind")
    return result
