#!/usr/bin/env python3
"""Upload a BARK bundle in separate, ordered BloodHound ingestion jobs."""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from urllib import error, parse, request


class UploadError(Exception):
    pass


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class BloodHound:
    def __init__(self, url, token="", timeout=60):
        parts = parse.urlsplit(url)
        if (parts.scheme not in {"http", "https"} or not parts.hostname
                or parts.username or parts.password or parts.query or parts.fragment):
            raise UploadError("URL must be an HTTP(S) BloodHound address without credentials or query parameters")
        self.url, self.token, self.timeout = url.rstrip("/"), token, timeout
        self.opener = request.build_opener(NoRedirect())

    def call(self, method, path, data=None, headers=None):
        headers = {"Accept": "application/json", **(headers or {})}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        if isinstance(data, dict):
            data = json.dumps(data).encode()
            headers["Content-Type"] = "application/json"
        req = request.Request(self.url + path, data=data, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                body = response.read()
            return json.loads(body) if body else {}
        except error.HTTPError as exc:
            # Do not dump server responses or credentials.
            raise UploadError(f"{method} {path}: HTTP {exc.code}") from None
        except (error.URLError, OSError, ValueError):
            raise UploadError(f"{method} {path}: request or JSON response failed") from None

    def login(self, username, password):
        data = self.call("POST", "/api/v2/login",
                         {"login_method": "secret", "username": username, "secret": password}).get("data", {})
        if data.get("auth_expired") or not data.get("session_token"):
            raise UploadError("BloodHound login did not return an active session")
        self.token = data["session_token"]


def bundle_plan(directory):
    root = Path(directory).expanduser().resolve()
    manifest = json.loads((root / "BARK_UPLOAD_MANIFEST.json").read_text(encoding="utf-8-sig"))
    native = manifest.get("mergedNative")
    if not isinstance(native, dict):
        raise UploadError("Bundle has no merged native phase; regenerate it with bark_role_graph.py")
    entries = [native] + [
        entry for entry in manifest.get("files", [])
        if entry.get("action") == "upload" and entry.get("format") == "open-graph"
    ]
    phases = [[], []]
    seen = set()
    for entry in entries:
        relative = entry["output"]
        path = (root / relative).resolve()
        phase = 0 if entry is native else 1
        # Accept current top-level phase folders and older nested bundles.
        directories = (("01-upload-native", "upload/01-azure-v5") if phase == 0
                       else ("02-upload-opengraph", "upload/02-opengraph"))
        expected = [(root / directory).resolve() for directory in directories]
        if not path.is_relative_to(root) or not any(path.is_relative_to(folder) for folder in expected):
            raise UploadError("Manifest upload path escapes its phase directory")
        if path in seen:
            raise UploadError("Duplicate file in the bundle manifest")
        seen.add(path)
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest() != entry.get("sha256"):
            raise UploadError(f"Bundle checksum mismatch: {path.name}")
        phases[phase].append((path, entry["sha256"]))
    return phases


def wait_for_job(api, job_id, wait_seconds, interval=2, clock=time.monotonic, sleep=time.sleep):
    deadline = clock() + wait_seconds
    while True:
        rows = api.call("GET", f"/api/v2/file-upload?id=eq:{job_id}&limit=1").get("data", [])
        job = next((row for row in rows if row.get("id") == job_id), None)
        if job is not None:
            status = job.get("status")
            failed = job.get("failed_files", 0) or job.get("partial_failed_files", 0)
            if status == 2 and not failed:
                return
            if status in {-1, 3, 4, 5, 8} or (status == 2 and failed):
                raise UploadError(f"Upload job {job_id} was not fully successful (status {status}); check File Ingest")
            if status not in {0, 1, 6, 7}:
                raise UploadError(f"Upload job {job_id} returned an unknown status")
        if clock() >= deadline:
            raise UploadError(f"Timed out waiting for upload job {job_id}; later phases were not submitted")
        sleep(min(interval, max(0, deadline - clock())))


def upload_bundle(api, phases, wait_seconds=1800):
    jobs = []
    for index, files in enumerate(phases, 1):
        if not files:
            continue
        # A distinct job is essential: BloodHound does not preserve file order
        # inside one job. Never submit phase 2 until phase 1 is fully complete.
        response = api.call("POST", "/api/v2/file-upload/start")
        job_id = response.get("data", {}).get("id")
        if not isinstance(job_id, int) or isinstance(job_id, bool) or job_id < 1:
            raise UploadError("BloodHound did not return a valid upload job ID")
        jobs.append(job_id)
        print(f"[*] Phase {index}: upload job {job_id}", file=sys.stderr, flush=True)
        try:
            for path, checksum in files:
                payload = path.read_bytes()
                if hashlib.sha256(payload).hexdigest() != checksum:
                    raise UploadError(f"Bundle file changed before upload: {path.name}")
                api.call("POST", f"/api/v2/file-upload/{job_id}", payload,
                         {"Content-Type": "application/json", "X-File-Upload-Name": path.name})
            api.call("POST", f"/api/v2/file-upload/{job_id}/end")
            wait_for_job(api, job_id, wait_seconds)
        except (UploadError, OSError) as exc:
            raise UploadError(f"Phase {index}, job {job_id}: {exc}. No later phase was submitted.") from None
    return jobs


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--url", default="http://127.0.0.1:8080")
    auth = parser.add_mutually_exclusive_group()
    auth.add_argument("--username", help="BloodHound username; password is prompted")
    auth.add_argument("--token-file", type=Path, help="BloodHound session JWT file (not an Entra token)")
    parser.add_argument("--wait-timeout", type=int, default=1800, help="seconds to wait per ingestion job")
    parser.add_argument("--dry-run", action="store_true", help="validate checksums and list phases without connecting")
    args = parser.parse_args(argv)
    if args.wait_timeout < 1:
        parser.error("--wait-timeout must be positive")
    try:
        phases = bundle_plan(args.bundle)
        if args.dry_run:
            for index, files in enumerate(phases, 1):
                print(f"Phase {index}: {len(files)} file(s)")
                for path, _ in files:
                    print(f"  {path.name}")
            print("Install the bundle schema first. Phase 2 waits for phase 1 success.")
            return 0
        api = BloodHound(args.url)
        if args.username:
            api.login(args.username, getpass.getpass("BloodHound password: "))
        else:
            api.token = (args.token_file.read_text(encoding="utf-8-sig").strip() if args.token_file
                         else os.environ.get("BARK_BH_TOKEN") or getpass.getpass("BloodHound session JWT: ").strip())
        if not api.token:
            raise UploadError("BloodHound session token is empty")
        jobs = upload_bundle(api, phases, args.wait_timeout)
        print("[*] Completed: BloodHound upload jobs " + ", ".join(map(str, jobs)))
        return 0
    except KeyboardInterrupt:
        print("[!] Interrupted; check File Ingest for any submitted job.", file=sys.stderr)
        return 130
    except (UploadError, OSError, ValueError, KeyError, TypeError, EOFError) as exc:
        print(f"[!] {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
