# BARK Cypher queries

Run these in **BloodHound → Explore → Cypher** after importing the BARK data.
Path queries display relationships in the graph; the count query returns a table.

Install `schema/BARK_OpenGraph_Extension.json` from the generated bundle,
then import phase 1 native JSON followed by phase 2 OpenGraph JSON.
See [BloodHound import instructions](../wiki/BloodHound-Import.md).

## 1. Show all BARK relationships

```cypher
MATCH p=(a)-[r]->(b)
WHERE type(r) STARTS WITH 'BARK_'
RETURN p
LIMIT 200
```

## 2. List available relationship types and counts

Role-derived relationship names vary with the collected Azure roles.
Use this query to discover the exact types present in your graph.

```cypher
MATCH ()-[r]->()
WHERE type(r) STARTS WITH 'BARK_'
RETURN type(r) AS relationship, count(r) AS total
ORDER BY total DESC
```

## 3. Show application-role assignments and resource applications

The `appRoleAssignedTo` conversion produces:
principal → app role → resource service principal.
Principals can be users, groups, or service principals.

```cypher
MATCH p=(principal)-[:BARK_AssignedAppRole]->(role)
       -[:BARK_AppRoleOf]->(application)
RETURN p
LIMIT 200
```

## 4. Find assignments to a specific application role

Replace `flag` with the lowercase role display name.

```cypher
MATCH p=(principal)-[:BARK_AssignedAppRole]->(role)
       -[:BARK_AppRoleOf]->(application)
WHERE toLower(role.displayname) = 'flag'
RETURN p
LIMIT 200
```

## 5. Find roles belonging to a specific application

Replace `application-name` with a lowercase substring of the resource
application's display name.

```cypher
MATCH p=(principal)-[:BARK_AssignedAppRole]->(role)
       -[:BARK_AppRoleOf]->(application)
WHERE toLower(role.resourcedisplayname) CONTAINS 'application-name'
RETURN p
LIMIT 200
```

## 6. Show outgoing BARK relationships for a specific principal

Replace `OBJECT-ID` with the node's exact BloodHound Object ID.

```cypher
MATCH p=(principal)-[r]->(target)
WHERE principal.objectid = 'OBJECT-ID'
  AND type(r) STARTS WITH 'BARK_'
RETURN p
LIMIT 200
```

## 7. Show permission relationships from the bundled capability catalog

```cypher
MATCH p=(principal)-[r]->(target)
WHERE type(r) IN [
  'BARK_CanAssignAzureRole',
  'BARK_CanEscalateAzureRBAC',
  'BARK_CanWriteAzureRoleDefinition',
  'BARK_CanRunAzureVMCommand',
  'BARK_CanAssignAzureManagedIdentity',
  'BARK_CanListAzureStorageKeys'
]
RETURN p
LIMIT 200
```

## 8. Show PIM eligibility

Eligibility does not mean the role is currently active. These relationships
are non-traversable in the generated extension.

```cypher
MATCH p=()-[:BARK_EligibleForAzureRole]->()
RETURN p
LIMIT 200
```

## 9. Show potential permission relationships

These relationships are emitted only when conversion uses
`--include-potential-edges`. They represent uncertain permissions and are
non-traversable in the generated extension.

```cypher
MATCH p=()-[r]->()
WHERE type(r) STARTS WITH 'BARK_Potential_'
RETURN p
LIMIT 200
```

If the first query returns nothing, check that both import phases completed
and that the phase 2 files contain BARK relationships. An empty result does
not establish that the tenant has no assignments; collection permissions,
partial results, and skipped stages can affect coverage.


## 10. Show CAP observations on users

```cypher
MATCH (u:AZUser)
WHERE u.cap_policies IS NOT NULL
RETURN u, u.cap_policies AS CAPPolicies
LIMIT 200
```

Use `AZGroup` to inspect group observations. These are collected policy
exclusion/condition observations, not a complete sign-in policy evaluation.
See [CAP properties and native identity preservation](../wiki/OpenGraph-Node-Preservation.md).
