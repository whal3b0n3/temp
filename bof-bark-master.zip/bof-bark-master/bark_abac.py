#!/usr/bin/env python3
"""Small, conservative parser/evaluator for Azure RBAC ABAC conditions.

The evaluator intentionally returns UNKNOWN for syntax or attributes it does
not understand.  Permission analysis must never turn an unsupported condition
into a confirmed BloodHound attack-path edge.
"""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any


class TriState(str, Enum):
    TRUE = "true"
    FALSE = "false"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class Token:
    kind: str
    value: str


@dataclass(frozen=True)
class ParseError(Exception):
    message: str

    def __str__(self) -> str:
        return self.message


_TOKEN_RE = re.compile(r"\s+|[(){}!,]|'[^']*(?:''[^']*)*'|[^\s(){}!,]+")


def _tokenize(value: str) -> list[Token]:
    tokens: list[Token] = []
    position = 0
    for match in _TOKEN_RE.finditer(value):
        if match.start() != position:
            raise ParseError(f"unexpected ABAC text at offset {position}")
        position = match.end()
        raw = match.group(0)
        if raw.isspace():
            continue
        if raw in {"(", ")", "{", "}", ",", "!"}:
            tokens.append(Token(raw, raw))
        elif raw.startswith("'"):
            if not raw.endswith("'"):
                raise ParseError("unterminated ABAC string")
            tokens.append(Token("value", raw[1:-1].replace("''", "'")))
        else:
            tokens.append(Token("word", raw))
    if position != len(value):
        raise ParseError(f"unexpected ABAC text at offset {position}")
    tokens.append(Token("eof", ""))
    return tokens


class _Parser:
    def __init__(self, value: str):
        self.tokens = _tokenize(value)
        self.index = 0

    def current(self) -> Token:
        return self.tokens[self.index]

    def take(self, kind: str | None = None) -> Token:
        token = self.current()
        if kind is not None and token.kind != kind:
            raise ParseError(f"expected {kind}, got {token.value!r}")
        self.index += 1
        return token

    def accept(self, kind: str) -> bool:
        if self.current().kind == kind:
            self.index += 1
            return True
        return False

    def parse(self) -> Any:
        result = self.parse_or()
        if self.current().kind != "eof":
            raise ParseError(f"unexpected ABAC token {self.current().value!r}")
        return result

    def parse_or(self) -> Any:
        values = [self.parse_and()]
        while self.current().value.lower() == "or":
            self.take()
            values.append(self.parse_and())
        return values[0] if len(values) == 1 else ("or", values)

    def parse_and(self) -> Any:
        values = [self.parse_not()]
        while self.current().value.lower() == "and":
            self.take()
            values.append(self.parse_not())
        return values[0] if len(values) == 1 else ("and", values)

    def parse_not(self) -> Any:
        if self.accept("!") or self.current().value.lower() == "not":
            if self.tokens[self.index - 1].kind != "!":
                self.take()
            return ("not", self.parse_not())
        return self.parse_primary()

    def parse_primary(self) -> Any:
        if self.accept("("):
            value = self.parse_or()
            self.take(")")
            return value

        lhs = self.take()
        if lhs.kind == "eof":
            raise ParseError("unexpected end of ABAC condition")

        if lhs.value.lower() in {"actionmatches", "suboperationmatches"}:
            values = self.parse_set_or_value()
            return ("function", lhs.value.lower(), values)

        operator = self.take("word").value
        rhs = self.parse_set_or_value()
        return ("compare", lhs.value, operator, rhs)

    def parse_set_or_value(self) -> list[str]:
        if self.accept("{"):
            values: list[str] = []
            while self.current().kind != "}":
                if self.current().kind == ",":
                    self.take(",")
                    continue
                if self.current().kind == "eof":
                    raise ParseError("unterminated ABAC set")
                values.append(self.take().value)
            self.take("}")
            return values
        return [self.take().value]


def parse_condition(value: str) -> Any:
    """Parse an Azure condition into a small immutable tuple AST."""
    if not isinstance(value, str) or not value.strip():
        raise ParseError("empty ABAC condition")
    return _Parser(value).parse()


def _truth_not(value: TriState) -> TriState:
    if value is TriState.TRUE:
        return TriState.FALSE
    if value is TriState.FALSE:
        return TriState.TRUE
    return TriState.UNKNOWN


def _truth_and(values: list[TriState]) -> TriState:
    if any(value is TriState.FALSE for value in values):
        return TriState.FALSE
    if all(value is TriState.TRUE for value in values):
        return TriState.TRUE
    return TriState.UNKNOWN


def _truth_or(values: list[TriState]) -> TriState:
    if any(value is TriState.TRUE for value in values):
        return TriState.TRUE
    if all(value is TriState.FALSE for value in values):
        return TriState.FALSE
    return TriState.UNKNOWN


def _pattern_match(pattern: str, value: str) -> bool:
    return fnmatch.fnmatchcase(value.lower(), pattern.lower())


def _context_values(attribute: str, context: dict[str, Any]) -> list[str] | None:
    wanted = attribute.lower()
    for key, value in context.items():
        if str(key).lower() != wanted:
            continue
        if isinstance(value, (list, tuple, set)):
            return [str(item) for item in value]
        return [str(value)]
    return None


def _compare_one(left: str, operator: str, right: str) -> bool | None:
    op = operator.lower()
    left_guid = left.lower()
    right_guid = right.lower()
    if op.endswith("guid equals") or op == "guidequals":
        return left_guid == right_guid
    if op.endswith("guidnotequals") or op == "guidnotequals":
        return left_guid != right_guid
    if op.endswith("stringequals") or op == "stringequals":
        return left == right
    if op.endswith("stringequalsignorecase") or op == "stringequalsignorecase":
        return left.lower() == right.lower()
    if op.endswith("stringnotequals") or op == "stringnotequals":
        return left != right
    if op.endswith("stringnotequalsignorecase") or op == "stringnotequalsignorecase":
        return left.lower() != right.lower()
    if op.endswith("stringlike") or op == "stringlike":
        return fnmatch.fnmatchcase(left, right)
    if op.endswith("stringlikeignorecase") or op == "stringlikeignorecase":
        return fnmatch.fnmatchcase(left.lower(), right.lower())
    if op.endswith("stringnotlike") or op == "stringnotlike":
        return not fnmatch.fnmatchcase(left, right)
    if op.endswith("stringnotlikeignorecase") or op == "stringnotlikeignorecase":
        return not fnmatch.fnmatchcase(left.lower(), right.lower())
    if op.endswith("guids"):
        return left_guid == right_guid
    return None


def _compare(attribute: str, operator: str, left: list[str] | None, right: list[str]) -> TriState:
    if left is None:
        return TriState.UNKNOWN
    op = operator.lower()
    if ":" in op and op.startswith("forallofall"):
        quantifier = "all-left-all-right"
    elif ":" in op and op.startswith("forallofany"):
        quantifier = "all-left-any-right"
    elif ":" in op and op.startswith("foranyofall"):
        quantifier = "any-left-all-right"
    elif ":" in op and op.startswith("foranyofany"):
        quantifier = "any-pair"
    else:
        quantifier = "any-pair"

    base = op.split(":", 1)[-1]
    values: list[TriState] = []
    for left_value in left:
        row = [_compare_one(left_value, base, right_value) for right_value in right]
        if any(result is None for result in row):
            values.append(TriState.UNKNOWN)
            continue
        booleans = [bool(result) for result in row]
        if quantifier == "all-left-all-right":
            values.append(TriState.TRUE if all(booleans) else TriState.FALSE)
        elif quantifier == "any-left-all-right":
            values.append(TriState.TRUE if all(booleans) else TriState.FALSE)
        elif quantifier == "all-left-any-right":
            values.append(TriState.TRUE if any(booleans) else TriState.FALSE)
        else:
            values.append(TriState.TRUE if any(booleans) else TriState.FALSE)

    if quantifier in {"all-left-all-right", "all-left-any-right"}:
        return _truth_and(values)
    return _truth_or(values)


def evaluate_ast(ast: Any, context: dict[str, Any]) -> TriState:
    kind = ast[0]
    if kind == "not":
        return _truth_not(evaluate_ast(ast[1], context))
    if kind == "and":
        return _truth_and([evaluate_ast(value, context) for value in ast[1]])
    if kind == "or":
        return _truth_or([evaluate_ast(value, context) for value in ast[1]])
    if kind == "function":
        values = ast[2]
        current = str(context.get("action", ""))
        if ast[1] == "actionmatches":
            return TriState.TRUE if any(_pattern_match(value, current) for value in values) else TriState.FALSE
        if ast[1] == "suboperationmatches":
            current_suboperation = str(context.get("suboperation", ""))
            return TriState.TRUE if any(_pattern_match(value, current_suboperation) for value in values) else TriState.FALSE
        return TriState.UNKNOWN
    if kind == "compare":
        return _compare(ast[1], ast[2], _context_values(ast[1], context), ast[3])
    return TriState.UNKNOWN


def evaluate_condition(value: str | None, context: dict[str, Any]) -> TriState:
    if value is None or not str(value).strip():
        return TriState.TRUE
    try:
        return evaluate_ast(parse_condition(str(value)), context)
    except (ParseError, IndexError, ValueError):
        return TriState.UNKNOWN


def request_context(
    action: str,
    principal_id: str | None = None,
    principal_type: str | None = None,
    role_definition_id: str | None = None,
    suboperation: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    context: dict[str, Any] = {
        "action": action,
        "suboperation": suboperation or "",
    }
    values = {
        "@Request[Microsoft.Authorization/roleAssignments:PrincipalId]": principal_id,
        "@Request[Microsoft.Authorization/roleAssignments:PrincipalType]": principal_type,
        "@Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId]": role_definition_id,
    }
    context.update({key: value for key, value in values.items() if value is not None})
    if extra:
        context.update(extra)
    return context
