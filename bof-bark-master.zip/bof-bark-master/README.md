# bof-bark

[English](README.md) | [日本語](README.ja.md)

BARK provides Cobalt Strike BOFs for Entra ID and Azure operations, plus a
local Python collector that prepares data for BloodHound. The BOFs are based
on [BARKKAI](https://github.com/whal3b0n3/BARKKAI).

This README covers the operator workflow. Use the [wiki](wiki/Home.md) for
configuration, collection behavior, command references, and troubleshooting.

## Choose a collection path

| Run from | Entry point | Output |
| --- | --- | --- |
| Operator machine, Python 3.10+ | `python3 bark_all_info.py <tenant-guid-or-domain>` | Local JSON and a BloodHound upload bundle |
| Cobalt Strike Beacon | `bark_get_all_info_bh_rt <tenantId> <refreshToken>` | JSON downloaded through C2; prepare the upload bundle locally |

Both paths use a refresh token to collect Entra objects and relationships,
application-role assignments, Conditional Access, Azure resources and RBAC,
and Storage/Key Vault metadata. Available results depend on the token's
permissions. See [authentication](wiki/Authentication.md) and
[collection coverage](wiki/Python-Collector.md#collection-coverage).

```mermaid
flowchart TD
    A[Tenant ID and refresh token] --> B{Run from}
    B -->|Operator machine| C[Python collector]
    B -->|Beacon| D[Load CNA and run all-info]
    C --> E[Local JSON and upload bundle]
    D --> F[Download collection results]
    F --> G[Run bark_role_graph.py locally]
    G --> E
    E --> H[Check collection results and upload instructions]
    H --> I[Install schema, ingest native JSON, then OpenGraph]
```

## Obtain tokens with Python

Pass a resource URL; the authentication commands add the v2 scope suffix
internally. To obtain tokens with a username and password:

```bash
python3 bark_tokens.py up --tenant <tenant-guid> \
  --username operator@example.com --resource https://graph.microsoft.com \
  --output ./tokens.json --refresh-token-output ./refresh-token.txt
```

The password is requested at a hidden prompt. The returned refresh-token file
can be passed to the collector below. ROPC requires a tenant policy that permits
password authentication without an interactive prompt.

If you already have a refresh token, exchange it for a resource token:

```bash
python3 bark_tokens.py rt --tenant <tenant-guid> \
  --resource https://management.azure.com --refresh-token-file ./refresh-token.txt
```

See [Python token commands](wiki/Python-Tokens.md) for client credentials,
PRT cookies, portal delegation, token output, and the Beacon-to-Python mapping.

## Collect with Python

Run from this repository checkout with Python 3.10 or later. The collector
uses the standard library; retain the adjacent graph helpers and `data/`
directory for bundle generation.

```bash
python3 bark_all_info.py <tenant-guid-or-domain> --output ./bark-results
```

Standard output shows one count per saved collection, such as
`[+] AZUser: Found 123 objects`, followed by the completion status and output directory.
Owner/member collections show total relationship counts, without individual object details.
Partial collections are marked `(incomplete collection)`.
Errors are printed to standard error; bundle details are saved in
`bundle_conversion.log` inside the output directory.

Collection uses eight workers by default. Add `--workers 16` to increase
concurrency or `--workers 1` for sequential troubleshooting (allowed: 1-32).

The tenant argument accepts a GUID or a domain such as `megabigtech.com`.
Enter the refresh token at the hidden prompt. For a token already stored
in a file:

```bash
python3 bark_all_info.py <tenant-guid-or-domain> \
  --refresh-token-file /path/to/token.txt \
  --output ./bark-results
```

Each run creates `bark-results/BARK_<UTC timestamp>/` containing JSON,
`collection_manifest.json`, and a `BARK_BloodHound_Bundle_<timestamp>/`
directory. Check the manifest for failed or skipped collections before
interpreting the graph. Exit code `2` indicates partial collection or
conversion failure for a valid invocation.

Continue to [Import into BloodHound](#import-into-bloodhound). See the
[Python collector wiki](wiki/Python-Collector.md) for all options, permission
handling, and differences from the Beacon workflow.

## Collect with Beacon

1. Keep `bark.cna` and `bofs/` together. If rebuilding the BOFs, follow
   [Installation](wiki/Installation.md).
2. Load `bark.cna` through **Cobalt Strike -> Script Manager -> Load**.
3. Run the combined collector in the Beacon console:

```text
beacon> bark_download_mode on
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken>
```

Download mode is on by default. Collect the completed JSON downloads into
one local directory, then build the upload bundle:

```bash
python3 bark_role_graph.py /path/to/bark/downloads \
  --bundle-output ./bloodhound-upload
```

The helper reassembles complete split JSON files. Wait for all download
parts to finish before conversion.

For a password-protected ZIP, select staging mode before collection:

```text
beacon> bark_download_mode off
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken> <zip-password>
```

Follow [Downloads and archives](wiki/Downloads-and-Archives.md) to reassemble
and extract the ZIP, then run `bark_role_graph.py` on the extracted directory.
For scoped collection, legacy fallback, or interrupted jobs, see the
[Beacon workflow](wiki/Collection-Workflow.md). Use `bark_help` or
`help bark_<name>` for command help.

## Import into BloodHound

Use BloodHound with property-based OpenGraph endpoint matching (supported by
BloodHound 9.0). Updated bundles preserve native nodes; see
[node preservation and migration](wiki/OpenGraph-Node-Preservation.md).


Use the bundle created by Python or the offline converter:

The numbered folders show the required order:

```text
00-install-schema/    Install the extension
01-upload-native/     Upload alone; wait for Complete
02-upload-opengraph/  Upload as a new job
do-not-upload/        Supporting data only
```

1. Read `UPLOAD_INSTRUCTIONS.txt` and review `BARK_UPLOAD_MANIFEST.json`.
2. Install `00-install-schema/BARK_OpenGraph_Extension.json` as an OpenGraph extension.
3. Upload the bundle with Python; it waits for native ingestion to succeed
   before starting a separate OpenGraph job:

```bash
python3 bark_upload.py ./bloodhound-upload --dry-run
python3 bark_upload.py ./bloodhound-upload --username <bloodhound-user>
```

The password is prompted. Use `--url https://bloodhound.example` for a remote
instance. These are **BloodHound credentials**, separate from Entra tokens.

For manual import, submit only `01-upload-native/azurehound_bark.json`
and wait for its job to report **Complete**. Then submit the files under
`02-upload-opengraph/` as a **new job**. Never combine both phases in one
upload or ZIP: file order within a job is not a dependency guarantee.

Upload only the data files present in those upload directories. Keep
`do-not-upload/` for review. Custom application roles are represented through
`BARK_AssignedAppRole` relationships in the OpenGraph phase.

CAP observations appear in the user/group's `cap_policies` property. The
phase-2 CAP file contains only these observations and native IDs/kinds; upload
after native ingestion to preserve the existing identity data.

See [BloodHound import](wiki/BloodHound-Import.md) for app-role resolution,
permission findings, output compatibility, and troubleshooting.

PIM eligibility/approver edges, Key Vault access-policy edges and managed-identity reference fixes are included in the native upload. Review nativeEdgeConversion in BARK_UPLOAD_MANIFEST.json for excluded evidence. Recollect with the updated collector when older snapshots lack PIM rules or identity mappings. See [native edge details and verified coverage](wiki/Azure-Native-Edges.md).

### What each JSON file is for

Timestamps vary by run. Both Python and BOF bundles use these roles:

| Folder / JSON | Purpose | Operator action |
| --- | --- | --- |
| `00-install-schema/BARK_OpenGraph_Extension.json` | Defines BARK node/relationship kinds, appearance, and traversability. | Install through **OpenGraph Management**. |
| `01-upload-native/azurehound_bark.json` | Merged native Azure users, groups, applications, service principals, resources, and supported relationships. | Upload alone through **File Ingest**; wait for **Complete**. |
| `02-upload-opengraph/AZAppRoleGraph_*.json` | Application-role assignments: principal ? app role ? resource service principal. | Upload in the second job. |
| `02-upload-opengraph/AZRoleGraph_*.json` | Azure RBAC assignments: who holds which role on a resource or scope. | Upload in the second job. |
| `02-upload-opengraph/AZPermissionGraph_*.json` | Capabilities derived from RBAC analysis, such as running VM commands or assigning managed identities. | Upload in the second job. |
| `02-upload-opengraph/AZConditionalAccessPolicy_*.json` (BOF) / `AZConditionalAccessGraph.json` (Python) | CAP observations stored in native user/group `cap_policies` properties; no CAP edges. | Upload in the second job. |
| `BARK_UPLOAD_MANIFEST.json` | File classifications, checksums, and upload order. | Review only. |
| `CAP_PROPERTIES_VALIDATION.json` (supplied repaired bundles) | Local validation results for the CAP-property migration. | Review only; not generated on every collection. |
| `do-not-upload/*.json` and its subdirectories | Raw inputs, permission findings, and native source copies already included in the merge. | Review only. |

All JSON files inside `02-upload-opengraph/` can be submitted together,
after the native job completes. Available files depend on collection results.

### Install the OpenGraph extension

Sign in as a BloodHound Administrator. If needed, enable **OpenGraph Extension
Management** under **Administration ? Early Access Features** and refresh.
Open **Administration ? OpenGraph Management ? Upload File**, select
`00-install-schema/BARK_OpenGraph_Extension.json`, and click **Upload**.
Confirm that **BARK Azure Permissions** appears in the extension list.
The schema does not belong in File Ingest. See the
[official extension guide](https://bloodhound.specterops.io/opengraph/extensions/manage#verify-or-install-an-extension).

## Reference

- [Wiki index](wiki/Home.md)
- [Python collector options](wiki/Python-Collector.md)
- [Command reference](wiki/Command-Reference.md)
- [Additional collectors](wiki/Additional-Collectors.md)
- [Build and development](wiki/Development.md)

[Azure edge coverage and planned work](wiki/Azure-Edge-Coverage-Plan.md)
