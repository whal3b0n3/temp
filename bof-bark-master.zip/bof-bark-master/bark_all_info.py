#!/usr/bin/env python3
"""Local refresh-token counterpart of bark_get_all_info_bh_rt (Python 3.10+).

Only OAuth token exchanges and read-only collection requests are performed.
Run from this checkout to also use the existing BloodHound bundle converter.
"""
from __future__ import annotations

import argparse
from bark_opengraph import conditional_access_graph
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from itertools import islice
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import getpass
import json
import os
from pathlib import Path
import re
import sys
import time
import threading
from urllib import error, parse, request
import uuid
import xml.etree.ElementTree as ET

GRAPH = "https://graph.microsoft.com"
LEGACY = "https://graph.windows.net"
ARM = "https://management.azure.com"
STORAGE = "https://storage.azure.com"
VAULT = "https://vault.azure.net"
CLIENTS = (
    "04b07795-8ddb-461a-bbee-02f9e1bf7b46",  # Azure CLI
    "1950a258-227b-4e31-a9cf-717495945fc2",  # Azure PowerShell
    "1b730954-1685-4b74-9bfd-dac224a7b894",  # AAD PowerShell
    "d3590ed6-52b3-4102-aeff-aad2292ab01c",  # Office
    "1fec8e78-bce4-4aaf-ab1b-5451cc387264",  # Teams
    "d326c1ce-6cc6-4de2-bebc-4591e5e13ef0",  # SharePoint
)

# API versions match the BOF collectors.
ARM_COLLECTIONS = (
    ("AZUserAssignedIdentity", "providers/Microsoft.ManagedIdentity/userAssignedIdentities", "2023-01-31"),
    ("AZRoleDefinition", "providers/Microsoft.Authorization/roleDefinitions", "2022-04-01"),
    ("AZResourceGroup", "resourcegroups", "2021-04-01"),
    ("AZResource", "resources", "2021-04-01"),
    ("AZVM", "providers/Microsoft.Compute/virtualMachines", "2022-03-01"),
    ("AZVMScaleSet", "providers/Microsoft.Compute/virtualMachineScaleSets", "2022-03-01"),
    ("AZKeyVault", "providers/Microsoft.KeyVault/vaults", "2021-10-01"),
    ("AZStorageAccount", "providers/Microsoft.Storage/storageAccounts", "2021-09-01"),
    ("AZLogicApp", "providers/Microsoft.Logic/workflows", "2016-06-01"),
    ("AZWebApp", "providers/Microsoft.Web/sites", "2022-03-01"),
    ("AZManagedCluster", "providers/Microsoft.ContainerService/managedClusters", "2022-03-01"),
    ("AZContainerRegistry", "providers/Microsoft.ContainerRegistry/registries", "2021-09-01"),
    ("AZAutomationAccount", "providers/Microsoft.Automation/automationAccounts", "2021-06-22"),
    ("AZContainerApp", "providers/Microsoft.App/containerApps", "2024-03-01"),
    ("AZContainerGroup", "providers/Microsoft.ContainerInstance/containerGroups", "2023-05-01"),
    ("AZCosmosDB", "providers/Microsoft.DocumentDB/databaseAccounts", "2021-10-15"),
)
EXTRAS = (
    ("AZDenyAssignment", "denyAssignments", "2022-04-01"),
    ("AZRoleEligibilityScheduleInstance", "roleEligibilityScheduleInstances", "2020-10-01"),
    ("AZRoleAssignmentScheduleInstance", "roleAssignmentScheduleInstances", "2020-10-01"),
    ("AZRoleManagementPolicyAssignment", "roleManagementPolicyAssignments", "2020-10-01"),
    ("AZRoleManagementPolicy", "roleManagementPolicies", "2020-10-01"),
)
USER_FIELDS = (
    "id,deletedDateTime,accountEnabled,ageGroup,businessPhones,city,createdDateTime,"
    "creationType,companyName,consentProvidedForMinor,country,department,displayName,"
    "employeeId,employeeHireDate,employeeLeaveDateTime,employeeType,faxNumber,givenName,"
    "imAddresses,infoCatalogs,isHardDeleteProtectionEnabled,isLicenseReconciliationNeeded,"
    "isManagementRestricted,isResourceAccount,jobTitle,lastPasswordChangeDateTime,"
    "legalAgeGroupClassification,mail,mailNickname,mobilePhone,onPremisesDistinguishedName,"
    "officeLocation,onPremisesDomainName,onPremisesImmutableId,onPremisesLastSyncDateTime,"
    "onPremisesObjectIdentifier,onPremisesSecurityIdentifier,onPremisesSamAccountName,"
    "onPremisesSyncEnabled,onPremisesUserPrincipalName,otherMails,passwordPolicies,"
    "postalCode,preferredDataLocation,preferredLanguage,proxyAddresses,"
    "refreshTokensValidFromDateTime,securityIdentifier,showInAddressList,"
    "signInSessionsValidFromDateTime,state,streetAddress,surname,usageLocation,"
    "userPrincipalName,externalUserConvertedOn,externalUserState,"
    "externalUserStateChangeDateTime,userType,identityParentId,agentIdentityBlueprintId,"
    "isProvisionedToOnPremises,identityProfileIds,employeeOrgData,inviteTicket,"
    "passwordProfile,assignedLicenses,assignedPlans,authorizationInfo,"
    "cloudRealtimeCommunicationInfo,deviceKeys,identities,onPremisesExtensionAttributes,"
    "onPremisesProvisioningErrors,onPremisesSipInfo,provisionedPlans,serviceProvisioningErrors"
)


class CollectionError(Exception):
    """Sanitized error: never include response bodies or credentials."""

    def __init__(self, message, status=0):
        super().__init__(message)
        self.status = status


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Http:
    def __init__(self, timeout=60, retries=4, sleep=time.sleep):
        self.timeout, self.retries, self.sleep = timeout, retries, sleep
        self._local = threading.local()
        self.cancelled = threading.Event()

    @property
    def opener(self):
        # urllib handlers retain request state; each worker owns its handlers.
        if not hasattr(self._local, "opener"):
            self._local.opener = request.build_opener(NoRedirect())
        return self._local.opener

    @opener.setter
    def opener(self, value):
        self._local.opener = value

    def send(self, method, url, headers=None, data=None):
        for attempt in range(self.retries + 1):
            if self.cancelled.is_set():
                raise CollectionError("collection cancelled")
            retry_after = None
            try:
                req = request.Request(url, data=data, headers=headers or {}, method=method)
                with self.opener.open(req, timeout=self.timeout) as response:
                    return response.read()
            except error.HTTPError as exc:
                status = exc.code
                retry_after = exc.headers.get("Retry-After")
                exc.close()
                problem = CollectionError(f"HTTP {status}", status)
                if status not in (408, 429, 500, 502, 503, 504):
                    raise problem from None
            except (error.URLError, TimeoutError, OSError):
                problem = CollectionError("network request failed")
            if attempt == self.retries:
                raise problem from None
            delay = min(2 ** attempt, 60)
            if retry_after:
                try:
                    delay = float(retry_after)
                except ValueError:
                    try:
                        delay = parsedate_to_datetime(retry_after).timestamp() - time.time()
                    except (ValueError, TypeError, OverflowError):
                        pass
            delay = max(0, min(delay, 300))
            if self.sleep is time.sleep:
                if self.cancelled.wait(delay):
                    raise CollectionError("collection cancelled")
            else:
                self.sleep(delay)
        raise AssertionError("unreachable")


def decode_json(raw):
    try:
        result = json.loads(raw)
    except (ValueError, UnicodeError):
        raise CollectionError("invalid JSON response") from None
    if not isinstance(result, dict):
        raise CollectionError("expected a JSON object")
    return result


class Tokens:
    def __init__(self, tenant, refresh_token, http, client_id=None, clock=time.monotonic):
        self.tenant, self.refresh_token, self.http = tenant, refresh_token, http
        self.client_id, self.clock = client_id, clock
        self.cache = {}
        # One shared refresh token rotates across audiences. Serialize only OAuth.
        self._lock = threading.Lock()

    def get(self, audience, force=False):
        with self._lock:
            return self._get_locked(audience, force)

    def refresh_after_rejection(self, audience, rejected_token):
        with self._lock:
            cached = self.cache.get(audience)
            # Another worker may already have replaced the rejected token.
            force = not cached or cached[0] == rejected_token
            return self._get_locked(audience, force)

    def _get_locked(self, audience, force=False):
        cached = self.cache.get(audience)
        if cached and not force and self.clock() < cached[1]:
            return cached[0]
        rank = (0, 2, 4, 3, 1, 5) if audience == GRAPH else (
            (2, 0, 1, 3, 4, 5) if audience == LEGACY else (0, 1, 2, 3, 4, 5))
        clients = [self.client_id] if self.client_id else [CLIENTS[i] for i in rank]
        last = CollectionError("token exchange failed")
        for client in clients:
            form = parse.urlencode({"grant_type": "refresh_token", "client_id": client,
                                    "refresh_token": self.refresh_token, "resource": audience})
            try:
                token = decode_json(self.http.send(
                    "POST", f"https://login.microsoftonline.com/{self.tenant}/oauth2/token",
                    {"Content-Type": "application/x-www-form-urlencoded"}, form.encode()))
                access = token.get("access_token")
                if not isinstance(access, str) or not access:
                    raise CollectionError("token exchange returned no access token")
                rotated = token.get("refresh_token")
                if isinstance(rotated, str) and rotated:
                    self.refresh_token = rotated
                try:
                    lifetime = min(2700, max(0, float(token.get("expires_in", 3600)) - 60))
                except (TypeError, ValueError):
                    lifetime = 0
                self.cache[audience] = (access, self.clock() + lifetime)
                return access
            except CollectionError as exc:
                last = exc
        raise CollectionError(f"authentication for {audience} failed ({last})", last.status)


def checked_url(url, origin):
    """Reject foreign pagination links before acquiring or attaching a token."""
    resolved = parse.urljoin(origin + "/", url)
    parts, base = parse.urlsplit(resolved), parse.urlsplit(origin)
    if (parts.scheme != "https" or parts.netloc.lower() != base.netloc.lower()
            or parts.username or parts.password or parts.fragment):
        raise CollectionError("refused an off-origin or invalid URL")
    return resolved


@dataclass
class Result:
    items: list = field(default_factory=list)
    complete: bool = True


class Api:
    def __init__(self, http, tokens):
        self.http, self.tokens = http, tokens
        self.failures = []
        self._report_lock = threading.Lock()

    def raw(self, url, audience, origin=None, headers=None):
        url = checked_url(url, origin or audience)
        token = self.tokens.get(audience)
        for force in (False, True):
            if force:
                refresh = getattr(self.tokens, "refresh_after_rejection", None)
                token = refresh(audience, token) if refresh else self.tokens.get(audience, True)
            auth = {"Authorization": "Bearer " + token,
                    "Accept": "application/json", **(headers or {})}
            try:
                return self.http.send("GET", url, auth)
            except CollectionError as exc:
                if exc.status != 401 or force:
                    raise
        raise AssertionError("unreachable")

    def failure(self, label, exc):
        with self._report_lock:
            self.failures.append({"collection": label, "error": str(exc)})
            print(f"[!] {label}: {exc}", file=sys.stderr, flush=True)

    def listing(self, url, audience, label, origin=None, headers=None):
        result, seen = Result(), set()
        origin = origin or audience
        try:
            while url:
                url = checked_url(url, origin)
                if url in seen:
                    raise CollectionError("pagination cycle detected")
                seen.add(url)
                page = decode_json(self.raw(url, audience, origin, headers))
                values = page.get("value")
                if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
                    raise CollectionError("invalid or missing collection value array")
                result.items.extend(values)
                next_url = page.get("@odata.nextLink", page.get("odata.nextLink", page.get("nextLink")))
                if next_url is not None and not isinstance(next_url, str):
                    raise CollectionError("invalid pagination link")
                url = parse.urljoin(url, next_url) if next_url else None
        except CollectionError as exc:
            result.complete = False
            self.failure(label, exc)
        return result


def write_json(path, document):
    # Stream the encoding: no BeaconDownload buffer or size limit.
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(document, handle, ensure_ascii=False, separators=(",", ":"))
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def coverage(requested, successful, parent_complete=True, unit="Scopes"):
    successful_set = set(successful)
    failed = [scope for scope in requested if scope not in successful_set]
    return {"complete": parent_complete and not failed,
            "parentEnumerationComplete": parent_complete,
            "requested" + unit: requested, "successful" + unit: successful,
            "failed" + unit: failed}



def parallel_results(function, jobs, workers, on_cancel=None):
    """Bound submitted jobs and yield in input order for reproducible snapshots."""
    if workers < 1:
        raise ValueError("workers must be positive")
    if workers == 1:
        for job in jobs:
            yield function(job)
        return
    iterator = iter(jobs)
    executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="bark")
    pending = deque()
    try:
        pending.extend(executor.submit(function, job) for job in islice(iterator, workers * 2))
        while pending:
            result = pending.popleft().result()
            yield result
            try:
                job = next(iterator)
            except StopIteration:
                continue
            pending.append(executor.submit(function, job))
    except BaseException:
        if on_cancel:
            on_cancel()
        for future in pending:
            future.cancel()
        raise
    finally:
        executor.shutdown(wait=True, cancel_futures=True)


class Collector:
    def __init__(self, api, tenant, output, workers=8):
        self.api, self.tenant, self.output = api, tenant.upper(), output
        self.tenant_name = ""
        self.inventory = {}
        self.files = []
        self.workers = workers

    def parallel(self, function, jobs):
        cancelled = getattr(self.api.http, "cancelled", None)
        return parallel_results(function, jobs, self.workers,
                                cancelled.set if cancelled is not None else None)

    def save(self, kind, items, complete=True, suffix="", collection=None):
        name = kind + suffix + ".json"
        document = {"data": [{"kind": kind, "data": item} for item in items],
                    "meta": {"type": "azure", "version": 5, "count": len(items),
                             "collection": collection or {"complete": complete}}}
        write_json(self.output / name, document)
        self.files.append(name)
        # Grouped wrappers represent parent objects, not the relationships found.
        child_key = {
            "AZGroupMember": "members", "AZGroupOwner": "owners",
            "AZDeviceOwner": "registeredOwners", "AZAppOwner": "owners",
            "AZServicePrincipalOwner": "owners", "AZRoleAssignment": "roleAssignments",
            "AZFederatedIdentityCredential": "fics",
        }.get(kind)
        count = sum(len(item.get(child_key, [])) for item in items) if child_key else len(items)
        unit = "relationships" if child_key and child_key != "fics" else "objects"
        partial = "" if document["meta"]["collection"].get("complete") else " (incomplete collection)"
        print(f"[+] {kind}{suffix}: Found {count} {unit}{partial}", flush=True)

    def normalize(self, item, kind):
        item = dict(item)
        if "objectId" in item:
            item["id"] = item.pop("objectId")
        for key in ("id", "appId", "tenantId", "deviceId"):
            # appRoleAssignment IDs are opaque, case-sensitive strings, not GUIDs.
            if key == "id" and kind == "AZAppRoleAssignment":
                continue
            if isinstance(item.get(key), str):
                item[key] = item[key].upper()
        item.update(tenantId=self.tenant, tenantName=self.tenant_name.upper())
        # Relationship consumers use @odata.type to distinguish users, groups and SPs.
        object_type = item.get("objectType")
        if object_type and "@odata.type" not in item:
            item["@odata.type"] = "#microsoft.graph." + object_type[0].lower() + object_type[1:]
        keys = ["appOwnerOrganizationId", "principalId", "resourceId",
                "onPremisesSecurityIdentifier"]
        if kind in {"AZTenant", "AZUser", "AZGroup", "AZDevice", "AZRole",
                    "AZApp", "AZServicePrincipal", "AZSubscription"}:
            keys.append("displayName")
        for key in keys:
            if isinstance(item.get(key), str):
                item[key] = item[key].upper()
        if kind == "AZTenant":
            item.update(id="/tenants/" + self.tenant, tenantType="AAD", collected=True)
            domains = item.get("verifiedDomains") or []
            item["domains"] = [domain["name"] for domain in domains if domain.get("name")]
            for domain in domains:
                if domain.get("isDefault"):
                    item["defaultDomain"] = domain.get("name", "")
                    break
            if "countryLetterCode" in item:
                item["countryCode"] = item["countryLetterCode"]
        elif kind == "AZServicePrincipal" and "publishedPermissionScopes" in item:
            item["oauth2PermissionScopes"] = item.pop("publishedPermissionScopes")
        elif kind == "AZDevice" and "extensionAttributes" in item:
            item["onPremisesExtensionAttributes"] = item.pop("extensionAttributes")
        return item

    def identity(self, legacy=False):
        audience = LEGACY if legacy else GRAPH
        suffix = "_legacy" if legacy else ""

        def endpoint(path, beta=False):
            if legacy:
                return f"/{self.tenant}/{path}?api-version=1.6&$top=999"
            return f"/{'beta' if beta else 'v1.0'}/{path}"

        specs = [("AZTenant", "tenantDetails" if legacy else "organization"),
                 ("AZUser", "users"), ("AZGroup", "groups"), ("AZDevice", "devices"),
                 ("AZRole", "directoryRoles" if legacy else "roleManagement/directory/roleDefinitions"),
                 ("AZApp", "applications"), ("AZServicePrincipal", "servicePrincipals")]
        def fetch_entity(spec):
            kind, path = spec
            url = endpoint(path, kind in {"AZUser", "AZGroup", "AZDevice", "AZApp", "AZServicePrincipal"})
            if not legacy:
                if kind == "AZUser":
                    url += "?$top=999&$select=" + USER_FIELDS
                elif kind not in {"AZTenant", "AZRole"}:
                    url += "?$count=true"
            result = self.api.listing(url, audience, kind + suffix,
                                      headers={"ConsistencyLevel": "eventual"} if not legacy else None)
            if kind == "AZUser" and not legacy:
                for fields in ("lastPasswordChangeDateTime", "signInActivity"):
                    page_size = 500 if fields == "signInActivity" else 999
                    extra = self.api.listing(f"/v1.0/users?$top={page_size}&$select=id," + fields,
                                             GRAPH, "AZUser_" + fields, headers={"ConsistencyLevel": "eventual"})
                    lookup = {v.get("id"): v for v in extra.items}
                    for user in result.items:
                        if fields in lookup.get(user.get("id"), {}):
                            user[fields] = lookup[user["id"]][fields]
            return kind, result

        snapshot = {}
        for kind, result in self.parallel(fetch_entity, specs):
            if kind == "AZTenant" and result.items:
                self.tenant_name = result.items[0].get("displayName", "")
            snapshot[kind] = result
            values = [self.normalize(v, kind) for v in result.items]
            if legacy and kind == "AZRole":
                for value in values:
                    value["id"] = str(value.get("roleTemplateId") or value["id"]).upper()
            self.save(kind, values, result.complete, suffix)
            self.inventory[kind + suffix] = result

        relationships = (
            ("AZGroup", "groups", "members", "AZGroupMember", "groupId", "members", "member"),
            ("AZGroup", "groups", "owners", "AZGroupOwner", "groupId", "owners", "owner"),
            ("AZDevice", "devices", "registeredOwners", "AZDeviceOwner", "deviceId", "registeredOwners", "registeredOwner"),
            ("AZApp", "applications", "owners", "AZAppOwner", "appId", "owners", "owner"),
            ("AZServicePrincipal", "servicePrincipals", "owners", "AZServicePrincipalOwner", "servicePrincipalId", "owners", "owner"),
        )
        if not legacy:
            relationships += (("AZApp", "applications", "federatedIdentityCredentials",
                               "AZFederatedIdentityCredential", "appId", "fics", "fic"),)
        complete = all(r.complete for r in snapshot.values())
        states = {kind: {"rows": [], "requested": [], "successful": [],
                         "parents_complete": snapshot[parent_kind].complete}
                  for parent_kind, _, _, kind, _, _, _ in relationships}

        def relationship_jobs():
            for parent_kind, collection, relation, kind, parent_key, array_key, child_key in relationships:
                state = states[kind]
                for parent in snapshot[parent_kind].items:
                    oid = parent.get("id") or parent.get("objectId")
                    parent_id = parent.get("appId") if parent_kind == "AZApp" else oid
                    if not oid or not parent_id:
                        state["parents_complete"] = False
                        self.api.failure(kind + suffix, CollectionError("parent has no object/client ID"))
                        continue
                    parent_id = str(parent_id).upper()
                    state["requested"].append(parent_id)
                    url = endpoint(f"{collection}/{parse.quote(oid, safe='')}/{relation}")
                    if not legacy:
                        url += "?$top=999"
                    yield kind, parent_id, oid, url, parent_key, array_key, child_key

        def fetch_relationship(job):
            kind, parent_id, oid, url, parent_key, array_key, child_key = job
            children = self.api.listing(url, audience, f"{kind}{suffix}/{oid}")
            return job, children

        for job, children in self.parallel(fetch_relationship, relationship_jobs()):
            kind, parent_id, _, _, parent_key, array_key, child_key = job
            state = states[kind]
            if children.complete:
                state["successful"].append(parent_id)
            state["rows"].append({parent_key: parent_id, "tenantId": self.tenant,
                                  array_key: [{parent_key: parent_id, child_key: self.normalize(child, kind)}
                                              for child in children.items]})
        for kind, state in states.items():
            meta = coverage(state["requested"], state["successful"], state["parents_complete"], "Parents")
            complete &= meta["complete"]
            self.save(kind, state["rows"], suffix=suffix, collection=meta)

        grouped = defaultdict(list)
        if legacy:
            role_results = []
            def fetch_role_members(role):
                oid = role.get("objectId") or role.get("id")
                members = self.api.listing(endpoint(f"directoryRoles/{oid}/members"), audience,
                                           f"AZRoleAssignment_legacy/{oid}")
                return role, oid, members

            for role, oid, members in self.parallel(fetch_role_members, snapshot["AZRole"].items):
                role_results.append(members.complete)
                for member in members.items:
                    grouped[role.get("roleTemplateId", oid)].append({
                        "principalId": str(member.get("objectId") or member.get("id")).upper(),
                        "roleDefinitionId": role.get("roleTemplateId", oid), "directoryScopeId": "/"})
            roles_complete = snapshot["AZRole"].complete and all(role_results)
        else:
            assignments = self.api.listing("/v1.0/roleManagement/directory/roleAssignments?$top=999",
                                           GRAPH, "AZRoleAssignment")
            roles_complete = assignments.complete
            for assignment in assignments.items:
                value = dict(assignment)
                value["principalId"] = str(value.get("principalId", "")).upper()
                grouped[value.get("roleDefinitionId", "")].append(value)
        self.save("AZRoleAssignment", [{"roleDefinitionId": str(role).upper(), "tenantId": self.tenant,
                                        "roleAssignments": values} for role, values in grouped.items()],
                  roles_complete, suffix)
        app_roles, requested, successful = [], [], []
        resource_lookup = {str(s.get("objectId") or s.get("id")).lower(): s
                           for s in snapshot["AZServicePrincipal"].items}
        def fetch_app_roles(sp):
            oid = sp.get("id") or sp.get("objectId")
            relation = "appRoleAssignments" if legacy else "appRoleAssignedTo"
            url = endpoint(f"servicePrincipals/{oid}/{relation}")
            if not legacy:
                url += "?$top=999"
            assignments = self.api.listing(url, audience, f"AZAppRoleAssignment{suffix}/{oid}")
            return sp, oid, assignments

        for sp, oid, assignments in self.parallel(fetch_app_roles, snapshot["AZServicePrincipal"].items):
            requested.append(oid)
            if assignments.complete:
                successful.append(oid)
            for raw in assignments.items:
                value = self.normalize(raw, "AZAppRoleAssignment")
                resource = resource_lookup.get(str(raw.get("resourceId")).lower(), {}) if legacy else sp
                value["appId"] = str(resource.get("appId", "")).upper()
                if legacy:
                    value["appRoleId"] = raw.get("id", "")
                app_roles.append(value)
        meta = coverage(requested, successful, snapshot["AZServicePrincipal"].complete, "Parents")
        self.save("AZAppRoleAssignment", app_roles, suffix=suffix, collection=meta)
        if not legacy:
            self.entra_pim()
        return complete and roles_complete and meta["complete"]

    def entra_pim(self):
        # Separate raw kinds avoid colliding with ARM PIM files and native models.
        eligibility = self.api.listing(
            "/v1.0/roleManagement/directory/roleEligibilityScheduleInstances",
            GRAPH, "AZEntraRoleEligibilityScheduleInstance")
        self.save("AZEntraRoleEligibilityScheduleInstance",
                  [self.normalize(row, "AZEntraRoleEligibilityScheduleInstance")
                   for row in eligibility.items], eligibility.complete)
        assignments = self.api.listing(
            "/v1.0/policies/roleManagementPolicyAssignments?"
            "$filter=scopeId%20eq%20%27/%27%20and%20scopeType%20eq%20%27Directory%27"
            "&$expand=policy($expand=rules)", GRAPH, "AZEntraRoleManagementPolicyAssignment")

        def complete_policy(raw):
            value = dict(raw)
            policy = dict(raw["policy"]) if isinstance(raw.get("policy"), dict) else {}
            complete = True
            if not isinstance(policy.get("rules"), list) or policy.get("rules@odata.nextLink") or policy.get("@odata.nextLink"):
                policy_id = value.get("policyId")
                if not isinstance(policy_id, str) or not policy_id:
                    self.api.failure("EntraPIMPolicyRules", CollectionError("missing policy ID"))
                    complete = False
                else:
                    rules = self.api.listing(
                        "/v1.0/policies/roleManagementPolicies/" + parse.quote(policy_id, safe="")
                        + "/rules", GRAPH, "EntraPIMPolicyRules/" + policy_id)
                    policy["rules"] = rules.items
                    complete = rules.complete
                    if complete:
                        policy.pop("rules@odata.nextLink", None)
                        policy.pop("@odata.nextLink", None)
                    else:
                        policy["rules@odata.nextLink"] = "incomplete"
            value["policy"] = policy
            return self.normalize(value, "AZEntraRoleManagementPolicyAssignment"), complete

        rows, complete = [], assignments.complete
        for value, success in self.parallel(complete_policy, assignments.items):
            rows.append(value)
            complete &= success
        self.save("AZEntraRoleManagementPolicyAssignment", rows, complete)

    def arm(self):
        root_jobs = (
            ("AZSubscription", "/subscriptions?api-version=2020-01-01"),
            ("AZManagementGroup", "/providers/Microsoft.Management/managementGroups?api-version=2020-05-01"),
        )

        def fetch_root(job):
            kind, url = job
            return self.api.listing(url, ARM, kind)

        subscriptions, groups = self.parallel(fetch_root, root_jobs)
        descendants = []
        descendants_complete = groups.complete
        known = {str(s.get("subscriptionId", "")).lower() for s in subscriptions.items}
        group_ids = {str(g.get("id", "")).lower() for g in groups.items}
        missing_subscriptions = {}

        def fetch_descendants(group):
            return self.api.listing(group.get("id", "") + "/descendants?api-version=2020-05-01",
                                    ARM, "AZManagementGroupDescendant/" + group.get("name", ""))

        for result in self.parallel(fetch_descendants, list(groups.items)):
            descendants_complete &= result.complete
            for child in result.items:
                descendants.append(self.normalize(child, "AZManagementGroupDescendant"))
                child_type = str(child.get("type", "")).lower()
                if "subscriptions" in child_type:
                    sid = child.get("name") or child.get("id", "").rsplit("/", 1)[-1]
                    if sid.lower() not in known:
                        missing_subscriptions[sid.lower()] = sid
                elif "managementgroups" in child_type and child.get("id", "").lower() not in group_ids:
                    groups.items.append(child)
                    group_ids.add(child["id"].lower())

        def fetch_subscription(sid):
            try:
                return decode_json(self.api.raw(f"/subscriptions/{sid}?api-version=2020-01-01", ARM))
            except CollectionError as exc:
                self.api.failure("AZSubscription/" + sid, exc)
                return None

        for detail in self.parallel(fetch_subscription, missing_subscriptions.values()):
            if detail is None:
                descendants_complete = False
            else:
                subscriptions.items.append(detail)
        self.save("AZManagementGroup", [self.normalize(x, "AZManagementGroup") for x in groups.items], groups.complete)
        self.save("AZManagementGroupDescendant", descendants, descendants_complete)
        sub_rows = []
        for sub in subscriptions.items:
            value = self.normalize(sub, "AZSubscription")
            value["subscriptionId"] = str(sub.get("id") or "/subscriptions/" + sub["subscriptionId"]).upper()
            sub_rows.append(value)
        self.save("AZSubscription", sub_rows, subscriptions.complete)
        scope_complete = subscriptions.complete and groups.complete and descendants_complete
        sub_scopes = [s["subscriptionId"] for s in sub_rows]
        scopes = list(dict.fromkeys(sub_scopes + [g["id"] for g in groups.items]))
        resources = []
        resources_complete = subscriptions.complete
        inventory = {kind: {"rows": [], "successful": []} for kind, _, _ in ARM_COLLECTIONS}

        def fetch_resource(job):
            kind, relative, version, scope = job
            result = self.api.listing(f"{scope}/{relative}?api-version={version}", ARM,
                                      kind + "/" + scope.rsplit("/", 1)[-1])
            if kind == "AZKeyVault":
                for index, vault in enumerate(result.items):
                    props = vault["properties"] if isinstance(vault.get("properties"), dict) else {}
                    if props.get("enableRbacAuthorization") is True or isinstance(props.get("accessPolicies"), list):
                        continue
                    identifier = vault.get("id")
                    if not isinstance(identifier, str) or not identifier.startswith("/subscriptions/"):
                        result.complete = False
                        self.api.failure("KeyVaultDetails", CollectionError("missing vault ARM ID"))
                        continue
                    try:
                        detail = decode_json(self.api.raw(identifier + "?api-version=2021-10-01", ARM))
                        if not isinstance(detail, dict) or str(detail.get("id", "")).lower() != identifier.lower():
                            raise CollectionError("invalid vault detail response")
                        detail_props = detail["properties"] if isinstance(detail.get("properties"), dict) else {}
                        if detail_props.get("enableRbacAuthorization") is not True and not isinstance(detail_props.get("accessPolicies"), list):
                            raise CollectionError("vault response has no access policies")
                        result.items[index] = detail
                    except CollectionError as exc:
                        result.complete = False
                        self.api.failure("KeyVaultDetails/" + identifier, exc)
            return kind, scope, result

        jobs = ((kind, relative, version, scope)
                for kind, relative, version in ARM_COLLECTIONS for scope in sub_scopes)
        for kind, scope, result in self.parallel(fetch_resource, jobs):
            state = inventory[kind]
            if result.complete:
                state["successful"].append(scope)
            for raw in result.items:
                value = self.normalize(raw, kind)
                value["subscriptionId"] = scope
                match = re.match(r"(/subscriptions/[^/]+/resourceGroups/[^/]+)", raw.get("id", ""), re.I)
                if match:
                    value["resourceGroup" if kind == "AZKeyVault" else "resourceGroupId"] = match[1].upper()
                if kind == "AZVM":
                    value.setdefault("plan", {})
                    value.setdefault("extendedLocation", {})
                state["rows"].append(value)
        for kind, state in inventory.items():
            rows = state["rows"]
            meta = coverage(sub_scopes, state["successful"], subscriptions.complete)
            if kind == "AZWebApp":
                self.save("AZFunctionApp", [r for r in rows if "functionapp" in str(r.get("kind", "")).lower()], collection=meta)
                self.save(kind, [r for r in rows if "functionapp" not in str(r.get("kind", "")).lower()], collection=meta)
            else:
                self.save(kind, rows, collection=meta)
            if kind == "AZResource":
                resources, resources_complete = rows, meta["complete"]
            if kind in {"AZStorageAccount", "AZKeyVault"}:
                self.inventory[kind] = Result(rows, meta["complete"])

        assignment_scopes = list(dict.fromkeys(scopes + [r["id"] for r in resources]))
        assignments, successful = [], []

        def fetch_assignments(scope):
            url = scope + "/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01"
            if "/managementgroups/" in scope.lower():
                url += "&$filter=atScope()"
            return scope, self.api.listing(url, ARM, "ARMRoleAssignment/" + scope)

        for scope, result in self.parallel(fetch_assignments, assignment_scopes):
            if result.complete:
                successful.append(scope)
            assignments.extend({"Unknown": row, "id": scope} for row in result.items)
        write_json(self.output / "AZUnknown.json", {"kind": "AZUnknown", "data": assignments,
                   "meta": {"type": "azure", "version": 5, "count": len(assignments),
                            "collection": coverage(assignment_scopes, successful, scope_complete and resources_complete)}})
        self.files.append("AZUnknown.json")
        extras = {kind: {"rows": [], "successful": []} for kind, _, _ in EXTRAS}

        def fetch_extra(job):
            kind, relative, version, scope = job
            result = self.api.listing(f"{scope}/providers/Microsoft.Authorization/{relative}?api-version={version}",
                                      ARM, kind + "/" + scope)
            return kind, scope, result

        jobs = ((kind, relative, version, scope)
                for kind, relative, version in EXTRAS for scope in scopes)
        for kind, scope, result in self.parallel(fetch_extra, jobs):
            state = extras[kind]
            if result.complete:
                state["successful"].append(scope)
            state["rows"].extend(self.normalize(r, kind) for r in result.items)
        for kind, state in extras.items():
            self.save(kind, state["rows"], collection=coverage(scopes, state["successful"], scope_complete))


    def conditional_access(self):
        result = self.api.listing(f"/{self.tenant}/policies?api-version=1.61-internal", LEGACY, "ConditionalAccessPolicies")
        write_json(self.output / "ConditionalAccessPolicies.json", {"policies": result.items,
                   "collection": {"complete": result.complete}})
        nodes = {}
        for policy in result.items:
            if policy.get("policyType") != 18:
                continue
            try:
                detail = json.loads(policy["policyDetail"][0])
                if not isinstance(detail, dict):
                    raise ValueError()
            except (KeyError, IndexError, TypeError, ValueError):
                self.api.failure("ConditionalAccessPolicy", CollectionError("invalid policyDetail"))
                continue
            if detail.get("State", "Enabled") != "Enabled":
                continue
            controls = detail.get("Controls") or []
            control_types = {value.lower() for control in controls for value in control.get("Control", [])}
            for control in controls:
                strengths = (control.get("AuthStrengthIds") or []) + [control.get("AuthStrengthId", "")]
                if any(s in {f"00000000-0000-0000-0000-00000000000{i}" for i in (2, 3, 4)} for s in strengths):
                    control_types.add("mfa")
            if not control_types.intersection({"mfa", "block"}):
                continue
            conditions = detail.get("Conditions") or {}
            users = conditions.get("Users") or {}
            excluded = users.get("Exclude") or []
            annotation = json.dumps({"policy": policy.get("displayName", "UnnamedPolicy"),
                                     "controls": sorted(control_types), "conditions": conditions}, ensure_ascii=False)

            def add(oid, kind, reason):
                if not isinstance(oid, str):
                    return
                try:
                    uuid.UUID(oid)
                except ValueError:
                    return
                node = nodes.setdefault(oid.upper(), {"id": oid.upper(), "kinds": [kind], "properties": {}})
                properties = node["properties"]
                properties[f"MFA{len(properties) + 1}"] = reason + ": " + annotation

            for entry in excluded:
                for key, kind in (("Users", "AZUser"), ("Groups", "AZGroup")):
                    for oid in entry.get(key, []):
                        add(oid, kind, "Excluded principal")
            conditional_exclusions = any((conditions.get(k) or {}).get("Exclude") for k in
                                         ("Applications", "Platforms", "Locations", "Devices"))
            if conditional_exclusions:
                excluded_users = {v.upper() for e in excluded for v in e.get("Users", [])}
                excluded_groups = {v.upper() for e in excluded for v in e.get("Groups", [])}
                for entry in users.get("Include", []):
                    for oid in entry.get("Users", []):
                        if oid.lower() == "all":
                            # Merge both snapshots; a partial MS Graph snapshot must not hide legacy users.
                            candidates = {}
                            for key in ("AZUser", "AZUser_legacy"):
                                for candidate in self.inventory.get(key, Result()).items:
                                    uid = candidate.get("id") or candidate.get("objectId", "")
                                    candidates[uid.upper()] = candidate
                            for uid in candidates:
                                if uid not in excluded_users:
                                    add(uid, "AZUser", "Conditional exclusion applies to included scope")
                        elif oid.upper() not in excluded_users:
                            add(oid, "AZUser", "Conditional exclusion applies to included scope")
                    for oid in entry.get("Groups", []):
                        if oid.upper() not in excluded_groups:
                            add(oid, "AZGroup", "Conditional exclusion applies to included scope")
        write_json(self.output / "AZConditionalAccessGraph.json", conditional_access_graph(list(nodes.values())))
        self.files.extend(["ConditionalAccessPolicies.json", "AZConditionalAccessGraph.json"])

    def probes(self):
        hosts = set()
        for kind, result in self.inventory.items():
            if kind == "AZStorageAccount":
                for item in result.items:
                    name = item.get("name", "")
                    if re.fullmatch(r"[a-z0-9]{3,24}", name):
                        hosts.add(name + ".blob.core.windows.net")
            if kind.startswith(("AZApp", "AZServicePrincipal")) or kind == "AZKeyVault":
                for item in result.items:
                    for host in re.findall(r"https://([a-zA-Z0-9-]+\.(?:blob\.core\.windows\.net|vault\.azure\.net))(?=[/\"\s]|$)", json.dumps(item)):
                        hosts.add(host.lower())
        def probe_host(host):
            origin = "https://" + host
            if host.endswith(".vault.azure.net"):
                result = self.api.listing(origin + "/secrets?api-version=7.3", VAULT, "KeyVaultProbe/" + host, origin)
                return {"host": host, "kind": "secretMetadata", "complete": result.complete, "items": result.items}
            else:
                containers, marker, seen, complete = [], "", set(), True
                try:
                    while True:
                        url = origin + "/?" + parse.urlencode({"comp": "list", "marker": marker})
                        body = self.api.raw(url, STORAGE, origin, {"x-ms-version": "2021-08-06", "Accept": "application/xml"})
                        try:
                            root = ET.fromstring(body)
                        except ET.ParseError:
                            raise CollectionError("invalid Storage XML response") from None
                        if root.tag != "EnumerationResults":
                            raise CollectionError("invalid Storage list response")
                        containers.extend(e.text for e in root.findall("./Containers/Container/Name") if e.text)
                        marker = root.findtext("NextMarker", "")
                        if not marker:
                            break
                        if marker in seen:
                            raise CollectionError("Storage pagination cycle detected")
                        seen.add(marker)
                except CollectionError as exc:
                    complete = False
                    self.api.failure("StorageProbe/" + host, exc)
                return {"host": host, "kind": "containers", "complete": complete, "items": containers}

        results = list(self.parallel(probe_host, sorted(hosts)))
        write_json(self.output / "DataPlaneProbes.json", {"probes": results})
        self.files.append("DataPlaneProbes.json")



def tenant_identifier(value):
    """Accept a tenant GUID or DNS domain, never a URL or multi-tenant authority."""
    value = value.strip()
    try:
        return str(uuid.UUID(value))
    except ValueError:
        domain = value.rstrip(".").lower()
        labels = domain.split(".")
        if (len(domain) <= 253 and len(labels) >= 2 and
                all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
                    for label in labels) and
                re.search(r"[a-z]", labels[-1])):
            return domain
        raise argparse.ArgumentTypeError("expected a tenant GUID or verified tenant domain") from None


def resolve_tenant_id(identifier, http):
    """Resolve a domain through public metadata before building Azure object IDs."""
    identifier = tenant_identifier(identifier)
    try:
        return str(uuid.UUID(identifier))
    except ValueError:
        pass
    url = ("https://login.microsoftonline.com/" + parse.quote(identifier, safe="")
           + "/v2.0/.well-known/openid-configuration")
    try:
        metadata = decode_json(http.send("GET", url, {"Accept": "application/json"}))
    except CollectionError as exc:
        raise CollectionError(f"tenant discovery failed ({exc})", exc.status) from None
    issuer = metadata.get("issuer")
    match = re.fullmatch(r"https://login\.microsoftonline\.com/([0-9a-fA-F-]{36})/v2\.0/?",
                         issuer if isinstance(issuer, str) else "")
    if match:
        try:
            return str(uuid.UUID(match[1]))
        except ValueError:
            pass
    raise CollectionError("tenant discovery did not return a public-cloud tenant GUID")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tenant_id", type=tenant_identifier, help="tenant GUID or verified domain (public Azure cloud)")
    parser.add_argument("--output", type=Path, default=Path("bark-results"), help="parent directory for a new collection directory")
    parser.add_argument("--refresh-token-file", type=Path, help="read refresh token from this UTF-8 file; otherwise use BARK_REFRESH_TOKEN or a hidden prompt")
    parser.add_argument("--client-id", type=lambda value: str(uuid.UUID(value)), help="use only this OAuth client instead of BARK's audience-specific ranking")
    parser.add_argument("--workers", type=int, default=8,
                        help="maximum concurrent collection jobs (1-32; default: 8; 1 is sequential)")
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--retries", type=int, default=4)
    parser.add_argument("--no-legacy-fallback", action="store_true")
    parser.add_argument("--no-probes", action="store_true")
    parser.add_argument("--no-bundle", action="store_true", help="collect JSON only; skip the local BloodHound converter")
    args = parser.parse_args(argv)
    if not 1 <= args.workers <= 32:
        parser.error("workers must be between 1 and 32")
    if args.timeout < 1 or not 0 <= args.retries <= 10:
        parser.error("timeout must be positive and retries must be between 0 and 10")
    api = None
    output = None
    status = 1
    try:
        http = Http(args.timeout, args.retries)
        tenant = resolve_tenant_id(args.tenant_id, http)
        secret = (args.refresh_token_file.read_text(encoding="utf-8-sig").strip() if args.refresh_token_file
                  else os.environ.get("BARK_REFRESH_TOKEN") or getpass.getpass("Refresh token: ").strip())
        if not secret:
            parser.error("refresh token is empty")
        output = args.output.expanduser().resolve() / ("BARK_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f"))
        output.mkdir(parents=True, exist_ok=False, mode=0o700)
        api = Api(http, Tokens(tenant, secret, http, args.client_id))
        collector = Collector(api, tenant, output, workers=args.workers)
        identity_complete = collector.identity()
        if not identity_complete and not args.no_legacy_fallback:
            collector.identity(legacy=True)
        collector.conditional_access()
        collector.arm()
        if not args.no_probes:
            collector.probes()
        bundle_status = None
        if not args.no_bundle:
            import bark_role_graph
            # Collection workers have finished before redirecting process-wide stdout.
            with (output / "bundle_conversion.log").open("w", encoding="utf-8") as log:
                with redirect_stdout(log):
                    bundle_status = bark_role_graph.main([str(output)])
            collector.files.append("bundle_conversion.log")
        status = 0 if not api.failures and bundle_status in (None, 0) else 2
        write_json(output / "collection_manifest.json", {
            "tenantId": tenant.upper(), "tenantInput": args.tenant_id, "finishedUtc": datetime.now(timezone.utc).isoformat(),
            "complete": status == 0, "workers": args.workers, "failures": api.failures, "files": collector.files,
            "skipped": [name for name, skip in (("legacyFallback", args.no_legacy_fallback),
                       ("dataPlaneProbes", args.no_probes), ("bloodhoundBundle", args.no_bundle)) if skip],
            "bundleExitCode": bundle_status})
        print(f"[*] {'Completed' if status == 0 else 'Completed with incomplete collections'}: {output}", flush=True)
    except KeyboardInterrupt:
        print("[!] Interrupted; completed JSON files have been retained.", file=sys.stderr)
        status = 130
    except CollectionError as exc:
        print(f"[!] {exc}", file=sys.stderr)
        status = 1
    except (OSError, ImportError, EOFError) as exc:
        print(f"[!] Collection stopped ({type(exc).__name__}); completed JSON files have been retained.", file=sys.stderr)
        status = 1
    finally:
        if output is not None and output.is_dir() and not (output / "collection_manifest.json").exists():
            write_json(output / "collection_manifest.json", {"complete": False, "interrupted": True,
                       "failures": api.failures if api else [], "exitCode": status})
    return status


if __name__ == "__main__":
    sys.exit(main())
