#!/usr/bin/env python3
"""
bark_decrypt.py — Extract BARK BOF password-protected ZIP files.

The output of `bark_zip_collect` is a standard ZipCrypto-encrypted
.zip file. Any tool can open it with the password:

    unzip -P <password>    file.zip
    7z   x  -p<password>   file.zip
    Windows Explorer       (right-click -> Extract All, prompts for pwd)

This script is a convenience wrapper for batch extraction and optional
merging of multiple BloodHound JSON envelopes.

Usage:
    python3 bark_decrypt.py <file.zip> <password> [output_dir]
    python3 bark_decrypt.py --batch <password> [--dir DIR]
    python3 bark_decrypt.py --batch <password> [--dir DIR] --merge out.json

No external dependencies — uses Python's built-in `zipfile` module.

Author : BARK BOF project
License: GPLv3
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys
import zipfile


def extract_zip(zip_path: str, password: str, out_dir: str) -> list[str]:
    """Extract all entries from a ZipCrypto ZIP into out_dir.
    Returns a list of extracted file paths."""
    os.makedirs(out_dir, exist_ok=True)
    extracted: list[str] = []
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            data = zf.read(name, pwd=password.encode("utf-8"))
            safe_name = os.path.basename(name) or "extracted.bin"
            out_path = os.path.join(out_dir, safe_name)
            with open(out_path, "wb") as f:
                f.write(data)
            extracted.append(out_path)
    return extracted


def cmd_single(opts: argparse.Namespace) -> int:
    if len(opts.args) < 2:
        print(
            "Error: expected at least 2 arguments: <file.zip> <password>",
            file=sys.stderr,
        )
        return 1

    zip_path = opts.args[0]
    password = opts.args[1]
    out_dir = opts.args[2] if len(opts.args) >= 3 else "."

    if not os.path.isfile(zip_path):
        print(f"ERROR: File not found: {zip_path}", file=sys.stderr)
        return 1

    try:
        extracted = extract_zip(zip_path, password, out_dir)
    except RuntimeError as e:
        # zipfile raises RuntimeError("Bad password ...") on wrong password
        print(f"[-] {zip_path}: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[-] {zip_path}: {e}", file=sys.stderr)
        return 1

    for p in extracted:
        print(f"[+] extracted {p}  ({os.path.getsize(p)} bytes)")
    return 0


def cmd_batch(opts: argparse.Namespace) -> int:
    if len(opts.args) < 1:
        print(
            "Error: --batch requires a password: bark_decrypt --batch <password>",
            file=sys.stderr,
        )
        return 1

    password = opts.args[0]
    target_dir = opts.dir

    files = sorted(glob.glob(os.path.join(target_dir, "*.zip")))
    if not files:
        print(f"No *.zip files found in {os.path.abspath(target_dir)}")
        return 0

    print(f"[*] Found {len(files)} ZIP file(s) in {os.path.abspath(target_dir)}")

    ok = fail = 0
    merged_data: list = []

    for fpath in files:
        try:
            extracted = extract_zip(fpath, password, opts.dir)
            ok += 1
            for p in extracted:
                print(
                    f"  [+] {os.path.basename(fpath)} -> {os.path.basename(p)}"
                    f"  ({os.path.getsize(p)} bytes)"
                )
                if opts.merge:
                    try:
                        with open(p, "r", encoding="utf-8") as jf:
                            obj = json.load(jf)
                        if isinstance(obj, dict) and "data" in obj:
                            merged_data.extend(obj["data"])
                    except Exception as e:
                        print(f"      (merge skipped: {e})", file=sys.stderr)
        except Exception as e:
            fail += 1
            print(f"  [-] {os.path.basename(fpath)}: {e}", file=sys.stderr)

    if opts.merge and merged_data:
        envelope = {
            "data": merged_data,
            "meta": {"type": "azure", "count": len(merged_data)},
        }
        with open(opts.merge, "w", encoding="utf-8") as f:
            json.dump(envelope, f)
        print(f"\n[+] Merged {len(merged_data)} BH items into {opts.merge}")

    print(f"\n[*] Done. {ok} succeeded, {fail} failed.")
    return 0 if fail == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="bark_decrypt",
        description=(
            "Extract BARK BOF password-protected ZIP files.\n\n"
            "The output of bark_zip_collect is a standard ZipCrypto .zip.\n"
            "This script is a convenience wrapper; you can also use:\n"
            "  unzip -P <password> file.zip\n"
            "  7z x -p<password> file.zip"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  %(prog)s bark_collect_azurerm_20250520_123456.zip MyPassword\n"
            "  %(prog)s --batch MyPassword\n"
            "  %(prog)s --batch MyPassword --dir ./loot\n"
            "  %(prog)s --batch MyPassword --merge bloodhound.json\n"
        ),
    )
    parser.add_argument(
        "--batch",
        action="store_true",
        help="Extract every *.zip in the target directory.",
    )
    parser.add_argument(
        "--dir",
        default=".",
        help="Directory to scan/extract into (default: current directory).",
    )
    parser.add_argument(
        "--merge",
        metavar="OUTPUT.json",
        help=(
            "After batch extraction, concatenate every BH envelope's "
            "`data` array into a single JSON file."
        ),
    )
    parser.add_argument(
        "args",
        nargs="*",
        metavar="ARG",
        help=(
            "Single-file mode: <file.zip> <password> [output_dir]\n"
            "Batch mode:       <password>"
        ),
    )

    opts = parser.parse_args()
    return cmd_batch(opts) if opts.batch else cmd_single(opts)


if __name__ == "__main__":
    sys.exit(main())
