# bof-bark

[English](README.md) | [日本語](README.ja.md)

BARK は Entra ID と Azure を操作する Cobalt Strike BOF と、BloodHound 用データを生成するローカル Python コレクターを提供します。BOF は [BARKKAI](https://github.com/whal3b0n3/BARKKAI) を基にしています。

この README はオペレーター向けの実行手順です。設定、収集動作、コマンド一覧、トラブルシューティングは [日本語 wiki](wiki/ja/Home.md) を参照してください。

## 収集方法を選ぶ

| 実行場所 | エントリーポイント | 出力 |
| --- | --- | --- |
| オペレーター端末、Python 3.10 以降 | `python3 bark_all_info.py <tenant-guid-or-domain>` | ローカル JSON と BloodHound アップロード用バンドル |
| Cobalt Strike Beacon | `bark_get_all_info_bh_rt <tenantId> <refreshToken>` | C2 経由の JSON ダウンロード。バンドルはローカルで生成 |

どちらも refresh token を使い、Entra オブジェクトと関連、アプリケーションロールの割り当て、条件付きアクセス、Azure リソースと RBAC、Storage / Key Vault のメタデータを収集します。取得できる範囲はトークンの権限に依存します。[認証](wiki/ja/Authentication.md)と[収集範囲](wiki/ja/Python-Collector.md#collection-coverage)も確認してください。

```mermaid
flowchart TD
    A["テナント ID と refresh token"] --> B{"実行場所"}
    B -->|"オペレーター端末"| C["Python コレクター"]
    B -->|"Beacon"| D["CNA をロードし all-info を実行"]
    C --> E["JSON とアップロード用バンドル"]
    D --> F["収集結果をダウンロード"]
    F --> G["ローカルで bark_role_graph.py を実行"]
    G --> E
    E --> H["収集結果とアップロード手順を確認"]
    H --> I["拡張定義を登録 → ネイティブ JSON → OpenGraph"]
```

## Python でトークンを取得する

resource には URL だけを指定します。`/.default` は内部で付加されるため入力不要です。

```bash
python3 bark_tokens.py up --tenant <tenant-guid> \
  --username operator@example.com --resource https://graph.microsoft.com \
  --output ./tokens.json --refresh-token-output ./refresh-token.txt
```

パスワードは非表示のプロンプトで入力します。出力された refresh token ファイルをコレクターに渡せます。ROPC は対話認証なしのパスワード認証をテナントが許可している場合に使用できます。

既存の refresh token を別リソースの access token に交換する例です。

```bash
python3 bark_tokens.py rt --tenant <tenant-guid> \
  --resource https://management.azure.com --refresh-token-file ./refresh-token.txt
```

クライアント資格情報、PRT cookie、Portal 委任、出力形式、Beacon コマンドとの対応は [Python トークンコマンド](wiki/ja/Python-Tokens.md)を参照してください。

## Python で収集する

リポジトリのルートで Python 3.10 以降を使用します。標準ライブラリのみで動作しますが、バンドル生成に使う隣接スクリプトと `data/` も必要です。

```bash
python3 bark_all_info.py <tenant-guid-or-domain> --output ./bark-results
```

標準出力には、保存したコレクションごとに `[+] AZUser: Found 123 objects` のような件数と、最終状態・出力先を表示します。所有者・メンバーは関係の合計件数を表示し、個々のオブジェクトの詳細は表示しません。部分収集には `(incomplete collection)` を付けます。エラーは標準エラー出力に、変換の詳細は出力先の `bundle_conversion.log` に記録します。

並列数の既定値は 8 です。`--workers 16` で増やすか、`--workers 1` で逐次実行にできます。指定範囲は 1～32 です。

テナントには GUID または `megabigtech.com` のようなドメインを指定します。refresh token は非表示プロンプトに入力するか、ファイルから渡します。

```bash
python3 bark_all_info.py <tenant-guid-or-domain> \
  --refresh-token-file /path/to/token.txt \
  --output ./bark-results
```

実行ごとに `bark-results/BARK_<UTC timestamp>/` が作成され、JSON、`collection_manifest.json`、`BARK_BloodHound_Bundle_<timestamp>/` が保存されます。グラフを解釈する前に manifest の失敗・スキップを確認してください。有効な引数での終了コード `2` は部分収集または変換失敗を示します。

次は[BloodHound への取り込み](#bloodhound-import)です。全オプション、権限の扱い、Beacon 版との違いは [Python コレクター](wiki/ja/Python-Collector.md)を参照してください。

## Beacon で収集する

1. `bark.cna` と `bofs/` を同じ場所に配置します。再ビルドは[インストール](wiki/ja/Installation.md)を参照してください。
2. **Cobalt Strike → Script Manager → Load** から `bark.cna` をロードします。
3. Beacon コンソールで実行します。

```text
beacon> bark_download_mode on
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken>
```

download mode は既定で ON です。完了した JSON ダウンロードを同じローカルディレクトリに集め、バンドルを生成します。

```bash
python3 bark_role_graph.py /path/to/bark/downloads \
  --bundle-output ./bloodhound-upload
```

ヘルパーは全パートが揃った JSON を再結合します。すべてのダウンロードが完了してから実行してください。

パスワード付き ZIP が必要な場合は、収集前にステージング用の設定に切り替えます。

```text
beacon> bark_download_mode off
beacon> bark_get_all_info_bh_rt <tenantId> <refreshToken> <zip-password>
```

[ダウンロードとアーカイブ](wiki/ja/Downloads-and-Archives.md)に従って ZIP を再結合・展開し、展開先で `bark_role_graph.py` を実行します。範囲指定、legacy fallback、中断時の復旧は [Beacon 収集ワークフロー](wiki/ja/Collection-Workflow.md)を参照してください。コマンドのヘルプは `bark_help` または `help bark_<name>` で確認できます。

<a id="bloodhound-import"></a>
## BloodHound への取り込み

プロパティによる OpenGraph エンドポイント照合に対応した BloodHound を使用してください。BloodHound 9.0 はこの形式に対応しています。[ネイティブノードの保護と移行](wiki/ja/OpenGraph-Node-Preservation.md)に詳細があります。

Python またはオフライン変換で作成したバンドルを使用します。フォルダー名の数字が作業順を表します。

```text
00-install-schema/    OpenGraph 拡張定義を登録
01-upload-native/     単独でアップロードし Complete を待つ
02-upload-opengraph/  別の新規ジョブでアップロード
do-not-upload/        確認用。アップロードしない
```

1. `UPLOAD_INSTRUCTIONS.txt` と `BARK_UPLOAD_MANIFEST.json` を確認します。
2. `00-install-schema/BARK_OpenGraph_Extension.json` を OpenGraph 拡張として登録します。
3. Python でアップロードします。ネイティブ取り込みの成功後に OpenGraph の別ジョブを開始します。

```bash
python3 bark_upload.py ./bloodhound-upload --dry-run
python3 bark_upload.py ./bloodhound-upload --username <bloodhound-user>
```

パスワードはプロンプトで入力します。別ホストには `--url https://bloodhound.example` を指定します。使用するのは **BloodHound の認証情報**です。Entra トークンとは異なります。

手動の場合は **File Ingest** で `01-upload-native/azurehound_bark.json` だけを送信し、ジョブが **Complete** になるまで待ちます。その後、**新しいジョブ**で `02-upload-opengraph/` の JSON を送信します。両フェーズを同じジョブや ZIP に混在させないでください。ジョブ内のファイル順序は依存関係の順序を保証しません。

アップロード用フォルダーのデータだけを使用し、`do-not-upload/` は確認用として残します。カスタムアプリケーションロールは OpenGraph の `BARK_AssignedAppRole` 関係で表現します。CAP の観測結果はユーザー／グループの `cap_policies` プロパティに入ります。CAP ファイルは観測結果とネイティブ ID・種類だけを含むため、必ずネイティブデータの後に取り込んでください。

PIM の適格性・承認者、Key Vault アクセスポリシー、マネージド ID 参照の修正はネイティブアップロードに含まれます。除外されたデータは BARK_UPLOAD_MANIFEST.json の nativeEdgeConversion で確認できます。古い結果に PIM ルールや ID 対応がない場合は更新後のコレクターで再収集してください。[実装の詳細と検証済み範囲](wiki/ja/Azure-Native-Edges.md)。

### 各 JSON の役割

ファイル名の時刻部分は実行ごとに変わります。Python 版と BOF 版の役割は同じです。

| フォルダー / JSON | 用途 | 操作 |
| --- | --- | --- |
| `00-install-schema/BARK_OpenGraph_Extension.json` | BARK のノード・関係の種類、表示、経路探索の可否を定義 | **OpenGraph Management** で登録 |
| `01-upload-native/azurehound_bark.json` | Azure のユーザー、グループ、アプリ、サービスプリンシパル、リソース、対応する関係を統合 | **File Ingest** で単独送信し **Complete** を待つ |
| `02-upload-opengraph/AZAppRoleGraph_*.json` | プリンシパル → アプリロール → リソース側サービスプリンシパルの割り当て | 第2ジョブで送信 |
| `02-upload-opengraph/AZRoleGraph_*.json` | 誰がどのリソース／スコープの Azure RBAC ロールを持つか | 第2ジョブで送信 |
| `02-upload-opengraph/AZPermissionGraph_*.json` | RBAC 解析から導いた VM コマンド実行、マネージド ID 割り当てなどの操作権限 | 第2ジョブで送信 |
| `02-upload-opengraph/AZConditionalAccessPolicy_*.json`（BOF）/ `AZConditionalAccessGraph.json`（Python） | ユーザー／グループの `cap_policies` に CAP 観測結果を追加。CAP エッジは生成しない | 第2ジョブで送信 |
| `BARK_UPLOAD_MANIFEST.json` | ファイル分類、チェックサム、アップロード順 | 確認のみ |
| `CAP_PROPERTIES_VALIDATION.json`（提供済み修正版バンドル） | CAP プロパティ移行のローカル検証結果 | 確認のみ。通常の毎回の収集では生成しない |
| `do-not-upload/*.json` と配下のファイル | 生データ、権限解析結果、統合済みネイティブデータの元ファイル | 確認のみ |

`02-upload-opengraph/` 内の JSON はまとめて送信できます。ネイティブ側のジョブ完了が前提です。収集結果によって含まれるファイルは変わります。

### OpenGraph 拡張の登録

BloodHound の Administrator でログインします。必要な場合は **Administration → Early Access Features** で **OpenGraph Extension Management** を有効にして再読み込みします。

**Administration → OpenGraph Management → Upload File** を開き、`00-install-schema/BARK_OpenGraph_Extension.json` を選択して **Upload** を押します。一覧に **BARK Azure Permissions** が表示されることを確認してください。拡張定義は File Ingest には送信しません。[公式手順](https://bloodhound.specterops.io/opengraph/extensions/manage#verify-or-install-an-extension)も参照できます。

アプリロールの解決、権限解析、互換性、トラブルシューティングは [BloodHound 取り込み](wiki/ja/BloodHound-Import.md)にまとめています。

## リファレンス

- [日本語 wiki の目次](wiki/ja/Home.md)
- [Python コレクター](wiki/ja/Python-Collector.md)
- [コマンド一覧](wiki/ja/Command-Reference.md)
- [追加コレクター](wiki/ja/Additional-Collectors.md)
- [ビルドと開発](wiki/ja/Development.md)

[Azure エッジの対応範囲と拡張計画](wiki/ja/Azure-Edge-Coverage-Plan.md)
