#!/usr/bin/env python3
"""
Gather BARK ARM role-assignment JSON and convert it to BloodHound OpenGraph.

The helper is intentionally client-side.  It does not depend on Cobalt Strike
download events and does not run code in Beacon.  It understands BARK's
``.json.partNNNofMMM`` download chunks and materializes each complete group as
one JSON file in a classified BloodHound upload bundle.

By default it writes a canonical gathered assignment file, an ``AZRoleGraph``
OpenGraph file, and an ``AZNativeRBAC`` AzureHound-compatible file next to the
inputs. It also creates ``BARK_BloodHound_Bundle_<timestamp>`` with native JSON
in upload phase 1, OpenGraph JSON in upload phase 2, and conversion-only files
under ``do-not-upload``. Native records are merged into one deterministically
ordered AzureHound envelope so relationship-generated placeholder nodes are
ingested before their complete entity records. The graph references
already-ingested BloodHound Azure nodes without redeclaring reserved ``AZ*``
node kinds. Use ``--standalone`` only when those Azure nodes are unavailable.

Examples:
    python3 bark_role_graph.py C:\\path\\to\\downloads
    python3 bark_role_graph.py ./downloads --recursive
    python3 bark_role_graph.py ./downloads --bundle-output ./bloodhound-upload
    python3 bark_role_graph.py ./downloads --no-gather \
        --graph-output ./AZRoleGraph.json

No external dependencies are required.

Author: BARK BOF project
License: GPLv3
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import bark_permission_analysis
from bark_native_edges import build_native_edge_records, identity_index, hydrate_managed_identities
from bark_opengraph import native_endpoint, preserve_native_nodes, endpoint_id, standalone_id


PART_RE = re.compile(
    r"^(?P<base>.+\.json)\.part(?P<index>\d+)of(?P<total>\d+)$",
    re.IGNORECASE,
)
OPEN_GRAPH_KIND_RE = re.compile(r"^[A-Za-z0-9_]+$")
BUNDLE_DIR_PREFIX = "BARK_BloodHound_Bundle_"
MERGED_NATIVE_FILENAME = "azurehound_bark.json"

# AzureHound 3.1 native kinds.  BloodHound's Azure ingest maps these wrappers
# to their concrete node/relationship types.  Other AZ* values emitted by
# BARK (for example AZRoleDefinition and generic AZResource inventory) are
# useful conversion inputs but must not be presented as native upload files,
# or BloodHound can reduce them to an unhelpful AZBase node.
AZUREHOUND_NATIVE_KINDS = frozenset(
    {
        "AZApp",
        "AZAppMember",
        "AZAppOwner",
        "AZAppRoleAssignment",
        "AZAutomationAccount",
        "AZAutomationAccountRoleAssignment",
        "AZContainerRegistry",
        "AZContainerRegistryRoleAssignment",
        "AZDevice",
        "AZFederatedIdentityCredential",
        "AZFunctionApp",
        "AZFunctionAppRoleAssignment",
        "AZGroup",
        "AZGroupMember",
        "AZGroupOwner",
        "AZKeyVault",
        "AZKeyVaultAccessPolicy",
        "AZKeyVaultContributor",
        "AZKeyVaultKVContributor",
        "AZKeyVaultOwner",
        "AZKeyVaultRoleAssignment",
        "AZKeyVaultUserAccessAdmin",
        "AZLogicApp",
        "AZLogicAppRoleAssignment",
        "AZManagedCluster",
        "AZManagedClusterRoleAssignment",
        "AZManagementGroup",
        "AZManagementGroupContributor",
        "AZManagementGroupDescendant",
        "AZManagementGroupOwner",
        "AZManagementGroupRoleAssignment",
        "AZManagementGroupUserAccessAdmin",
        "AZResourceGroup",
        "AZResourceGroupContributor",
        "AZResourceGroupOwner",
        "AZResourceGroupRoleAssignment",
        "AZResourceGroupUserAccessAdmin",
        "AZRole",
        "AZRoleAssignment",
        "AZRoleEligibilityScheduleInstance",
        "AZRoleManagementPolicyAssignment",
        "AZServicePrincipal",
        "AZServicePrincipalOwner",
        "AZStorageAccount",
        "AZStorageAccountRoleAssignment",
        "AZStorageContainer",
        "AZSubscription",
        "AZSubscriptionContributor",
        "AZSubscriptionOwner",
        "AZSubscriptionRoleAssignment",
        "AZSubscriptionUserAccessAdmin",
        "AZTenant",
        "AZUser",
        "AZVM",
        "AZVMAdminLogin",
        "AZVMAvereContributor",
        "AZVMContributor",
        "AZVMOwner",
        "AZVMRoleAssignment",
        "AZVMScaleSet",
        "AZVMScaleSetRoleAssignment",
        "AZVMUserAccessAdmin",
        "AZVMVMContributor",
        "AZWebApp",
        "AZWebAppRoleAssignment",
    }
)

_SHAPE_SENSITIVE_NATIVE_KINDS = frozenset(
    {
        "AZManagementGroupRoleAssignment",
        "AZRoleEligibilityScheduleInstance",
        "AZRoleManagementPolicyAssignment",
    }
)

# Native wrappers that provide the complete properties for an Azure entity.
# Relationship wrappers are deliberately placed first in the merged upload.
# BloodHound's AZAppRoleAssignment converter creates partial
# AZServicePrincipal nodes, and the AZServicePrincipal converter creates a
# partial AZApp node. Keeping complete service principals and apps last means
# their name/displayname properties win even when the importer flushes every
# 500 records.
AZUREHOUND_ENTITY_KINDS = frozenset(
    {
        "AZApp",
        "AZAutomationAccount",
        "AZContainerRegistry",
        "AZDevice",
        "AZFederatedIdentityCredential",
        "AZFunctionApp",
        "AZGroup",
        "AZKeyVault",
        "AZLogicApp",
        "AZManagedCluster",
        "AZManagementGroup",
        "AZResourceGroup",
        "AZRole",
        "AZServicePrincipal",
        "AZStorageAccount",
        "AZStorageContainer",
        "AZSubscription",
        "AZTenant",
        "AZUser",
        "AZVM",
        "AZVMScaleSet",
        "AZWebApp",
    }
)

OWNER_ROLE_ID = "8e3af657-a8ff-443c-a75c-2fe8c4bcb635"
CONTRIBUTOR_ROLE_ID = "b24988ac-6180-42a0-ab88-20f7382dd24c"
USER_ACCESS_ADMIN_ROLE_ID = "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9"
KEY_VAULT_CONTRIBUTOR_ROLE_ID = "f25e0fa2-a7c8-4377-a976-54943a77a395"
AVERE_CONTRIBUTOR_ROLE_ID = "4f8fab4f-1852-4a58-a46a-8eaf358af14a"
VM_ADMIN_LOGIN_ROLE_ID = "1c0163c0-47e6-4577-8991-ea5c82e286e4"
VM_CONTRIBUTOR_ROLE_ID = "9980e02c-c2be-4d73-94e8-173b1dc7cf3c"
MS_GRAPH_APP_ID = "00000003-0000-0000-c000-000000000000"
DEFAULT_APP_ROLE_ID = "00000000-0000-0000-0000-000000000000"
BLOODHOUND_NATIVE_APP_ROLE_IDS = frozenset(
    {
        "1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9",  # Application.ReadWrite.All
        "06b708a9-e830-4db3-a914-8e69da51d44f",  # AppRoleAssignment.ReadWrite.All
        "19dbc75e-c2e2-444c-a770-ec69d8559fc7",  # Directory.ReadWrite.All
        "62a82d76-70ea-41e2-9197-370581804d09",  # Group.ReadWrite.All
        "dbaae8cf-10b5-4b86-a4a1-f871c94c6695",  # GroupMember.ReadWrite.All
        "9e3f62cf-ca93-4989-b6ce-bf83c28f9fe8",  # RoleManagement.ReadWrite.Directory
        "89c8469c-83ad-45f7-8ff2-6e3d4285709e",  # ServicePrincipalEndpoint.ReadWrite.All
    }
)
OPEN_GRAPH_EXTENSION_FILENAME = "BARK_OpenGraph_Extension.json"

# Resource role-assignment wrappers emitted directly by AzureHound's az-rm
# pipeline.  The remaining special scopes (management group, subscription,
# resource group, key vault, and VM) are converted to their native filtered
# relationship records below.
NATIVE_GENERIC_ROLE_ASSIGNMENT_KINDS = {
    "AZStorageAccount": "AZStorageAccountRoleAssignment",
    "AZAutomationAccount": "AZAutomationAccountRoleAssignment",
    "AZLogicApp": "AZLogicAppRoleAssignment",
    "AZFunctionApp": "AZFunctionAppRoleAssignment",
    "AZContainerRegistry": "AZContainerRegistryRoleAssignment",
    "AZWebApp": "AZWebAppRoleAssignment",
    "AZManagedCluster": "AZManagedClusterRoleAssignment",
    "AZVMScaleSet": "AZVMScaleSetRoleAssignment",
}


@dataclass(frozen=True)
class JsonDocument:
    name: str
    data: bytes
    reassembled: bool = False
    part_count: int = 0
    generated: bool = False


@dataclass(frozen=True)
class BundleClassification:
    action: str
    directory: str
    format: str
    reason: str
    kinds: tuple[str, ...] = ()
    count: int = 0


@dataclass
class Assignment:
    role_name: str
    role_definition_id: str
    principal_id: str
    principal_type: str
    authored_scope: str
    effective_scope: str
    assignment_id: str
    source: str
    raw: dict[str, Any]


class Reporter:
    def __init__(self) -> None:
        self.warnings: list[str] = []

    def warn(self, message: str) -> None:
        self.warnings.append(message)
        print(f"[!] {message}", file=sys.stderr)


def _files_under(input_dir: Path, recursive: bool) -> list[Path]:
    iterator: Iterable[Path]
    iterator = input_dir.rglob("*") if recursive else input_dir.iterdir()
    files: list[Path] = []
    for path in iterator:
        if not path.is_file():
            continue
        relative = path.relative_to(input_dir)
        if any(part.startswith(BUNDLE_DIR_PREFIX) for part in relative.parts[:-1]):
            continue
        files.append(path)
    return sorted(files, key=lambda p: str(p).lower())


def _is_valid_json_bytes(data: bytes) -> bool:
    try:
        json.loads(data.decode("utf-8-sig"))
        return True
    except (UnicodeDecodeError, json.JSONDecodeError):
        return False


def load_documents(
    input_dir: Path, recursive: bool, reporter: Reporter
) -> list[JsonDocument]:
    """Load standalone JSON and reassemble complete BARK part groups."""
    standalone: dict[Path, Path] = {}
    groups: dict[Path, list[tuple[int, int, Path]]] = {}

    for path in _files_under(input_dir, recursive):
        match = PART_RE.match(path.name)
        if match:
            base = path.with_name(match.group("base"))
            groups.setdefault(base, []).append(
                (int(match.group("index")), int(match.group("total")), path)
            )
        elif path.suffix.lower() == ".json":
            standalone[path] = path

    documents: list[JsonDocument] = []

    # A complete chunk set is authoritative.  This also avoids trusting a
    # manually reconstructed base file that may have been assembled wrongly.
    for base, parts in sorted(groups.items(), key=lambda item: str(item[0]).lower()):
        totals = {total for _, total, _ in parts}
        if len(totals) != 1:
            reporter.warn(
                f"inconsistent part totals for {base.name}: {sorted(totals)}; "
                "using a standalone base file if available"
            )
            continue

        total = next(iter(totals))
        by_index: dict[int, Path] = {}
        duplicate_indexes: list[int] = []
        for index, _, path in parts:
            if index in by_index:
                duplicate_indexes.append(index)
            else:
                by_index[index] = path

        expected = set(range(total))
        missing = sorted(expected - set(by_index))
        extra = sorted(set(by_index) - expected)
        if duplicate_indexes or missing or extra:
            detail: list[str] = []
            if missing:
                detail.append(f"missing={missing}")
            if extra:
                detail.append(f"extra={extra}")
            if duplicate_indexes:
                detail.append(f"duplicates={sorted(set(duplicate_indexes))}")
            reporter.warn(
                f"incomplete part group for {base.name} ({', '.join(detail)}); "
                "using a standalone base file if available"
            )
            continue

        combined = b"".join(by_index[index].read_bytes() for index in range(total))
        if base in standalone:
            base_data = base.read_bytes()
            if base_data != combined:
                if not _is_valid_json_bytes(combined) and _is_valid_json_bytes(base_data):
                    reporter.warn(
                        f"the complete part set for {base.name} is invalid JSON; "
                        "using the valid standalone base file"
                    )
                    continue
                reporter.warn(
                    f"{base.name} differs from its complete part set; "
                    "using the reassembled parts"
                )
            del standalone[base]

        relative = base.relative_to(input_dir)
        documents.append(
            JsonDocument(
                str(relative), combined, reassembled=True, part_count=total
            )
        )

    for path in sorted(standalone, key=lambda p: str(p).lower()):
        # Never consume this helper's own outputs on a later run.
        lower_name = path.name.lower()
        if (
            lower_name.startswith("azrolegraph_")
            or lower_name.startswith("azroleassignments_gathered_")
            or lower_name.startswith("aznativerbac_")
            or lower_name.startswith("azpermissiongraph_")
            or lower_name.startswith("azpermissionfindings_")
            or lower_name.startswith("azapprolegraph_")
        ):
            continue
        relative = path.relative_to(input_dir)
        documents.append(JsonDocument(str(relative), path.read_bytes()))

    return documents


def parse_documents(
    documents: list[JsonDocument], reporter: Reporter
) -> list[tuple[JsonDocument, Any]]:
    parsed: list[tuple[JsonDocument, Any]] = []
    for document in documents:
        try:
            text = document.data.decode("utf-8-sig")
            parsed.append((document, json.loads(text)))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            suffix = " (reassembled)" if document.reassembled else ""
            reporter.warn(f"invalid JSON in {document.name}{suffix}: {exc}")
    return parsed


def _last_arm_segment(value: str) -> str:
    return value.rstrip("/").rsplit("/", 1)[-1].lower()


def build_role_definition_lookup(parsed: list[tuple[JsonDocument, Any]]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for _, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict):
                continue
            if wrapper.get("kind") != "AZRoleDefinition":
                continue
            role_definition = wrapper.get("data")
            if not isinstance(role_definition, dict):
                continue
            properties = role_definition.get("properties")
            if not isinstance(properties, dict):
                continue
            role_name = properties.get("roleName")
            role_id = role_definition.get("id") or role_definition.get("name")
            if not isinstance(role_name, str) or not isinstance(role_id, str):
                continue
            if not role_name or not role_id:
                continue
            lookup[role_id.lower()] = role_name
            lookup[_last_arm_segment(role_id)] = role_name
    return lookup


def build_resource_kind_lookup(
    parsed: list[tuple[JsonDocument, Any]],
) -> dict[str, str]:
    """Map collected ARM resource IDs to their exact AzureHound kinds.

    ARM scope paths alone cannot distinguish Function Apps from Web Apps
    because both use Microsoft.Web/sites.  Reusing the collected entity files
    makes the native wrapper kind deterministic without another Azure request.
    """
    lookup: dict[str, str] = {}
    descendants: list[tuple[str, str]] = []
    for _, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict):
                continue
            kind = wrapper.get("kind")
            data = wrapper.get("data")
            if not isinstance(kind, str) or not isinstance(data, dict):
                continue
            object_id = data.get("id")
            if isinstance(object_id, str) and object_id:
                if kind == "AZManagementGroupDescendant":
                    descendant_type = str(data.get("type") or "").lower()
                    if "managementgroups/subscriptions" in descendant_type:
                        descendants.append((object_id.lower(), "AZSubscription"))
                    elif "managementgroups" in descendant_type:
                        descendants.append((object_id.lower(), "AZManagementGroup"))
                    continue
                lookup[object_id.lower()] = kind
    # Descendant wrappers describe existing entities; never let their partial
    # records replace a complete AZSubscription/AZManagementGroup wrapper.
    for object_id, kind in descendants:
        lookup.setdefault(object_id, kind)
    return lookup


def build_entity_kind_lookup(
    parsed: Iterable[tuple[JsonDocument, Any]],
) -> dict[str, str]:
    """Map directory-object IDs to the native kind collected for that object."""

    accepted = {"AZUser", "AZGroup", "AZServicePrincipal", "AZDevice"}
    lookup: dict[str, str] = {}
    for _, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict) or wrapper.get("kind") not in accepted:
                continue
            data = wrapper.get("data")
            object_id = data.get("id") if isinstance(data, dict) else None
            if isinstance(object_id, str) and object_id:
                lookup[object_id.lower()] = str(wrapper["kind"])
    return lookup


def build_app_role_catalog(
    parsed: Iterable[tuple[JsonDocument, Any]],
) -> dict[tuple[str, str], dict[str, Any]]:
    """Index every service-principal app role by resource SP and role ID."""

    catalog: dict[tuple[str, str], dict[str, Any]] = {}
    for _, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict) or wrapper.get("kind") != "AZServicePrincipal":
                continue
            data = wrapper.get("data")
            if not isinstance(data, dict):
                continue
            resource_id = data.get("id")
            roles = data.get("appRoles")
            if not isinstance(resource_id, str) or not isinstance(roles, list):
                continue
            for role in roles:
                role_id = role.get("id") if isinstance(role, dict) else None
                if not isinstance(role_id, str) or not role_id:
                    continue
                catalog[(resource_id.lower(), role_id.lower())] = {
                    "role": role,
                    "resource": data,
                }
    return catalog


def _is_arm_assignment(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    properties = value.get("properties")
    if not isinstance(properties, dict) or not properties.get("principalId"):
        return False
    resource_type = value.get("type")
    if isinstance(resource_type, str):
        lowered_type = resource_type.lower()
        if lowered_type != "microsoft.authorization/roleassignments":
            return False
        return True
    # Older BARK envelopes did not always preserve the ARM type field.
    return bool(properties.get("roleDefinitionId") and properties.get("scope"))


def _find_nested_assignment(
    item: dict[str, Any], expected_key: str
) -> tuple[str, dict[str, Any]] | None:
    preferred = item.get(expected_key)
    if _is_arm_assignment(preferred):
        return expected_key, preferred

    for key, value in item.items():
        if key != "id" and _is_arm_assignment(value):
            return key, value

    # Support the older {"kind":"AZRoleAssignment","data":{...}} shape.
    value = item.get("data")
    if _is_arm_assignment(value):
        return expected_key, value
    return None


def _resolved_role_name(
    hint: str, role_definition_id: str, lookup: dict[str, str]
) -> str:
    if hint and hint.lower() not in {"data", "unknown", "roleassignment"}:
        return hint
    if role_definition_id:
        return lookup.get(role_definition_id.lower()) or lookup.get(
            _last_arm_segment(role_definition_id), "Unknown"
        )
    return "Unknown"


def gather_assignments(
    parsed: list[tuple[JsonDocument, Any]],
    role_lookup: dict[str, str],
    reporter: Reporter,
) -> list[Assignment]:
    assignments: list[Assignment] = []
    seen: set[tuple[str, str, str, str]] = set()
    unresolved_role_ids: set[str] = set()

    for document, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue

        outer_kind = root.get("kind")
        expected_key = ""
        if isinstance(outer_kind, str):
            expected_key = outer_kind[2:] if outer_kind.startswith("AZ") else outer_kind

        for item in root["data"]:
            if not isinstance(item, dict):
                continue

            found_assignments: list[tuple[str, dict[str, Any], str]] = []
            if item.get("kind") == "AZManagementGroupRoleAssignment":
                grouped = item.get("data")
                rows = grouped.get("roleAssignments") if isinstance(grouped, dict) else None
                if isinstance(rows, list):
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        raw = row.get("roleAssignment")
                        if not _is_arm_assignment(raw):
                            continue
                        management_group = row.get("managementGroupId")
                        if not isinstance(management_group, str) and isinstance(grouped, dict):
                            management_group = grouped.get("managementGroupId")
                        if isinstance(management_group, str) and management_group:
                            if not management_group.startswith("/"):
                                management_group = (
                                    "/providers/Microsoft.Management/managementGroups/"
                                    + management_group
                                )
                        found_assignments.append(("roleAssignment", raw, management_group or ""))

            found = _find_nested_assignment(item, expected_key)
            if found is not None:
                nested_key, raw_assignment = found
                found_assignments.append((nested_key, raw_assignment, ""))
            if not found_assignments:
                continue

            for nested_key, raw_assignment, management_group_scope in found_assignments:
                properties = raw_assignment.get("properties")
                assert isinstance(properties, dict)

                principal_id = properties.get("principalId")
                role_definition_id = properties.get("roleDefinitionId") or ""
                authored_scope = properties.get("scope") or management_group_scope
                effective_scope = item.get("id") or authored_scope
                principal_type = properties.get("principalType") or ""
                assignment_id = raw_assignment.get("id") or raw_assignment.get("name") or ""

                if not isinstance(principal_id, str) or not principal_id:
                    continue
                if not isinstance(effective_scope, str) or not effective_scope:
                    continue
                if not isinstance(role_definition_id, str):
                    role_definition_id = ""
                if not isinstance(authored_scope, str):
                    authored_scope = ""
                if not isinstance(principal_type, str):
                    principal_type = ""
                if not isinstance(assignment_id, str):
                    assignment_id = ""

                hint = expected_key or nested_key
                if hint.lower() in {"data", "unknown", "roleassignment"}:
                    hint = nested_key
                role_name = _resolved_role_name(hint, role_definition_id, role_lookup)
                if role_name == "Unknown":
                    unresolved_role_ids.add(role_definition_id or "<missing roleDefinitionId>")

                # Keep inherited grants at every scope where they are effective.
                # Duplicate collectors can still observe the same effective grant.
                key = (
                    principal_id.lower(),
                    role_definition_id.lower() or role_name.lower(),
                    effective_scope.lower(),
                    assignment_id.lower(),
                )
                if key in seen:
                    continue
                seen.add(key)
                assignments.append(
                    Assignment(
                        role_name=role_name,
                        role_definition_id=role_definition_id,
                        principal_id=principal_id,
                        principal_type=principal_type,
                        authored_scope=authored_scope,
                        effective_scope=effective_scope,
                        assignment_id=assignment_id,
                        source=document.name,
                        raw=raw_assignment,
                    )
                )

    if unresolved_role_ids:
        preview = ", ".join(sorted(unresolved_role_ids)[:5])
        remaining = len(unresolved_role_ids) - 5
        if remaining > 0:
            preview += f", ... (+{remaining})"
        reporter.warn(
            "could not resolve some role names; include AZRoleDefinition JSON "
            f"in the input directory: {preview}"
        )
    return assignments


def principal_kind(principal_type: str) -> str:
    lowered = principal_type.lower()
    if lowered.startswith("user"):
        return "AZUser"
    if lowered.startswith("foreigngroup") or lowered.startswith("group"):
        return "AZGroup"
    if lowered.startswith("serviceprincipal"):
        return "AZServicePrincipal"
    if lowered.startswith("device"):
        return "AZDevice"
    if not principal_type:
        return "AZBase"
    return f"AZ{principal_type}"


def scope_kind(scope: str, resource_kinds: dict[str, str] | None = None) -> str:
    if resource_kinds:
        collected_kind = resource_kinds.get(scope.lower())
        if collected_kind:
            return collected_kind
    lowered = scope.lower()
    known_types = (
        ("microsoft.compute/virtualmachinescalesets", "AZVMScaleSet"),
        ("microsoft.compute/virtualmachines", "AZVM"),
        ("microsoft.keyvault/vaults", "AZKeyVault"),
        ("microsoft.storage/storageaccounts", "AZStorageAccount"),
        ("microsoft.logic/workflows", "AZLogicApp"),
        ("microsoft.web/sites", "AZWebApp"),
        ("microsoft.containerservice/managedclusters", "AZManagedCluster"),
        ("microsoft.containerregistry/registries", "AZContainerRegistry"),
        ("microsoft.automation/automationaccounts", "AZAutomationAccount"),
        ("microsoft.app/containerapps", "AZContainerApp"),
        ("microsoft.containerinstance/containergroups", "AZContainerGroup"),
        ("microsoft.documentdb/databaseaccounts", "AZCosmosDB"),
    )
    for fragment, kind in known_types:
        if fragment in lowered:
            return kind
    if "/providers/microsoft.management/managementgroups/" in lowered:
        return "AZManagementGroup"
    if "/providers/" in lowered:
        return "AZResource"
    if "/resourcegroups/" in lowered:
        return "AZResourceGroup"
    if "/subscriptions/" in lowered:
        return "AZSubscription"
    return "AZResource"


def normalized_role_kind(role_name: str) -> str:
    # Match BarkStripSpaces: BARK's emitted kind retains punctuation.
    return role_name.replace(" ", "") or "Unknown"


def edge_kind(role_name: str, target_kind: str) -> str:
    role = normalized_role_kind(role_name)
    if role == "UserAccessAdministrator":
        role = "UserAccessAdmin"
    prefix = target_kind[2:] if target_kind.startswith("AZ") else target_kind
    if prefix and prefix != "Resource":
        return f"{prefix}{role}"
    return role


def open_graph_kind(value: str, fallback: str) -> str:
    """Return a BARK-namespaced kind accepted by OpenGraph validation."""
    sanitized = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    sanitized = re.sub(r"_+", "_", sanitized)
    if not sanitized:
        sanitized = fallback
    result = f"BARK_{sanitized}"
    assert OPEN_GRAPH_KIND_RE.fullmatch(result)
    return result


def custom_node_kind(native_kind: str) -> str:
    suffix = native_kind[2:] if native_kind.startswith("AZ") else native_kind
    return open_graph_kind(f"Azure{suffix}", "AzureObject")


def make_graph(
    assignments: list[Assignment], standalone: bool = False,
    resource_kinds: dict[str, str] | None = None,
) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    node_ids: set[str] = set()
    edge_ids: set[tuple[str, str, str]] = set()

    def add_node(node_id: str, kind: str) -> None:
        if not standalone:
            return
        lowered = node_id.lower()
        if lowered in node_ids:
            return
        node_ids.add(lowered)
        nodes.append({"id": standalone_id(node_id), "kinds": [custom_node_kind(kind)]})

    for assignment in assignments:
        # AzureHound canonicalizes Azure object and ARM resource IDs to upper
        # case before native BloodHound ingest.  Use the same representation
        # when matching endpoints in the existing Azure graph.
        principal_id = assignment.principal_id.upper()
        effective_scope = assignment.effective_scope.upper()
        target_kind = scope_kind(assignment.effective_scope, resource_kinds)
        native_edge_kind = edge_kind(assignment.role_name, target_kind)
        kind = open_graph_kind(native_edge_kind, "AzureRoleAssignment")
        add_node(principal_id, principal_kind(assignment.principal_type))
        add_node(effective_scope, target_kind)

        identity = (
            kind,
            principal_id,
            effective_scope,
        )
        if identity in edge_ids:
            continue
        edge_ids.add(identity)
        start: dict[str, Any] = {
            "value": principal_id,
            "match_by": "id",
        }
        end: dict[str, Any] = {
            "value": effective_scope,
            "match_by": "id",
        }
        if standalone:
            start["value"] = standalone_id(principal_id)
            end["value"] = standalone_id(effective_scope)
        else:
            start = native_endpoint(principal_id)
            end = native_endpoint(effective_scope)
        edges.append(
            {
                "kind": kind,
                "start": start,
                "end": end,
                "properties": {
                    "rolename": assignment.role_name,
                    "roledefinitionid": assignment.role_definition_id,
                    "roleassignmentid": assignment.assignment_id,
                    "principaltype": assignment.principal_type,
                    "authoredscope": assignment.authored_scope,
                    "effectivescope": assignment.effective_scope,
                },
            }
        )

    return {"graph": {"nodes": nodes, "edges": edges}}


def app_role_node_id(resource_id: str, app_role_id: str) -> str:
    """Return a collision-resistant OpenGraph ID without colon separators."""

    def compact(value: str) -> str:
        normalized = re.sub(r"[^A-Za-z0-9]+", "", value).upper()
        return normalized or hashlib.sha256(value.encode("utf-8")).hexdigest().upper()

    return f"BARK_APPROLE_{compact(resource_id)}_{compact(app_role_id)}"


def _app_role_principal_kind(
    assignment: dict[str, Any], entity_kinds: dict[str, str]
) -> str:
    principal_id = str(assignment.get("principalId") or "")
    declared = principal_kind(str(assignment.get("principalType") or ""))
    observed = entity_kinds.get(principal_id.lower())
    if observed in {"AZUser", "AZGroup", "AZServicePrincipal", "AZDevice"}:
        return observed
    return declared


def make_app_role_graph(
    parsed: Iterable[tuple[JsonDocument, Any]],
    reporter: Reporter | None = None,
    standalone: bool = False,
) -> dict[str, Any]:
    """Convert Entra app-role assignments to type-safe OpenGraph paths."""

    parsed_list = list(parsed)
    catalog = build_app_role_catalog(parsed_list)
    entity_kinds = build_entity_kind_lookup(parsed_list)
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    seen_edges: set[tuple[str, str, str]] = set()
    unresolved_roles: set[tuple[str, str]] = set()
    skipped_principals: set[str] = set()
    assignments_seen = 0

    def add_endpoint_node(node_id: str, native_kind: str) -> None:
        if not standalone or node_id.lower() in seen_nodes:
            return
        seen_nodes.add(node_id.lower())
        nodes.append({"id": standalone_id(node_id), "kinds": [custom_node_kind(native_kind)]})

    for _, root in parsed_list:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict) or wrapper.get("kind") != "AZAppRoleAssignment":
                continue
            assignment = wrapper.get("data")
            if not isinstance(assignment, dict):
                continue
            principal_id = str(assignment.get("principalId") or "")
            resource_id = str(assignment.get("resourceId") or "")
            role_id = str(assignment.get("appRoleId") or "")
            if not principal_id or not resource_id or not role_id:
                continue
            assignments_seen += 1
            source_kind = _app_role_principal_kind(assignment, entity_kinds)
            if source_kind == "AZBase" or source_kind not in {
                "AZUser", "AZGroup", "AZServicePrincipal", "AZDevice"
            }:
                skipped_principals.add(principal_id)
                continue

            principal_id = principal_id.upper()
            resource_id = resource_id.upper()
            node_id = app_role_node_id(resource_id, role_id)
            indexed = catalog.get((resource_id.lower(), role_id.lower()))
            role = indexed.get("role", {}) if indexed else {}
            resource = indexed.get("resource", {}) if indexed else {}
            if not indexed and role_id.lower() != DEFAULT_APP_ROLE_ID:
                unresolved_roles.add((resource_id, role_id))
            display_name = str(
                role.get("displayName")
                or role.get("value")
                or assignment.get("appRoleDisplayName")
                or (
                    "Default Access"
                    if role_id.lower() == DEFAULT_APP_ROLE_ID
                    else None
                )
                or role_id
            )
            value = str(role.get("value") or "")
            resource_name = str(
                resource.get("displayName")
                or assignment.get("resourceDisplayName")
                or resource_id
            )

            if node_id.lower() not in seen_nodes:
                seen_nodes.add(node_id.lower())
                nodes.append(
                    {
                        "id": node_id,
                        "kinds": ["BARK_AppRole"],
                        "properties": {
                            "name": f"{display_name}@{resource_name}",
                            "displayname": display_name,
                            "value": value,
                            "description": str(role.get("description") or ""),
                            "approleid": role_id,
                            "resourceid": resource_id,
                            "resourcedisplayname": resource_name,
                            "isenabled": bool(role.get("isEnabled", True)),
                            "allowedmembertypes": ",".join(
                                str(member_type)
                                for member_type in role.get("allowedMemberTypes", [])
                                if isinstance(member_type, str)
                            ),
                        },
                    }
                )
            add_endpoint_node(principal_id, source_kind)
            add_endpoint_node(resource_id, "AZServicePrincipal")

            assigned_key = (
                "BARK_AssignedAppRole",
                principal_id.lower(),
                node_id.lower(),
            )
            if assigned_key not in seen_edges:
                seen_edges.add(assigned_key)
                start: dict[str, Any] = {"value": principal_id, "match_by": "id"}
                end: dict[str, Any] = {"value": node_id, "match_by": "id"}
                if standalone:
                    start["value"] = standalone_id(principal_id)
                else:
                    start = native_endpoint(principal_id)
                edges.append(
                    {
                        "kind": "BARK_AssignedAppRole",
                        "start": start,
                        "end": end,
                        "properties": {
                            "assignmentid": str(assignment.get("id") or ""),
                            "principaltype": source_kind.removeprefix("AZ"),
                            "approleid": role_id,
                            "resourceid": resource_id,
                        },
                    }
                )

            role_of_key = (
                "BARK_AppRoleOf",
                node_id.lower(),
                resource_id.lower(),
            )
            if role_of_key not in seen_edges:
                seen_edges.add(role_of_key)
                start = {"value": node_id, "match_by": "id"}
                end = {"value": resource_id, "match_by": "id"}
                if standalone:
                    end["value"] = standalone_id(resource_id)
                else:
                    end = native_endpoint(resource_id)
                edges.append(
                    {
                        "kind": "BARK_AppRoleOf",
                        "start": start,
                        "end": end,
                        "properties": {"approleid": role_id},
                    }
                )

    if reporter is not None and unresolved_roles:
        reporter.warn(
            f"could not resolve {len(unresolved_roles)} app role name(s); include the "
            "matching AZServicePrincipal JSON with appRoles in the input directory"
        )
    if reporter is not None and skipped_principals:
        reporter.warn(
            f"skipped {len(skipped_principals)} app-role principal(s) whose type "
            "could not be resolved"
        )
    return {
        "graph": {"nodes": nodes, "edges": edges},
        "meta": {
            "generator": "bark_role_graph.py",
            "mode": "entra-app-role",
            "assignments": assignments_seen,
            "unresolvedRoles": len(unresolved_roles),
            "skippedPrincipals": len(skipped_principals),
            "nodeCount": len(nodes),
            "edgeCount": len(edges),
        },
    }


def _role_definition_guid(role_definition_id: str) -> str:
    return _last_arm_segment(role_definition_id)


def _azurehound_assignment(assignment: Assignment) -> dict[str, Any]:
    """Return the minimal normalized ARM assignment AzureHound serializes."""
    raw = copy.deepcopy(assignment.raw)
    properties = raw.setdefault("properties", {})
    if isinstance(properties, dict):
        properties["principalId"] = assignment.principal_id.upper()
        properties["roleDefinitionId"] = assignment.role_definition_id
        properties["scope"] = assignment.authored_scope.upper()
        if assignment.principal_type:
            properties["principalType"] = assignment.principal_type
    return raw


def _native_direct_descriptor(
    target_kind: str, role_definition_guid: str
) -> tuple[str, str, str, str] | None:
    """Return kind, collection field, item field, and target field."""
    role_fields = {
        OWNER_ROLE_ID: ("Owner", "owners", "owner"),
        CONTRIBUTOR_ROLE_ID: ("Contributor", "contributors", "contributor"),
        USER_ACCESS_ADMIN_ROLE_ID: (
            "UserAccessAdmin",
            "userAccessAdmins",
            "userAccessAdmin",
        ),
    }
    prefix_and_target = {
        "AZManagementGroup": ("AZManagementGroup", "managementGroupId"),
        "AZSubscription": ("AZSubscription", "subscriptionId"),
        "AZResourceGroup": ("AZResourceGroup", "resourceGroupId"),
        "AZKeyVault": ("AZKeyVault", "keyVaultId"),
        "AZVM": ("AZVM", "virtualMachineId"),
    }
    base = prefix_and_target.get(target_kind)
    role = role_fields.get(role_definition_guid)

    if target_kind == "AZKeyVault" and role_definition_guid == KEY_VAULT_CONTRIBUTOR_ROLE_ID:
        role = ("KVContributor", "kvContributors", "kvContributor")
    elif target_kind == "AZVM":
        vm_roles = {
            AVERE_CONTRIBUTOR_ROLE_ID: (
                "AvereContributor",
                "avereContributors",
                "avereContributor",
            ),
            VM_ADMIN_LOGIN_ROLE_ID: ("AdminLogin", "adminLogins", "adminLogin"),
            VM_CONTRIBUTOR_ROLE_ID: (
                "VMContributor",
                "vmContributors",
                "vmContributor",
            ),
        }
        role = vm_roles.get(role_definition_guid, role)

    if base is None or role is None:
        return None
    prefix, target_field = base
    suffix, collection_field, item_field = role
    return f"{prefix}{suffix}", collection_field, item_field, target_field


def make_native_rbac(
    assignments: list[Assignment],
    resource_kinds: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Create AzureHound/BloodHound-native RBAC records where supported.

    Every assignment still remains in the BARK OpenGraph output.  This native
    payload is deliberately limited to kinds emitted by AzureHound 3.1's
    az-rm pipeline so unsupported/custom roles are never mislabeled.
    """
    data: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, str]] = set()

    for assignment in assignments:
        target_kind = scope_kind(assignment.effective_scope, resource_kinds)
        target_id = assignment.effective_scope.upper()
        role_guid = _role_definition_guid(assignment.role_definition_id)
        normalized = _azurehound_assignment(assignment)

        generic_kind = NATIVE_GENERIC_ROLE_ASSIGNMENT_KINDS.get(target_kind)
        if generic_kind:
            identity = (
                generic_kind,
                assignment.assignment_id.lower(),
                assignment.principal_id.lower(),
                target_id.lower(),
            )
            if identity not in seen:
                seen.add(identity)
                data.append(
                    {
                        "kind": generic_kind,
                        "data": {
                            "assignees": [
                                {
                                    "assignee": normalized,
                                    "objectId": target_id,
                                    "roleDefinitionId": role_guid,
                                }
                            ],
                            "objectId": target_id,
                        },
                    }
                )

        descriptor = _native_direct_descriptor(target_kind, role_guid)
        if descriptor is None:
            continue
        native_kind, collection_field, item_field, target_field = descriptor
        identity = (
            native_kind,
            assignment.assignment_id.lower(),
            assignment.principal_id.lower(),
            target_id.lower(),
        )
        if identity in seen:
            continue
        seen.add(identity)
        data.append(
            {
                "kind": native_kind,
                "data": {
                    collection_field: [
                        {item_field: normalized, target_field: target_id}
                    ],
                    target_field: target_id,
                },
            }
        )

    return {
        "data": data,
        "meta": {
            "type": "azure",
            "version": 5,
            "count": len(data),
            "generator": "bark_role_graph.py",
            "mode": "native-rbac",
        },
    }


def make_gathered(assignments: list[Assignment]) -> dict[str, Any]:
    data: list[dict[str, Any]] = []
    for assignment in assignments:
        data.append(
            {
                "roleName": assignment.role_name,
                "roleDefinitionId": assignment.role_definition_id,
                "principalId": assignment.principal_id,
                "principalType": assignment.principal_type,
                "authoredScope": assignment.authored_scope,
                "effectiveScope": assignment.effective_scope,
                "assignmentId": assignment.assignment_id,
                "source": assignment.source,
                "assignment": assignment.raw,
            }
        )
    return {
        "roleAssignments": data,
        "meta": {
            "type": "azure",
            "version": 5,
            "count": len(data),
            "generator": "bark_role_graph.py",
        },
    }


def json_bytes(payload: Any, pretty: bool) -> bytes:
    kwargs: dict[str, Any] = {"ensure_ascii": False}
    if pretty:
        kwargs["indent"] = 2
    else:
        kwargs["separators"] = (",", ":")
    return (json.dumps(payload, **kwargs) + "\n").encode("utf-8")


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
        os.replace(temporary_name, path)
    except BaseException:
        try:
            os.unlink(temporary_name)
        except OSError:
            pass
        raise


def atomic_write_json(path: Path, payload: Any, pretty: bool) -> None:
    atomic_write_bytes(path, json_bytes(payload, pretty))


def _native_shape_supported(data: list[Any], kind: str) -> bool:
    """Reject ARM-shaped records that share an AzureHound native kind.

    The ARM helper intentionally preserves raw ``properties`` for the
    permission analyzer.  Those records must not be merged into the native
    upload unless they have the exact AzureHound model shape; otherwise the
    importer can silently discard the relationship.
    """
    records = [
        item.get("data")
        for item in data
        if isinstance(item, dict) and item.get("kind") == kind
    ]
    if not records:
        return True
    for record in records:
        if not isinstance(record, dict):
            return False
        if kind == "AZManagementGroupRoleAssignment":
            if not isinstance(record.get("roleAssignments"), list):
                return False
            management_group_id = record.get("managementGroupId")
            if not isinstance(management_group_id, str) or not management_group_id.lower().startswith(
                "/providers/microsoft.management/managementgroups/"
            ):
                return False
            for row in record["roleAssignments"]:
                if not isinstance(row, dict) or not isinstance(
                    row.get("roleAssignment"), dict
                ):
                    return False
                row_group_id = row.get("managementGroupId")
                if not isinstance(row_group_id, str) or not row_group_id.lower().startswith(
                    "/providers/microsoft.management/managementgroups/"
                ):
                    return False
            continue
        if "properties" in record:
            return False
        if kind == "AZRoleEligibilityScheduleInstance":
            if not record.get("principalId") or not record.get("roleDefinitionId"):
                return False
        elif kind == "AZRoleManagementPolicyAssignment":
            if not record.get("policyId") or not record.get("roleDefinitionId"):
                return False
    return True


def classify_for_bundle(root: Any) -> BundleClassification:
    if isinstance(root, dict):
        graph = root.get("graph")
        if isinstance(graph, dict):
            nodes = graph.get("nodes")
            edges = graph.get("edges")
            if isinstance(nodes, list) and isinstance(edges, list):
                count = len(nodes) + len(edges)
                if count == 0:
                    return BundleClassification(
                        "do-not-upload",
                        "do-not-upload",
                        "open-graph",
                        "empty OpenGraph payload",
                    )
                return BundleClassification(
                    "upload",
                    "02-upload-opengraph",
                    "open-graph",
                    "BloodHound OpenGraph payload; upload after native Azure JSON",
                    count=count,
                )

        data = root.get("data")
        meta = root.get("meta")
        if isinstance(data, list) and isinstance(meta, dict):
            if meta.get("type") != "azure" or meta.get("version") != 5:
                return BundleClassification(
                    "do-not-upload",
                    "do-not-upload",
                    "json",
                    "not an AzureHound v5 envelope",
                    count=len(data),
                )
            if not data:
                return BundleClassification(
                    "do-not-upload",
                    "do-not-upload",
                    "azure-v5",
                    "empty AzureHound envelope",
                )

            kinds = tuple(
                sorted(
                    {
                        item.get("kind")
                        for item in data
                        if isinstance(item, dict)
                        and isinstance(item.get("kind"), str)
                    }
                )
            )
            if len(kinds) == 0 or any(
                not isinstance(item, dict)
                or not isinstance(item.get("kind"), str)
                for item in data
            ):
                return BundleClassification(
                    "do-not-upload",
                    "do-not-upload",
                    "azure-v5",
                    "Azure envelope contains records without a kind",
                    kinds=kinds,
                    count=len(data),
                )

            unsupported = sorted(set(kinds) - AZUREHOUND_NATIVE_KINDS)
            if unsupported:
                return BundleClassification(
                    "do-not-upload",
                    "do-not-upload",
                    "azure-v5",
                    "unsupported native kind(s): " + ", ".join(unsupported),
                    kinds=kinds,
                    count=len(data),
                )
            invalid_shapes = sorted(
                {
                    kind
                    for kind in kinds
                    if kind in _SHAPE_SENSITIVE_NATIVE_KINDS
                    and not _native_shape_supported(data, kind)
                }
            )
            if invalid_shapes:
                return BundleClassification(
                    "do-not-upload",
                    "do-not-upload",
                    "azure-v5",
                    "native kind(s) have non-AzureHound record shapes: "
                    + ", ".join(invalid_shapes),
                    kinds=kinds,
                    count=len(data),
                )
            return BundleClassification(
                "upload",
                "01-upload-native",
                "azure-v5",
                "supported AzureHound v5 payload",
                kinds=kinds,
                count=len(data),
            )

        if isinstance(root.get("roleAssignments"), list):
            return BundleClassification(
                "do-not-upload",
                "do-not-upload",
                "diagnostic",
                "gathered role-assignment review data",
                count=len(root["roleAssignments"]),
            )
        if isinstance(data, list):
            return BundleClassification(
                "do-not-upload",
                "do-not-upload",
                "collector-input",
                "raw collector/conversion input without an AzureHound v5 envelope",
                count=len(data),
            )

    return BundleClassification(
        "do-not-upload",
        "do-not-upload",
        "json",
        "not a supported AzureHound v5 or OpenGraph payload",
    )


def default_bundle_output(input_dir: Path, timestamp: str) -> Path:
    candidate = input_dir / f"{BUNDLE_DIR_PREFIX}{timestamp}"
    serial = 1
    while candidate.exists():
        candidate = input_dir / f"{BUNDLE_DIR_PREFIX}{timestamp}_{serial:03d}"
        serial += 1
    return candidate


def _safe_bundle_relative_path(name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts or not relative.name:
        raise ValueError(f"unsafe document path: {name}")
    return relative


def _native_record_priority(record: dict[str, Any]) -> int:
    """Order partial relationship nodes before complete entity nodes."""
    kind = record["kind"]
    if kind == "AZApp":
        # A service-principal conversion also emits a partial AZApp node.
        return 30
    if kind == "AZServicePrincipal":
        # App-role assignments emit partial service-principal nodes.
        return 20
    if kind in AZUREHOUND_ENTITY_KINDS:
        return 10
    return 0


def _native_app_role_assignment_safe(
    record: dict[str, Any],
    entity_kinds: dict[str, str],
    catalog: dict[tuple[str, str], dict[str, Any]],
) -> tuple[bool, str]:
    """Return whether BloodHound can ingest this app-role record correctly."""

    data = record.get("data")
    if not isinstance(data, dict):
        return False, "invalid-shape"
    source_kind = _app_role_principal_kind(data, entity_kinds)
    if source_kind != "AZServicePrincipal":
        return False, "non-service-principal"
    role_id = str(data.get("appRoleId") or "").lower()
    resource_id = str(data.get("resourceId") or "").lower()
    if role_id not in BLOODHOUND_NATIVE_APP_ROLE_IDS:
        return False, "unsupported-or-custom-role"
    indexed = catalog.get((resource_id, role_id))
    resource = indexed.get("resource", {}) if indexed else {}
    resource_app_id = str(data.get("appId") or resource.get("appId") or "").lower()
    if resource_app_id != MS_GRAPH_APP_ID:
        return False, "non-microsoft-graph-resource"
    return True, "supported-microsoft-graph-service-principal-role"


def merge_native_documents(
    documents: list[tuple[JsonDocument, dict[str, Any], BundleClassification]],
    identities: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Create one ordered AzureHound envelope from uploadable native inputs."""
    ordered: list[tuple[int, int, int, dict[str, Any]]] = []
    kinds: set[str] = set()
    parsed_sources = [(document, root) for document, root, _ in documents]
    entity_kinds = build_entity_kind_lookup(parsed_sources)
    app_role_catalog = build_app_role_catalog(parsed_sources)
    excluded_app_roles: dict[str, int] = {}
    for source_index, (_, root, _) in enumerate(documents):
        for record_index, record in enumerate(root["data"]):
            record = hydrate_managed_identities(record, identities or {})
            kind = record["kind"]
            if kind == "AZAppRoleAssignment":
                safe, reason = _native_app_role_assignment_safe(
                    record, entity_kinds, app_role_catalog
                )
                if not safe:
                    excluded_app_roles[reason] = excluded_app_roles.get(reason, 0) + 1
                    continue
            kinds.add(kind)
            ordered.append(
                (
                    _native_record_priority(record),
                    source_index,
                    record_index,
                    record,
                )
            )

    ordered.sort(key=lambda item: item[:3])
    data = [record for _, _, _, record in ordered]
    return (
        {
            "data": data,
            "meta": {
                "type": "azure",
                "version": 5,
                "count": len(data),
                "generator": "bark_role_graph.py",
                "mode": "ordered-native-merge",
                "appRoleAssignmentsExcluded": sum(excluded_app_roles.values()),
                "appRoleAssignmentExclusionReasons": excluded_app_roles,
            },
        },
        sorted(kinds),
    )


def make_opengraph_extension(
    parsed: Iterable[tuple[JsonDocument, Any]],
) -> dict[str, Any] | None:
    """Build a Structured OpenGraph schema for the graph payloads in a bundle."""

    node_kinds: set[str] = set()
    relationship_kinds: set[str] = set()
    traversable_relationships: set[str] = set()
    for _, root in parsed:
        graph = root.get("graph") if isinstance(root, dict) else None
        if not isinstance(graph, dict):
            continue
        for node in graph.get("nodes", []):
            if not isinstance(node, dict):
                continue
            for kind in node.get("kinds", []):
                if isinstance(kind, str) and kind.startswith("BARK_"):
                    node_kinds.add(kind)
        for edge in graph.get("edges", []):
            kind = edge.get("kind") if isinstance(edge, dict) else None
            if isinstance(kind, str) and kind.startswith("BARK_"):
                relationship_kinds.add(kind)
                properties = edge.get("properties")
                # Pathfinding is reserved for capability edges that the
                # permission analyzer proved after ABAC, deny, and PIM
                # resolution.  A relationship being observed is not enough:
                # Reader/custom role assignments and app-role structure do
                # not inherently represent an attack-path traversal.
                if (
                    isinstance(properties, dict)
                    and properties.get("confidence") == "confirmed"
                    and isinstance(properties.get("capability"), str)
                    and properties.get("capability")
                ):
                    traversable_relationships.add(kind)
    if not node_kinds and not relationship_kinds:
        return None

    return {
        "schema": {
            "name": "BARK_Azure_Permissions",
            "display_name": "BARK Azure Permissions",
            "version": "v1.0.0",
            "namespace": "BARK",
        },
        "node_kinds": [
            {
                "name": kind,
                "display_name": kind.removeprefix("BARK_").replace("_", " "),
                "description": "BARK OpenGraph Azure object",
                "is_display_kind": True,
                "icon": "key",
                "color": "#7C3AED",
            }
            for kind in sorted(node_kinds)
        ],
        "relationship_kinds": [
            {
                "name": kind,
                "description": "Permission or assignment relationship derived by BARK",
                "is_traversable": kind in traversable_relationships,
            }
            for kind in sorted(relationship_kinds)
        ],
    }


def create_upload_bundle(
    bundle_output: Path,
    parsed: list[tuple[JsonDocument, Any]],
    input_dir: Path,
    reporter: Reporter,
    part_file_count: int,
) -> dict[str, Any]:
    if bundle_output.exists():
        if not bundle_output.is_dir():
            raise ValueError(f"bundle output is not a directory: {bundle_output}")
        if any(bundle_output.iterdir()):
            raise ValueError(f"bundle output directory is not empty: {bundle_output}")
    if bundle_output == input_dir:
        raise ValueError("bundle output must be different from the input directory")

    parsed = list(parsed)
    native_edges = build_native_edge_records(parsed)
    if native_edges["data"] or native_edges["meta"]["excludedRecords"]:
        parsed.append((JsonDocument("AZNativeEdgeCoverage.json",
                                    json_bytes(native_edges, False), generated=True), native_edges))
    entries: list[dict[str, Any]] = []
    occupied: set[str] = set()
    counts = {"native": 0, "opengraph": 0, "do_not_upload": 0}
    native_principal_ids = {
        str(wrapper["data"]["id"]).upper(): wrapper["kind"]
        for _, payload in parsed
        if isinstance(payload, dict) and isinstance(payload.get("data"), list)
        for wrapper in payload["data"] if isinstance(wrapper, dict)
        if wrapper.get("kind") in {"AZUser", "AZGroup"}
        and isinstance(wrapper.get("data"), dict) and wrapper["data"].get("id")
    }
    classified = []
    for document, root in sorted(parsed, key=lambda item: item[0].name.lower()):
        classification = classify_for_bundle(root)
        if classification.directory == "02-upload-opengraph":
            safe_root = preserve_native_nodes(root, native_principal_ids)
            if safe_root != root:
                document = JsonDocument(
                    document.name, json_bytes(safe_root, False),
                    reassembled=document.reassembled, part_count=document.part_count,
                    generated=document.generated,
                )
                root = safe_root
                classification = classify_for_bundle(root)
        classified.append((document, root, classification))
    native_documents: list[
        tuple[JsonDocument, dict[str, Any], BundleClassification]
    ] = []

    for document, root, classification in classified:
        relative = _safe_bundle_relative_path(document.name)
        is_native = classification.directory == "01-upload-native"
        if is_native:
            # Preserve source material for auditing, but make accidental
            # multi-file upload impossible from either upload phase.
            if not isinstance(root, dict):
                raise ValueError(f"invalid native document: {document.name}")
            native_documents.append((document, root, classification))
            target = bundle_output / "do-not-upload/native-source" / relative
        else:
            target = bundle_output / classification.directory / relative
        target_key = str(target).lower()
        if target_key in occupied:
            raise ValueError(f"duplicate bundle output path: {target}")
        occupied.add(target_key)
        atomic_write_bytes(target, document.data)

        if is_native:
            counts["do_not_upload"] += 1
        elif classification.directory == "02-upload-opengraph":
            counts["opengraph"] += 1
        else:
            counts["do_not_upload"] += 1

        entry = {
            "source": document.name,
            "output": str(target.relative_to(bundle_output)),
            "action": "merged" if is_native else classification.action,
            "format": classification.format,
            "reason": (
                f"merged into 01-upload-native/{MERGED_NATIVE_FILENAME}; "
                "do not upload this source copy"
                if is_native
                else classification.reason
            ),
            "kinds": list(classification.kinds),
            "count": classification.count,
            "bytes": len(document.data),
            "sha256": hashlib.sha256(document.data).hexdigest(),
            "reassembled": document.reassembled,
            "partCount": document.part_count,
            "generated": document.generated,
        }
        if isinstance(root, dict) and root.get("meta", {}).get("unmatchedConditionalAccessPrincipals"):
            entry["unmatchedConditionalAccessPrincipals"] = root["meta"]["unmatchedConditionalAccessPrincipals"]
        if is_native:
            entry["mergedInto"] = f"01-upload-native/{MERGED_NATIVE_FILENAME}"
        entries.append(entry)

    merged_native: dict[str, Any] | None = None
    if native_documents:
        merged_payload, merged_kinds = merge_native_documents(native_documents, identity_index(parsed))
        merged_data = json_bytes(merged_payload, False)
        merged_target = (
            bundle_output / "01-upload-native" / MERGED_NATIVE_FILENAME
        )
        merged_key = str(merged_target).lower()
        if merged_key in occupied:
            raise ValueError(f"duplicate bundle output path: {merged_target}")
        occupied.add(merged_key)
        atomic_write_bytes(merged_target, merged_data)
        counts["native"] = 1
        merged_native = {
            "output": str(merged_target.relative_to(bundle_output)),
            "action": "upload",
            "format": "azure-v5",
            "reason": (
                "single ordered native upload; complete entity records follow "
                "relationship-generated placeholders"
            ),
            "kinds": merged_kinds,
            "count": len(merged_payload["data"]),
            "bytes": len(merged_data),
            "sha256": hashlib.sha256(merged_data).hexdigest(),
            "sourceCount": len(native_documents),
            "sources": [document.name for document, _, _ in native_documents],
            "appRoleAssignmentsExcluded": merged_payload["meta"][
                "appRoleAssignmentsExcluded"
            ],
            "appRoleAssignmentExclusionReasons": merged_payload["meta"][
                "appRoleAssignmentExclusionReasons"
            ],
            "ordering": [
                "relationship records",
                "complete entity records",
                "AZServicePrincipal records",
                "AZApp records",
            ],
        }

    extension = make_opengraph_extension(
        (document, root)
        for document, root, classification in classified
        if classification.directory == "02-upload-opengraph"
    )
    extension_manifest: dict[str, Any] | None = None
    if extension is not None:
        extension_target = bundle_output / "00-install-schema" / OPEN_GRAPH_EXTENSION_FILENAME
        extension_data = json_bytes(extension, True)
        atomic_write_bytes(extension_target, extension_data)
        extension_manifest = {
            "output": str(extension_target.relative_to(bundle_output)),
            "action": "install-before-data-upload",
            "format": "structured-opengraph-extension",
            "relationshipKinds": len(extension["relationship_kinds"]),
            "nodeKinds": len(extension["node_kinds"]),
            "sha256": hashlib.sha256(extension_data).hexdigest(),
        }

    manifest = {
        "schemaVersion": 3,
        "createdAt": datetime.now().astimezone().isoformat(timespec="seconds"),
        "inputDirectory": str(input_dir),
        "uploadOrder": [
            {
                "phase": 1,
                "directory": "01-upload-native",
                "description": "single ordered native AzureHound v5 JSON",
                "files": counts["native"],
            },
            {
                "phase": 2,
                "directory": "02-upload-opengraph",
                "description": "OpenGraph JSON; upload after phase 1 finishes",
                "files": counts["opengraph"],
            },
        ],
        "doNotUploadDirectory": "do-not-upload",
        "doNotUploadFiles": counts["do_not_upload"],
        "nativeSourceFilesMerged": len(native_documents),
        "nativeEdgeConversion": {"records": len(native_edges["data"]),
                                 "excludedRecords": native_edges["meta"]["excludedRecords"]},
        "mergedNative": merged_native,
        "openGraphExtension": extension_manifest,
        "sourcePartFilesExcluded": part_file_count,
        "warnings": list(reporter.warnings),
        "files": entries,
    }
    atomic_write_json(bundle_output / "BARK_UPLOAD_MANIFEST.json", manifest, True)

    instructions = (
        "BARK BloodHound upload bundle\n"
        "\n"
        "Requires property-based OpenGraph endpoint matching (BloodHound 9.0 supports it).\n"
        "Native references must resolve after phase 1; no placeholder native nodes are emitted.\n"
        "CAP observations are cap_policies properties on native users/groups; unmatched principals stay in audit data.\n"
        "\n"
        f"1. Install 00-install-schema/{OPEN_GRAPH_EXTENSION_FILENAME} as an OpenGraph "
        "extension. This makes confirmed BARK relationships traversable.\n"
        f"2. Upload only 01-upload-native/{MERGED_NATIVE_FILENAME}.\n"
        "3. Wait for that job to report Complete, then upload every JSON file under "
        "02-upload-opengraph in a NEW job.\n"
        "Never combine phases in one upload job or ZIP; file order is not guaranteed.\n"
        "Alternatively, after installing the schema, run from the BARK repository:\n"
        "  python3 bark_upload.py <bundle-directory> --username <bloodhound-user>\n"
        "This validates checksums and waits for phase 1 success before submitting phase 2.\n"
        "4. Do not upload the schema file as graph data, files under "
        "do-not-upload/native-source, elsewhere "
        "under do-not-upload, or any original .part file.\n"
        "\n"
        "Complete split sets were reassembled and all supported native records "
        "were merged in dependency-safe order. BARK_UPLOAD_MANIFEST.json "
        "records every decision and checksum.\n"
    )
    atomic_write_bytes(
        bundle_output / "UPLOAD_INSTRUCTIONS.txt", instructions.encode("utf-8")
    )
    return {"path": bundle_output, **counts}


def default_output(input_dir: Path, prefix: str, timestamp: str) -> Path:
    candidate = input_dir / f"{prefix}_{timestamp}.json"
    serial = 1
    while candidate.exists():
        candidate = input_dir / f"{prefix}_{timestamp}_{serial:03d}.json"
        serial += 1
    return candidate


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gather BARK ARM role-assignment downloads and create hybrid "
            "BloodHound-native and BARK OpenGraph RBAC outputs."
        )
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default=".",
        help="directory containing BARK JSON downloads (default: current directory)",
    )
    parser.add_argument(
        "--recursive", "-r", action="store_true", help="scan subdirectories recursively"
    )
    parser.add_argument(
        "--graph-output", "-o", help="OpenGraph output path (default: input directory)"
    )
    parser.add_argument(
        "--native-output",
        help="BloodHound-native RBAC output path (default: input directory)",
    )
    parser.add_argument(
        "--app-role-graph-output",
        help="Entra app-role OpenGraph output path (default: input directory)",
    )
    parser.add_argument(
        "--gather-output", "-g", help="canonical gathered assignment output path"
    )
    parser.add_argument(
        "--no-gather",
        action="store_true",
        help="skip the canonical gathered output (native and OpenGraph are still written)",
    )
    parser.add_argument(
        "--bundle-output",
        help=(
            "upload bundle directory (default: "
            "BARK_BloodHound_Bundle_<timestamp> under the input directory)"
        ),
    )
    parser.add_argument(
        "--no-bundle",
        action="store_true",
        help="write only the legacy graph/native/gather outputs",
    )
    parser.add_argument(
        "--standalone",
        action="store_true",
        help=(
            "declare BARK_* custom endpoint nodes instead of linking to existing "
            "native BloodHound Azure nodes"
        ),
    )
    parser.add_argument(
        "--pretty", action="store_true", help="pretty-print output instead of compact JSON"
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="return a failure status if any invalid/incomplete input is observed",
    )
    parser.add_argument(
        "--no-permission-analysis",
        action="store_true",
        help="skip permission-derived analysis and OpenGraph output",
    )
    parser.add_argument(
        "--include-potential-edges",
        action="store_true",
        help="include ABAC/deny-unknown findings as separately marked OpenGraph edges",
    )
    parser.add_argument(
        "--capability-catalog",
        help="JSON capability catalog (default: data/azure_privilege_capabilities.json)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    options = parse_args(sys.argv[1:] if argv is None else argv)
    input_dir = Path(options.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        print(f"[-] input directory does not exist: {input_dir}", file=sys.stderr)
        return 2
    if options.no_bundle and options.bundle_output:
        print("[-] --bundle-output cannot be used with --no-bundle", file=sys.stderr)
        return 2

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bundle_output: Path | None = None
    if not options.no_bundle:
        bundle_output = (
            Path(options.bundle_output).expanduser().resolve()
            if options.bundle_output
            else default_bundle_output(input_dir, timestamp)
        )
        if bundle_output == input_dir:
            print(
                "[-] bundle output must be different from the input directory",
                file=sys.stderr,
            )
            return 2
        if bundle_output.exists() and (
            not bundle_output.is_dir() or any(bundle_output.iterdir())
        ):
            print(
                f"[-] bundle output must be a new or empty directory: {bundle_output}",
                file=sys.stderr,
            )
            return 2

    reporter = Reporter()
    input_files = _files_under(input_dir, options.recursive)
    part_file_count = sum(1 for path in input_files if PART_RE.match(path.name))
    documents = load_documents(input_dir, options.recursive, reporter)
    if not documents:
        print(f"[-] no JSON input found under {input_dir}", file=sys.stderr)
        return 1

    parsed = parse_documents(documents, reporter)
    if not parsed:
        print(f"[-] no valid JSON input found under {input_dir}", file=sys.stderr)
        return 1
    role_lookup = build_role_definition_lookup(parsed)
    resource_kinds = build_resource_kind_lookup(parsed)
    assignments = gather_assignments(parsed, role_lookup, reporter)
    generated: list[tuple[JsonDocument, Any]] = []
    graph_output: Path | None = None
    native_output: Path | None = None
    gather_output: Path | None = None
    permission_graph_output: Path | None = None
    permission_findings_output: Path | None = None
    app_role_graph_output: Path | None = None
    graph: dict[str, Any] | None = None
    native_rbac: dict[str, Any] | None = None
    app_role_graph = make_app_role_graph(
        parsed, reporter=reporter, standalone=options.standalone
    )

    if app_role_graph["graph"]["edges"]:
        app_role_graph_output = (
            Path(options.app_role_graph_output).expanduser().resolve()
            if options.app_role_graph_output
            else default_output(input_dir, "AZAppRoleGraph", timestamp)
        )
        app_role_graph_data = json_bytes(app_role_graph, options.pretty)
        atomic_write_bytes(app_role_graph_output, app_role_graph_data)
        generated.append(
            (
                JsonDocument(
                    app_role_graph_output.name,
                    app_role_graph_data,
                    generated=True,
                ),
                app_role_graph,
            )
        )

    if assignments:
        graph_output = (
            Path(options.graph_output).expanduser().resolve()
            if options.graph_output
            else default_output(input_dir, "AZRoleGraph", timestamp)
        )
        graph = make_graph(
            assignments,
            standalone=options.standalone,
            resource_kinds=resource_kinds,
        )
        graph_data = json_bytes(graph, options.pretty)
        atomic_write_bytes(graph_output, graph_data)
        generated.append(
            (
                JsonDocument(graph_output.name, graph_data, generated=True),
                graph,
            )
        )

        native_output = (
            Path(options.native_output).expanduser().resolve()
            if options.native_output
            else default_output(input_dir, "AZNativeRBAC", timestamp)
        )
        native_rbac = make_native_rbac(assignments, resource_kinds)
        native_data = json_bytes(native_rbac, options.pretty)
        atomic_write_bytes(native_output, native_data)
        generated.append(
            (
                JsonDocument(native_output.name, native_data, generated=True),
                native_rbac,
            )
        )

        if not options.no_gather:
            gather_output = (
                Path(options.gather_output).expanduser().resolve()
                if options.gather_output
                else default_output(input_dir, "AZRoleAssignments_Gathered", timestamp)
            )
            gathered = make_gathered(assignments)
            gathered_data = json_bytes(gathered, options.pretty)
            atomic_write_bytes(gather_output, gathered_data)
            generated.append(
                (
                    JsonDocument(gather_output.name, gathered_data, generated=True),
                    gathered,
                )
            )
    else:
        reporter.warn(
            "no ARM role assignments found; no RoleGraph/native RBAC output was "
            "created, but uploadable JSON will still be bundled"
        )

    if not options.no_permission_analysis:
        permission_graph, permission_findings = bark_permission_analysis.analyze(
            assignments,
            parsed,
            scope_kind,
            principal_kind,
            resource_kinds=resource_kinds,
            standalone=options.standalone,
            include_potential=options.include_potential_edges,
            capability_path=(
                Path(options.capability_catalog).expanduser().resolve()
                if options.capability_catalog
                else None
            ),
        )
        permission_edges = permission_graph.get("graph", {}).get("edges", [])
        permission_findings_list = permission_findings.get("permissionFindings", [])
        if permission_edges or permission_findings_list:
            permission_graph_output = default_output(
                input_dir, "AZPermissionGraph", timestamp
            )
            permission_findings_output = default_output(
                input_dir, "AZPermissionFindings", timestamp
            )
            permission_graph_data = json_bytes(permission_graph, options.pretty)
            permission_findings_data = json_bytes(permission_findings, options.pretty)
            atomic_write_bytes(permission_graph_output, permission_graph_data)
            atomic_write_bytes(permission_findings_output, permission_findings_data)
            generated.extend(
                [
                    (
                        JsonDocument(
                            permission_graph_output.name,
                            permission_graph_data,
                            generated=True,
                        ),
                        permission_graph,
                    ),
                    (
                        JsonDocument(
                            permission_findings_output.name,
                            permission_findings_data,
                            generated=True,
                        ),
                        permission_findings,
                    ),
                ]
            )

    bundle_summary: dict[str, Any] | None = None
    if bundle_output is not None:
        try:
            bundle_summary = create_upload_bundle(
                bundle_output,
                parsed + generated,
                input_dir,
                reporter,
                part_file_count,
            )
        except (OSError, ValueError) as exc:
            print(f"[-] could not create upload bundle: {exc}", file=sys.stderr)
            return 2

    reassembled = sum(1 for document in documents if document.reassembled)
    print(
        f"[+] scanned {len(documents)} JSON document(s); "
        f"reassembled {reassembled} part group(s)"
    )
    if assignments and graph is not None and native_rbac is not None:
        nodes = len(graph["graph"]["nodes"])
        referenced_nodes = len(
            {
                endpoint_id(endpoint).lower()
                for edge in graph["graph"]["edges"]
                for endpoint in (edge["start"], edge["end"])
            }
        )
        edges = len(graph["graph"]["edges"])
        print(
            f"[+] gathered {len(assignments)} effective role assignment(s); "
            f"resolved {len(role_lookup) // 2} role definition(s)"
        )
        if gather_output is not None:
            print(f"[+] gathered output: {gather_output}")
        mode = "standalone" if options.standalone else "native-link"
        print(
            f"[+] OpenGraph output: {graph_output} "
            f"({mode}, {nodes} declared nodes, {referenced_nodes} referenced nodes, "
            f"{edges} edges)"
        )
        print(
            f"[+] native RBAC output: {native_output} "
            f"({native_rbac['meta']['count']} AzureHound-compatible record(s))"
        )
    if permission_graph_output is not None and permission_findings_output is not None:
        permission_meta = permission_findings["meta"]
        print(
            f"[+] permission graph output: {permission_graph_output} "
            f"({permission_graph['meta']['edgeCount']} edge(s))"
        )
        print(
            f"[+] permission findings: {permission_findings_output} "
            f"({permission_meta['confirmed']} confirmed, "
            f"{permission_meta['unknown']} unknown, "
            f"{permission_meta['eligible']} eligible)"
        )
    if app_role_graph_output is not None:
        app_role_meta = app_role_graph["meta"]
        print(
            f"[+] app-role OpenGraph output: {app_role_graph_output} "
            f"({app_role_meta['assignments']} assignment(s), "
            f"{app_role_meta['edgeCount']} edge(s), "
            f"{app_role_meta['unresolvedRoles']} unresolved role name(s))"
        )
    if bundle_summary is not None:
        print(f"[+] BloodHound upload bundle: {bundle_summary['path']}")
        print(
            f"[+] upload phase 1: {bundle_summary['native']} AzureHound v5 file(s); "
            f"phase 2: {bundle_summary['opengraph']} OpenGraph file(s)"
        )
        print(
            f"[+] do not upload: {bundle_summary['do_not_upload']} source/support/empty "
            f"file(s); excluded {part_file_count} source part file(s)"
        )

    if options.strict and reporter.warnings:
        print(
            f"[-] strict mode failed with {len(reporter.warnings)} warning(s)",
            file=sys.stderr,
        )
        return 1
    if not assignments and not app_role_graph["graph"]["edges"] and options.no_bundle:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
