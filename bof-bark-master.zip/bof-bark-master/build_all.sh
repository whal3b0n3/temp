#!/usr/bin/env bash
# build_all.sh -- compile every BARKKAI BOF into bofs/<category>/<name>.{x64,x86}.o
#
# Requirements: x86_64-w64-mingw32-gcc and i686-w64-mingw32-gcc in PATH.
set -u

CC64="x86_64-w64-mingw32-gcc"
CC86="i686-w64-mingw32-gcc"
CFLAGS="-masm=intel -Os -Wall -Wno-unused-parameter -Wno-incompatible-pointer-types -mno-stack-arg-probe"

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
OUT="$ROOT/bofs"

ok=0
fail=0
failures=()

for src_file in $(find "$SRC" -type f -name '*.c' | sort); do
    rel="${src_file#$SRC/}"           # category/name.c
    category="${rel%/*}"
    base="$(basename "$rel" .c)"
    out_dir="$OUT/$category"
    mkdir -p "$out_dir"

    obj64="$out_dir/$base.x64.o"
    obj86="$out_dir/$base.x86.o"

    if $CC64 $CFLAGS -o "$obj64" -c "$src_file" 2>/tmp/bark.err && \
       $CC86 $CFLAGS -o "$obj86" -c "$src_file" 2>>/tmp/bark.err; then
        ok=$((ok + 1))
        printf '[+] %-50s ok\n' "$category/$base"
    else
        fail=$((fail + 1))
        failures+=("$category/$base")
        printf '[-] %-50s FAIL\n' "$category/$base"
        sed 's/^/      /' /tmp/bark.err
    fi
done

echo
echo "================================================================"
echo " Built : $ok"
echo " Failed: $fail"
if [ "$fail" -gt 0 ]; then
    echo " Failures:"
    for f in "${failures[@]}"; do echo "   - $f"; done
fi
echo "================================================================"
exit $fail
