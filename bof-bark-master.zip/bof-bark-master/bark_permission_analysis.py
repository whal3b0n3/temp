#!/usr/bin/env python3
"""Permission-derived Azure RBAC analysis for BARK's client-side converter."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

from bark_opengraph import native_endpoint, standalone_id
from bark_abac import TriState, evaluate_condition, request_context


ANALYSIS_VERSION = "1.0"
_PATTERN_CACHE: dict[str, re.Pattern[str]] = {}


@dataclass(frozen=True)
class Capability:
    identifier: str
    edge_kind: str
    category: str
    requirements: tuple[tuple[str, ...], ...]
    target_kinds: tuple[str, ...]
    description: str
    data_plane: bool = False


@dataclass(frozen=True)
class PermissionBlock:
    actions: tuple[str, ...]
    not_actions: tuple[str, ...]
    data_actions: tuple[str, ...]
    not_data_actions: tuple[str, ...]
    condition: str | None = None
    condition_version: str | None = None


@dataclass(frozen=True)
class RoleDefinition:
    identifier: str
    guid: str
    name: str
    role_type: str
    assignable_scopes: tuple[str, ...]
    permissions: tuple[PermissionBlock, ...]
    source: str


@dataclass(frozen=True)
class AuthorizationExtra:
    kind: str
    raw: dict[str, Any]
    properties: dict[str, Any]
    source: str


@dataclass(frozen=True)
class DenySnapshotCoverage:
    """Scopes whose deny-assignment enumeration completed successfully.

    A deny record can prove that an operation is denied even when collection
    was partial.  The absence of a matching deny is only authoritative when a
    successful collector scope covers the target being analysed.
    """

    successful_scopes: frozenset[str]
    failed_scopes: frozenset[str]
    requested_scopes: frozenset[str]
    metadata_files: int = 0
    incomplete_metadata_files: int = 0

    def covers(
        self, target_scope: str, scope_parents: dict[str, str] | None = None
    ) -> bool:
        # A failed request for the target itself (or one of its ancestors)
        # must win over a successful, broader snapshot.  Otherwise a partial
        # management-group/subscription collection could incorrectly turn the
        # absence of a deny assignment into an authoritative allow decision.
        if any(
            _scope_within(target_scope, scope, scope_parents)
            for scope in self.failed_scopes
        ):
            return False
        return any(
            _scope_within(target_scope, scope, scope_parents)
            for scope in self.successful_scopes
        )

    @property
    def complete(self) -> bool:
        return (
            self.metadata_files > 0
            and self.incomplete_metadata_files == 0
            and not self.failed_scopes
            and self.requested_scopes <= self.successful_scopes
        )


def _lower(value: Any) -> str:
    return str(value or "").strip().lower()


def _guid(value: str) -> str:
    return value.rstrip("/").rsplit("/", 1)[-1].lower()


def _iter_wrappers(parsed: Iterable[tuple[Any, Any]]) -> Iterable[tuple[str, dict[str, Any], str]]:
    for document, root in parsed:
        if not isinstance(root, dict) or not isinstance(root.get("data"), list):
            continue
        for wrapper in root["data"]:
            if not isinstance(wrapper, dict):
                continue
            kind = wrapper.get("kind")
            data = wrapper.get("data")
            if isinstance(kind, str) and isinstance(data, dict):
                yield kind, data, getattr(document, "name", "")


def load_capabilities(path: Path | None = None) -> tuple[Capability, ...]:
    selected = path or Path(__file__).with_name("data") / "azure_privilege_capabilities.json"
    try:
        payload = json.loads(selected.read_text(encoding="utf-8"))
        rows = payload.get("capabilities", [])
    except (OSError, json.JSONDecodeError, AttributeError):
        rows = []
    result: list[Capability] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        requirements = tuple(
            tuple(str(operation) for operation in group if str(operation).strip())
            for group in row.get("requirements", [])
            if isinstance(group, list) and group
        )
        if not requirements:
            continue
        result.append(
            Capability(
                str(row.get("id", "")),
                str(row.get("edgeKind", "BARK_Permission")),
                str(row.get("category", "azure")),
                requirements,
                tuple(str(kind) for kind in row.get("targetKinds", [])),
                str(row.get("description", "")),
                bool(row.get("dataPlane", False) or str(row.get("plane", "")).lower() == "data"),
            )
        )
    return tuple(result)


def parse_role_definitions(parsed: Iterable[tuple[Any, Any]]) -> dict[str, RoleDefinition]:
    definitions: dict[str, RoleDefinition] = {}
    for kind, raw, source in _iter_wrappers(parsed):
        if kind.lower() != "azroledefinition":
            continue
        properties = raw.get("properties")
        if not isinstance(properties, dict):
            continue
        identifier = raw.get("id") or raw.get("name")
        if not isinstance(identifier, str) or not identifier:
            continue
        blocks: list[PermissionBlock] = []
        for permission in properties.get("permissions", []):
            if not isinstance(permission, dict):
                continue
            blocks.append(
                PermissionBlock(
                    tuple(str(value) for value in permission.get("actions", []) if isinstance(value, str)),
                    tuple(str(value) for value in permission.get("notActions", []) if isinstance(value, str)),
                    tuple(str(value) for value in permission.get("dataActions", []) if isinstance(value, str)),
                    tuple(str(value) for value in permission.get("notDataActions", []) if isinstance(value, str)),
                    permission.get("condition") if isinstance(permission.get("condition"), str) else None,
                    permission.get("conditionVersion") if isinstance(permission.get("conditionVersion"), str) else None,
                )
            )
        record = RoleDefinition(
            identifier=identifier,
            guid=_guid(identifier),
            name=str(properties.get("roleName") or raw.get("name") or "Unknown"),
            role_type=str(properties.get("type") or ""),
            assignable_scopes=tuple(str(value) for value in properties.get("assignableScopes", []) if isinstance(value, str)),
            permissions=tuple(blocks),
            source=source,
        )
        definitions[record.guid] = record
        definitions[_lower(identifier)] = record
    return definitions


def collect_authorization_extras(parsed: Iterable[tuple[Any, Any]]) -> list[AuthorizationExtra]:
    wanted = {
        "azdenyassignment",
        "azroleeligibilityscheduleinstance",
        "azroleassignmentscheduleinstance",
        "azrolemanagementpolicyassignment",
        "azrolemanagementpolicy",
    }
    extras: list[AuthorizationExtra] = []
    for kind, raw, source in _iter_wrappers(parsed):
        if kind.lower() not in wanted:
            continue
        properties = raw.get("properties")
        extras.append(
            AuthorizationExtra(
                kind=kind,
                raw=raw,
                properties=properties if isinstance(properties, dict) else {},
                source=source,
            )
        )
    return extras


def collect_deny_snapshot_coverage(
    parsed: Iterable[tuple[Any, Any]],
) -> DenySnapshotCoverage:
    """Read explicit per-scope completion metadata from deny snapshots.

    Legacy files and files produced after a failed HTTP page are deliberately
    not treated as complete merely because their filename exists.  New ARM
    collectors write ``meta.collection`` with requested, successful, and
    failed scope arrays.
    """

    successful: set[str] = set()
    failed: set[str] = set()
    requested: set[str] = set()
    metadata_files = 0
    incomplete_metadata_files = 0
    for document, root in parsed:
        if not isinstance(root, dict):
            continue
        # JsonDocument.name is relative to the input directory when recursive
        # scanning is enabled.  Match the basename so deny metadata is not
        # silently ignored merely because files are grouped in a subdirectory.
        name = _lower(getattr(document, "name", "")).replace("\\", "/").rsplit("/", 1)[-1]
        wrappers = root.get("data")
        contains_deny = name.startswith("azdenyassignment") or (
            isinstance(wrappers, list)
            and any(
                isinstance(wrapper, dict)
                and _lower(wrapper.get("kind")) == "azdenyassignment"
                for wrapper in wrappers
            )
        )
        if not contains_deny:
            continue
        meta = root.get("meta")
        collection = meta.get("collection") if isinstance(meta, dict) else None
        if not isinstance(collection, dict):
            continue
        metadata_files += 1
        if collection.get("complete") is not True:
            incomplete_metadata_files += 1

        local_requested: set[str] = set()
        local_successful: set[str] = set()
        local_failed: set[str] = set()

        def add_scopes(destination: set[str], values: Any) -> None:
            if not isinstance(values, list):
                return
            destination.update(
                _lower(value).rstrip("/")
                for value in values
                if isinstance(value, str) and value.strip()
            )

        add_scopes(local_requested, collection.get("requestedScopes"))
        add_scopes(local_successful, collection.get("successfulScopes"))
        add_scopes(local_failed, collection.get("failedScopes"))

        # Single-scope collectors may use a scalar scope.  It is accepted only
        # when they explicitly state that collection completed.
        scalar_scope = collection.get("scope")
        if isinstance(scalar_scope, str) and scalar_scope.strip():
            normalized = _lower(scalar_scope).rstrip("/")
            local_requested.add(normalized)
            if collection.get("complete") is True:
                local_successful.add(normalized)
            else:
                local_failed.add(normalized)

        if collection.get("complete") is False:
            # If a producer omitted failedScopes, conservatively mark every
            # requested scope not explicitly successful as failed.
            local_failed.update(local_requested - local_successful)

        requested.update(local_requested)
        successful.update(local_successful)
        failed.update(local_failed)

    successful.difference_update(failed)
    return DenySnapshotCoverage(
        frozenset(successful),
        frozenset(failed),
        frozenset(requested),
        metadata_files,
        incomplete_metadata_files,
    )


def has_deny_assignment_snapshot(parsed: Iterable[tuple[Any, Any]]) -> bool:
    """Compatibility wrapper for callers that need whole-snapshot status."""

    return collect_deny_snapshot_coverage(parsed).complete


def collect_group_members(parsed: Iterable[tuple[Any, Any]]) -> dict[str, list[tuple[str, str]]]:
    """Return direct group membership as (object id, principal type) pairs."""
    members: dict[str, list[tuple[str, str]]] = {}
    for kind, raw, _source in _iter_wrappers(parsed):
        if kind.lower() != "azgroupmember" or not isinstance(raw, dict):
            continue
        group_id = raw.get("groupId")
        if not isinstance(group_id, str) or not group_id:
            continue
        rows = raw.get("members")
        if not isinstance(rows, list):
            continue
        bucket = members.setdefault(_lower(group_id), [])
        for row in rows:
            member = row.get("member") if isinstance(row, dict) else None
            if isinstance(member, dict):
                member_id = member.get("id") or member.get("objectId")
                odata_type = _lower(member.get("@odata.type"))
                principal_type = (
                    "User" if "user" in odata_type else
                    "Group" if "group" in odata_type else
                    "ServicePrincipal" if "serviceprincipal" in odata_type else
                    ""
                )
            else:
                member_id = member
                principal_type = ""
            if isinstance(member_id, str) and member_id:
                pair = (_lower(member_id), principal_type)
                if pair not in bucket:
                    bucket.append(pair)
    return members


def group_membership_snapshot_complete(
    parsed: Iterable[tuple[Any, Any]],
) -> bool:
    """Return whether Graph group parents and every members page completed.

    Relationship chunks intentionally remain valid/uploadable when one parent
    fails.  A final metadata-only envelope records whether that partial data is
    complete enough for negative ("not a member") permission conclusions.
    Legacy snapshots without this explicit marker are treated as incomplete.
    """

    saw_complete = False
    saw_incomplete = False
    for document, root in parsed:
        if not isinstance(root, dict):
            continue
        name = _lower(getattr(document, "name", "")).replace("\\", "/").rsplit("/", 1)[-1]
        wrappers = root.get("data")
        contains_group_members = name.startswith("azgroupmember") or (
            isinstance(wrappers, list)
            and any(
                isinstance(wrapper, dict)
                and _lower(wrapper.get("kind")) == "azgroupmember"
                for wrapper in wrappers
            )
        )
        if not contains_group_members:
            continue
        meta = root.get("meta")
        collection = meta.get("collection") if isinstance(meta, dict) else None
        if not isinstance(collection, dict):
            continue
        if collection.get("complete") is True:
            saw_complete = True
        else:
            saw_incomplete = True
    return saw_complete and not saw_incomplete


def expand_group_members(
    group_id: str,
    members: dict[str, list[tuple[str, str]]],
) -> list[tuple[str, str]]:
    """Expand nested groups while preventing cycles in malformed snapshots."""
    result: list[tuple[str, str]] = []
    visited: set[str] = set()
    queue = [(_lower(group_id), "Group")]
    while queue:
        current, _type = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        for member_id, member_type in members.get(current, []):
            if member_id in members and member_type.lower() == "group":
                queue.append((member_id, "Group"))
                continue
            if not member_type:
                # A missing @odata.type is not enough evidence to invent a
                # User endpoint.  Keeping it out prevents AZBase/wrong-kind
                # permission edges and lets the native identity collector
                # remain the source of truth for principal typing.
                continue
            pair = (member_id, member_type)
            if pair not in result:
                result.append(pair)
    return result


def collect_principal_ancestor_groups(
    members: dict[str, list[tuple[str, str]]],
) -> dict[str, set[str]]:
    """Return every direct and transitive group that contains each principal."""

    direct_parents: dict[str, set[str]] = {}
    for group_id, rows in members.items():
        for member_id, _member_type in rows:
            direct_parents.setdefault(member_id, set()).add(group_id)

    ancestors: dict[str, set[str]] = {}
    for principal_id in direct_parents:
        result: set[str] = set()
        queue = list(direct_parents.get(principal_id, set()))
        while queue:
            group_id = queue.pop(0)
            if group_id in result:
                continue
            result.add(group_id)
            queue.extend(direct_parents.get(group_id, set()) - result)
        ancestors[principal_id] = result
    return ancestors


def collect_scope_parents(parsed: Iterable[tuple[Any, Any]]) -> dict[str, str]:
    """Build child->parent links from management-group descendant records."""
    parents: dict[str, str] = {}
    for kind, raw, _source in _iter_wrappers(parsed):
        if kind.lower() != "azmanagementgroupdescendant" or not isinstance(raw, dict):
            continue
        child = raw.get("id") or raw.get("scope")
        properties = raw.get("properties") if isinstance(raw.get("properties"), dict) else raw
        parent = properties.get("parentId") or properties.get("parentScope")
        parent_value = properties.get("parent")
        if isinstance(parent_value, dict):
            parent = parent_value.get("id") or parent_value.get("name")
        if isinstance(child, str) and isinstance(parent, str) and parent:
            if not parent.startswith("/"):
                parent = (
                    "/providers/Microsoft.Management/managementGroups/" + parent
                )
            parents[_lower(child)] = _lower(parent)
    return parents


def _compiled_pattern(pattern: str) -> re.Pattern[str]:
    key = _lower(pattern)
    if key not in _PATTERN_CACHE:
        _PATTERN_CACHE[key] = re.compile("^" + re.escape(key).replace(r"\*", ".*") + "$")
    return _PATTERN_CACHE[key]


def operation_matches(pattern: str, operation: str) -> bool:
    return bool(_compiled_pattern(pattern).match(_lower(operation)))


def _block_allows(block: PermissionBlock, operation: str, data_plane: bool) -> bool:
    allows = block.data_actions if data_plane else block.actions
    excludes = block.not_data_actions if data_plane else block.not_actions
    return any(operation_matches(pattern, operation) for pattern in allows) and not any(
        operation_matches(pattern, operation) for pattern in excludes
    )


def _role_allows(
    role: RoleDefinition,
    operation: str,
    assignment_context: dict[str, Any],
    data_plane: bool = False,
) -> TriState:
    matching_blocks = [block for block in role.permissions if _block_allows(block, operation, data_plane)]
    if not matching_blocks:
        return TriState.FALSE
    states = [evaluate_condition(block.condition, assignment_context) for block in matching_blocks]
    if any(state is TriState.TRUE for state in states):
        return TriState.TRUE
    return TriState.UNKNOWN


def _privileged_role(role: RoleDefinition) -> bool:
    name = _lower(role.name)
    if any(value in name for value in ("owner", "user access administrator", "role based access control administrator")):
        return True
    for block in role.permissions:
        if any(
            operation_matches(pattern, "Microsoft.Authorization/roleAssignments/write")
            or operation_matches(pattern, "Microsoft.Authorization/roleDefinitions/write")
            for pattern in block.actions
        ):
            return True
    return False


def _role_assignable_at(
    role: RoleDefinition, scope: str, scope_parents: dict[str, str] | None = None
) -> bool:
    if not role.assignable_scopes:
        return False
    return any(_scope_within(scope, assignable, scope_parents) for assignable in role.assignable_scopes)


def _role_assignment_write_state(
    role: RoleDefinition,
    assignment: Any,
    definitions: dict[str, RoleDefinition],
    effective_scope: str,
    escalation_only: bool,
    scope_parents: dict[str, str] | None = None,
) -> tuple[TriState, list[str]]:
    candidates = {
        role.guid: role
        for role in definitions.values()
        if isinstance(role, RoleDefinition)
        and len(role.guid) > 0
        and _role_assignable_at(role, effective_scope, scope_parents)
        and (not escalation_only or _privileged_role(role))
    }
    if not candidates:
        return TriState.UNKNOWN, []
    states: list[TriState] = []
    allowed: list[str] = []
    # In an assignment-write condition, @Request PrincipalId/PrincipalType
    # describes the prospective assignee, not the caller who holds `role`.
    # The concrete assignee is not present in a capability edge, so evaluate
    # the existential question over known principal types and leave PrincipalId
    # absent.  Conditions requiring a particular target object ID therefore
    # remain UNKNOWN instead of being evaluated against the caller's ID.
    target_principal_types = ("User", "Group", "ServicePrincipal")
    for candidate in candidates.values():
        condition = _record_properties(assignment).get("condition")
        if isinstance(assignment, dict):
            condition = assignment.get("condition")
        candidate_states: list[TriState] = []
        for target_type in target_principal_types:
            context = request_context(
                "Microsoft.Authorization/roleAssignments/write",
                None,
                target_type,
                candidate.guid,
            )
            role_state = _role_allows(role, "Microsoft.Authorization/roleAssignments/write", context)
            assignment_state = evaluate_condition(condition, context)
            if role_state is TriState.FALSE or assignment_state is TriState.FALSE:
                candidate_states.append(TriState.FALSE)
            elif role_state is TriState.UNKNOWN or assignment_state is TriState.UNKNOWN:
                candidate_states.append(TriState.UNKNOWN)
            else:
                candidate_states.append(TriState.TRUE)
        state = (
            TriState.TRUE
            if any(value is TriState.TRUE for value in candidate_states)
            else TriState.UNKNOWN
            if any(value is TriState.UNKNOWN for value in candidate_states)
            else TriState.FALSE
        )
        states.append(state)
        if state is TriState.TRUE:
            allowed.append(candidate.guid)
    if any(state is TriState.TRUE for state in states):
        return TriState.TRUE, sorted(set(allowed))
    if any(state is TriState.UNKNOWN for state in states):
        return TriState.UNKNOWN, []
    return TriState.FALSE, []


def _permission_state_for_operation(
    role: RoleDefinition,
    assignment: Any,
    definitions: dict[str, RoleDefinition],
    operation: str,
    effective_scope: str,
    escalation_only: bool,
    scope_parents: dict[str, str] | None = None,
    data_plane: bool = False,
) -> tuple[TriState, list[str]]:
    if operation.lower() == "microsoft.authorization/roleassignments/write":
        return _role_assignment_write_state(
            role, assignment, definitions, effective_scope, escalation_only,
            scope_parents,
        )
    principal_id = (
        str(assignment.get("principalId") or "")
        if isinstance(assignment, dict)
        else str(getattr(assignment, "principal_id", ""))
    )
    principal_type = (
        str(assignment.get("principalType") or "")
        if isinstance(assignment, dict)
        else str(getattr(assignment, "principal_type", ""))
    )
    role_id = (
        str(assignment.get("roleDefinitionId") or "")
        if isinstance(assignment, dict)
        else str(getattr(assignment, "role_definition_id", ""))
    )
    context = request_context(
        operation,
        principal_id,
        principal_type,
        role_id,
    )
    return _role_allows(role, operation, context, data_plane=data_plane), []


def _scope_within(scope: str, parent: str, scope_parents: dict[str, str] | None = None) -> bool:
    child = _lower(scope).rstrip("/")
    ancestor = _lower(parent).rstrip("/")
    if ancestor in {"", "/"}:
        return True
    if child == ancestor or child.startswith(ancestor + "/"):
        return True
    visited: set[str] = set()
    while child and child not in visited:
        visited.add(child)
        parents = scope_parents or {}
        mapped_parent = parents.get(child)
        if not mapped_parent:
            # Descendant snapshots map subscription or child-management-group
            # scopes, while the target may be a resource several ARM segments
            # below that scope.  Walk through the longest mapped prefix before
            # following the explicit management-group ancestry.
            mapped_children = (
                candidate
                for candidate in parents
                if child.startswith(candidate.rstrip("/") + "/")
            )
            nearest = max(mapped_children, key=len, default="")
            mapped_parent = parents.get(nearest, "") if nearest else ""
        child = _lower(mapped_parent).rstrip("/")
        if child == ancestor:
            return True
    return False


def _target_scopes(
    assignment: Any,
    capability: Capability,
    scope_kind: Callable[[str, dict[str, str] | None], str],
    resource_kinds: dict[str, str],
    scope_parents: dict[str, str] | None = None,
) -> list[tuple[str, str]]:
    effective = str(getattr(assignment, "effective_scope", ""))
    if not effective:
        return []
    kind = scope_kind(effective, resource_kinds)
    targets: list[tuple[str, str]] = []
    if kind in capability.target_kinds:
        targets.append((effective, kind))
    targets.extend(
        (identifier, resource_kind)
        for identifier, resource_kind in resource_kinds.items()
        if resource_kind in capability.target_kinds and _scope_within(identifier, effective, scope_parents)
    )
    return list(dict.fromkeys(targets))


def _extra_assignment(extra: AuthorizationExtra) -> dict[str, Any] | None:
    properties = extra.properties
    if not properties.get("principalId") or not properties.get("roleDefinitionId") or not properties.get("scope"):
        return None
    if extra.kind.lower() == "azroleeligibilityscheduleinstance":
        state = "eligible"
    elif extra.kind.lower() == "azroleassignmentscheduleinstance":
        state = "active"
    else:
        return None
    return {
        "roleName": str(properties.get("roleDefinitionName") or "Unknown"),
        "roleDefinitionId": str(properties.get("roleDefinitionId")),
        "principalId": str(properties.get("principalId")),
        "principalType": str(properties.get("principalType") or ""),
        "scope": str(properties.get("scope")),
        "assignmentId": str(extra.raw.get("id") or extra.raw.get("name") or ""),
        "condition": properties.get("condition"),
        "conditionVersion": properties.get("conditionVersion"),
        "state": state,
        "startDateTime": properties.get("startDateTime"),
        "endDateTime": properties.get("endDateTime"),
        "status": properties.get("status"),
        "source": extra.source,
    }


def _now_active(record: dict[str, Any], now: datetime) -> bool:
    status = _lower(record.get("status"))
    if not status or status.startswith("pending"):
        return False
    accepted_statuses = {
        "accepted",
        "activated",
        "active",
        "assigned",
        "granted",
        "provisioned",
        "schedulecreated",
    }
    if record.get("state") == "eligible":
        accepted_statuses.update({"eligiblescheduled", "eligibilityscheduled"})
    if status not in accepted_statuses:
        return False
    for key, lower_bound in (("startDateTime", False), ("endDateTime", True)):
        value = record.get(key)
        if not isinstance(value, str) or not value:
            continue
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return False
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        if not lower_bound and now < parsed:
            return False
        if lower_bound and now >= parsed:
            return False
    return True


def _record_properties(assignment: Any) -> dict[str, Any]:
    raw = getattr(assignment, "raw", {})
    properties = raw.get("properties") if isinstance(raw, dict) else None
    return properties if isinstance(properties, dict) else {}


def _pim_policy_summary(
    extras: list[AuthorizationExtra], scope: str, role_definition_id: str = ""
) -> dict[str, Any]:
    """Summarize activation controls without guessing that activation succeeds."""
    policies: list[str] = []
    controls: set[str] = set()
    unknown = False
    normalized_scope = _lower(scope).rstrip("/")
    role_guid = _guid(role_definition_id)
    assignments = [
        extra
        for extra in extras
        if extra.kind.lower() == "azrolemanagementpolicyassignment"
        and _lower(extra.properties.get("scope")).rstrip("/") == normalized_scope
        and _guid(str(extra.properties.get("roleDefinitionId") or "")) == role_guid
    ]
    policies_by_id: dict[str, AuthorizationExtra] = {}
    for extra in extras:
        if extra.kind.lower() != "azrolemanagementpolicy":
            continue
        # Azure may expose policyId as either the full ARM ID or the policy
        # name. Index both exact representations, but never fall back to a
        # terminal-GUID scan that could cross management scopes.
        for identifier in (extra.raw.get("id"), extra.raw.get("name")):
            if isinstance(identifier, str) and identifier:
                policies_by_id[_lower(identifier)] = extra
    if not assignments:
        unknown = True

    for assignment in assignments:
        policy_id = str(assignment.properties.get("policyId") or "")
        if policy_id:
            policies.append(policy_id)
        rules = assignment.properties.get("effectiveRules")
        if not isinstance(rules, list) and policy_id:
            policy = policies_by_id.get(_lower(policy_id))
            if policy is not None:
                rules = policy.properties.get("rules")
        if not isinstance(rules, list):
            unknown = True
            continue
        for rule in rules:
            if not isinstance(rule, dict):
                unknown = True
                continue
            target = rule.get("target")
            if isinstance(target, dict):
                caller = _lower(target.get("caller"))
                level = _lower(target.get("level"))
                operations = target.get("operations")
                if caller and caller != "enduser":
                    continue
                if level and level != "assignment":
                    continue
                if isinstance(operations, list) and operations and not any(
                    _lower(operation) in {"all", "activate", "activation"}
                    for operation in operations
                ):
                    continue
            rule_type = _lower(rule.get("ruleType") or rule.get("@odata.type"))
            if "approvalrule" in rule_type:
                setting = rule.get("setting")
                if isinstance(setting, dict) and setting.get("isApprovalRequired") is True:
                    controls.add("approval")
                continue
            if "authenticationcontextrule" in rule_type:
                if rule.get("isEnabled") is True:
                    controls.add("authenticationContext")
                continue
            if "enablementrule" in rule_type:
                enabled_rules = rule.get("enabledRules")
                if not isinstance(enabled_rules, list):
                    unknown = True
                    continue
                for enabled in enabled_rules:
                    normalized = _lower(enabled)
                    if normalized in {"multifactorauthentication", "mfa"}:
                        controls.add("mfa")
                    elif normalized == "justification":
                        controls.add("justification")
                    elif normalized in {"ticketing", "ticketinformation"}:
                        controls.add("ticketInformation")
    return {
        "policyIds": sorted(set(policies)),
        "activationControls": sorted(controls),
        "activationRequirementsUnknown": unknown,
    }


def _condition_state(assignment: Any, operation: str, target_role: str | None = None) -> TriState:
    props = _record_properties(assignment)
    context = request_context(
        operation,
        str(getattr(assignment, "principal_id", "")),
        str(getattr(assignment, "principal_type", "")),
        target_role,
    )
    return evaluate_condition(props.get("condition"), context)


def _deny_matches(
    extras: list[AuthorizationExtra],
    principal_id: str,
    principal_type: str,
    target_scope: str,
    operation: str,
    principal_ids: Iterable[str] | None = None,
    scope_parents: dict[str, str] | None = None,
    snapshot_complete: bool = True,
    principal_ancestry_complete: bool = True,
    data_plane: bool = False,
) -> TriState:
    result = TriState.FALSE if snapshot_complete else TriState.UNKNOWN
    for extra in extras:
        if extra.kind.lower() != "azdenyassignment":
            continue
        props = extra.properties
        deny_scope = props.get("scope") or extra.raw.get("id") or ""
        if not isinstance(deny_scope, str) or not props.get("scope") or not _scope_within(target_scope, deny_scope, scope_parents):
            continue
        if props.get("doNotApplyToChildScopes") is True and _lower(target_scope) != _lower(deny_scope):
            continue
        principals = props.get("principals")
        excluded = props.get("excludePrincipals")
        def ids(items: Any) -> set[str]:
            if not isinstance(items, list):
                return set()
            return {_lower(item.get("id")) for item in items if isinstance(item, dict) and item.get("id")}
        subject_ids = {_lower(principal_id)}
        if principal_ids is not None:
            subject_ids.update(_lower(value) for value in principal_ids if value)
        if not isinstance(principals, list) or not principals:
            result = TriState.UNKNOWN
            continue
        permissions = props.get("permissions")
        if not isinstance(permissions, list):
            continue
        matched = False
        for permission in permissions:
            if not isinstance(permission, dict):
                continue
            actions = permission.get("dataActions" if data_plane else "actions", [])
            not_actions = permission.get(
                "notDataActions" if data_plane else "notActions", []
            )
            if any(operation_matches(str(pattern), operation) for pattern in actions if isinstance(pattern, str)) and not any(
                operation_matches(str(pattern), operation) for pattern in not_actions if isinstance(pattern, str)
            ):
                matched = True
                break
        if not matched:
            continue
        excluded_ids = ids(excluded)
        if subject_ids & excluded_ids:
            continue
        exclusion_uncertain = bool(excluded_ids) and not principal_ancestry_complete
        deny_principal_ids = ids(principals)
        all_principals = bool(deny_principal_ids & {
            "*", "allprincipals", "all principals",
            "00000000-0000-0000-0000-000000000000",
        })
        if not all_principals and not (subject_ids & deny_principal_ids):
            # With a partial membership graph, an otherwise non-matching deny
            # principal may be an unobserved ancestor group.  Do not turn that
            # absence into a confirmed permission edge.
            if not principal_ancestry_complete:
                result = TriState.UNKNOWN
            continue
        condition_state = evaluate_condition(
            props.get("condition"),
            request_context(operation, principal_id, principal_type),
        )
        if condition_state is TriState.TRUE:
            if exclusion_uncertain:
                result = TriState.UNKNOWN
            else:
                return TriState.TRUE
        if condition_state is TriState.UNKNOWN:
            result = TriState.UNKNOWN
    return result


def _edge_kind(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    clean = re.sub(r"_+", "_", clean)
    return clean if clean.startswith("BARK_") else "BARK_" + (clean or "Permission")


def _make_edge(
    capability: Capability,
    principal_id: str,
    principal_type: str,
    target_scope: str,
    target_kind: str,
    properties: dict[str, Any],
    standalone: bool,
    principal_kind: Callable[[str], str],
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    start_kind = principal_kind(principal_type)
    nodes: list[dict[str, Any]] = []
    if standalone:
        nodes = [
            {"id": standalone_id(principal_id), "kinds": ["BARK_Azure" + start_kind.removeprefix("AZ")]},
            {"id": standalone_id(target_scope), "kinds": ["BARK_Azure" + target_kind.removeprefix("AZ")]},
        ]
    edge = {
        "kind": _edge_kind(capability.edge_kind),
        "start": {"value": principal_id.upper(), "match_by": "id"},
        "end": {"value": target_scope.upper(), "match_by": "id"},
        "properties": properties,
    }
    if standalone:
        edge["start"]["value"] = standalone_id(principal_id)
        edge["end"]["value"] = standalone_id(target_scope)
    else:
        edge["start"] = native_endpoint(principal_id)
        edge["end"] = native_endpoint(target_scope)
    return edge, {"nodes": nodes} if standalone else None


def analyze(
    assignments: list[Any],
    parsed: Iterable[tuple[Any, Any]],
    scope_kind: Callable[[str, dict[str, str] | None], str],
    principal_kind: Callable[[str], str],
    resource_kinds: dict[str, str] | None = None,
    standalone: bool = False,
    include_potential: bool = False,
    capability_path: Path | None = None,
    now: datetime | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    parsed_list = list(parsed)
    definitions = parse_role_definitions(parsed_list)
    extras = collect_authorization_extras(parsed_list)
    deny_coverage = collect_deny_snapshot_coverage(parsed_list)
    group_members = collect_group_members(parsed_list)
    group_snapshot_complete = group_membership_snapshot_complete(parsed_list)
    ancestor_groups = collect_principal_ancestor_groups(group_members)
    scope_parents = collect_scope_parents(parsed_list)
    capabilities = load_capabilities(capability_path)
    resources = {str(key): value for key, value in (resource_kinds or {}).items()}
    analysis_time = now or datetime.now(timezone.utc)
    edges_by_key: dict[tuple[str, str, str], dict[str, Any]] = {}
    nodes_by_key: dict[str, dict[str, Any]] = {}
    findings: list[dict[str, Any]] = []
    eligible_edges: list[dict[str, Any]] = []

    all_assignments = list(assignments)
    for extra in extras:
        record = _extra_assignment(extra)
        if record is not None:
            all_assignments.append(record)
    # Keep the group edge and add effective member subjects.  The latter is
    # needed for permission-derived paths because ARM evaluates a group's
    # grant for each effective member, while BloodHound paths start at users
    # and service principals.
    for assignment in list(all_assignments):
        if isinstance(assignment, dict):
            subject_id = str(assignment.get("principalId") or "")
            subject_type = str(assignment.get("principalType") or "")
            proxy = dict(assignment)
        else:
            subject_id = str(getattr(assignment, "principal_id", ""))
            subject_type = str(getattr(assignment, "principal_type", ""))
            proxy = {
                "principalId": subject_id,
                "principalType": subject_type,
                "roleDefinitionId": str(getattr(assignment, "role_definition_id", "")),
                "scope": str(getattr(assignment, "effective_scope", "")),
                "assignmentId": str(getattr(assignment, "assignment_id", "")),
                "condition": _record_properties(assignment).get("condition"),
                "state": "active",
            }
        if subject_id and (subject_type.lower().startswith("group") or _lower(subject_id) in group_members):
            for member_id, member_type in expand_group_members(subject_id, group_members):
                member_proxy = dict(proxy)
                member_proxy["principalId"] = member_id
                member_proxy["principalType"] = member_type
                member_proxy["effectiveFromGroupId"] = subject_id
                all_assignments.append(member_proxy)
    for assignment in all_assignments:
        if isinstance(assignment, dict):
            principal_id = str(assignment.get("principalId") or "")
            principal_type = str(assignment.get("principalType") or "")
            role_id = str(assignment.get("roleDefinitionId") or "")
            effective_scope = str(assignment.get("scope") or "")
            assignment_id = str(assignment.get("assignmentId") or "")
            state = str(assignment.get("state") or "active")
            role_name = str(assignment.get("roleName") or "Unknown")
            condition = assignment.get("condition")
            effective_from_group = str(assignment.get("effectiveFromGroupId") or "")
        else:
            principal_id = str(getattr(assignment, "principal_id", ""))
            principal_type = str(getattr(assignment, "principal_type", ""))
            role_id = str(getattr(assignment, "role_definition_id", ""))
            effective_scope = str(getattr(assignment, "effective_scope", ""))
            assignment_id = str(getattr(assignment, "assignment_id", ""))
            state = "active"
            role_name = str(getattr(assignment, "role_name", "Unknown"))
            condition = _record_properties(assignment).get("condition")
            effective_from_group = ""
        if not principal_id or not role_id or not effective_scope:
            continue
        if state == "eligible":
            # Eligibility is not active permission.  It is emitted as a
            # separate informational edge below after policy analysis.
            continue
        if state == "active" and isinstance(assignment, dict) and not _now_active(assignment, analysis_time):
            continue
        role = definitions.get(_lower(role_id)) or definitions.get(_guid(role_id))
        if role is None:
            findings.append({
                "status": "unknown",
                "reason": "role definition is missing from the input snapshot",
                "principalId": principal_id,
                "assignmentId": assignment_id,
                "roleDefinitionId": role_id,
                "scope": effective_scope,
            })
            continue
        role_name = role.name
        for capability in capabilities:
            escalation_only = capability.identifier == "azure.rbac.role_assignment_escalation"
            for requirement in capability.requirements:
                operation_states: list[tuple[str, TriState]] = []
                allowed_target_roles: list[str] = []
                for operation in requirement:
                    role_state, target_roles = _permission_state_for_operation(
                        role,
                        assignment,
                        definitions,
                        operation,
                        effective_scope,
                        escalation_only,
                        scope_parents,
                        capability.data_plane,
                    )
                    allowed_target_roles.extend(target_roles)
                    context = request_context(operation, principal_id, principal_type, role_id)
                    assignment_state = (
                        TriState.TRUE
                        if operation.lower() == "microsoft.authorization/roleassignments/write"
                        else evaluate_condition(condition, context)
                    )
                    if role_state is TriState.FALSE or assignment_state is TriState.FALSE:
                        state_for_operation = TriState.FALSE
                    elif role_state is TriState.UNKNOWN or assignment_state is TriState.UNKNOWN:
                        state_for_operation = TriState.UNKNOWN
                    else:
                        state_for_operation = TriState.TRUE
                    operation_states.append((operation, state_for_operation))
                if not operation_states:
                    continue
                if any(state_for_operation is TriState.FALSE for _, state_for_operation in operation_states):
                    continue
                grant_state = TriState.TRUE if all(state_for_operation is TriState.TRUE for _, state_for_operation in operation_states) else TriState.UNKNOWN
                targets = _target_scopes(assignment, capability, scope_kind, resources, scope_parents) if not isinstance(assignment, dict) else _target_scopes_dict(assignment, capability, scope_kind, resources, scope_parents)
                if not targets:
                    findings.append({
                        "status": "unknown" if grant_state is TriState.UNKNOWN else "potential",
                        "reason": "the capability applies to a descendant resource that was not collected",
                        "capability": capability.identifier,
                        "principalId": principal_id,
                        "assignmentId": assignment_id,
                        "roleDefinitionId": role_id,
                        "scope": effective_scope,
                    })
                    continue
                for target_scope, target_kind in targets:
                    deny_subjects = {principal_id}
                    if effective_from_group:
                        deny_subjects.add(effective_from_group)
                    for subject in tuple(deny_subjects):
                        deny_subjects.update(
                            ancestor_groups.get(_lower(subject), set())
                        )
                    target_deny_snapshot_complete = deny_coverage.covers(
                        target_scope, scope_parents
                    )
                    deny_states = [
                        _deny_matches(
                            extras, principal_id, principal_type, target_scope, operation,
                            principal_ids=deny_subjects, scope_parents=scope_parents,
                            snapshot_complete=target_deny_snapshot_complete,
                            principal_ancestry_complete=group_snapshot_complete,
                            data_plane=capability.data_plane,
                        )
                        for operation in requirement
                    ]
                    deny_state = (
                        TriState.TRUE
                        if any(state is TriState.TRUE for state in deny_states)
                        else TriState.UNKNOWN
                        if any(state is TriState.UNKNOWN for state in deny_states)
                        else TriState.FALSE
                    )
                    final_state = (
                        TriState.FALSE if deny_state is TriState.TRUE
                        else TriState.UNKNOWN if deny_state is TriState.UNKNOWN
                        else grant_state
                    )
                    confidence = "confirmed" if final_state is TriState.TRUE and deny_state is TriState.FALSE else "unknown"
                    finding = {
                        "status": confidence,
                        "capability": capability.identifier,
                        "edgeKind": capability.edge_kind,
                        "description": capability.description,
                        "principalId": principal_id,
                        "principalType": principal_type,
                        "roleName": role_name,
                        "roleDefinitionId": role_id,
                        "assignmentId": assignment_id,
                        "scope": target_scope,
                        "authoredScope": getattr(assignment, "authored_scope", effective_scope) if not isinstance(assignment, dict) else effective_scope,
                        "matchedOperations": list(requirement),
                        "allowedTargetRoleIds": sorted(set(allowed_target_roles)),
                        "condition": condition,
                        "conditionDecision": grant_state.value,
                        "denyDecision": deny_state.value,
                        "assignmentState": state,
                        "effectiveFromGroupId": effective_from_group,
                    }
                    findings.append(finding)
                    if final_state is not TriState.TRUE and not include_potential:
                        continue
                    if final_state is TriState.FALSE:
                        continue
                    if principal_kind(principal_type) == "AZBase":
                        continue
                    edge, node_payload = _make_edge(
                        capability,
                        principal_id,
                        principal_type,
                        target_scope,
                        target_kind,
                        {
                            "capability": capability.identifier,
                            "rolename": role_name,
                            "roledefinitionid": role_id,
                            "roleassignmentid": assignment_id,
                            "matchedoperations": list(requirement),
                            "authoredscope": finding["authoredScope"],
                            "effectivescope": target_scope,
                            "conditiondecision": grant_state.value,
                            "denydecision": deny_state.value,
                            "assignmentstate": state,
                            "effectivefromgroupid": finding.get("effectiveFromGroupId", ""),
                            "allowedtargetroleids": sorted(set(allowed_target_roles)),
                            "confidence": "confirmed" if final_state is TriState.TRUE else "potential",
                            "analysisversion": ANALYSIS_VERSION,
                        },
                        standalone,
                        principal_kind,
                    )
                    if final_state is TriState.UNKNOWN:
                        edge["kind"] = _edge_kind(
                            "BARK_Potential_" + edge["kind"].removeprefix("BARK_")
                        )
                    key = (edge["kind"], principal_id.lower(), target_scope.lower())
                    if key not in edges_by_key:
                        edges_by_key[key] = edge
                    if node_payload:
                        for node in node_payload["nodes"]:
                            nodes_by_key[node["id"].lower()] = node

    # Eligible PIM assignments are represented separately from active access.
    for extra in extras:
        if extra.kind.lower() != "azroleeligibilityscheduleinstance":
            continue
        record = _extra_assignment(extra)
        if record is None:
            continue
        if not _now_active(record, analysis_time):
            continue
        target_kind = scope_kind(record["scope"], resources)
        if principal_kind(record["principalType"]) == "AZBase":
            continue
        pim_policy = _pim_policy_summary(
            extras, record["scope"], record["roleDefinitionId"]
        )
        edge, node_payload = _make_edge(
            Capability("azure.pim.eligible", "BARK_EligibleForAzureRole", "pim", (("PIM",),), (target_kind,), "Eligible for an Azure role; activation requirements may apply."),
            record["principalId"], record["principalType"], record["scope"], target_kind,
            {
                "roledefinitionid": record["roleDefinitionId"],
                "roleassignmentid": record["assignmentId"],
                "assignmentstate": "eligible",
                "confidence": "informational",
                "pimpolicyids": pim_policy["policyIds"],
                "pimactivationcontrols": pim_policy["activationControls"],
                "pimactivationrequirementsunknown": pim_policy["activationRequirementsUnknown"],
                "analysisversion": ANALYSIS_VERSION,
            },
            standalone, principal_kind,
        )
        eligible_edges.append(edge)
        if node_payload:
            for node in node_payload["nodes"]:
                nodes_by_key[node["id"].lower()] = node

    graph_edges = list(edges_by_key.values()) + eligible_edges
    graph = {"graph": {"nodes": list(nodes_by_key.values()), "edges": graph_edges}, "meta": {"analysisVersion": ANALYSIS_VERSION, "edgeCount": len(graph_edges)}}
    findings_payload = {
        "permissionFindings": findings,
        "meta": {
            "analysisVersion": ANALYSIS_VERSION,
            "analysisTime": analysis_time.isoformat(),
            "count": len(findings),
            "confirmed": sum(1 for item in findings if item.get("status") == "confirmed"),
            "unknown": sum(1 for item in findings if item.get("status") == "unknown"),
            "eligible": len(eligible_edges),
            "denySnapshotComplete": deny_coverage.complete,
            "groupMembershipSnapshotComplete": group_snapshot_complete,
            "denySnapshotCoverage": {
                "requestedScopes": sorted(deny_coverage.requested_scopes),
                "successfulScopes": sorted(deny_coverage.successful_scopes),
                "failedScopes": sorted(deny_coverage.failed_scopes),
                "metadataFiles": deny_coverage.metadata_files,
                "incompleteMetadataFiles": deny_coverage.incomplete_metadata_files,
            },
        },
    }
    return graph, findings_payload


def _target_scopes_dict(
    assignment: dict[str, Any],
    capability: Capability,
    scope_kind: Callable[[str, dict[str, str] | None], str],
    resource_kinds: dict[str, str],
    scope_parents: dict[str, str] | None = None,
) -> list[tuple[str, str]]:
    effective = str(assignment.get("scope") or "")
    if not effective:
        return []
    kind = scope_kind(effective, resource_kinds)
    targets: list[tuple[str, str]] = []
    if kind in capability.target_kinds:
        targets.append((effective, kind))
    targets.extend(
        (identifier, resource_kind)
        for identifier, resource_kind in resource_kinds.items()
        if resource_kind in capability.target_kinds and _scope_within(identifier, effective, scope_parents)
    )
    return list(dict.fromkeys(targets))
