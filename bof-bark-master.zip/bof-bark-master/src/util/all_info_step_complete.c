/*
 * all_info_step_complete.c - BARK BOF
 * Emits a collector boundary marker after one all-info step has drained.
 */

#include <windows.h>
#include "../../include/beacon.h"

void go(char *args, int alen)
{
    datap parser;
    char *jobId = NULL;
    int step = -1;

    BeaconDataParse(&parser, args, alen);
    jobId = BeaconDataExtract(&parser, NULL);
    step = BeaconDataInt(&parser);
    if (!jobId || jobId[0] == '\0' || step < 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] all-info step marker requires a job ID and step\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info step drained: job=%s; step=%d\n",
        jobId, step);
}
