/*
 * parse_jwt_token.c — BARK BOF
 * Parse-JWTToken — Decode and display JWT token payload claims (no HTTP request)
 *
 * Args : token (the JWT string to decode — this IS the target, not a bearer for auth)
 * API  : No HTTP request — base64url-decodes the JWT payload segment locally
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* Base64UrlDecode is now provided by http_utils.h */

void go(char *args, int alen)
{
    datap  parser;
    char  *token     = NULL;
    char  *dot1      = NULL;
    char  *dot2      = NULL;
    char  *payload   = NULL;
    int    payLen    = 0;
    char  *decoded   = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_parse_jwt_token <jwt_token>\n"
            "    Decodes the JWT payload (base64url) and prints all claims.\n");
        return;
    }

    /* Find the two dots that delimit header.payload.signature */
    dot1 = MSVCRT$strstr(token, ".");
    if (!dot1) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Invalid JWT: no first '.' found\n");
        return;
    }
    dot2 = MSVCRT$strstr(dot1 + 1, ".");
    if (!dot2) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Invalid JWT: no second '.' found\n");
        return;
    }

    payload = dot1 + 1;
    payLen  = (int)(dot2 - payload);

    if (payLen <= 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] JWT payload segment is empty\n");
        return;
    }

    decoded = (char *)HAlloc((SIZE_T)(payLen * 2 + 8));
    if (!decoded) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n");
        return;
    }

    if (Base64UrlDecode(payload, payLen, decoded, payLen * 2 + 8) <= 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Base64url decode failed\n");
        HFree(decoded);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] JWT Payload Claims:\n%s\n", decoded);

    HFree(decoded);
}
