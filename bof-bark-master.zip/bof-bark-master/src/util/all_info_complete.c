/*
 * all_info_complete.c - BARK BOF
 * Emits an explicit terminal marker after the all-info queue has drained.
 */

#include <windows.h>
#include "../../include/beacon.h"

void go(char *args, int alen)
{
    datap parser;
    char *jobId = NULL;

    BeaconDataParse(&parser, args, alen);
    jobId = BeaconDataExtract(&parser, NULL);
    if (!jobId || jobId[0] == '\0') {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] all-info completion marker requires a job ID\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info queue drained: job=%s\n", jobId);
}
