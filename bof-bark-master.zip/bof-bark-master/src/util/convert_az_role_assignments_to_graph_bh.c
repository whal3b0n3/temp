/*
 * convert_az_role_assignments_to_graph_bh.c — BARK BOF
 * Convert-AZRoleAssignmentsToGraphBH — Convert ARM role assignment BH JSON
 * files into BloodHound graph format (nodes + edges).
 *
 * Args : [pattern]
 *   pattern : glob for role assignment JSON files to read
 *             (default: .\AZ*RoleAssignment*.json)
 *
 * Reads every matching .json file produced by any
 * bark_get_all_azurerm_*_role_assignments_bh BOF, extracts
 * principalId / principalType / scope from each
 * Microsoft.Authorization/roleAssignments object, deduplicates
 * nodes, and writes a single graph envelope:
 *
 *   {
 *     "graph": {
 *       "nodes": [{"id":"<guid>","kinds":["AZUser"]}, ...],
 *       "edges": [
 *         {
 *           "kind":  "AZRoleAssignment",
 *           "start": {"value":"<principalId>","match_by":"id"},
 *           "end":   {"value":"<scope>",      "match_by":"id"}
 *         }, ...
 *       ]
 *     }
 *   }
 *
 * Output file: .\AZRoleGraph_yyyyMMdd_HHmmss.json
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* ================================================================
 * Additional Win32 imports (file enumeration + reading)
 * ================================================================ */
WINBASEAPI HANDLE WINAPI KERNEL32$FindFirstFileA(
    LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindNextFileA(
    HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindClose(HANDLE hFindFile);
WINBASEAPI BOOL   WINAPI KERNEL32$ReadFile(
    HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead,
    LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);
WINBASEAPI DWORD  WINAPI KERNEL32$GetFileSize(
    HANDLE hFile, LPDWORD lpFileSizeHigh);

/* ================================================================
 * Graph data structures
 * ================================================================ */

#define MAX_NODES  2048
#define MAX_EDGES  4096
#define ID_LEN     512   /* max ARM resource path / GUID */
#define KIND_LEN    64   /* max BH node/edge kind */

typedef struct { char id[ID_LEN]; char kind[KIND_LEN]; } GNode;
typedef struct {
    char kind[KIND_LEN];
    char roleName[KIND_LEN];
    char roleDefinitionId[64];
    char assignmentId[64];
    char startId[ID_LEN];
    char endId[ID_LEN];
} GEdge;

/* BSS (not stack) — safe even for large arrays in a BOF */
static GNode g_nodes[MAX_NODES];
static GEdge g_edges[MAX_EDGES];
static int   g_nodeCount;
static int   g_edgeCount;
static BarkBuf g_nativeOutput;
static int g_nativeCount;

/* Entra GUIDs and ARM resource IDs are case-insensitive. */
static int EqualId(const char *left, const char *right) {
    unsigned char a, b;
    if (!left || !right) return 0;
    while (*left && *right) {
        a = (unsigned char)*left++;
        b = (unsigned char)*right++;
        if (a >= 'A' && a <= 'Z') a = (unsigned char)(a + ('a' - 'A'));
        if (b >= 'A' && b <= 'Z') b = (unsigned char)(b + ('a' - 'A'));
        if (a != b) return 0;
    }
    return *left == '\0' && *right == '\0';
}

static int ContainsInsensitive(const char *value, const char *needle) {
    size_t valueLen, needleLen, i, j;
    if (!value || !needle) return 0;
    valueLen = MSVCRT$strlen(value);
    needleLen = MSVCRT$strlen(needle);
    if (needleLen == 0 || needleLen > valueLen) return 0;
    for (i = 0; i + needleLen <= valueLen; i++) {
        for (j = 0; j < needleLen; j++) {
            unsigned char a = (unsigned char)value[i + j];
            unsigned char b = (unsigned char)needle[j];
            if (a >= 'A' && a <= 'Z') a += (unsigned char)('a' - 'A');
            if (b >= 'A' && b <= 'Z') b += (unsigned char)('a' - 'A');
            if (a != b) break;
        }
        if (j == needleLen) return 1;
    }
    return 0;
}

/* ================================================================
 * GetKindFromScope
 *
 * Derive the BloodHound node kind from an ARM resource scope path.
 * The scope is the resource the role assignment is on, e.g.:
 *   /subscriptions/xxx
 *   /subscriptions/xxx/resourceGroups/yyy
 *   /subscriptions/xxx/resourceGroups/yyy/providers/Microsoft.Compute/virtualMachines/zzz
 * ================================================================ */
static void GetKindFromScope(const char *scope, char *out, int outSize) {
    if (!scope || MSVCRT$strlen(scope) == 0) {
        MSVCRT$strncpy(out, "AZResource", (size_t)(outSize - 1));
        out[outSize - 1] = '\0';
        return;
    }
    /* Check known provider types — order matters: more-specific first */
    const char *kind = NULL;
    if      (ContainsInsensitive(scope, "Microsoft.Compute/virtualMachineScaleSets"))  kind = "AZVMScaleSet";
    else if (ContainsInsensitive(scope, "Microsoft.Compute/virtualMachines"))          kind = "AZVM";
    else if (ContainsInsensitive(scope, "Microsoft.KeyVault/vaults"))                  kind = "AZKeyVault";
    else if (ContainsInsensitive(scope, "Microsoft.Storage/storageAccounts"))           kind = "AZStorageAccount";
    else if (ContainsInsensitive(scope, "Microsoft.Logic/workflows"))                   kind = "AZLogicApp";
    else if (ContainsInsensitive(scope, "Microsoft.Web/sites"))                         kind = "AZWebApp";
    else if (ContainsInsensitive(scope, "Microsoft.ContainerService/managedClusters")) kind = "AZManagedCluster";
    else if (ContainsInsensitive(scope, "Microsoft.ContainerRegistry/registries"))     kind = "AZContainerRegistry";
    else if (ContainsInsensitive(scope, "Microsoft.Automation/automationAccounts"))    kind = "AZAutomationAccount";
    else if (ContainsInsensitive(scope, "Microsoft.App/containerApps"))                kind = "AZContainerApp";
    else if (ContainsInsensitive(scope, "Microsoft.ContainerInstance/containerGroups")) kind = "AZContainerGroup";
    else if (ContainsInsensitive(scope, "Microsoft.DocumentDB/databaseAccounts"))      kind = "AZCosmosDB";
    else if (ContainsInsensitive(scope, "/providers/Microsoft.Management/managementGroups/")) kind = "AZManagementGroup";
    else if (ContainsInsensitive(scope, "/providers/"))                                 kind = "AZResource";
    else if (ContainsInsensitive(scope, "/resourceGroups/"))                            kind = "AZResourceGroup";
    else if (ContainsInsensitive(scope, "/subscriptions/"))                             kind = "AZSubscription";
    else                                                                           kind = "AZResource";

    MSVCRT$strncpy(out, kind, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
}

/* AzureHound names ARM relationships with the target resource kind (for
 * example VMOwner and VMUserAccessAdmin).  Bark's role-assignment files use
 * the role name alone, so add the scope prefix while converting the graph. */
static void GetTypedEdgeKind(const char *roleKind, const char *scopeKind,
                             char *out, int outSize) {
    const char *role = roleKind ? roleKind : "";
    const char *prefix = scopeKind ? scopeKind : "";
    if (prefix[0] == 'A' && prefix[1] == 'Z') prefix += 2;

    if (MSVCRT$strcmp(role, "UserAccessAdministrator") == 0)
        role = "UserAccessAdmin";

    if (prefix[0] != '\0' && MSVCRT$strcmp(prefix, "Resource") != 0)
        MSVCRT$sprintf_s(out, (size_t)outSize, "%s%s", prefix, role);
    else
        MSVCRT$strncpy(out, role, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
}

/* ================================================================
 * GetPrincipalKind
 *
 * Map ARM principalType strings to BloodHound node kinds.
 * ================================================================ */
static void GetPrincipalKind(const char *principalType, char *out, int outSize) {
    const char *kind = NULL;
    if      (!principalType || MSVCRT$strlen(principalType) == 0) kind = "AZBase";
    else if (MSVCRT$strncmp(principalType, "User",              4)  == 0) kind = "AZUser";
    else if (MSVCRT$strncmp(principalType, "ForeignGroup",      12) == 0) kind = "AZGroup";
    else if (MSVCRT$strncmp(principalType, "Group",             5)  == 0) kind = "AZGroup";
    else if (MSVCRT$strncmp(principalType, "ServicePrincipal",  16) == 0) kind = "AZServicePrincipal";
    else if (MSVCRT$strncmp(principalType, "Device",            6)  == 0) kind = "AZDevice";
    else {
        /* Fallback: prepend "AZ" */
        MSVCRT$sprintf_s(out, (size_t)outSize, "AZ%s", principalType);
        out[outSize - 1] = '\0';
        return;
    }
    MSVCRT$strncpy(out, kind, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
}

/* ================================================================
 * EnsureNode — add a node if it is not already present
 * ================================================================ */
static void EnsureNode(const char *id, const char *kind) {
    int i;
    if (!id || MSVCRT$strlen(id) == 0) return;
    for (i = 0; i < g_nodeCount; i++) {
        if (EqualId(g_nodes[i].id, id))
            return; /* already present */
    }
    if (g_nodeCount >= MAX_NODES) return;
    MSVCRT$strncpy(g_nodes[g_nodeCount].id,   id,   ID_LEN   - 1);
    MSVCRT$strncpy(g_nodes[g_nodeCount].kind, kind, KIND_LEN - 1);
    g_nodes[g_nodeCount].id  [ID_LEN   - 1] = '\0';
    g_nodes[g_nodeCount].kind[KIND_LEN - 1] = '\0';
    g_nodeCount++;
}

/* ================================================================
 * AddEdge — append a unique effective relationship.  Multiple collectors
 * can observe the same underlying assignment, so compare the complete edge.
 * ================================================================ */
static void CopyLastArmSegment(const char *value, char *out, int outSize) {
    const char *segment = value;
    const char *p;
    if (!out || outSize <= 0) return;
    out[0] = '\0';
    if (!value) return;
    for (p = value; *p; p++) {
        if (*p == '/' && *(p + 1)) segment = p + 1;
    }
    MSVCRT$strncpy(out, segment, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
}

static int AddEdge(const char *kind, const char *roleName,
                   const char *roleDefinitionId, const char *assignmentId,
                   const char *startId, const char *endId) {
    int i;
    if (g_edgeCount >= MAX_EDGES) return 0;
    if (!kind || !startId || !endId) return 0;
    for (i = 0; i < g_edgeCount; i++) {
        if (MSVCRT$strcmp(g_edges[i].kind, kind) == 0 &&
            EqualId(g_edges[i].startId, startId) &&
            EqualId(g_edges[i].endId, endId))
            return 0;
    }
    MSVCRT$strncpy(g_edges[g_edgeCount].kind,    kind,    KIND_LEN - 1);
    MSVCRT$strncpy(g_edges[g_edgeCount].roleName,
        roleName ? roleName : "", KIND_LEN - 1);
    CopyLastArmSegment(roleDefinitionId,
        g_edges[g_edgeCount].roleDefinitionId,
        sizeof(g_edges[g_edgeCount].roleDefinitionId));
    CopyLastArmSegment(assignmentId,
        g_edges[g_edgeCount].assignmentId,
        sizeof(g_edges[g_edgeCount].assignmentId));
    MSVCRT$strncpy(g_edges[g_edgeCount].startId, startId, ID_LEN   - 1);
    MSVCRT$strncpy(g_edges[g_edgeCount].endId,   endId,   ID_LEN   - 1);
    g_edges[g_edgeCount].kind   [KIND_LEN - 1] = '\0';
    g_edges[g_edgeCount].roleName[KIND_LEN - 1] = '\0';
    g_edges[g_edgeCount].startId[ID_LEN   - 1] = '\0';
    g_edges[g_edgeCount].endId  [ID_LEN   - 1] = '\0';
    g_edgeCount++;
    return 1;
}

static void CopyUpperJsonString(const char *value, char *out, int outSize) {
    int i = 0;
    int escaped = 0;
    if (!out || outSize <= 0) return;
    if (!value) { out[0] = '\0'; return; }
    while (*value && i < outSize - 1) {
        unsigned char c = (unsigned char)*value++;
        if (escaped) {
            /* Preserve JSON escape introducers (especially \uXXXX). */
            out[i++] = (char)c;
            escaped = 0;
            continue;
        }
        if (c == '\\') {
            out[i++] = (char)c;
            escaped = 1;
            continue;
        }
        if (c >= 'a' && c <= 'z') c -= (unsigned char)('a' - 'A');
        out[i++] = (char)c;
    }
    out[i] = '\0';
}

static const char *NativeGenericKind(const char *scopeKind) {
    if (MSVCRT$strcmp(scopeKind, "AZStorageAccount") == 0)
        return "AZStorageAccountRoleAssignment";
    if (MSVCRT$strcmp(scopeKind, "AZAutomationAccount") == 0)
        return "AZAutomationAccountRoleAssignment";
    if (MSVCRT$strcmp(scopeKind, "AZLogicApp") == 0)
        return "AZLogicAppRoleAssignment";
    if (MSVCRT$strcmp(scopeKind, "AZContainerRegistry") == 0)
        return "AZContainerRegistryRoleAssignment";
    if (MSVCRT$strcmp(scopeKind, "AZManagedCluster") == 0)
        return "AZManagedClusterRoleAssignment";
    if (MSVCRT$strcmp(scopeKind, "AZVMScaleSet") == 0)
        return "AZVMScaleSetRoleAssignment";
    /* Microsoft.Web/sites cannot distinguish Web Apps from Function Apps
     * using an assignment scope alone. Keep those in BARK OpenGraph here;
     * the offline helper resolves them from the collected resource files. */
    return NULL;
}

static int NativeDirectDescriptor(const char *scopeKind,
                                  const char *roleGuid,
                                  const char **nativeKind,
                                  const char **collectionField,
                                  const char **itemField,
                                  const char **targetField) {
    const char *prefix = NULL;
    const char *suffix = NULL;
    static char kindBuffer[96];

    if (MSVCRT$strcmp(scopeKind, "AZManagementGroup") == 0) {
        prefix = "AZManagementGroup";
        *targetField = "managementGroupId";
    } else if (MSVCRT$strcmp(scopeKind, "AZSubscription") == 0) {
        prefix = "AZSubscription";
        *targetField = "subscriptionId";
    } else if (MSVCRT$strcmp(scopeKind, "AZResourceGroup") == 0) {
        prefix = "AZResourceGroup";
        *targetField = "resourceGroupId";
    } else if (MSVCRT$strcmp(scopeKind, "AZKeyVault") == 0) {
        prefix = "AZKeyVault";
        *targetField = "keyVaultId";
    } else if (MSVCRT$strcmp(scopeKind, "AZVM") == 0) {
        prefix = "AZVM";
        *targetField = "virtualMachineId";
    } else {
        return 0;
    }

    if (EqualId(roleGuid, "8e3af657-a8ff-443c-a75c-2fe8c4bcb635")) {
        suffix = "Owner";
        *collectionField = "owners";
        *itemField = "owner";
    } else if (EqualId(roleGuid, "b24988ac-6180-42a0-ab88-20f7382dd24c")) {
        suffix = "Contributor";
        *collectionField = "contributors";
        *itemField = "contributor";
    } else if (EqualId(roleGuid, "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9")) {
        suffix = "UserAccessAdmin";
        *collectionField = "userAccessAdmins";
        *itemField = "userAccessAdmin";
    } else if (MSVCRT$strcmp(scopeKind, "AZKeyVault") == 0 &&
               EqualId(roleGuid, "f25e0fa2-a7c8-4377-a976-54943a77a395")) {
        suffix = "KVContributor";
        *collectionField = "kvContributors";
        *itemField = "kvContributor";
    } else if (MSVCRT$strcmp(scopeKind, "AZVM") == 0 &&
               EqualId(roleGuid, "4f8fab4f-1852-4a58-a46a-8eaf358af14a")) {
        suffix = "AvereContributor";
        *collectionField = "avereContributors";
        *itemField = "avereContributor";
    } else if (MSVCRT$strcmp(scopeKind, "AZVM") == 0 &&
               EqualId(roleGuid, "1c0163c0-47e6-4577-8991-ea5c82e286e4")) {
        suffix = "AdminLogin";
        *collectionField = "adminLogins";
        *itemField = "adminLogin";
    } else if (MSVCRT$strcmp(scopeKind, "AZVM") == 0 &&
               EqualId(roleGuid, "9980e02c-c2be-4d73-94e8-173b1dc7cf3c")) {
        suffix = "VMContributor";
        *collectionField = "vmContributors";
        *itemField = "vmContributor";
    } else {
        return 0;
    }

    MSVCRT$sprintf_s(kindBuffer, sizeof(kindBuffer), "%s%s", prefix, suffix);
    *nativeKind = kindBuffer;
    return 1;
}

static void AppendNativeAssignmentObject(BarkBuf *out,
                                         const char *assignmentObject,
                                         const char *assignmentEnd,
                                         const char *principalId,
                                         const char *principalType,
                                         const char *roleDefinitionId,
                                         const char *authoredScope) {
    char *assignmentId = JsonExtractStringValue(
        assignmentObject, assignmentEnd, "\"id\"");
    char *assignmentName = JsonExtractStringValue(
        assignmentObject, assignmentEnd, "\"name\"");
    char principalUpper[ID_LEN];
    char scopeUpper[ID_LEN];
    char nameFallback[64];

    CopyUpperJsonString(principalId, principalUpper, sizeof(principalUpper));
    CopyUpperJsonString(authoredScope, scopeUpper, sizeof(scopeUpper));
    if (!assignmentName && assignmentId) {
        CopyLastArmSegment(assignmentId, nameFallback, sizeof(nameFallback));
        assignmentName = nameFallback;
    }

    BarkBufAppend(out, "{\"id\":\"", MSVCRT$strlen("{\"id\":\""));
    if (assignmentId)
        BarkBufAppend(out, assignmentId, MSVCRT$strlen(assignmentId));
    BarkBufAppend(out, "\",\"name\":\"", MSVCRT$strlen("\",\"name\":\""));
    if (assignmentName)
        BarkBufAppend(out, assignmentName, MSVCRT$strlen(assignmentName));
    BarkBufAppend(out,
        "\",\"type\":\"Microsoft.Authorization/roleAssignments\","
        "\"properties\":{\"principalId\":\"",
        MSVCRT$strlen(
        "\",\"type\":\"Microsoft.Authorization/roleAssignments\","
        "\"properties\":{\"principalId\":\""));
    BarkBufAppend(out, principalUpper, MSVCRT$strlen(principalUpper));
    BarkBufAppend(out, "\"", 1);
    if (principalType && principalType[0]) {
        BarkBufAppend(out, ",\"principalType\":\"",
            MSVCRT$strlen(",\"principalType\":\""));
        BarkBufAppend(out, principalType, MSVCRT$strlen(principalType));
        BarkBufAppend(out, "\"", 1);
    }
    BarkBufAppend(out, ",\"roleDefinitionId\":\"",
        MSVCRT$strlen(",\"roleDefinitionId\":\""));
    if (roleDefinitionId)
        BarkBufAppend(out, roleDefinitionId,
            MSVCRT$strlen(roleDefinitionId));
    BarkBufAppend(out, "\",\"scope\":\"",
        MSVCRT$strlen("\",\"scope\":\""));
    BarkBufAppend(out, scopeUpper, MSVCRT$strlen(scopeUpper));
    BarkBufAppend(out, "\"}}", MSVCRT$strlen("\"}}"));

    if (assignmentId) HFree(assignmentId);
    if (assignmentName && assignmentName != nameFallback) HFree(assignmentName);
}

static void AppendNativeRBAC(const char *scopeKind,
                             const char *effectiveScope,
                             const char *assignmentObject,
                             const char *assignmentEnd,
                             const char *principalId,
                             const char *principalType,
                             const char *roleDefinitionId,
                             const char *authoredScope) {
    char targetUpper[ID_LEN];
    char roleGuid[64];
    const char *genericKind = NativeGenericKind(scopeKind);
    const char *nativeKind = NULL;
    const char *collectionField = NULL;
    const char *itemField = NULL;
    const char *targetField = NULL;

    CopyUpperJsonString(effectiveScope, targetUpper, sizeof(targetUpper));
    CopyLastArmSegment(roleDefinitionId, roleGuid, sizeof(roleGuid));

    if (genericKind) {
        char prefix[256];
        int n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "%s{\"kind\":\"%s\",\"data\":{\"assignees\":[{\"assignee\":",
            g_nativeCount > 0 ? "," : "", genericKind);
        if (n > 0) BarkBufAppend(&g_nativeOutput, prefix, (SIZE_T)n);
        AppendNativeAssignmentObject(&g_nativeOutput,
            assignmentObject, assignmentEnd, principalId, principalType,
            roleDefinitionId, authoredScope);
        BarkBufAppend(&g_nativeOutput, ",\"objectId\":\"",
            MSVCRT$strlen(",\"objectId\":\""));
        BarkBufAppend(&g_nativeOutput, targetUpper,
            MSVCRT$strlen(targetUpper));
        BarkBufAppend(&g_nativeOutput, "\",\"roleDefinitionId\":\"",
            MSVCRT$strlen("\",\"roleDefinitionId\":\""));
        BarkBufAppend(&g_nativeOutput, roleGuid, MSVCRT$strlen(roleGuid));
        BarkBufAppend(&g_nativeOutput, "\"}],\"objectId\":\"",
            MSVCRT$strlen("\"}],\"objectId\":\""));
        BarkBufAppend(&g_nativeOutput, targetUpper,
            MSVCRT$strlen(targetUpper));
        BarkBufAppend(&g_nativeOutput, "\"}}", MSVCRT$strlen("\"}}"));
        g_nativeCount++;
    }

    if (NativeDirectDescriptor(scopeKind, roleGuid, &nativeKind,
            &collectionField, &itemField, &targetField)) {
        char prefix[384];
        int n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "%s{\"kind\":\"%s\",\"data\":{\"%s\":[{\"%s\":",
            g_nativeCount > 0 ? "," : "", nativeKind,
            collectionField, itemField);
        if (n > 0) BarkBufAppend(&g_nativeOutput, prefix, (SIZE_T)n);
        AppendNativeAssignmentObject(&g_nativeOutput,
            assignmentObject, assignmentEnd, principalId, principalType,
            roleDefinitionId, authoredScope);
        BarkBufAppend(&g_nativeOutput, ",\"", 2);
        BarkBufAppend(&g_nativeOutput, targetField,
            MSVCRT$strlen(targetField));
        BarkBufAppend(&g_nativeOutput, "\":\"",
            MSVCRT$strlen("\":\""));
        BarkBufAppend(&g_nativeOutput, targetUpper,
            MSVCRT$strlen(targetUpper));
        BarkBufAppend(&g_nativeOutput, "\"}],\"",
            MSVCRT$strlen("\"}],\""));
        BarkBufAppend(&g_nativeOutput, targetField,
            MSVCRT$strlen(targetField));
        BarkBufAppend(&g_nativeOutput, "\":\"",
            MSVCRT$strlen("\":\""));
        BarkBufAppend(&g_nativeOutput, targetUpper,
            MSVCRT$strlen(targetUpper));
        BarkBufAppend(&g_nativeOutput, "\"}}",
            MSVCRT$strlen("\"}}"));
        g_nativeCount++;
    }
}

/* ================================================================
 * ProcessFile
 *
 * Parse one BH JSON file produced by the role-assignment BOFs:
 *
 *   {
 *     "data": [
 *       {
 *         "kind": "AZRoleAssignment",
 *         "data": {
 *           "id": "...",
 *           "properties": {
 *             "principalId":   "...",
 *             "principalType": "User|Group|ServicePrincipal|...",
 *             "scope":         "/subscriptions/.../resource",
 *             "roleDefinitionId": "..."
 *           }
 *         }
 *       },
 *       ...
 *     ],
 *     "meta": {...}
 *   }
 * ================================================================ */
static int ProcessFile(const char *content, SIZE_T contentLen) {
    const char *end = content + contentLen;
    int added = 0;

    /* Locate outer "data" array */
    const char *dKey = JsonFindKey(content, end, "\"data\"");
    if (!dKey) return 0;
    const char *dColon = JsonFindKey(dKey, end, ":");
    if (!dColon) return 0;
    dColon++;
    while (dColon < end &&
           (*dColon == ' ' || *dColon == '\t' || *dColon == '\n' || *dColon == '\r'))
        dColon++;
    if (dColon >= end || *dColon != '[') return 0;
    const char *arrEnd = JsonSkipBalanced(dColon, end);
    if (!arrEnd) return 0;

    /* Top-level "kind" appears AFTER the data array in the new format:
     *   {"data":[...],"kind":"AZ<RoleName>"}
     * If not found here, this file is not a role-assignment file — skip it. */
    const char *kindKey = JsonFindKey(arrEnd, end, "\"kind\"");
    if (!kindKey) return 0;
    char *kindVal = JsonExtractStringValue(kindKey, end, "\"kind\"");
    if (!kindVal) return 0;

    /* Strip "AZ" prefix → role name = data key name = edge kind */
    char edgeKind[KIND_LEN] = {0};
    const char *roleName = kindVal;
    if (roleName[0] == 'A' && roleName[1] == 'Z') roleName += 2;
    MSVCRT$strncpy(edgeKind, roleName, KIND_LEN - 1);
    edgeKind[KIND_LEN - 1] = '\0';
    HFree(kindVal);
    if (edgeKind[0] == '\0') return 0;

    /* Build the quoted key we look for inside each item, e.g. "\"Contributor\"" */
    char roleKey[KIND_LEN + 2];
    MSVCRT$sprintf_s(roleKey, sizeof(roleKey), "\"%s\"", edgeKind);

    /* Walk each item in the data array:
     *   {"<RoleName>":{<assignment_obj>},"id":"<scope>"} */
    const char *p = dColon + 1;
    while (p < arrEnd - 1) {
        while (p < arrEnd - 1 && *p != '{') p++;
        if (p >= arrEnd - 1) break;
        const char *itemEnd = JsonSkipBalanced(p, arrEnd);
        if (!itemEnd) break;

        /* Find the role-name key (e.g. "Contributor") within the item */
        const char *rkPos = JsonFindKey(p, itemEnd, roleKey);
        if (!rkPos) { p = itemEnd; continue; }

        /* Advance past the key to its value (the assignment object) */
        const char *rkColon = JsonFindKey(rkPos + MSVCRT$strlen(roleKey), itemEnd, ":");
        if (!rkColon) { p = itemEnd; continue; }
        rkColon++;
        while (rkColon < itemEnd &&
               (*rkColon == ' ' || *rkColon == '\t' ||
                *rkColon == '\n' || *rkColon == '\r'))
            rkColon++;
        if (rkColon >= itemEnd || *rkColon != '{') { p = itemEnd; continue; }
        const char *assignEnd = JsonSkipBalanced(rkColon, itemEnd);
        if (!assignEnd) { p = itemEnd; continue; }

        /* Find "properties" within the assignment object */
        const char *propsKey = JsonFindKey(rkColon, assignEnd, "\"properties\"");
        if (!propsKey) { p = itemEnd; continue; }
        const char *propsColon = JsonFindKey(propsKey, assignEnd, ":");
        if (!propsColon) { p = itemEnd; continue; }
        propsColon++;
        while (propsColon < assignEnd &&
               (*propsColon == ' ' || *propsColon == '\t' ||
                *propsColon == '\n' || *propsColon == '\r'))
            propsColon++;
        if (propsColon >= assignEnd || *propsColon != '{') { p = itemEnd; continue; }
        const char *propsEnd = JsonSkipBalanced(propsColon, assignEnd);
        if (!propsEnd) { p = itemEnd; continue; }

        /* The assignment properties retain the scope where the grant was
         * authored.  New collectors put the scope where it is effective in
         * the wrapper's outer id, so inherited grants point at the resource
         * being evaluated. */
        char *principalId   = JsonExtractStringValue(propsColon, propsEnd, "\"principalId\"");
        char *principalType = JsonExtractStringValue(propsColon, propsEnd, "\"principalType\"");
        char *roleDefinitionId = JsonExtractStringValue(
            propsColon, propsEnd, "\"roleDefinitionId\"");
        char *authoredScope = JsonExtractStringValue(propsColon, propsEnd, "\"scope\"");
        char *effectiveScope = JsonExtractStringValue(assignEnd, itemEnd, "\"id\"");
        char *assignmentId = JsonExtractStringValue(
            rkColon, assignEnd, "\"id\"");
        const char *scope = (effectiveScope && MSVCRT$strlen(effectiveScope) > 0)
            ? effectiveScope : authoredScope;

        if (principalId && scope &&
            MSVCRT$strlen(principalId) > 0 &&
            MSVCRT$strlen(scope)       > 0) {

            char principalKind[KIND_LEN] = {0};
            char scopeKind[KIND_LEN]     = {0};
            char typedEdgeKind[KIND_LEN] = {0};
            GetPrincipalKind(principalType ? principalType : "", principalKind, KIND_LEN);
            GetKindFromScope(scope, scopeKind, KIND_LEN);
            GetTypedEdgeKind(edgeKind, scopeKind, typedEdgeKind, KIND_LEN);

            EnsureNode(principalId, principalKind);
            EnsureNode(scope,       scopeKind);
            if (AddEdge(typedEdgeKind, edgeKind, roleDefinitionId,
                    assignmentId, principalId, scope)) {
                AppendNativeRBAC(scopeKind, scope, rkColon, assignEnd,
                    principalId, principalType, roleDefinitionId,
                    authoredScope ? authoredScope : scope);
            }
            added++;
        }

        if (principalId)   HFree(principalId);
        if (principalType) HFree(principalType);
        if (roleDefinitionId) HFree(roleDefinitionId);
        if (authoredScope) HFree(authoredScope);
        if (effectiveScope) HFree(effectiveScope);
        if (assignmentId) HFree(assignmentId);

        p = itemEnd;
    }
    return added;
}

/* ================================================================
 * WriteGraphJSON
 *
 * Serialize g_nodes / g_edges into the BloodHound graph envelope
 * and write to .\AZRoleGraph_yyyyMMdd_HHmmss.json.
 * ================================================================ */
static const char *FindNodeKind(const char *id) {
    int i;
    for (i = 0; i < g_nodeCount; i++) {
        if (EqualId(g_nodes[i].id, id)) return g_nodes[i].kind;
    }
    return "AZBase";
}

static void MakeOpenGraphKind(const char *nativeKind,
                              char *out, int outSize) {
    int oi = 0;
    const char *prefix = "BARK_";
    while (*prefix && oi < outSize - 1) out[oi++] = *prefix++;
    while (nativeKind && *nativeKind && oi < outSize - 1) {
        unsigned char c = (unsigned char)*nativeKind++;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '_')
            out[oi++] = (char)c;
        else if (oi > 0 && out[oi - 1] != '_')
            out[oi++] = '_';
    }
    while (oi > 5 && out[oi - 1] == '_') oi--;
    out[oi] = '\0';
}

static void WriteGraphJSON(void) {
    BarkBuf b = { NULL, 0, 0, 1 };
    int i;

    /* Native-link OpenGraph: reserved AZ* nodes are imported from the normal
     * BARK/AzureHound files and must not be redeclared as OpenGraph nodes. */
    BarkBufAppend(&b, "{\"graph\":{\"nodes\":[],\"edges\":[",
        MSVCRT$strlen("{\"graph\":{\"nodes\":[],\"edges\":["));

    for (i = 0; i < g_edgeCount; i++) {
        static char buf[4096];
        char graphKind[KIND_LEN + 8];
        char startUpper[ID_LEN];
        char endUpper[ID_LEN];
        const char *startKind = FindNodeKind(g_edges[i].startId);
        const char *endKind = FindNodeKind(g_edges[i].endId);
        MakeOpenGraphKind(g_edges[i].kind, graphKind, sizeof(graphKind));
        CopyUpperJsonString(g_edges[i].startId,
            startUpper, sizeof(startUpper));
        CopyUpperJsonString(g_edges[i].endId,
            endUpper, sizeof(endUpper));
        int n = MSVCRT$sprintf_s(buf, sizeof(buf),
            "%s{\"kind\":\"%s\","
            "\"start\":{\"value\":\"%s\",\"match_by\":\"id\",\"kind\":\"%s\"},"
            "\"end\":{\"value\":\"%s\",\"match_by\":\"id\",\"kind\":\"%s\"},"
            "\"properties\":{\"rolename\":\"%s\","
            "\"roledefinitionid\":\"%s\",\"roleassignmentid\":\"%s\","
            "\"effectivescope\":\"%s\"}}",
            i > 0 ? "," : "",
            graphKind, startUpper, startKind, endUpper, endKind,
            g_edges[i].roleName, g_edges[i].roleDefinitionId,
            g_edges[i].assignmentId, endUpper);
        if (n > 0) BarkBufAppend(&b, buf, (SIZE_T)n);
    }

    BarkBufAppend(&b, "]}}", 3);

    if (!b.ok || !b.buf) {
        BeaconPrintf(CALLBACK_ERROR, "[-] convert_az_role_assignments_to_graph_bh: out of memory\n");
        BarkBufFree(&b);
        return;
    }

    SYSTEMTIME st;
    KERNEL32$GetLocalTime(&st);
    static char filename[300];
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZRoleGraph_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);

    BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] %s - native-link OpenGraph, 0 declared node(s), "
        "%d referenced node(s), %d BARK edge(s), %lu bytes\n",
        filename, g_nodeCount, g_edgeCount, (unsigned long)b.len);
    BarkBufFree(&b);
}

static void WriteNativeRBACJSON(void) {
    char tail[160];
    int tailLen;
    SYSTEMTIME st;
    static char filename[300];

    if (g_nativeCount == 0 || !g_nativeOutput.buf) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No BloodHound-native RBAC records matched; BARK OpenGraph still contains all effective assignments\n");
        return;
    }
    tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d,"
        "\"generator\":\"BARK hybrid RBAC\"}}",
        g_nativeCount);
    if (tailLen > 0)
        BarkBufAppend(&g_nativeOutput, tail, (SIZE_T)tailLen);
    if (!g_nativeOutput.ok) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Native RBAC output exceeded available memory\n");
        return;
    }

    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZNativeRBAC_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
    BarkWriteOutput(filename, g_nativeOutput.buf,
        (DWORD)g_nativeOutput.len);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] %s - %d AzureHound-compatible native RBAC record(s), %lu bytes\n",
        filename, g_nativeCount, (unsigned long)g_nativeOutput.len);
}

/* ================================================================
 * go — BOF entry point
 * ================================================================ */
void go(char *args, int alen)
{
    datap  parser;
    char  *pattern = NULL;

    BeaconDataParse(&parser, args, alen);
    pattern = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!pattern || MSVCRT$strlen(pattern) == 0)
        pattern = ".\\AZ*.json";

    MSVCRT$memset(g_nodes, 0, sizeof(g_nodes));
    MSVCRT$memset(g_edges, 0, sizeof(g_edges));
    g_nodeCount = 0;
    g_edgeCount = 0;
    g_nativeOutput.buf = NULL;
    g_nativeOutput.cap = 0;
    g_nativeOutput.len = 0;
    g_nativeOutput.ok = 1;
    g_nativeCount = 0;
    BarkBufAppend(&g_nativeOutput, "{\"data\":[", 9);

    int fileCount = 0;
    int totalAdded = 0;

    if (g_use_download) {
        /* Diskless mode: role assignment data passed as blob from CNA.
         * Wire format: [uint32 count][uint32 len_0][data_0]...[uint32 len_N][data_N] */
        int blobLen = 0;
        char *blob = BeaconDataExtract(&parser, &blobLen);
        if (!blob || blobLen < 4) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] No role assignment data blob provided.\n"
                "    Run role assignment BOFs first with download mode ON,\n"
                "    then re-run this command.\n");
            BeaconPrintf(CALLBACK_OUTPUT,
                "[BARK/v5] all-info collector complete: role_graph_conversion\n");
            BarkBufFree(&g_nativeOutput);
            return;
        }

        unsigned int count = *(unsigned int *)blob;
        char *p = blob + 4;
        char *blobEnd = blob + blobLen;

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] convert_az_role_assignments_to_graph_bh: "
            "processing %u in-memory segment(s)\n", count);

        unsigned int i;
        for (i = 0; i < count && p + 4 <= blobEnd; i++) {
            unsigned int segLen = *(unsigned int *)p;
            p += 4;
            if (p + segLen > blobEnd) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Blob segment %u overflows (len=%u, remaining=%u)\n",
                    i, segLen, (unsigned int)(blobEnd - p));
                break;
            }
            if (segLen == 0) continue;

            char *content = (char *)HAlloc(segLen + 1);
            if (!content) continue;
            MSVCRT$memcpy(content, p, segLen);
            content[segLen] = '\0';

            int n = ProcessFile(content, (SIZE_T)segLen);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] segment[%u] (%u bytes) - %d assignment(s) parsed\n",
                i, segLen, n);
            totalAdded += n;
            fileCount++;

            HFree(content);
            p += segLen;
        }
    } else {
        /* Disk mode: enumerate matching files */
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] convert_az_role_assignments_to_graph_bh: scanning %s\n",
            pattern);

        WIN32_FIND_DATAA fd;
        HANDLE hFind = KERNEL32$FindFirstFileA(pattern, &fd);
        if (hFind == INVALID_HANDLE_VALUE) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] No files matching %s\n", pattern);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[BARK/v5] all-info collector complete: role_graph_conversion\n");
            BarkBufFree(&g_nativeOutput);
            return;
        }

        do {
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;

            HANDLE hf = KERNEL32$CreateFileA(fd.cFileName,
                GENERIC_READ, FILE_SHARE_READ, NULL,
                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hf == INVALID_HANDLE_VALUE) continue;

            DWORD fsize = KERNEL32$GetFileSize(hf, NULL);
            if (fsize == INVALID_FILE_SIZE || fsize == 0) {
                KERNEL32$CloseHandle(hf);
                continue;
            }

            char *content = (char *)HAlloc(fsize + 1);
            if (!content) {
                KERNEL32$CloseHandle(hf);
                continue;
            }

            DWORD nread = 0;
            if (KERNEL32$ReadFile(hf, content, fsize, &nread, NULL) &&
                nread > 0) {
                content[nread] = '\0';
                int n = ProcessFile(content, (SIZE_T)nread);
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[*] %s - %d assignment(s) parsed\n", fd.cFileName, n);
                totalAdded += n;
                fileCount++;
            }

            HFree(content);
            KERNEL32$CloseHandle(hf);
        } while (KERNEL32$FindNextFileA(hFind, &fd));
        KERNEL32$FindClose(hFind);
    }

    if (fileCount == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No readable JSON data found%s\n",
            g_use_download ? " in blob" : "");
        BeaconPrintf(CALLBACK_OUTPUT,
            "[BARK/v5] all-info collector complete: role_graph_conversion\n");
        BarkBufFree(&g_nativeOutput);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Processed %d file(s), %d total assignments, "
        "%d unique node(s), %d edge(s)\n",
        fileCount, totalAdded, g_nodeCount, g_edgeCount);

    if (g_nodeCount == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[-] No graph data extracted - check that the files contain "
            "valid BH role-assignment envelopes.\n");
        BeaconPrintf(CALLBACK_OUTPUT,
            "[BARK/v5] all-info collector complete: role_graph_conversion\n");
        BarkBufFree(&g_nativeOutput);
        return;
    }

    WriteGraphJSON();
    WriteNativeRBACJSON();
    BarkBufFree(&g_nativeOutput);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: role_graph_conversion\n");
}
