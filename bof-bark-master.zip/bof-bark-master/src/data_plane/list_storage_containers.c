/* List Azure Blob Storage containers with a storage-scoped bearer token. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/storage_blob_utils.h"

void go(char *args, int alen) {
    datap parser;
    char *token;
    char *accountName;
    char host[96];
    char *marker = NULL;
    int pages = 0;
    int containers = 0;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    accountName = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0 ||
        !BarkStorageIsAccountName(accountName)) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_list_storage_containers <storageToken> <accountName>\n"
            "    accountName must be 3-24 lowercase letters or digits.\n");
        return;
    }

    MSVCRT$sprintf_s(host, sizeof(host), "%s.blob.core.windows.net", accountName);
    LPWSTR headers = BarkMakeAuthHeader(token,
        "x-ms-version: " BARK_STORAGE_API_VERSION "\r\n");
    if (!headers) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build storage auth header\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Listing containers in storage account: %s\n", accountName);

    while (1) {
        char *path = BarkStorageBuildListPath(NULL, marker);
        DWORD status = 0;
        char *response;
        const char *cursor;
        const char *end;

        if (!path) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build container list path\n");
            break;
        }
        LPWSTR wideHost = MbsToWcs(host);
        LPWSTR widePath = MbsToWcs(path);
        HFree(path);
        if (!wideHost || !widePath) {
            if (wideHost) HFree(wideHost);
            if (widePath) HFree(widePath);
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert storage request path\n");
            break;
        }

        response = HttpRequestWithRetry(L"GET", wideHost, widePath,
                                        headers, NULL, 0, &status);
        HFree(wideHost);
        HFree(widePath);
        pages++;

        if (!response || status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Container listing failed: HTTP %lu\n", status);
            if (response) HFree(response);
            break;
        }

        end = response + MSVCRT$strlen(response);
        cursor = response;
        while (1) {
            const char *itemEnd;
            const char *item = BarkStorageXmlNextItem(cursor, end,
                                                       "Container", &itemEnd);
            char *name;
            if (!item) break;
            name = BarkStorageXmlValue(item, itemEnd, "Name");
            if (name) {
                BeaconPrintf(CALLBACK_OUTPUT, "[+] container: %s\n", name);
                containers++;
                HFree(name);
            }
            cursor = itemEnd;
        }

        char *nextMarker = BarkStorageXmlNextMarker(response);
        HFree(response);
        if (!nextMarker) break;
        if (marker && MSVCRT$strcmp(marker, nextMarker) == 0) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Storage returned a repeated continuation marker; stopping\n");
            HFree(nextMarker);
            break;
        }
        if (marker) HFree(marker);
        marker = nextMarker;
    }

    if (marker) HFree(marker);
    HFree(headers);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Container listing complete: %d container(s), %d page(s)\n",
        containers, pages);
}
