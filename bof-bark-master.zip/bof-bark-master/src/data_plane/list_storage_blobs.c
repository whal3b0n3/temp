/* List Azure Blob Storage objects in a container with a bearer token. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/storage_blob_utils.h"

static const char *BarkStorageText(const char *value) {
    return value ? value : "-";
}

void go(char *args, int alen) {
    datap parser;
    char *token;
    char *accountName;
    char *containerName;
    char host[96];
    char *marker = NULL;
    int pages = 0;
    int blobs = 0;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    accountName = BeaconDataExtract(&parser, NULL);
    containerName = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0 ||
        !BarkStorageIsAccountName(accountName) ||
        !BarkStorageIsContainerName(containerName)) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_list_storage_blobs <storageToken> <accountName> <containerName>\n"
            "    accountName must be 3-24 lowercase letters or digits;\n"
            "    containerName must be a valid Azure Blob container name.\n");
        return;
    }

    MSVCRT$sprintf_s(host, sizeof(host), "%s.blob.core.windows.net", accountName);
    LPWSTR headers = BarkMakeAuthHeader(token,
        "x-ms-version: " BARK_STORAGE_API_VERSION "\r\n");
    if (!headers) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build storage auth header\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Listing blobs in %s/%s\n", accountName, containerName);

    while (1) {
        char *path = BarkStorageBuildListPath(containerName, marker);
        DWORD status = 0;
        char *response;
        const char *cursor;
        const char *end;

        if (!path) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to build blob list path\n");
            break;
        }
        LPWSTR wideHost = MbsToWcs(host);
        LPWSTR widePath = MbsToWcs(path);
        HFree(path);
        if (!wideHost || !widePath) {
            if (wideHost) HFree(wideHost);
            if (widePath) HFree(widePath);
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert storage request path\n");
            break;
        }

        response = HttpRequestWithRetry(L"GET", wideHost, widePath,
                                        headers, NULL, 0, &status);
        HFree(wideHost);
        HFree(widePath);
        pages++;

        if (!response || status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Blob listing failed: HTTP %lu\n", status);
            if (response) HFree(response);
            break;
        }

        end = response + MSVCRT$strlen(response);
        cursor = response;
        while (1) {
            const char *itemEnd;
            const char *item = BarkStorageXmlNextItem(cursor, end,
                                                       "Blob", &itemEnd);
            char *name;
            char *length;
            char *contentType;
            char *lastModified;
            char *blobType;
            char *etag;
            if (!item) break;

            name = BarkStorageXmlValue(item, itemEnd, "Name");
            length = BarkStorageXmlValue(item, itemEnd, "Content-Length");
            contentType = BarkStorageXmlValue(item, itemEnd, "Content-Type");
            lastModified = BarkStorageXmlValue(item, itemEnd, "Last-Modified");
            blobType = BarkStorageXmlValue(item, itemEnd, "BlobType");
            etag = BarkStorageXmlValue(item, itemEnd, "Etag");
            if (name) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[+] blob: %s | size=%s | type=%s | modified=%s | blobType=%s | etag=%s\n",
                    name, BarkStorageText(length), BarkStorageText(contentType),
                    BarkStorageText(lastModified), BarkStorageText(blobType),
                    BarkStorageText(etag));
                blobs++;
            }
            if (name) HFree(name);
            if (length) HFree(length);
            if (contentType) HFree(contentType);
            if (lastModified) HFree(lastModified);
            if (blobType) HFree(blobType);
            if (etag) HFree(etag);
            cursor = itemEnd;
        }

        char *nextMarker = BarkStorageXmlNextMarker(response);
        HFree(response);
        if (!nextMarker) break;
        if (marker && MSVCRT$strcmp(marker, nextMarker) == 0) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Storage returned a repeated continuation marker; stopping\n");
            HFree(nextMarker);
            break;
        }
        if (marker) HFree(marker);
        marker = nextMarker;
    }

    if (marker) HFree(marker);
    HFree(headers);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Blob listing complete: %d blob(s), %d page(s)\n", blobs, pages);
}
