/*
 * set_entra_user_attribute.c — BARK BOF
 * Set-EntraUserAttribute — Update a single writable attribute on an Entra user
 *
 * PATCH https://graph.microsoft.com/v1.0/users/{userId}
 *
 * Automatically selects the correct JSON encoding for the attribute type:
 *   accountEnabled, showInAddressList  -> boolean   (true / false)
 *   businessPhones, otherMails         -> string[]  (["value"])
 *   all other properties               -> string    ("value")
 *
 * Args : token, userId, attributeName, attributeValue
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* Returns 1 if the attribute name is a Graph boolean property */
static int IsBoolAttr(const char *name)
{
    return (MSVCRT$strcmp(name, "accountEnabled")    == 0 ||
            MSVCRT$strcmp(name, "showInAddressList") == 0);
}

/* Returns 1 if the attribute name is a Graph string-array property */
static int IsArrayAttr(const char *name)
{
    return (MSVCRT$strcmp(name, "businessPhones") == 0 ||
            MSVCRT$strcmp(name, "otherMails")     == 0);
}

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token         = NULL;
    char  *userId        = NULL;
    char  *attributeName = NULL;
    char  *attributeValue = NULL;

    BeaconDataParse(&parser, args, alen);
    token          = BeaconDataExtract(&parser, NULL);
    userId         = BeaconDataExtract(&parser, NULL);
    attributeName  = BeaconDataExtract(&parser, NULL);
    attributeValue = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0 ||
        !userId || MSVCRT$strlen(userId) == 0 ||
        !attributeName || MSVCRT$strlen(attributeName) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_set_entra_user_attribute"
            " <token> <userId> <attributeName> <attributeValue>\n");
        return;
    }
    if (!attributeValue) attributeValue = "";

    /* ── Build JSON body with correct type encoding ─────────────── */
    if (IsBoolAttr(attributeName)) {
        /* Compare case-insensitively: accept "true"/"1" as true */
        int isTrue = (MSVCRT$strcmp(attributeValue, "true")  == 0 ||
                      MSVCRT$strcmp(attributeValue, "True")  == 0 ||
                      MSVCRT$strcmp(attributeValue, "TRUE")  == 0 ||
                      MSVCRT$strcmp(attributeValue, "1")     == 0);
        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "{\"%s\":%s}", attributeName, isTrue ? "true" : "false");
    }
    else if (IsArrayAttr(attributeName)) {
        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "{\"%s\":[\"%s\"]}", attributeName, attributeValue);
    }
    else {
        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "{\"%s\":\"%s\"}", attributeName, attributeValue);
    }

    /* ── Build URL path ─────────────────────────────────────────── */
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/users/%s", userId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Set-EntraUserAttribute: PATCH user %s  { %s: %s }\n",
        userId, attributeName, attributeValue);

    BarkPost(L"graph.microsoft.com", widePath, L"PATCH",
             bodyBuf, token, "application/json");

    HFree(widePath);
}
