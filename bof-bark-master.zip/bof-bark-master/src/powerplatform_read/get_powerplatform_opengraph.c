/*
 * get_powerplatform_opengraph.c — BARK BOF
 *
 * Conservative read-only Power Platform discovery using documented direct
 * Power Platform REST API endpoints only.
 *
 * Collected:
 *   - Environments:
 *       GET https://api.powerplatform.com/environmentmanagement/environments?api-version=2024-10-01
 *   - Connections per environment:
 *       GET https://api.powerplatform.com/connectivity/environments/{environmentId}/connections?api-version=2024-10-01
 *   - Cloud flows per Dataverse-backed environment:
 *       GET https://api.powerplatform.com/powerautomate/environments/{environmentId}/cloudFlows?api-version=2024-10-01
 *   - Inventory query for agents, flows, and connector metadata:
 *       POST https://api.powerplatform.com/resourcequery/resources/query?api-version=2024-10-01
 *
 * Not collected:
 *   - Connection secrets/credentials.
 *   - Flow definitions/clientdata, connection secrets, run history, or
 *     individual run-only principals. Inventory owner IDs and connector
 *     metadata are collected without reading credentials or runtime content.
 *
 * Args: powerPlatformToken, downloadMode
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define PP_API_VERSION "2024-10-01"
#define PP_HOST_W L"api.powerplatform.com"

typedef struct {
    char **ids;
    int count;
    int cap;
} PPEnvRefs;

typedef struct {
    BarkBuf nodes;
    BarkBuf edges;
    int nodeCount;
    int edgeCount;
    int envCount;
    int connCount;
    int flowCount;
    int agentCount;
    int failedEnvPages;
    int failedConnectionEnvs;
    int failedConnectionPages;
    int failedFlowEnvs;
} PPGraph;

static void PPEnvRefsInit(PPEnvRefs *refs) {
    refs->ids = NULL;
    refs->count = 0;
    refs->cap = 0;
}

static int PPEnvRefsAdd(PPEnvRefs *refs, const char *id) {
    char **newIds;
    char *copy;
    int i;

    if (!id || MSVCRT$strlen(id) == 0)
        return 1;

    for (i = 0; i < refs->count; i++) {
        if (MSVCRT$strcmp(refs->ids[i], id) == 0)
            return 1;
    }

    if (refs->count >= refs->cap) {
        int newCap = refs->cap == 0 ? 32 : refs->cap * 2;
        newIds = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        if (!newIds)
            return 0;
        if (refs->count > 0)
            MSVCRT$memcpy(newIds, refs->ids,
                          (SIZE_T)refs->count * sizeof(char *));
        if (refs->ids)
            HFree(refs->ids);
        refs->ids = newIds;
        refs->cap = newCap;
    }

    copy = (char *)HAlloc(MSVCRT$strlen(id) + 1);
    if (!copy)
        return 0;
    MSVCRT$memcpy(copy, id, MSVCRT$strlen(id) + 1);
    refs->ids[refs->count++] = copy;
    return 1;
}

static void PPEnvRefsFree(PPEnvRefs *refs) {
    int i;
    for (i = 0; i < refs->count; i++)
        HFree(refs->ids[i]);
    HFree(refs->ids);
    PPEnvRefsInit(refs);
}

static void PPJsonString(BarkBuf *b, const char *value) {
    size_t i;
    char escaped[8];

    BarkBufAppend(b, "\"", 1);
    if (value) {
        for (i = 0; value[i]; i++) {
            unsigned char c = (unsigned char)value[i];
            if (c == '"' || c == '\\') {
                BarkBufAppend(b, "\\", 1);
                BarkBufAppend(b, (const char *)&value[i], 1);
            } else if (c == '\n') {
                BarkBufAppend(b, "\\n", 2);
            } else if (c == '\r') {
                BarkBufAppend(b, "\\r", 2);
            } else if (c == '\t') {
                BarkBufAppend(b, "\\t", 2);
            } else if (c < 0x20) {
                MSVCRT$sprintf_s(escaped, sizeof(escaped), "\\u%04x", c);
                BarkBufAppend(b, escaped, MSVCRT$strlen(escaped));
            } else {
                BarkBufAppend(b, (const char *)&value[i], 1);
            }
        }
    }
    BarkBufAppend(b, "\"", 1);
}

static void PPProperty(BarkBuf *b, int *first, const char *name,
                       const char *value) {
    if (!value || MSVCRT$strlen(value) == 0)
        return;
    if (!*first)
        BarkBufAppend(b, ",", 1);
    PPJsonString(b, name);
    BarkBufAppend(b, ":", 1);
    PPJsonString(b, value);
    *first = 0;
}

static void PPPropertyFromJson(BarkBuf *b, int *first,
                               const char *item, const char *itemEnd,
                               const char *name, const char *jsonKey) {
    if (!item || !itemEnd)
        return;
    char *value = JsonExtractStringValueUtf8(item, itemEnd, jsonKey);
    PPProperty(b, first, name, value);
    if (value)
        HFree(value);
}

static char *PPExtractPrimitiveValue(const char *obj, const char *objEnd,
                                     const char *jsonKey) {
    const char *key = JsonFindKey(obj, objEnd, jsonKey);
    const char *p;
    const char *start;
    size_t len;
    char *result;

    if (!key)
        return NULL;
    p = key + MSVCRT$strlen(jsonKey);
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
                          *p == '\n' || *p == '\r'))
        p++;
    if (p >= objEnd || *p != ':')
        return NULL;
    p++;
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
                          *p == '\n' || *p == '\r'))
        p++;
    if (p >= objEnd || *p == '"' || *p == '{' || *p == '[')
        return NULL;
    start = p;
    while (p < objEnd && *p != ',' && *p != '}' && *p != ']' &&
           *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r')
        p++;
    if (p <= start)
        return NULL;
    len = (size_t)(p - start);
    result = (char *)HAlloc(len + 1);
    if (!result)
        return NULL;
    MSVCRT$memcpy(result, start, len);
    result[len] = '\0';
    return result;
}

static void PPPropertyPrimitiveFromJson(BarkBuf *b, int *first,
                                        const char *item,
                                        const char *itemEnd,
                                        const char *name,
                                        const char *jsonKey) {
    if (!item || !itemEnd)
        return;
    char *value = PPExtractPrimitiveValue(item, itemEnd, jsonKey);
    PPProperty(b, first, name, value);
    if (value)
        HFree(value);
}

static int PPGraphHasNode(const PPGraph *graph, const char *nodeId) {
    const char *p;
    size_t idLen;
    if (!graph || !graph->nodes.buf || !nodeId) return 0;
    idLen = MSVCRT$strlen(nodeId);
    p = graph->nodes.buf;
    while (p < graph->nodes.buf + graph->nodes.len) {
        if (MSVCRT$strncmp(p, "{\"id\":\"", 8) == 0 &&
            MSVCRT$strncmp(p + 8, nodeId, idLen) == 0 &&
            p[8 + idLen] == '"')
            return 1;
        p++;
    }
    return 0;
}

static char *PPNodeId2(const char *prefix, const char *id) {
    size_t size;
    char *nodeId;

    if (!prefix || !id)
        return NULL;
    size = MSVCRT$strlen(prefix) + MSVCRT$strlen(id) + 1;
    nodeId = (char *)HAlloc(size);
    if (!nodeId)
        return NULL;
    MSVCRT$sprintf_s(nodeId, size, "%s%s", prefix, id);
    return nodeId;
}

static char *PPNodeId3(const char *prefix, const char *environmentId,
                       const char *id) {
    size_t size;
    char *nodeId;

    if (!prefix || !environmentId || !id)
        return NULL;
    size = MSVCRT$strlen(prefix) + MSVCRT$strlen(environmentId) +
           MSVCRT$strlen(id) + 2;
    nodeId = (char *)HAlloc(size);
    if (!nodeId)
        return NULL;
    MSVCRT$sprintf_s(nodeId, size, "%s%s:%s", prefix, environmentId, id);
    return nodeId;
}

static const char *PPFindObjectValue(const char *item, const char *itemEnd,
                                     const char *jsonKey,
                                     const char **objectEnd) {
    const char *key = JsonFindKey(item, itemEnd, jsonKey);
    const char *colon;
    const char *p;
    const char *end;

    if (!key)
        return NULL;
    colon = JsonFindKey(key, itemEnd, ":");
    if (!colon)
        return NULL;
    p = colon + 1;
    while (p < itemEnd &&
           (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r'))
        p++;
    if (p >= itemEnd || *p != '{')
        return NULL;
    end = JsonSkipBalanced(p, itemEnd);
    if (!end)
        return NULL;
    if (objectEnd)
        *objectEnd = end;
    return p;
}

static const char *PPFindArrayValue(const char *item, const char *itemEnd,
                                    const char *jsonKey,
                                    const char **arrayEnd) {
    const char *key = JsonFindKey(item, itemEnd, jsonKey);
    const char *p;
    const char *end;

    if (!key)
        return NULL;
    p = key + MSVCRT$strlen(jsonKey);
    while (p < itemEnd && (*p == ' ' || *p == '\t' ||
                           *p == '\n' || *p == '\r'))
        p++;
    if (p >= itemEnd || *p != ':')
        return NULL;
    p++;
    while (p < itemEnd && (*p == ' ' || *p == '\t' ||
                           *p == '\n' || *p == '\r'))
        p++;
    if (p >= itemEnd || *p != '[')
        return NULL;
    end = JsonSkipBalanced(p, itemEnd);
    if (!end)
        return NULL;
    if (arrayEnd)
        *arrayEnd = end;
    return p + 1;
}

static int PPAppendEdge(PPGraph *graph, const char *kind,
                        const char *start, const char *end) {
    if (!start || !end || MSVCRT$strlen(start) == 0 ||
        MSVCRT$strlen(end) == 0)
        return 1;

    if (graph->edgeCount > 0)
        BarkBufAppend(&graph->edges, ",", 1);
    BarkBufAppend(&graph->edges, "{\"kind\":",
                  MSVCRT$strlen("{\"kind\":"));
    PPJsonString(&graph->edges, kind);
    BarkBufAppend(&graph->edges, ",\"start\":{\"value\":",
                  MSVCRT$strlen(",\"start\":{\"value\":"));
    PPJsonString(&graph->edges, start);
    BarkBufAppend(&graph->edges,
                  ",\"match_by\":\"id\"},\"end\":{\"value\":",
                  MSVCRT$strlen(",\"match_by\":\"id\"},\"end\":{\"value\":"));
    PPJsonString(&graph->edges, end);
    BarkBufAppend(&graph->edges, ",\"match_by\":\"id\"}}",
                  MSVCRT$strlen(",\"match_by\":\"id\"}}"));
    graph->edgeCount++;
    return graph->edges.ok;
}

static int PPAppendEnvironmentNode(PPGraph *graph, PPEnvRefs *envRefs,
                                   const char *item, const char *itemEnd) {
    char *envId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    char *displayName = JsonExtractStringValueUtf8(item, itemEnd,
                                               "\"displayName\"");
    char *nodeId;
    int first = 1;

    if (!envId || MSVCRT$strlen(envId) == 0) {
        if (envId)
            HFree(envId);
        if (displayName)
            HFree(displayName);
        return 1;
    }

    nodeId = PPNodeId2("powerplatform:environment:", envId);
    if (!nodeId) {
        HFree(envId);
        if (displayName)
            HFree(displayName);
        return 0;
    }

    if (PPGraphHasNode(graph, nodeId)) {
        HFree(envId);
        if (displayName)
            HFree(displayName);
        HFree(nodeId);
        return 1;
    }

    if (!PPEnvRefsAdd(envRefs, envId)) {
        HFree(envId);
        if (displayName)
            HFree(displayName);
        HFree(nodeId);
        return 0;
    }

    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, "PowerPlatformEnvironment");
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));

    PPProperty(&graph->nodes, &first, "name", displayName ? displayName : envId);
    PPProperty(&graph->nodes, &first, "displayname", displayName);
    PPProperty(&graph->nodes, &first, "environmentid", envId);
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "tenantid", "\"tenantId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "type", "\"type\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "state", "\"state\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "geo", "\"geo\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "azureregion", "\"azureRegion\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "createddatetime", "\"createdDateTime\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "dataverseid", "\"dataverseId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "domainname", "\"domainName\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "url", "\"url\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "environmentgroupid", "\"environmentGroupId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "connectedgroupid", "\"connectedGroupId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "securitygroupid", "\"securityGroupId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "protectionlevel", "\"protectionLevel\"");
    BarkBufAppend(&graph->nodes, "}}", 2);

    graph->nodeCount++;
    graph->envCount++;
    HFree(envId);
    if (displayName)
        HFree(displayName);
    HFree(nodeId);
    return graph->nodes.ok;
}

static int PPAppendConnectionNode(PPGraph *graph, const char *environmentId,
                                  const char *item, const char *itemEnd) {
    const char *propsEnd = NULL;
    const char *props = PPFindObjectValue(item, itemEnd, "\"properties\"",
                                          &propsEnd);
    char *connectionId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    char *connectionName = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    char *displayName = NULL;
    char *envNodeId;
    char *connNodeId;
    int first = 1;

    if (props)
        displayName = JsonExtractStringValueUtf8(props, propsEnd,
                                             "\"displayName\"");

    if (!connectionId || MSVCRT$strlen(connectionId) == 0) {
        if (connectionId)
            HFree(connectionId);
        if (connectionName)
            HFree(connectionName);
        if (displayName)
            HFree(displayName);
        return 1;
    }

    envNodeId = PPNodeId2("powerplatform:environment:", environmentId);
    connNodeId = PPNodeId3("powerplatform:connection:", environmentId,
                           connectionId);
    if (!envNodeId || !connNodeId) {
        if (connectionId)
            HFree(connectionId);
        if (connectionName)
            HFree(connectionName);
        if (displayName)
            HFree(displayName);
        if (envNodeId)
            HFree(envNodeId);
        if (connNodeId)
            HFree(connNodeId);
        return 0;
    }

    if (PPGraphHasNode(graph, connNodeId)) {
        HFree(connectionId);
        if (connectionName)
            HFree(connectionName);
        if (displayName)
            HFree(displayName);
        HFree(envNodeId);
        HFree(connNodeId);
        return 1;
    }

    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, connNodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, "PowerPlatformConnection");
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));

    PPProperty(&graph->nodes, &first, "name",
               displayName ? displayName :
               (connectionName ? connectionName : connectionId));
    PPProperty(&graph->nodes, &first, "displayname", displayName);
    PPProperty(&graph->nodes, &first, "connectionid", connectionId);
    PPProperty(&graph->nodes, &first, "connectionname", connectionName);
    PPProperty(&graph->nodes, &first, "environmentid", environmentId);
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "type", "\"type\"");
    if (props) {
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "apienvironment", "\"apiEnvironment\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "apiversion", "\"apiVersion\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "createdtime", "\"createdTime\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "changedtime", "\"changedTime\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "description", "\"description\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "publisher", "\"publisher\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "tier", "\"tier\"");
        PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                           "releasetag", "\"releaseTag\"");
    }
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
    graph->connCount++;

    if (!PPAppendEdge(graph, "PowerPlatformEnvironmentHasConnection",
                      envNodeId, connNodeId)) {
        HFree(connectionId);
        if (connectionName)
            HFree(connectionName);
        if (displayName)
            HFree(displayName);
        HFree(envNodeId);
        HFree(connNodeId);
        return 0;
    }

    HFree(connectionId);
    if (connectionName)
        HFree(connectionName);
    if (displayName)
        HFree(displayName);
    HFree(envNodeId);
    HFree(connNodeId);
    return graph->nodes.ok && graph->edges.ok;
}

static const char *PPFindValueArray(const char *resp, const char *end,
                                    const char **arrayEnd) {
    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    const char *colon;
    const char *bracket;
    const char *close;

    if (!vKey)
        return NULL;
    colon = JsonFindKey(vKey, end, ":");
    if (!colon)
        return NULL;
    bracket = colon + 1;
    while (bracket < end &&
           (*bracket == ' ' || *bracket == '\t' ||
            *bracket == '\n' || *bracket == '\r'))
        bracket++;
    if (bracket >= end || *bracket != '[')
        return NULL;
    close = JsonSkipBalanced(bracket, end);
    if (!close)
        return NULL;
    if (arrayEnd)
        *arrayEnd = close;
    return bracket + 1;
}

static const char *PPFindDataArray(const char *resp, const char *end,
                                   const char **arrayEnd) {
    return PPFindArrayValue(resp, end, "\"data\"", arrayEnd);
}

static LPWSTR PPResolveNextLink(const char *nextUrl) {
    const char *path = nextUrl;
    char *pathBuf = NULL;
    LPWSTR widePath;
    size_t needed;

    if (!nextUrl || MSVCRT$strlen(nextUrl) == 0)
        return NULL;

    if (MSVCRT$strncmp(nextUrl, "https://api.powerplatform.com/", 30) == 0) {
        path = nextUrl + 29;
    } else if (nextUrl[0] == '/') {
        path = nextUrl;
    } else if (MSVCRT$strncmp(nextUrl, "http://", 7) == 0 ||
               MSVCRT$strncmp(nextUrl, "https://", 8) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Refusing Power Platform pagination URL for unexpected host: %.120s\n",
            nextUrl);
        return NULL;
    }

    if (path[0] == '/') {
        return MbsToWcs(path);
    }

    needed = MSVCRT$strlen(path) + 2;
    pathBuf = (char *)HAlloc(needed);
    if (!pathBuf)
        return NULL;
    MSVCRT$sprintf_s(pathBuf, needed, "/%s", path);
    widePath = MbsToWcs(pathBuf);
    HFree(pathBuf);
    return widePath;
}

static char *PPGetPage(LPCWSTR widePath, const char *bearerToken,
                       DWORD *status) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken,
        "Accept: application/json\r\n");
    char *resp;

    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform: header conversion failed\n");
        return NULL;
    }

    resp = HttpRequestWithRetry(L"GET", PP_HOST_W, widePath,
                                hdrWide, NULL, 0, status);
    HFree(hdrWide);
    return resp;
}

static int PPProcessEnvironmentsPage(PPGraph *graph, PPEnvRefs *envRefs,
                                     const char *resp) {
    const char *end = resp + MSVCRT$strlen(resp);
    const char *arrEnd = NULL;
    const char *p = PPFindValueArray(resp, end, &arrEnd);

    if (!p)
        return -1;

    while (p < arrEnd - 1) {
        const char *itemEnd;
        while (p < arrEnd - 1 &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= arrEnd - 1)
            break;
        if (*p != '{')
            break;
        itemEnd = JsonSkipBalanced(p, arrEnd);
        if (!itemEnd)
            break;
        if (!PPAppendEnvironmentNode(graph, envRefs, p, itemEnd))
            return 0;
        p = itemEnd;
    }
    return 1;
}

static int PPCollectEnvironments(PPGraph *graph, PPEnvRefs *envRefs,
                                 const char *bearerToken) {
    LPCWSTR pathArg =
        L"/environmentmanagement/environments?api-version=" PP_API_VERSION;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    int page = 0;
    int ok = 1;

    for (;;) {
        DWORD status = 0;
        char *resp = PPGetPage(pathArg, bearerToken, &status);

        if (nextUrl) {
            HFree(nextUrl);
            nextUrl = NULL;
        }
        if (nextWide) {
            HFree(nextWide);
            nextWide = NULL;
        }

        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform environments request failed (HTTP %lu)\n",
                status);
            graph->failedEnvPages++;
            ok = 0;
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform environments HTTP %lu:\n    %s\n",
                status, resp);
            HFree(resp);
            graph->failedEnvPages++;
            ok = 0;
            break;
        }

        {
            int processed = PPProcessEnvironmentsPage(graph, envRefs, resp);
            if (processed < 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] PowerPlatform environments response did not contain a value array\n");
                graph->failedEnvPages++;
                ok = 0;
            } else if (processed == 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Out of memory while processing Power Platform environments\n");
                ok = 0;
            }
        }

        nextUrl = JsonExtractNextLink(resp, resp + MSVCRT$strlen(resp));
        HFree(resp);
        page++;

        if (!ok || !nextUrl)
            break;
        nextWide = PPResolveNextLink(nextUrl);
        if (!nextWide) {
            graph->failedEnvPages++;
            ok = 0;
            break;
        }
        pathArg = nextWide;
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] PowerPlatform environments pagination: page %d, %d environments so far\n",
            page, graph->envCount);
    }

    if (nextUrl)
        HFree(nextUrl);
    if (nextWide)
        HFree(nextWide);
    return ok;
}

static int PPProcessConnectionsPage(PPGraph *graph, const char *environmentId,
                                    const char *resp) {
    const char *end = resp + MSVCRT$strlen(resp);
    const char *arrEnd = NULL;
    const char *p = PPFindValueArray(resp, end, &arrEnd);

    if (!p)
        return -1;

    while (p < arrEnd - 1) {
        const char *itemEnd;
        while (p < arrEnd - 1 &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= arrEnd - 1)
            break;
        if (*p != '{')
            break;
        itemEnd = JsonSkipBalanced(p, arrEnd);
        if (!itemEnd)
            break;
        if (!PPAppendConnectionNode(graph, environmentId, p, itemEnd))
            return 0;
        p = itemEnd;
    }
    return 1;
}

static int PPCollectConnectionsForEnvironment(PPGraph *graph,
                                              const char *environmentId,
                                              const char *bearerToken) {
    char pathBuf[1024];
    LPWSTR firstPath;
    LPCWSTR pathArg;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    int page = 0;
    int ok = 1;

    if (MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/connectivity/environments/%s/connections?api-version=%s",
        environmentId, PP_API_VERSION) < 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform connection path exceeded local buffer for environment %.80s\n",
            environmentId);
        graph->failedConnectionEnvs++;
        return 0;
    }

    firstPath = MbsToWcs(pathBuf);
    if (!firstPath) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform connection path conversion failed\n");
        graph->failedConnectionEnvs++;
        return 0;
    }
    pathArg = firstPath;

    for (;;) {
        DWORD status = 0;
        char *resp = PPGetPage(pathArg, bearerToken, &status);

        if (nextUrl) {
            HFree(nextUrl);
            nextUrl = NULL;
        }
        if (nextWide) {
            HFree(nextWide);
            nextWide = NULL;
        }

        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform connections request failed for environment %.80s (HTTP %lu)\n",
                environmentId, status);
            graph->failedConnectionEnvs++;
            graph->failedConnectionPages++;
            ok = 0;
            break;
        }
        if (status == 204) {
            HFree(resp);
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform connections HTTP %lu for environment %.80s:\n    %s\n",
                status, environmentId, resp);
            HFree(resp);
            graph->failedConnectionEnvs++;
            graph->failedConnectionPages++;
            ok = 0;
            break;
        }

        {
            int processed = PPProcessConnectionsPage(graph, environmentId, resp);
            if (processed < 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] PowerPlatform connections response for environment %.80s did not contain a value array\n",
                    environmentId);
                graph->failedConnectionEnvs++;
                graph->failedConnectionPages++;
                ok = 0;
            } else if (processed == 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Out of memory while processing Power Platform connections\n");
                ok = 0;
            }
        }

        nextUrl = JsonExtractNextLink(resp, resp + MSVCRT$strlen(resp));
        HFree(resp);
        page++;

        if (!ok || !nextUrl)
            break;
        nextWide = PPResolveNextLink(nextUrl);
        if (!nextWide) {
            graph->failedConnectionPages++;
            ok = 0;
            break;
        }
        pathArg = nextWide;
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] PowerPlatform connections pagination: env %.48s page %d, %d connections so far\n",
            environmentId, page, graph->connCount);
    }

    if (nextUrl)
        HFree(nextUrl);
    if (nextWide)
        HFree(nextWide);
    HFree(firstPath);
    return ok;
}

static void PPCollectConnections(PPGraph *graph, PPEnvRefs *envRefs,
                                 const char *bearerToken) {
    int i;
    for (i = 0; i < envRefs->count; i++)
        PPCollectConnectionsForEnvironment(graph, envRefs->ids[i],
                                           bearerToken);
}

static int PPAppendFlowNode(PPGraph *graph, const char *environmentId,
                            const char *item, const char *itemEnd) {
    char *flowId = JsonExtractStringValueUtf8(item, itemEnd, "\"workflowId\"");
    char *fallbackId = NULL;
    char *displayName = JsonExtractStringValueUtf8(item, itemEnd,
                                               "\"displayName\"");
    char *flowName = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    char *envNodeId;
    char *flowNodeId;
    int first = 1;

    if (!flowId || MSVCRT$strlen(flowId) == 0) {
        if (flowId)
            HFree(flowId);
        flowId = NULL;
        fallbackId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
        flowId = fallbackId;
        fallbackId = NULL;
    }

    if (!flowId || MSVCRT$strlen(flowId) == 0) {
        if (flowId)
            HFree(flowId);
        if (displayName)
            HFree(displayName);
        if (flowName)
            HFree(flowName);
        return 1;
    }

    envNodeId = PPNodeId2("powerplatform:environment:", environmentId);
    flowNodeId = PPNodeId3("powerplatform:flow:", environmentId, flowId);
    if (!envNodeId || !flowNodeId) {
        HFree(flowId);
        if (displayName)
            HFree(displayName);
        if (flowName)
            HFree(flowName);
        if (envNodeId)
            HFree(envNodeId);
        if (flowNodeId)
            HFree(flowNodeId);
        return 0;
    }

    if (PPGraphHasNode(graph, flowNodeId)) {
        HFree(flowId);
        if (displayName)
            HFree(displayName);
        if (flowName)
            HFree(flowName);
        HFree(envNodeId);
        HFree(flowNodeId);
        return 1;
    }

    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, flowNodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, "PowerPlatformFlow");
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));

    PPProperty(&graph->nodes, &first, "name",
               displayName ? displayName :
               (flowName ? flowName : flowId));
    PPProperty(&graph->nodes, &first, "displayname", displayName);
    PPProperty(&graph->nodes, &first, "flowid", flowId);
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "workflowid", "\"workflowId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "resourceid", "\"resourceId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "createdbydataverseid", "\"createdBy\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "ownerdataverseid", "\"ownerId\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "state", "\"state\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "status", "\"status\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "flowtype", "\"type\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "createdon", "\"createdOn\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "modifiedon", "\"modifiedOn\"");
    PPPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                       "description", "\"description\"");
    PPProperty(&graph->nodes, &first, "environmentid", environmentId);
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
    graph->flowCount++;

    if (!PPAppendEdge(graph, "PowerPlatformEnvironmentHasFlow",
                      envNodeId, flowNodeId)) {
        HFree(flowId);
        if (displayName)
            HFree(displayName);
        if (flowName)
            HFree(flowName);
        HFree(envNodeId);
        HFree(flowNodeId);
        return 0;
    }

    HFree(flowId);
    if (displayName)
        HFree(displayName);
    if (flowName)
        HFree(flowName);
    HFree(envNodeId);
    HFree(flowNodeId);
    return graph->nodes.ok && graph->edges.ok;
}

static int PPProcessFlowsPage(PPGraph *graph, const char *environmentId,
                              const char *resp) {
    const char *end = resp + MSVCRT$strlen(resp);
    const char *arrEnd = NULL;
    const char *p = PPFindValueArray(resp, end, &arrEnd);

    if (!p)
        return -1;

    while (p < arrEnd - 1) {
        const char *itemEnd;
        while (p < arrEnd - 1 &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= arrEnd - 1)
            break;
        if (*p != '{')
            break;
        itemEnd = JsonSkipBalanced(p, arrEnd);
        if (!itemEnd)
            break;
        if (!PPAppendFlowNode(graph, environmentId, p, itemEnd))
            return 0;
        p = itemEnd;
    }
    return 1;
}

static int PPCollectFlowsForEnvironment(PPGraph *graph,
                                        const char *environmentId,
                                        const char *bearerToken) {
    char pathBuf[1024];
    LPWSTR firstPath;
    LPCWSTR pathArg;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    int page = 0;
    int ok = 1;

    if (MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/powerautomate/environments/%s/cloudFlows?api-version=%s",
        environmentId, PP_API_VERSION) < 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform flow path exceeded local buffer for environment %.80s\n",
            environmentId);
        graph->failedFlowEnvs++;
        return 0;
    }

    firstPath = MbsToWcs(pathBuf);
    if (!firstPath) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform flow path conversion failed\n");
        graph->failedFlowEnvs++;
        return 0;
    }
    pathArg = firstPath;

    for (;;) {
        DWORD status = 0;
        char *resp = PPGetPage(pathArg, bearerToken, &status);

        if (nextUrl) {
            HFree(nextUrl);
            nextUrl = NULL;
        }
        if (nextWide) {
            HFree(nextWide);
            nextWide = NULL;
        }

        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform flows request failed for environment %.80s (HTTP %lu)\n",
                environmentId, status);
            graph->failedFlowEnvs++;
            ok = 0;
            break;
        }
        if (status == 204) {
            HFree(resp);
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform flows HTTP %lu for environment %.80s:\n    %s\n",
                status, environmentId, resp);
            HFree(resp);
            graph->failedFlowEnvs++;
            ok = 0;
            break;
        }

        {
            int processed = PPProcessFlowsPage(graph, environmentId, resp);
            if (processed < 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] PowerPlatform flows response for environment %.80s did not contain a value array\n",
                    environmentId);
                graph->failedFlowEnvs++;
                ok = 0;
            } else if (processed == 0) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Out of memory while processing PowerPlatform flows\n");
                ok = 0;
            }
        }

        nextUrl = JsonExtractNextLink(resp, resp + MSVCRT$strlen(resp));
        HFree(resp);
        page++;

        if (!ok || !nextUrl)
            break;
        nextWide = PPResolveNextLink(nextUrl);
        if (!nextWide) {
            graph->failedFlowEnvs++;
            ok = 0;
            break;
        }
        pathArg = nextWide;
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] PowerPlatform flows pagination: env %.48s page %d, %d flows so far\n",
            environmentId, page, graph->flowCount);
    }

    if (nextUrl)
        HFree(nextUrl);
    if (nextWide)
        HFree(nextWide);
    HFree(firstPath);
    return ok;
}

static void PPCollectFlows(PPGraph *graph, PPEnvRefs *envRefs,
                           const char *bearerToken) {
    int i;
    for (i = 0; i < envRefs->count; i++)
        PPCollectFlowsForEnvironment(graph, envRefs->ids[i], bearerToken);
}

static char *PPBuildInventoryQuery(const char *skipToken) {
    BarkBuf body = { NULL, 0, 0, 1 };

    BarkBufAppend(&body, "{\"Options\":{\"Top\":1000,\"Skip\":0,\"SkipToken\":",
                  MSVCRT$strlen("{\"Options\":{\"Top\":1000,\"Skip\":0,\"SkipToken\":"));
    PPJsonString(&body, skipToken ? skipToken : "");
    BarkBufAppend(&body,
        "},\"TableName\":\"PowerPlatformResources\",\"Clauses\":[{\"$type\":\"where\",\"FieldName\":\"type\",\"Operator\":\"in~\",\"Values\":[\"'microsoft.copilotstudio/agents'\",\"'microsoft.powerautomate/cloudflows'\",\"'microsoft.powerautomate/agentflows'\",\"'microsoft.powerautomate/m365agentflows'\"]}]}\n",
        MSVCRT$strlen("},\"TableName\":\"PowerPlatformResources\",\"Clauses\":[{\"$type\":\"where\",\"FieldName\":\"type\",\"Operator\":\"in~\",\"Values\":[\"'microsoft.copilotstudio/agents'\",\"'microsoft.powerautomate/cloudflows'\",\"'microsoft.powerautomate/agentflows'\",\"'microsoft.powerautomate/m365agentflows'\"]}]}\n"));
    if (!body.ok || !body.buf) {
        BarkBufFree(&body);
        return NULL;
    }
    return body.buf;
}

static char *PPGetInventoryPage(const char *bearerToken,
                                const char *skipToken, DWORD *status) {
    const char *path = "/resourcequery/resources/query?api-version=" PP_API_VERSION;
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken,
        "Accept: application/json\r\nContent-Type: application/json\r\n");
    char *body;
    LPWSTR pathWide;
    char *resp;

    if (!hdrWide)
        return NULL;
    pathWide = MbsToWcs(path);
    if (!pathWide) {
        HFree(hdrWide);
        return NULL;
    }
    body = PPBuildInventoryQuery(skipToken);
    if (!body) {
        HFree(hdrWide);
        HFree(pathWide);
        return NULL;
    }
    resp = HttpRequestWithRetry(L"POST", PP_HOST_W, pathWide, hdrWide,
                                body, (DWORD)MSVCRT$strlen(body), status);
    HFree(body);
    HFree(hdrWide);
    HFree(pathWide);
    return resp;
}

static void PPAppendTypedNode(PPGraph *graph, const char *nodeId,
                              const char *kind, const char *name,
                              const char *key1, const char *value1,
                              const char *key2, const char *value2,
                              const char *key3, const char *value3) {
    int first = 1;

    if (!nodeId || !kind || PPGraphHasNode(graph, nodeId))
        return;
    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, kind);
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));
    PPProperty(&graph->nodes, &first, "name", name);
    PPProperty(&graph->nodes, &first, key1, value1);
    PPProperty(&graph->nodes, &first, key2, value2);
    PPProperty(&graph->nodes, &first, key3, value3);
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
}

static int PPAppendInventoryOperation(PPGraph *graph,
                                       const char *resourceNodeId,
                                       const char *environmentId,
                                       const char *connectorId,
                                       const char *operation,
                                       const char *item,
                                       const char *itemEnd) {
    char *connectionId = JsonExtractStringValueUtf8(item, itemEnd,
                                                 "\"connectionIdSharedByMaker\"");
    char *operationId = JsonExtractStringValueUtf8(item, itemEnd,
                                                "\"operationId\"");
    char *provider = JsonExtractStringValueUtf8(item, itemEnd,
                                            "\"connectionProvider\"");
    char *operationCreator = JsonExtractStringValueUtf8(item, itemEnd,
                                                    "\"createdBy\"");
    char *whenUsed = JsonExtractStringValueUtf8(item, itemEnd,
                                             "\"whenCanBeUsed\"");
    char *requiresConsent = PPExtractPrimitiveValue(item, itemEnd,
                                                    "\"requiresEndUserConsent\"");
    char *operationNodeId = NULL;
    char *accessNodeId = NULL;
    char *connectionNodeId = NULL;
    char *connectorNodeId = NULL;
    size_t size;
    int ok = 1;

    (void)operation;
    if (connectorId && MSVCRT$strlen(connectorId) > 0) {
        connectorNodeId = PPNodeId3("powerplatform:connector:",
                                    environmentId, connectorId);
        PPAppendTypedNode(graph, connectorNodeId, "PowerPlatformConnector",
                          connectorId, "connectorid", connectorId,
                          "environmentid", environmentId, NULL, NULL);
        if (connectorNodeId)
            ok = PPAppendEdge(graph, "PowerPlatformResourceUsesConnector",
                              resourceNodeId, connectorNodeId) && ok;
    }

    if (operationId && MSVCRT$strlen(operationId) > 0) {
        size = MSVCRT$strlen(resourceNodeId) + MSVCRT$strlen(connectorId ? connectorId : "") +
               MSVCRT$strlen(operationId) + 4;
        operationNodeId = (char *)HAlloc(size);
        if (operationNodeId)
            MSVCRT$sprintf_s(operationNodeId, size, "%s:op:%s:%s",
                             resourceNodeId, connectorId ? connectorId : "",
                             operationId);
        PPAppendTypedNode(graph, operationNodeId,
                          "PowerPlatformConnectorOperation", operationId,
                          "operationid", operationId,
                          "connectorid", connectorId,
                          "connectionprovider", provider);
        if (operationNodeId) {
            ok = PPAppendEdge(graph, "PowerPlatformResourceHasOperation",
                              resourceNodeId, operationNodeId) && ok;
            /* Microsoft documents createdBy as the user who configured the
             * connector operation.  Treat it as the effective maker identity
             * only when the operation explicitly uses a maker-provided
             * connection.  This avoids inventing an ActsAs edge for user-
             * provided/OBO connections or for flow resources. */
            if (provider && operationCreator &&
                MSVCRT$strcmp(provider, "Maker") == 0 &&
                MSVCRT$strncmp(resourceNodeId, "powerplatform:agent:", 20) == 0)
                ok = PPAppendEdge(graph, "AZAgent_ActsAs", resourceNodeId,
                                  operationCreator) && ok;
            if (connectionId && MSVCRT$strlen(connectionId) > 0) {
                connectionNodeId = PPNodeId3("powerplatform:connection:",
                                             environmentId, connectionId);
                if (connectionNodeId && PPGraphHasNode(graph, connectionNodeId))
                    ok = PPAppendEdge(graph, "PowerPlatformOperationUsesConnection",
                                      operationNodeId, connectionNodeId) && ok;
            }
            if (whenUsed || requiresConsent) {
                size = MSVCRT$strlen(operationNodeId) + 8;
                accessNodeId = (char *)HAlloc(size);
                if (accessNodeId)
                    MSVCRT$sprintf_s(accessNodeId, size, "%s:access",
                                     operationNodeId);
                PPAppendTypedNode(graph, accessNodeId,
                                  "PowerPlatformOperationAccess",
                                  operationId, "whenused", whenUsed,
                                  "requiresenduserconsent", requiresConsent,
                                  "connectionprovider", provider);
                if (accessNodeId)
                    ok = PPAppendEdge(graph, "PowerPlatformOperationHasAccess",
                                      operationNodeId, accessNodeId) && ok;
            }
        }
    }

    if (connectionId)
        HFree(connectionId);
    if (operationId)
        HFree(operationId);
    if (provider)
        HFree(provider);
    if (operationCreator)
        HFree(operationCreator);
    if (whenUsed)
        HFree(whenUsed);
    if (requiresConsent)
        HFree(requiresConsent);
    if (operationNodeId)
        HFree(operationNodeId);
    if (accessNodeId)
        HFree(accessNodeId);
    if (connectionNodeId)
        HFree(connectionNodeId);
    if (connectorNodeId)
        HFree(connectorNodeId);
    return ok;
}

static int PPAppendInventoryConnectors(PPGraph *graph,
                                       const char *resourceNodeId,
                                       const char *environmentId,
                                       const char *properties,
                                       const char *propertiesEnd) {
    const char *arrayEnd = NULL;
    const char *p = PPFindArrayValue(properties, propertiesEnd,
                                     "\"powerPlatformConnectors\"", &arrayEnd);

    if (!p)
        return 1;
    while (p < arrayEnd - 1) {
        const char *itemEnd;
        const char *opsEnd = NULL;
        const char *op;
        char *connectorId;

        while (p < arrayEnd - 1 && (*p == ' ' || *p == '\t' ||
               *p == '\n' || *p == '\r' || *p == ','))
            p++;
        if (p >= arrayEnd - 1)
            break;
        if (*p != '{')
            break;
        itemEnd = JsonSkipBalanced(p, arrayEnd);
        if (!itemEnd)
            break;
        connectorId = JsonExtractStringValueUtf8(p, itemEnd, "\"connectorId\"");
        op = PPFindArrayValue(p, itemEnd, "\"operations\"", &opsEnd);
        if (op) {
            while (op < opsEnd - 1) {
                const char *opEnd;
                while (op < opsEnd - 1 && (*op == ' ' || *op == '\t' ||
                       *op == '\n' || *op == '\r' || *op == ','))
                    op++;
                if (op >= opsEnd - 1)
                    break;
                if (*op != '{')
                    break;
                opEnd = JsonSkipBalanced(op, opsEnd);
                if (!opEnd)
                    break;
                if (!PPAppendInventoryOperation(graph, resourceNodeId,
                                                 environmentId, connectorId,
                                                 NULL, op, opEnd)) {
                    if (connectorId)
                        HFree(connectorId);
                    return 0;
                }
                op = opEnd;
            }
        } else if (connectorId && MSVCRT$strlen(connectorId) > 0) {
            char *connectorNodeId = PPNodeId3("powerplatform:connector:",
                                              environmentId, connectorId);
            PPAppendTypedNode(graph, connectorNodeId,
                              "PowerPlatformConnector", connectorId,
                              "connectorid", connectorId,
                              "environmentid", environmentId, NULL, NULL);
            if (connectorNodeId) {
                if (!PPAppendEdge(graph, "PowerPlatformResourceUsesConnector",
                                  resourceNodeId, connectorNodeId)) {
                    HFree(connectorNodeId);
                    HFree(connectorId);
                    return 0;
                }
                HFree(connectorNodeId);
            }
        }
        if (connectorId)
            HFree(connectorId);
        p = itemEnd;
    }
    return graph->nodes.ok && graph->edges.ok;
}

static int PPAppendInventoryShareAccess(PPGraph *graph,
                                        const char *agentNodeId,
                                        const char *properties,
                                        const char *propertiesEnd,
                                        const char *jsonKey,
                                        const char *suffix,
                                        const char *kind) {
    const char *shareEnd = NULL;
    const char *share = PPFindObjectValue(properties, propertiesEnd,
                                          jsonKey, &shareEnd);
    char *userCount;
    char *groupCount;
    char *entireTenant;
    char *accessNodeId;
    size_t size;
    int ok = 1;

    if (!share)
        return 1;
    size = MSVCRT$strlen(agentNodeId) + MSVCRT$strlen(suffix) + 2;
    accessNodeId = (char *)HAlloc(size);
    if (!accessNodeId)
        return 0;
    MSVCRT$sprintf_s(accessNodeId, size, "%s:%s", agentNodeId, suffix);
    userCount = PPExtractPrimitiveValue(share, shareEnd, "\"userCount\"");
    groupCount = PPExtractPrimitiveValue(share, shareEnd, "\"groupCount\"");
    entireTenant = PPExtractPrimitiveValue(share, shareEnd, "\"entireTenant\"");
    PPAppendTypedNode(graph, accessNodeId, kind, suffix,
                      "usercount", userCount, "groupcount", groupCount,
                      "entiretenant", entireTenant);
    ok = PPAppendEdge(graph, "PowerPlatformAgentHasInvocationAccess",
                      agentNodeId, accessNodeId);
    if (userCount) HFree(userCount);
    if (groupCount) HFree(groupCount);
    if (entireTenant) HFree(entireTenant);
    HFree(accessNodeId);
    return ok;
}

static int PPAppendInventoryAgent(PPGraph *graph, const char *item,
                                  const char *itemEnd) {
    const char *propsEnd = NULL;
    const char *props = PPFindObjectValue(item, itemEnd, "\"properties\"",
                                          &propsEnd);
    char *environmentId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                          "\"environmentId\"") : NULL;
    char *resourceId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                       "\"name\"") : NULL;
    char *fallbackId = NULL;
    char *displayName = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                       "\"displayName\"") : NULL;
    char *ownerId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                   "\"ownerId\"") : NULL;
    char *createdBy = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                     "\"createdBy\"") : NULL;
    char *authentication = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                          "\"authentication\"") : NULL;
    char *entraAgentId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                        "\"entraAgentId\"") : NULL;
    char *entraBlueprintId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                             "\"entraAgentBlueprintId\"") : NULL;
    char *nodeId = NULL;
    char *targetId = NULL;
    char *envNodeId = NULL;
    int first = 1;
    int ok = 1;

    if (!environmentId || MSVCRT$strlen(environmentId) == 0) {
        if (environmentId) HFree(environmentId);
        if (resourceId) HFree(resourceId);
        if (displayName) HFree(displayName);
        if (ownerId) HFree(ownerId);
        if (createdBy) HFree(createdBy);
        if (authentication) HFree(authentication);
        if (entraAgentId) HFree(entraAgentId);
        if (entraBlueprintId) HFree(entraBlueprintId);
        return 1;
    }
    if (!resourceId || MSVCRT$strlen(resourceId) == 0) {
        fallbackId = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
        if (!fallbackId)
            fallbackId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
        resourceId = fallbackId;
        fallbackId = NULL;
    }
    if (!resourceId || MSVCRT$strlen(resourceId) == 0) {
        if (resourceId) HFree(resourceId);
        if (environmentId) HFree(environmentId);
        if (displayName) HFree(displayName);
        if (ownerId) HFree(ownerId);
        if (createdBy) HFree(createdBy);
        if (authentication) HFree(authentication);
        if (entraAgentId) HFree(entraAgentId);
        if (entraBlueprintId) HFree(entraBlueprintId);
        return 1;
    }

    nodeId = PPNodeId3("powerplatform:agent:", environmentId, resourceId);
    if (!nodeId) {
        ok = 0;
        goto agent_cleanup;
    }
    if (PPGraphHasNode(graph, nodeId))
        goto agent_cleanup;

    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, "PowerPlatformAgent");
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));
    PPProperty(&graph->nodes, &first, "name",
               displayName ? displayName : resourceId);
    PPProperty(&graph->nodes, &first, "displayname", displayName);
    PPProperty(&graph->nodes, &first, "resourceid", resourceId);
    PPProperty(&graph->nodes, &first, "environmentid", environmentId);
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "createdat", "\"createdAt\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "lastpublishedat", "\"lastPublishedAt\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "createdin", "\"createdIn\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "schemaname", "\"schemaName\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "orchestration", "\"orchestration\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "model", "\"model\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "authentication", "\"authentication\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "entraagentid", "\"entraAgentId\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "entraagentblueprintid", "\"entraAgentBlueprintId\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "entraappid", "\"entraAppId\"");
    PPPropertyPrimitiveFromJson(&graph->nodes, &first, props, propsEnd,
                                "isquarantined", "\"isQuarantined\"");
    PPPropertyPrimitiveFromJson(&graph->nodes, &first, props, propsEnd,
                                "ismanaged", "\"isManaged\"");
    PPPropertyPrimitiveFromJson(&graph->nodes, &first, props, propsEnd,
                                "viewergroups", "\"sharedWithViewers\"");
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
    graph->agentCount++;

    envNodeId = PPNodeId2("powerplatform:environment:", environmentId);
    if (envNodeId)
        ok = PPAppendEdge(graph, "PowerPlatformEnvironmentHasAgent",
                          envNodeId, nodeId) && ok;
    if (ownerId)
        ok = PPAppendEdge(graph, "PowerPlatformAgentOwnedBy",
                          nodeId, ownerId) && ok;
    if (createdBy)
        ok = PPAppendEdge(graph, "PowerPlatformAgentCreatedBy",
                          nodeId, createdBy) && ok;
    if (authentication && MSVCRT$strcmp(authentication, "None") == 0) {
        PPAppendTypedNode(graph, "powerplatform:anonymous-invoker",
                          "AZAgentAnonymousInvoker", "anonymous",
                          "accessmode", "anonymous", NULL, NULL, NULL, NULL);
        ok = PPAppendEdge(graph, "AZAgent_CanInvoke",
                          "powerplatform:anonymous-invoker", nodeId) && ok;
    }
    if (entraAgentId) {
        targetId = PPNodeId2("agent-identity:", entraAgentId);
        if (targetId)
            ok = PPAppendEdge(graph, "PowerPlatformAgentMapsToEntraIdentity",
                              nodeId, targetId) && ok;
        if (targetId) { HFree(targetId); targetId = NULL; }
    }
    if (entraBlueprintId) {
        targetId = PPNodeId2("agent-blueprint:", entraBlueprintId);
        if (targetId)
            ok = PPAppendEdge(graph, "PowerPlatformAgentMapsToEntraBlueprint",
                              nodeId, targetId) && ok;
        if (targetId) { HFree(targetId); targetId = NULL; }
    }
    if (props)
        ok = PPAppendInventoryConnectors(graph, nodeId, environmentId,
                                         props, propsEnd) && ok;
    if (props)
        ok = PPAppendInventoryShareAccess(graph, nodeId, props, propsEnd,
                                          "\"sharedWithViewers\"", "viewers",
                                          "PowerPlatformAgentViewerAccess") && ok;
    if (props)
        ok = PPAppendInventoryShareAccess(graph, nodeId, props, propsEnd,
                                          "\"sharedWithEditors\"", "editors",
                                          "PowerPlatformAgentEditorAccess") && ok;

agent_cleanup:
    if (targetId) HFree(targetId);
    if (envNodeId) HFree(envNodeId);
    if (nodeId) HFree(nodeId);
    if (environmentId) HFree(environmentId);
    if (resourceId) HFree(resourceId);
    if (displayName) HFree(displayName);
    if (ownerId) HFree(ownerId);
    if (createdBy) HFree(createdBy);
    if (authentication) HFree(authentication);
    if (entraAgentId) HFree(entraAgentId);
    if (entraBlueprintId) HFree(entraBlueprintId);
    return ok && graph->nodes.ok && graph->edges.ok;
}

static int PPAppendInventoryFlow(PPGraph *graph, const char *item,
                                 const char *itemEnd) {
    const char *propsEnd = NULL;
    const char *props = PPFindObjectValue(item, itemEnd, "\"properties\"",
                                          &propsEnd);
    char *environmentId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                          "\"environmentId\"") : NULL;
    char *resourceId = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    char *displayName = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                       "\"displayName\"") : NULL;
    char *ownerId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                   "\"ownerId\"") : NULL;
    char *createdBy = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                     "\"createdBy\"") : NULL;
    char *type = JsonExtractStringValueUtf8(item, itemEnd, "\"type\"");
    char *nodeId = NULL;
    char *envNodeId = NULL;
    const char *kind = (type && (MSVCRT$strstr(type, "agentflows") ||
                                 MSVCRT$strstr(type, "m365agentflows")))
                      ? "PowerPlatformAgentFlow" : "PowerPlatformFlow";
    const char *edgeKind = (type && (MSVCRT$strstr(type, "agentflows") ||
                                      MSVCRT$strstr(type, "m365agentflows")))
                         ? "PowerPlatformEnvironmentHasAgentFlow"
                         : "PowerPlatformEnvironmentHasFlow";
    int first = 1;
    int ok = 1;

    if (!resourceId || MSVCRT$strlen(resourceId) == 0) {
        if (resourceId) HFree(resourceId);
        resourceId = props ? JsonExtractStringValueUtf8(props, propsEnd,
                                                     "\"workflowEntityId\"") : NULL;
    }
    if (!environmentId || !resourceId || MSVCRT$strlen(environmentId) == 0 ||
        MSVCRT$strlen(resourceId) == 0)
        goto flow_cleanup;

    nodeId = PPNodeId3("powerplatform:flow:", environmentId, resourceId);
    envNodeId = PPNodeId2("powerplatform:environment:", environmentId);
    if (!nodeId || !envNodeId) {
        ok = 0;
        goto flow_cleanup;
    }
    if (PPGraphHasNode(graph, nodeId))
        goto flow_cleanup;

    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    PPJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    PPJsonString(&graph->nodes, kind);
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));
    PPProperty(&graph->nodes, &first, "name",
               displayName ? displayName : resourceId);
    PPProperty(&graph->nodes, &first, "displayname", displayName);
    PPProperty(&graph->nodes, &first, "resourceid", resourceId);
    PPProperty(&graph->nodes, &first, "environmentid", environmentId);
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "createdat", "\"createdAt\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "ownerid", "\"ownerId\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "createdby", "\"createdBy\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "lastmodifiedat", "\"lastModifiedAt\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "workflowentityid", "\"workflowEntityId\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "trigger", "\"trigger\"");
    PPPropertyFromJson(&graph->nodes, &first, props, propsEnd,
                       "triggeroperation", "\"triggerOperation\"");
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
    graph->flowCount++;
    ok = PPAppendEdge(graph, edgeKind, envNodeId, nodeId) && ok;
    if (ownerId)
        ok = PPAppendEdge(graph, "PowerPlatformFlowOwnedBy", nodeId,
                          ownerId) && ok;
    if (createdBy)
        ok = PPAppendEdge(graph, "PowerPlatformFlowCreatedBy", nodeId,
                          createdBy) && ok;
    if (props)
        ok = PPAppendInventoryConnectors(graph, nodeId, environmentId,
                                         props, propsEnd) && ok;

flow_cleanup:
    if (nodeId) HFree(nodeId);
    if (envNodeId) HFree(envNodeId);
    if (environmentId) HFree(environmentId);
    if (resourceId) HFree(resourceId);
    if (displayName) HFree(displayName);
    if (ownerId) HFree(ownerId);
    if (createdBy) HFree(createdBy);
    if (type) HFree(type);
    return ok && graph->nodes.ok && graph->edges.ok;
}

static int PPProcessInventoryPage(PPGraph *graph, const char *resp) {
    const char *end = resp + MSVCRT$strlen(resp);
    const char *arrayEnd = NULL;
    const char *p = PPFindDataArray(resp, end, &arrayEnd);

    if (!p)
        return -1;
    while (p < arrayEnd - 1) {
        const char *itemEnd;
        char *type;
        while (p < arrayEnd - 1 && (*p == ' ' || *p == '\t' ||
               *p == '\n' || *p == '\r' || *p == ','))
            p++;
        if (p >= arrayEnd - 1)
            break;
        if (*p != '{')
            break;
        itemEnd = JsonSkipBalanced(p, arrayEnd);
        if (!itemEnd)
            break;
        type = JsonExtractStringValueUtf8(p, itemEnd, "\"type\"");
        if (type && MSVCRT$strcmp(type, "microsoft.copilotstudio/agents") == 0)
            PPAppendInventoryAgent(graph, p, itemEnd);
        else if (type && (MSVCRT$strcmp(type, "microsoft.powerautomate/cloudflows") == 0 ||
                          MSVCRT$strcmp(type, "microsoft.powerautomate/agentflows") == 0 ||
                          MSVCRT$strcmp(type, "microsoft.powerautomate/m365agentflows") == 0))
            PPAppendInventoryFlow(graph, p, itemEnd);
        if (type)
            HFree(type);
        p = itemEnd;
    }
    return graph->nodes.ok && graph->edges.ok;
}

static int PPCollectInventory(PPGraph *graph, const char *bearerToken) {
    char *skipToken = NULL;
    int page = 0;
    int ok = 1;

    for (;;) {
        DWORD status = 0;
        char *resp = PPGetInventoryPage(bearerToken, skipToken, &status);
        char *nextToken = NULL;

        if (skipToken) {
            HFree(skipToken);
            skipToken = NULL;
        }
        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform inventory request failed (HTTP %lu)\n",
                status);
            ok = 0;
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform inventory HTTP %lu:\n    %s\n",
                status, resp);
            HFree(resp);
            ok = 0;
            break;
        }
        if (PPProcessInventoryPage(graph, resp) < 0) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] PowerPlatform inventory response did not contain a data array\n");
            HFree(resp);
            ok = 0;
            break;
        }
        nextToken = JsonExtractStringValueUtf8(resp, resp + MSVCRT$strlen(resp),
                                           "\"skipToken\"");
        HFree(resp);
        page++;
        if (!nextToken || MSVCRT$strlen(nextToken) == 0) {
            if (nextToken)
                HFree(nextToken);
            break;
        }
        skipToken = nextToken;
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] PowerPlatform inventory pagination: page %d, %d agents and %d flows so far\n",
            page, graph->agentCount, graph->flowCount);
    }
    if (skipToken)
        HFree(skipToken);
    return ok;
}

static void PPWriteGraph(PPGraph *graph) {
    BarkBuf output = { NULL, 0, 0, 1 };
    SYSTEMTIME st;
    char filename[300];

    BarkBufAppend(&output, "{\"graph\":{\"nodes\":[",
                  MSVCRT$strlen("{\"graph\":{\"nodes\":["));
    if (graph->nodes.buf)
        BarkBufAppend(&output, graph->nodes.buf, graph->nodes.len);
    BarkBufAppend(&output, "],\"edges\":[",
                  MSVCRT$strlen("],\"edges\":["));
    if (graph->edges.buf)
        BarkBufAppend(&output, graph->edges.buf, graph->edges.len);
    BarkBufAppend(&output, "]}}", 3);

    if (!output.ok || !output.buf) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform OpenGraph output exceeded available memory\n");
        BarkBufFree(&output);
        return;
    }

    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\PowerPlatformDiscovery_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
    BarkWriteOutput(filename, output.buf, (DWORD)output.len);
    BarkBufFree(&output);
}

void go(char *args, int alen) {
    datap parser;
    char *token;
    int downloadMode;
    PPEnvRefs envRefs;
    PPGraph graph = {
        { NULL, 0, 0, 1 }, { NULL, 0, 0, 1 },
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    downloadMode = BeaconDataInt(&parser);
    g_use_download = downloadMode ? 1 : 0;
    PPEnvRefsInit(&envRefs);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_powerplatform_opengraph <powerPlatformToken> [downloadMode]\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Collecting Power Platform environments, connections, agents, and flows using documented direct REST endpoints only\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Flow definitions/clientdata, secrets, run history, owners/run-only principals, and agent runtime data are not collected\n");

    if (PPCollectEnvironments(&graph, &envRefs, token)) {
        PPCollectConnections(&graph, &envRefs, token);
        /* The inventory API returns agents, cloud flows, agent flows, and
         * connector metadata in one paged ARG-backed query.  Keep the
         * per-environment cloud-flow endpoint as a narrow compatibility
         * fallback for tenants where inventory access is not granted. */
        if (!PPCollectInventory(&graph, token))
            PPCollectFlows(&graph, &envRefs, token);
    }

    if (graph.nodes.ok && graph.edges.ok) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] PowerPlatform discovery: %d environments, %d connections, %d agents, %d flows, %d failed environment pages, %d failed connection environments, %d failed connection pages, %d failed flow environments\n",
            graph.envCount, graph.connCount, graph.agentCount, graph.flowCount,
            graph.failedEnvPages, graph.failedConnectionEnvs,
            graph.failedConnectionPages, graph.failedFlowEnvs);
        PPWriteGraph(&graph);
    } else {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] PowerPlatform discovery output exceeded available memory\n");
    }

    PPEnvRefsFree(&envRefs);
    BarkBufFree(&graph.nodes);
    BarkBufFree(&graph.edges);
}
