/*
 * get_access_token_with_up.c — BARK BOF
 * Get-AccessTokenWithUsernamePassword — Password grant for any resource
 *
 * Args : tenantId, username, password, scope, clientId
 *
 * Uses the v2.0 ROPC endpoint.  resource URL examples (/.default is added internally):
 *   https://graph.microsoft.com
 *   https://management.azure.com
 *   https://vault.azure.net
 *
 * Response may include access_token + refresh_token + id_token depending on
 * scope; BarkTokenPost extracts and prints each via BeaconOutput safely.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/oauth_scope.h"

#define PATH_BUF_SIZE 512
#define BODY_BUF_SIZE 4096
#define ENC_BUF_SIZE  2048

void go(char *args, int alen)
{
    datap  parser;
    char *normalizedScope = NULL;
    LPWSTR widePath    = NULL;
    char  *pathBuf     = NULL;
    char  *bodyBuf     = NULL;
    char  *encPassword = NULL;
    char  *encUsername = NULL;
    char  *encScope    = NULL;
    char  *tenantId = NULL, *username = NULL, *password = NULL;
    char  *scope    = NULL, *clientId = NULL;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK] entered get_access_token_with_up (alen=%d)\n", alen);

    BeaconDataParse(&parser, args, alen);
    tenantId = BeaconDataExtract(&parser, NULL);
    username = BeaconDataExtract(&parser, NULL);
    password = BeaconDataExtract(&parser, NULL);
    scope    = BeaconDataExtract(&parser, NULL);
    clientId = BeaconDataExtract(&parser, NULL);

    if (!tenantId) tenantId = "";
    if (!username) username = "";
    if (!password) password = "";
    if (!scope)    scope    = "";
    if (!clientId) clientId = "";

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK] args: tenantId.len=%d username.len=%d password.len=%d scope.len=%d clientId.len=%d\n",
        (int)MSVCRT$strlen(tenantId), (int)MSVCRT$strlen(username),
        (int)MSVCRT$strlen(password), (int)MSVCRT$strlen(scope),
        (int)MSVCRT$strlen(clientId));

    if (MSVCRT$strlen(tenantId) == 0 || MSVCRT$strlen(scope) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_tokens_with_up <tenantId> <username> <password> <resource> [clientId]\n");
        return;
    }
    normalizedScope = (char *)HAlloc(ENC_BUF_SIZE);
    pathBuf     = (char *)HAlloc(PATH_BUF_SIZE);
    bodyBuf     = (char *)HAlloc(BODY_BUF_SIZE);
    encPassword = (char *)HAlloc(ENC_BUF_SIZE);
    encUsername = (char *)HAlloc(ENC_BUF_SIZE);
    encScope    = (char *)HAlloc(ENC_BUF_SIZE);
    if (!normalizedScope || !pathBuf || !bodyBuf || !encPassword || !encUsername || !encScope) {
        BeaconPrintf(CALLBACK_ERROR, "[-] HeapAlloc failed\n");
        goto cleanup;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[BARK] heap buffers allocated\n");

    if (!BarkNormalizeV2Scope(scope, normalizedScope, ENC_BUF_SIZE) ||
        MSVCRT$strlen(normalizedScope) * 3 + 1 > ENC_BUF_SIZE) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Resource/scope is empty or too long\n");
        goto cleanup;
    }
    scope = normalizedScope;

    UrlEncode(username, encUsername, ENC_BUF_SIZE);
    UrlEncode(password, encPassword, ENC_BUF_SIZE);
    UrlEncode(scope,    encScope,    ENC_BUF_SIZE);

    MSVCRT$sprintf_s(pathBuf, PATH_BUF_SIZE, "/%s/oauth2/v2.0/token", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        goto cleanup;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[BARK] path built: %s\n", pathBuf);

    if (MSVCRT$strlen(clientId) > 0) {
        MSVCRT$sprintf_s(bodyBuf, BODY_BUF_SIZE,
            "grant_type=password"
            "&scope=%s%%20offline_access"
            "&username=%s"
            "&password=%s"
            "&client_id=%s",
            encScope, encUsername, encPassword, clientId);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AccessTokenWithUsernamePassword for %s (scope: %s + offline_access)\n", username, scope);
        BarkTokenPost(widePath, bodyBuf);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AccessTokenWithUsernamePassword for %s (scope: %s + offline_access) -- no clientId specified, trying %d capability-ranked clients...\n",
            username, scope, BARK_DEFAULT_CLIENT_ID_COUNT);
        int found = 0;
        int i;
        for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
            int clientIndex = BarkClientIndexForResource(scope, i);
            BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                BARK_DEFAULT_CLIENT_IDS[clientIndex]);
            MSVCRT$sprintf_s(bodyBuf, BODY_BUF_SIZE,
                "grant_type=password"
                "&scope=%s%%20offline_access"
                "&username=%s"
                "&password=%s"
                "&client_id=%s",
                encScope, encUsername, encPassword,
                BARK_DEFAULT_CLIENT_IDS[clientIndex]);
            if (BarkTokenPostTry(widePath, bodyBuf, 1)) {
                BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                    BARK_DEFAULT_CLIENT_IDS[clientIndex],
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                found = 1;
                break;
            }
            BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
        }
        if (!found)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                BARK_DEFAULT_CLIENT_ID_COUNT);
    }

cleanup:
    if (normalizedScope) HFree(normalizedScope);
    if (widePath)    HFree(widePath);
    if (pathBuf)     HFree(pathBuf);
    if (bodyBuf)     HFree(bodyBuf);
    if (encPassword) HFree(encPassword);
    if (encUsername) HFree(encUsername);
    if (encScope)    HFree(encScope);
}
