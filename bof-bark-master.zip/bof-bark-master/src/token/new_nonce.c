/*
 * new_nonce.c — BARK BOF
 * New-Nonce — Retrieve a nonce from the Microsoft login endpoint
 *
 * Args : (none)
 * API  : POST login.microsoftonline.com /common/oauth2/token
 *        body: grant_type=srv_challenge
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    (void)args; (void)alen;
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Requesting nonce from login.microsoftonline.com...\n");
    BarkTokenPost(L"/common/oauth2/token", "grant_type=srv_challenge");
}
