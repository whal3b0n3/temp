/*
 * get_msgraph_token_with_rt.c — BARK BOF
 * Get-MSGraphTokenWithRefreshToken — Refresh token grant — get MS Graph token (v1 endpoint)
 *
 * Args : tenantId, refreshToken
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[512];
    static char bodyBuf[4096];
    static char encRT[4096];
    LPWSTR widePath = NULL;
    char  *tenantId = NULL, *refreshToken = NULL;

    BeaconDataParse(&parser, args, alen);
    tenantId     = BeaconDataExtract(&parser, NULL);
    refreshToken = BeaconDataExtract(&parser, NULL);

    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_msgraph_token_with_rt <tenantId> <refreshToken>\n");
        return;
    }

    UrlEncode(refreshToken, encRT, sizeof(encRT));

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token?api-version=1.0", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "grant_type=refresh_token&refresh_token=%s&scope=openid&resource=https%%3A%%2F%%2Fgraph.microsoft.com", encRT);

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-MSGraphTokenWithRefreshToken\n");
    BarkTokenPost(widePath, bodyBuf);
    HFree(widePath);
}
