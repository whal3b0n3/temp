/*
 * get_access_token_with_cc.c — BARK BOF
 * Get-AccessTokenWithClientCredentials — Client credentials for any resource
 *
 * Args : tenantId, clientId, clientSecret, scope
 *
 * Uses the v2.0 client_credentials endpoint.  resource URL examples (/.default is added internally):
 *   https://graph.microsoft.com
 *   https://management.azure.com
 *   https://vault.azure.net
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/oauth_scope.h"

#define PATH_BUF_SIZE 512
#define BODY_BUF_SIZE 4096
#define ENC_BUF_SIZE  2048

void go(char *args, int alen)
{
    datap  parser;
    char *normalizedScope = NULL;
    LPWSTR widePath   = NULL;
    char  *pathBuf    = NULL;
    char  *bodyBuf    = NULL;
    char  *encSecret  = NULL;
    char  *encScope   = NULL;
    char  *tenantId = NULL, *clientId = NULL, *clientSecret = NULL, *scope = NULL;

    BeaconDataParse(&parser, args, alen);
    tenantId     = BeaconDataExtract(&parser, NULL);
    clientId     = BeaconDataExtract(&parser, NULL);
    clientSecret = BeaconDataExtract(&parser, NULL);
    scope        = BeaconDataExtract(&parser, NULL);

    if (!tenantId)     tenantId     = "";
    if (!clientId)     clientId     = "";
    if (!clientSecret) clientSecret = "";
    if (!scope)        scope        = "";

    if (MSVCRT$strlen(tenantId) == 0 || MSVCRT$strlen(scope) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_tokens_with_cc <tenantId> <clientId> <clientSecret> <resource>\n");
        return;
    }

    normalizedScope = (char *)HAlloc(ENC_BUF_SIZE);
    pathBuf   = (char *)HAlloc(PATH_BUF_SIZE);
    bodyBuf   = (char *)HAlloc(BODY_BUF_SIZE);
    encSecret = (char *)HAlloc(ENC_BUF_SIZE);
    encScope  = (char *)HAlloc(ENC_BUF_SIZE);
    if (!normalizedScope || !pathBuf || !bodyBuf || !encSecret || !encScope) {
        BeaconPrintf(CALLBACK_ERROR, "[-] HeapAlloc failed\n");
        goto cleanup;
    }

    if (!BarkNormalizeV2Scope(scope, normalizedScope, ENC_BUF_SIZE) ||
        MSVCRT$strlen(normalizedScope) * 3 + 1 > ENC_BUF_SIZE) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Resource/scope is empty or too long\n");
        goto cleanup;
    }
    scope = normalizedScope;

    UrlEncode(clientSecret, encSecret, ENC_BUF_SIZE);
    UrlEncode(scope,        encScope,  ENC_BUF_SIZE);

    MSVCRT$sprintf_s(pathBuf, PATH_BUF_SIZE, "/%s/oauth2/v2.0/token", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        goto cleanup;
    }

    MSVCRT$sprintf_s(bodyBuf, BODY_BUF_SIZE,
        "grant_type=client_credentials"
        "&scope=%s"
        "&client_id=%s"
        "&client_secret=%s",
        encScope, clientId, encSecret);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AccessTokenWithClientCredentials (scope: %s)\n", scope);
    BarkTokenPost(widePath, bodyBuf);

cleanup:
    if (normalizedScope) HFree(normalizedScope);
    if (widePath)  HFree(widePath);
    if (pathBuf)   HFree(pathBuf);
    if (bodyBuf)   HFree(bodyBuf);
    if (encSecret) HFree(encSecret);
    if (encScope)  HFree(encScope);
}
