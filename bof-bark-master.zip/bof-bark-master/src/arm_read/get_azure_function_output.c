/*
 * get_azure_function_output.c — BARK BOF
 * Get-AzureFunctionOutput — Invoke an Azure Function and get its output
 *
 * Args : token, functionUrl
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   hostBuf[512], pathBuf[2048];
    char  *token = NULL, *functionUrl = NULL;
    LPWSTR wideHost = NULL, widePath = NULL;
    const char *start, *slash;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    functionUrl = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azure_function_output <token> <functionUrl>\n");
        return;
    }

    start = functionUrl;
    if (MSVCRT$strncmp(start, "https://", 8) == 0) start += 8;
    if (MSVCRT$strncmp(start, "http://",  7) == 0) start += 7;
    slash = MSVCRT$strstr(start, "/");
    if (!slash) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Invalid function URL\n");
        return;
    }
    {
        int hlen = (int)(slash - start);
        MSVCRT$strncpy(hostBuf, start, hlen);
        hostBuf[hlen] = '\0';
    }
    MSVCRT$strncpy(pathBuf, slash, sizeof(pathBuf) - 1);
    pathBuf[sizeof(pathBuf)-1] = '\0';

    wideHost = MbsToWcs(hostBuf);
    widePath = MbsToWcs(pathBuf);
    if (!wideHost || !widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] String conversion failed\n");
        HFree(wideHost); HFree(widePath);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureFunctionOutput\n");
    BarkGet(wideHost, widePath, token);
    HFree(wideHost);
    HFree(widePath);
}
