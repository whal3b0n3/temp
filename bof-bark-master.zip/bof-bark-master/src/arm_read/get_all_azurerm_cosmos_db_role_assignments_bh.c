/*
 * get_all_azurerm_cosmos_db_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMCosmosDBRoleAssignmentsBH — Enumerate role assignments on a Cosmos DB account (BloodHound)
 *
 * Args : token (ARM Bearer), cosmosDbId (full ARM resource path)
 * API  : GET management.azure.com/{cosmosDbId}/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *cosmosDbId = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    cosmosDbId = BeaconDataExtract(&parser, NULL);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_cosmos_db_role_assignments_bh <token> [cosmosDbId]\n");
        return;
    }

    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.DocumentDB/databaseAccounts", roleDefLookup, tenantId,
        (cosmosDbId && MSVCRT$strlen(cosmosDbId) > 0) ? cosmosDbId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
