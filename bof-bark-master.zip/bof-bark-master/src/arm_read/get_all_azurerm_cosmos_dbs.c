/*
 * get_all_azurerm_cosmos_dbs.c — BARK BOF
 * Get-AllAzureRMCosmosDBs — Enumerate Cosmos DB accounts in a subscription or resource group
 *
 * Args : token (ARM Bearer), subscriptionId, [resourceGroup]
 * API  : GET management.azure.com/subscriptions/{subId}/providers/Microsoft.DocumentDB/databaseAccounts?api-version=2021-10-15
 *         GET management.azure.com/subscriptions/{subId}/resourceGroups/{rg}/providers/Microsoft.DocumentDB/databaseAccounts?api-version=2021-10-15
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *subscriptionId = NULL;
    char  *resourceGroup = NULL;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    resourceGroup = BeaconDataExtract(&parser, NULL);

    if (!token || !subscriptionId) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_cosmos_dbs <token> <subscriptionId> [resourceGroup]\n");
        return;
    }

    resourceGroup = SAFE_STR(resourceGroup);

    if (MSVCRT$strlen(resourceGroup) > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Enumerating Cosmos DB accounts for resource group: %s (subscription: %s)\n",
            resourceGroup, subscriptionId);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s/resourceGroups/%s/providers/Microsoft.DocumentDB/databaseAccounts?api-version=2021-10-15",
            subscriptionId, resourceGroup);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Enumerating Cosmos DB accounts for subscription: %s\n", subscriptionId);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s/providers/Microsoft.DocumentDB/databaseAccounts?api-version=2021-10-15",
            subscriptionId);
    }

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
        return;
    }

    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
