/*
 * get_all_azurerm_resource_groups_bh.c — BARK BOF
 * Get-AllAzureRMResourceGroupsBH — Get all resource groups (BH format)
 *
 * Args : token, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

static int RgIdEquals(const char *left, const char *right)
{
    unsigned char a, b;
    if (!left || !right) return 0;
    while (*left && *right) {
        a = (unsigned char)*left++;
        b = (unsigned char)*right++;
        if (a >= 'A' && a <= 'Z') a = (unsigned char)(a + ('a' - 'A'));
        if (b >= 'A' && b <= 'Z') b = (unsigned char)(b + ('a' - 'A'));
        if (a != b) return 0;
    }
    return *left == '\0' && *right == '\0';
}

static int RgRemember(BarkIdList *ids, const char *id)
{
    int i;
    SIZE_T len;
    char *copy;
    for (i = 0; i < ids->count; i++) {
        if (RgIdEquals(ids->ids[i], id)) return 0;
    }
    len = MSVCRT$strlen(id) + 1;
    copy = (char *)HAlloc(len);
    if (!copy) return 0;
    MSVCRT$memcpy(copy, id, len);
    if (BarkIdListAppend(ids, copy) != 0) {
        HFree(copy);
        return 0;
    }
    return 1;
}

static void EmitListedResourceGroups(BarkBuf *output, BarkIdList *known,
    const char *token, const char *tenantId, const char *subscriptionId,
    int *emitted)
{
    char path[512];
    LPWSTR widePath;
    LPCWSTR pathArg;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPWSTR headers = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");

    if (!headers) return;
    MSVCRT$sprintf_s(path, sizeof(path),
        "/subscriptions/%s/resourcegroups?api-version=2021-04-01",
        subscriptionId);
    widePath = MbsToWcs(path);
    if (!widePath) { HFree(headers); return; }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
            pathArg, headers, NULL, 0, &status);

        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *value = JsonFindKey(resp, end, "\"value\"");
            if (value) {
                const char *colon = JsonFindKey(value, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end && (*colon == ' ' || *colon == '\t' ||
                           *colon == '\n' || *colon == '\r')) colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrayEnd = JsonSkipBalanced(colon, end);
                        const char *item = colon + 1;
                        while (arrayEnd && item < arrayEnd - 1) {
                            const char *itemEnd;
                            char *id;
                            while (item < arrayEnd - 1 && *item != '{') item++;
                            if (item >= arrayEnd - 1) break;
                            itemEnd = JsonSkipBalanced(item, arrayEnd);
                            if (!itemEnd) break;
                            id = JsonExtractStringValue(item, itemEnd, "\"id\"");
                            if (id && RgRemember(known, id)) {
                                BarkBufPrintBHItemArm(output, "AZResourceGroup",
                                    item, itemEnd, *emitted == 0,
                                    tenantId, NULL);
                                (*emitted)++;
                            }
                            if (id) HFree(id);
                            item = itemEnd;
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"management.azure.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(headers);
    HFree(widePath);
    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
}

/* A principal can be allowed to read resources while the resourceGroups
 * list is filtered or denied.  Resource ARM IDs still authoritatively name
 * their containing group, so emit a minimal group node for any missing ID. */
static int EmitInferredResourceGroups(BarkBuf *output, BarkIdList *known,
    const char *token, const char *tenantId, const char *subscriptionId,
    int *emitted)
{
    char path[512];
    LPWSTR widePath;
    LPCWSTR pathArg;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    int inferred = 0;
    LPWSTR headers = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");

    if (!headers) return 0;
    MSVCRT$sprintf_s(path, sizeof(path),
        "/subscriptions/%s/resources?api-version=2021-04-01",
        subscriptionId);
    widePath = MbsToWcs(path);
    if (!widePath) { HFree(headers); return 0; }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
            pathArg, headers, NULL, 0, &status);

        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *value = JsonFindKey(resp, end, "\"value\"");
            if (value) {
                const char *colon = JsonFindKey(value, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end && (*colon == ' ' || *colon == '\t' ||
                           *colon == '\n' || *colon == '\r')) colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrayEnd = JsonSkipBalanced(colon, end);
                        const char *item = colon + 1;
                        while (arrayEnd && item < arrayEnd - 1) {
                            const char *itemEnd;
                            char subId[128];
                            char rgId[512];
                            while (item < arrayEnd - 1 && *item != '{') item++;
                            if (item >= arrayEnd - 1) break;
                            itemEnd = JsonSkipBalanced(item, arrayEnd);
                            if (!itemEnd) break;
                            BarkParseArmId(item, itemEnd,
                                subId, sizeof(subId), rgId, sizeof(rgId));
                            if (rgId[0] && RgRemember(known, rgId)) {
                                const char *name = MSVCRT$strstr(rgId,
                                    "/resourceGroups/");
                                char synthetic[1536];
                                int syntheticLen;
                                if (!name) name = MSVCRT$strstr(rgId,
                                    "/resourcegroups/");
                                /* strlen("/resourceGroups/") == 15. */
                                name = name ? name + 15 : rgId;
                                syntheticLen = MSVCRT$sprintf_s(synthetic,
                                    sizeof(synthetic),
                                    "{\"id\":\"%s\",\"name\":\"%s\","
                                    "\"type\":\"Microsoft.Resources/resourceGroups\","
                                    "\"location\":null,\"properties\":{"
                                    "\"provisioningState\":\"Unknown\","
                                    "\"inferredFromResourceId\":true}}",
                                    rgId, name);
                                if (syntheticLen > 0) {
                                    BarkBufPrintBHItemArm(output,
                                        "AZResourceGroup", synthetic,
                                        synthetic + syntheticLen,
                                        *emitted == 0, tenantId, NULL);
                                    (*emitted)++;
                                    inferred++;
                                }
                            }
                            item = itemEnd;
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"management.azure.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(headers);
    HFree(widePath);
    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    return inferred;
}

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *subscriptionId = NULL;
    char *subscriptionSnapshot;
    char *tenantId;
    BarkIdList subscriptions;
    BarkIdList knownGroups;
    BarkBuf output = { NULL, 0, 0, 1 };
    int emitted = 0;
    int inferred = 0;
    int si;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_resource_groups_bh "
            "<token> [subscriptionId]\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMResourceGroupsBH\n");
    BarkIdListInit(&subscriptions);
    BarkIdListInit(&knownGroups);

    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        SIZE_T len = MSVCRT$strlen(subscriptionId) + 1;
        char *copy = (char *)HAlloc(len);
        if (copy) {
            MSVCRT$memcpy(copy, subscriptionId, len);
            BarkIdListAppend(&subscriptions, copy);
        }
    } else {
        subscriptions = BarkParseSubscriptionSnapshot(subscriptionSnapshot);
        if (subscriptions.count == 0) {
            subscriptions = BarkEnumEntityIds(L"management.azure.com",
                "/subscriptions?api-version=2020-01-01", token,
                "\"subscriptionId\"");
        }
        if (subscriptions.count == 0)
            subscriptions = BarkMgmtGroupFallbackGetSubscriptionIds(token);
    }

    tenantId = BarkExtractTidFromJWT(token);
    BarkBufAppend(&output, "{\"data\":[", 9);
    for (si = 0; si < subscriptions.count; si++) {
        EmitListedResourceGroups(&output, &knownGroups, token, tenantId,
            subscriptions.ids[si], &emitted);
        inferred += EmitInferredResourceGroups(&output, &knownGroups, token,
            tenantId, subscriptions.ids[si], &emitted);
    }

    {
        char tail[128];
        int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
        if (tailLen > 0) BarkBufAppend(&output, tail, (SIZE_T)tailLen);
    }

    if (output.ok && output.buf) {
        SYSTEMTIME st;
        char filename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZResourceGroup_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, output.buf, (DWORD)output.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZResourceGroup found %d object(s), %d inferred\n",
            emitted, inferred);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: arm_resource_groups\n");

    BarkBufFree(&output);
    BarkIdListFree(&knownGroups);
    BarkIdListFree(&subscriptions);
    if (tenantId) HFree(tenantId);
}
