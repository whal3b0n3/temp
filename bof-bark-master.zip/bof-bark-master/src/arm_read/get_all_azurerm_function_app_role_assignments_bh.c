/*
 * get_all_azurerm_function_app_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMFunctionAppRoleAssignmentsBH — Get role assignments for a Function App
 *
 * Args : token, functionAppId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *functionAppId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    functionAppId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <functionAppId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMFunctionAppRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.Web/sites", roleDefLookup, tenantId,
        (functionAppId && MSVCRT$strlen(functionAppId) > 0) ? functionAppId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
