/*
 * get_azure_function_app_functions.c — BARK BOF
 * Get-AzureFunctionAppFunctions — List functions in a Function App
 *
 * Args : token, functionAppPath
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *functionAppPath = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    functionAppPath = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <functionAppPath>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureFunctionAppFunctions\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s/functions?api-version=2018-11-01", functionAppPath);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
