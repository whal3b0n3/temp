/*
 * get_azurerm_role_assignments.c — BARK BOF
 * Get-AzureRMRoleAssignments — Get ARM role assignments for a target object
 *
 * Args : token, targetObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *targetObjectId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    targetObjectId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <targetObjectId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMRoleAssignments\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s/providers/Microsoft.Authorization/roleAssignments?api-version=2018-01-01-preview&$filter=atScope()", targetObjectId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
