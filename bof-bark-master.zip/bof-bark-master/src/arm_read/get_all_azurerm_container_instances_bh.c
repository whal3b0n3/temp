/*
 * get_all_azurerm_container_instances_bh.c — BARK BOF
 * Get-AllAzureRMContainerInstancesBH — Get all Container Instances (BH format)
 *
 * Args : token, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *subscriptionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <subscriptionId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMContainerInstancesBH\n");
    char *tenantId = BarkExtractTidFromJWT(token);
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/subscriptions/%s/providers/Microsoft.ContainerInstance/containerGroups?api-version=2023-05-01", subscriptionId);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkGetBHInnerArm(L"management.azure.com", widePath, token, "AZContainerGroup", tenantId, NULL);
        HFree(widePath);
    } else {
        BarkGetBHAllSubscriptionsArmWithSnapshot(token,
            "/subscriptions/%s/providers/Microsoft.ContainerInstance/containerGroups?api-version=2023-05-01",
            "AZContainerGroup", tenantId, NULL, subscriptionSnapshot);
    }
    if (tenantId) HFree(tenantId);
}
