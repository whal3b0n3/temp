/*
 * get_azurerm_web_app.c — BARK BOF
 * Get-AzureRMWebApp — Get a specific Web App
 *
 * Args : token, webAppId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *webAppId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    webAppId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <webAppId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMWebApp\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s?api-version=2022-03-01", webAppId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
