/*
 * get_all_azurerm_subscriptions_via_resource_graph.c — BARK BOF
 * Get-AllAzureRMSubscriptions (via Resource Graph) — Discover subscriptions
 * using Azure Resource Graph when the standard /subscriptions endpoint
 * returns empty due to missing direct RBAC.
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_subscriptions_via_resource_graph <token>\n");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AllAzureRMSubscriptions (via Resource Graph)\n");
    BarkPost(L"management.azure.com",
        L"/providers/Microsoft.ResourceGraph/resources?api-version=2021-03-01",
        L"POST",
        "{\"query\":\"resourcecontainers | where type == 'microsoft.resources/subscriptions'\"}",
        token, "application/json");
}
