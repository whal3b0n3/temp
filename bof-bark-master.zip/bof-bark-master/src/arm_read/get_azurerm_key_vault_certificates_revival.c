/*
 * get_azurerm_key_vault_certificates_revival.c — BARK BOF
 * Get-AzureRMKeyVaultCertificatesRevival — List certificates including pending (requires KV-scoped token)
 *
 * Args : token (KV-scoped), keyVaultUrl
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL, *keyVaultUrl = NULL;

    BeaconDataParse(&parser, args, alen);
    token      = BeaconDataExtract(&parser, NULL);
    keyVaultUrl  = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azurerm_key_vault_certificates_revival <token> <keyVaultUrl>\n");
        return;
    }
    /* Strip https:// prefix */
    const char *vaultHostStart = keyVaultUrl;
    if (MSVCRT$strncmp(keyVaultUrl, "https://", 8) == 0) vaultHostStart = keyVaultUrl + 8;
    LPWSTR wideVaultHost = MbsToWcs(vaultHostStart);
    if (!wideVaultHost) { BeaconPrintf(CALLBACK_ERROR, "[-] Host conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMKeyVaultCertificatesRevival\n");
    BarkGet(wideVaultHost, L"/certificates?api-version=7.3&includePending=true", token);
    HFree(wideVaultHost);
}
