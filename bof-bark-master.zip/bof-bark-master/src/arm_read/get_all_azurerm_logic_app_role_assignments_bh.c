/*
 * get_all_azurerm_logic_app_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMLogicAppRoleAssignmentsBH — Get role assignments for a Logic App
 *
 * Args : token, logicAppId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *logicAppId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    logicAppId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <logicAppId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMLogicAppRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.Logic/workflows", roleDefLookup, tenantId,
        (logicAppId && MSVCRT$strlen(logicAppId) > 0) ? logicAppId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
