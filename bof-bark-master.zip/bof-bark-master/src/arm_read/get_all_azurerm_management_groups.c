/*
 * get_all_azurerm_management_groups.c — BARK BOF
 * Get-AllAzureRMManagementGroups — List all Azure Management Groups
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_management_groups <token>\n");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMManagementGroups\n");
    BarkGet(L"management.azure.com",
        L"/providers/Microsoft.Management/managementGroups?api-version=2020-05-01",
        token);
}
