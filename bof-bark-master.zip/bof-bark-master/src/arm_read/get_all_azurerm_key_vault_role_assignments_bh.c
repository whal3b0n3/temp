/*
 * get_all_azurerm_key_vault_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMKeyVaultRoleAssignmentsBH — Get role assignments for a Key Vault
 *
 * Args : token, keyVaultId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *keyVaultId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    keyVaultId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <keyVaultId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMKeyVaultRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.KeyVault/vaults", roleDefLookup, tenantId,
        (keyVaultId && MSVCRT$strlen(keyVaultId) > 0) ? keyVaultId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
