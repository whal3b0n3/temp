/*
 * get_all_azurerm_authorization_extras_bh.c — BARK BOF
 * Collect deny assignments and Azure PIM schedule/policy records.
 *
 * Args: token, subscriptionSnapshot (optional), downloadMode
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *subscriptionSnapshot = NULL;
    char *tenantId = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_authorization_extras_bh <token> [subscriptionSnapshot]\n");
        return;
    }

    tenantId = BarkExtractTidFromJWT(token);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AllAzureRMAuthorizationExtrasBH (deny + PIM)\n");
    BarkGetBHAllAuthorizationExtrasWithSnapshot(token, tenantId,
        subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
