/*
 * get_all_azurerm_web_app_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMWebAppRoleAssignmentsBH — Get role assignments for a Web App
 *
 * Args : token, webAppId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *webAppId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    webAppId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <webAppId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMWebAppRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.Web/sites", roleDefLookup, tenantId,
        (webAppId && MSVCRT$strlen(webAppId) > 0) ? webAppId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
