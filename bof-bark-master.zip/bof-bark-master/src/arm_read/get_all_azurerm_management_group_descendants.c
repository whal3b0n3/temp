/*
 * get_all_azurerm_management_group_descendants.c — BARK BOF
 * Get-AllAzureRMManagementGroupDescendants — List descendants of a
 * management group (subscriptions + nested groups).
 *
 * Args : token, managementGroupId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[512];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *mgGroupId = NULL;
    BeaconDataParse(&parser, args, alen);
    token     = BeaconDataExtract(&parser, NULL);
    mgGroupId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0 ||
        !mgGroupId || MSVCRT$strlen(mgGroupId) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_management_group_descendants <token> <managementGroupId>\n");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AllAzureRMManagementGroupDescendants: %s\n", mgGroupId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/providers/Microsoft.Management/managementGroups/%s/descendants?api-version=2020-05-01",
        mgGroupId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return;
    }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
