/*
 * get_all_azurerm_aks_clusters_bh.c — BARK BOF
 * Get-AllAzureRMAKSClustersBH — Enumerate AKS clusters in a subscription (BloodHound)
 *
 * Args : token (ARM Bearer), subscriptionId
 * API  : GET management.azure.com/subscriptions/{subId}/providers/Microsoft.ContainerService/managedClusters?api-version=2022-03-01
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *subscriptionId = NULL;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_aks_clusters_bh <token> [subscriptionId]\n");
        return;
    }

    char *tenantId = BarkExtractTidFromJWT(token);
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Enumerating AKS clusters for subscription (BH): %s\n", subscriptionId);

        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s/providers/Microsoft.ContainerService/managedClusters?api-version=2022-03-01",
            subscriptionId);

        widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
            return;
        }

        BarkGetBHInnerArm(L"management.azure.com", widePath, token, "AZManagedCluster", tenantId, NULL);
        HFree(widePath);
    } else {
        BarkGetBHAllSubscriptionsArmWithSnapshot(token,
            "/subscriptions/%s/providers/Microsoft.ContainerService/managedClusters?api-version=2022-03-01",
            "AZManagedCluster", tenantId, NULL, subscriptionSnapshot);
    }
    if (tenantId) HFree(tenantId);
}
