/*
 * get_all_azurerm_vm_scale_sets_vms.c — BARK BOF
 * Get-AllAzureRMVMScaleSetsVMs — List VMs in a specific VM Scale Set
 *
 * Args : token (ARM Bearer), vmssId (full ARM path to scale set)
 * API  : GET management.azure.com/{vmssId}/virtualMachines?api-version=2022-03-01
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *vmssId = NULL;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    vmssId = BeaconDataExtract(&parser, NULL);

    if (!token || !vmssId) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_vm_scale_sets_vms <token> <vmssId>\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Enumerating VMs in VM Scale Set: %s\n", vmssId);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/virtualMachines?api-version=2022-03-01",
        vmssId);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
        return;
    }

    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
