/*
 * get_all_azurerm_management_group_role_assignments_bh.c — BARK BOF
 * Collect role assignments authored directly at management-group scope.
 *
 * Args: token, managementGroupName (optional), downloadMode
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *managementGroup = NULL;
    char *tenantId = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    managementGroup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_management_group_role_assignments_bh <token> [managementGroupName]\n");
        return;
    }

    tenantId = BarkExtractTidFromJWT(token);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AllAzureRMManagementGroupRoleAssignmentsBH\n");
    BarkGetBHAllManagementGroupRoleAssignments(token, tenantId,
        (managementGroup && MSVCRT$strlen(managementGroup) > 0)
            ? managementGroup : NULL);
    if (tenantId) HFree(tenantId);
}
