/*
 * get_all_azurerm_subscription_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMSubScriptionRoleAssignmentsBH — Get role assignments for a subscription
 *
 * Args : token, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   scopeBuf[256];
    char  *token = NULL;
    char  *subscriptionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <subscriptionId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMSubScriptionRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    const char *scope = NULL;
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        MSVCRT$sprintf_s(scopeBuf, sizeof(scopeBuf), "/subscriptions/%s", subscriptionId);
        scope = scopeBuf;
    }
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, NULL, roleDefLookup,
        tenantId, scope, subscriptionSnapshot);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: arm_subscription_role_assignments\n");
    if (tenantId) HFree(tenantId);
}
