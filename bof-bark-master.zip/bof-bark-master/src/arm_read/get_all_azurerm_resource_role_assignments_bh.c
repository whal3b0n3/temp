/*
 * get_all_azurerm_resource_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMResourceRoleAssignmentsBH — Get role assignments for an ARM resource
 *
 * Args : token, resourceId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *resourceId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    resourceId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <resourceId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMResourceRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *resourceSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshots(token, "*",
        roleDefLookup, tenantId,
        (resourceId && MSVCRT$strlen(resourceId) > 0) ? resourceId : NULL,
        subscriptionSnapshot, resourceSnapshot);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: arm_resource_role_assignments\n");
    if (tenantId) HFree(tenantId);
}
