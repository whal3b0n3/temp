/*
 * get_all_azurerm_subscriptions.c — BARK BOF
 * Get-AllAzureRMSubscriptions — Get all Azure subscriptions
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMSubscriptions\n");
    BarkGetSubscriptionsRawWithFallback(token);
}
