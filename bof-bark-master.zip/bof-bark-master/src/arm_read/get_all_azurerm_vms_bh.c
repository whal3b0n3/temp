/*
 * get_all_azurerm_vms_bh.c — BARK BOF
 * Get-AllAzureRMVirtualMachinesBH — Get all virtual machines (BH format)
 *
 * Args : token, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *subscriptionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <subscriptionId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMVirtualMachinesBH\n");
    char *tenantId = BarkExtractTidFromJWT(token);
    /* Some resource APIs return only identity ARM IDs. Collect the principal
     * mapping once in the VM stage, even in subscriptions with no VMs. */
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s/providers/Microsoft.ManagedIdentity/userAssignedIdentities?api-version=2023-01-31",
            subscriptionId);
        widePath = MbsToWcs(pathBuf);
        if (widePath) {
            BarkGetBHInnerArm(L"management.azure.com", widePath, token,
                "AZUserAssignedIdentity", tenantId, NULL);
            HFree(widePath);
        }
    } else {
        BarkGetBHAllSubscriptionsArmWithSnapshot(token,
            "/subscriptions/%s/providers/Microsoft.ManagedIdentity/userAssignedIdentities?api-version=2023-01-31",
            "AZUserAssignedIdentity", tenantId, NULL, subscriptionSnapshot);
    }
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0) {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/subscriptions/%s/providers/Microsoft.Compute/virtualMachines?api-version=2022-03-01", subscriptionId);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkGetBHInnerArm(L"management.azure.com", widePath, token, "AZVM", tenantId, NULL);
        HFree(widePath);
    } else {
        BarkGetBHAllSubscriptionsArmWithSnapshot(token,
            "/subscriptions/%s/providers/Microsoft.Compute/virtualMachines?api-version=2022-03-01",
            "AZVM", tenantId, NULL, subscriptionSnapshot);
    }
    if (tenantId) HFree(tenantId);
}
