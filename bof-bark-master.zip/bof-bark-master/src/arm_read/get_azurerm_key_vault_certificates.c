/*
 * get_azurerm_key_vault_certificates.c — BARK BOF
 * Get-AzureRMKeyVaultCertificates — List certificates in a Key Vault
 *
 * Args : token (KV-scoped), keyVaultUrl
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL, *keyVaultUrl = NULL;

    BeaconDataParse(&parser, args, alen);
    token      = BeaconDataExtract(&parser, NULL);
    keyVaultUrl  = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azurerm_key_vault_certificates <token> <keyVaultUrl>\n");
        return;
    }
    /* Strip https:// prefix and any trailing path/slash to isolate the hostname */
    const char *vaultHostStart = keyVaultUrl;
    if (MSVCRT$strncmp(keyVaultUrl, "https://", 8) == 0) vaultHostStart = keyVaultUrl + 8;
    char hostBuf[256];
    {
        const char *slash = MSVCRT$strstr(vaultHostStart, "/");
        int hlen = slash ? (int)(slash - vaultHostStart) : (int)MSVCRT$strlen(vaultHostStart);
        if (hlen <= 0 || hlen >= (int)sizeof(hostBuf)) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Invalid keyVaultUrl: %s\n", keyVaultUrl);
            return;
        }
        MSVCRT$strncpy(hostBuf, vaultHostStart, (size_t)hlen);
        hostBuf[hlen] = '\0';
    }
    LPWSTR wideVaultHost = MbsToWcs(hostBuf);
    if (!wideVaultHost) { BeaconPrintf(CALLBACK_ERROR, "[-] Host conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMKeyVaultCertificates\n");
    BarkGet(wideVaultHost, L"/certificates?api-version=7.3", token);
    HFree(wideVaultHost);
}
