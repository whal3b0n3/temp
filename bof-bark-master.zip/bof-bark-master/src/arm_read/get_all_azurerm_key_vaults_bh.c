/* Key Vault inventory plus complete access-policy evidence, read-only. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/edge_collection.h"

static int BarkVaultItem(const char *item,const char *end,void *context) {
    BarkEdgeOutput *out=(BarkEdgeOutput *)context;
    const char *propsEnd=NULL,*props=BarkEdgeField(item,end,"\"properties\"",&propsEnd);
    const char *policies=props?BarkEdgeField(props,propsEnd,"\"accessPolicies\"",NULL):NULL;
    const char *mode=props?BarkEdgeField(props,propsEnd,"\"enableRbacAuthorization\"",NULL):NULL;
    char *detail=NULL,*id=NULL;int ok=1;
    if (!(mode && MSVCRT$strncmp(mode,"true",4)==0) && (!policies || *policies!='[')) {
        char path[4096];LPWSTR wide;
        id=BarkEdgeString(item,end,"\"id\"");
        if (!id || MSVCRT$strncmp(id,"/subscriptions/",15)!=0 ||
            MSVCRT$strlen(id)>3800 || MSVCRT$strchr(id,'?')) ok=0;
        else {
            MSVCRT$sprintf_s(path,sizeof(path),"%s?api-version=2021-10-01",id);
            wide=MbsToWcs(path);
            if (wide) { detail=BarkEdgeGet(L"management.azure.com",wide,out->token);HFree(wide); }
            if (detail) {
                const char *detailEnd=detail+MSVCRT$strlen(detail);
                const char *object=BarkEdgeSpace(detail,detailEnd);
                props=BarkEdgeField(object,detailEnd,"\"properties\"",&propsEnd);
                policies=props?BarkEdgeField(props,propsEnd,"\"accessPolicies\"",NULL):NULL;
                mode=props?BarkEdgeField(props,propsEnd,"\"enableRbacAuthorization\"",NULL):NULL;
                char *detailId=BarkEdgeString(object,detailEnd,"\"id\"");
                int sameId=detailId && MSVCRT$_stricmp(detailId,id)==0;
                if (detailId) HFree(detailId);
                if (sameId && props && ((policies && *policies=='[') ||
                    (mode && MSVCRT$strncmp(mode,"true",4)==0))) {
                    item=object;end=JsonSkipBalanced(object,detailEnd);
                    if (!end) { HFree(detail);if(id)HFree(id);return 0; }
                } else ok=0;
            } else ok=0;
        }
    }
    BarkBufPrintBHItemArm(&out->output,"AZKeyVault",item,end,out->count==0,out->tenant,"resourceGroup");
    ++out->count;
    if (detail) HFree(detail);
    if (id) HFree(id);
    return ok && out->output.ok;
}

void go(char *args,int alen) {
    datap parser;char *token,*subscriptionId,*snapshot,*tenant;
    BarkIdList subs;int complete=1,i;
    BeaconDataParse(&parser,args,alen);
    token=BeaconDataExtract(&parser,NULL);
    subscriptionId=BeaconDataExtract(&parser,NULL);
    g_use_download=BeaconDataInt(&parser);
    snapshot=BeaconDataExtract(&parser,NULL);
    if (!token || !token[0]) {
        BeaconPrintf(CALLBACK_ERROR,"[-] Usage: bark_get_all_azurerm_key_vaults_bh <token> [subscriptionId]\n");
        return;
    }
    tenant=BarkExtractTidFromJWT(token);
    subs=BarkParseSubscriptionSnapshot(snapshot);
    if (subscriptionId && subscriptionId[0]) {
        BarkIdListFree(&subs);BarkIdListInit(&subs);
        char *copy=(char *)HAlloc(MSVCRT$strlen(subscriptionId)+1);
        if (copy) {
            MSVCRT$strcpy(copy,subscriptionId);
            if (BarkIdListAppend(&subs,copy)!=0) { HFree(copy);complete=0; }
        } else complete=0;
    } else if (!subs.count && !(snapshot && MSVCRT$strcmp(snapshot,"__none__")==0)) {
        int primary=0,fallback=0;
        BarkIdListFree(&subs);
        subs=BarkEnumEntityIdsWithStatus(L"management.azure.com",
            "/subscriptions?api-version=2020-01-01",token,"\"subscriptionId\"",&primary);
        complete=primary;
        if (!subs.count) {
            BarkIdListFree(&subs);
            subs=BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(token,&fallback);
            complete=primary && fallback;
        }
    }
    BarkEdgeOutput out={{NULL,0,0,1},0,complete,"AZKeyVault",tenant,token};
    BarkBufAppend(&out.output,"{\"data\":[",9);
    for (i=0;i<subs.count;i++) {
        char path[512];
        if (MSVCRT$strlen(subs.ids[i])>128 || MSVCRT$strchr(subs.ids[i],'/')) {
            out.complete=0;continue;
        }
        MSVCRT$sprintf_s(path,sizeof(path),
            "/subscriptions/%s/providers/Microsoft.KeyVault/vaults?api-version=2021-10-01",subs.ids[i]);
        if (!BarkEdgeList(L"management.azure.com",path,token,BarkVaultItem,&out)) out.complete=0;
    }
    BarkEdgeFinish(&out);
    BarkIdListFree(&subs);if (tenant) HFree(tenant);
    BarkEmitAllInfoArmMarker("AZKeyVault");
}
