/*
 * get_all_azurerm_automation_account_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMAutomationAccountRoleAssignmentsBH — Enumerate role assignments on an Automation Account (BloodHound)
 *
 * Args : token (ARM Bearer), automationAccountId (full ARM resource path)
 * API  : GET management.azure.com/{automationAccountId}/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *automationAccountId = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    automationAccountId = BeaconDataExtract(&parser, NULL);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_azurerm_automation_account_role_assignments_bh <token> [automationAccountId]\n");
        return;
    }

    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.Automation/automationAccounts", roleDefLookup, tenantId,
        (automationAccountId && MSVCRT$strlen(automationAccountId) > 0) ? automationAccountId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
