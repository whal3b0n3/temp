/*
 * get_all_azurerm_deployments.c — BARK BOF
 * Get-AllAzureRMDeployments — List ARM deployments at any scope
 *
 * Args : token, scope
 *
 * scope examples:
 *   /subscriptions/<subId>/resourcegroups/<rgName>  (resource group)
 *   /subscriptions/<subId>                           (subscription)
 *   /providers/Microsoft.Management/managementGroups/<groupId>  (management group)
 *   (empty string)                                   (tenant level)
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *scope = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    scope = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_all_azurerm_deployments <token> <scope>\n");
        return;
    }
    scope = SAFE_STR(scope);
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMDeployments (scope: %s)\n", scope[0] ? scope : "(tenant)");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/providers/Microsoft.Resources/deployments?api-version=2025-04-01", scope);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
