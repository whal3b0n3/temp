/*
 * get_azurerm_foundry_opengraph.c — BARK BOF
 *
 * Collect read-only Azure AI Foundry account/project inventory from the ARM
 * control plane and emit a generic OpenGraph payload.  This BOF intentionally
 * avoids data-plane endpoints, account keys, model lists, project contents,
 * deployments, or secrets.  It only reads:
 *   - Microsoft.CognitiveServices/accounts (api-version=2025-06-01)
 *   - Microsoft.CognitiveServices/accounts/projects (api-version=2025-06-01)
 *   - account-scope Microsoft.Authorization/roleAssignments, when readable
 *
 * Args: armToken, downloadMode
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define FOUNDRY_ARM_HOST L"management.azure.com"
#define FOUNDRY_ACCOUNTS_API_VERSION "2025-06-01"
#define FOUNDRY_ROLE_ASSIGNMENTS_API_VERSION "2022-04-01"

typedef struct {
    char **ids;
    int count;
    int cap;
} FoundryStringSet;

typedef struct {
    BarkBuf nodes;
    BarkBuf edges;
    int nodeCount;
    int edgeCount;
    int accountCount;
    int projectCount;
    int skippedAccounts;
    int roleAssignmentCount;
    int failedPages;
    int failedRolePages;
} FoundryGraph;

static void FoundrySetInit(FoundryStringSet *set) {
    set->ids = NULL;
    set->count = 0;
    set->cap = 0;
}

static int FoundrySetHas(const FoundryStringSet *set, const char *id) {
    int i;
    if (!id) return 0;
    for (i = 0; i < set->count; i++) {
        if (MSVCRT$strcmp(set->ids[i], id) == 0)
            return 1;
    }
    return 0;
}

static int FoundrySetAdd(FoundryStringSet *set, const char *id) {
    char **newIds;
    char *copy;

    if (!id || MSVCRT$strlen(id) == 0)
        return 1;
    if (FoundrySetHas(set, id))
        return 1;

    if (set->count >= set->cap) {
        int newCap = set->cap == 0 ? 64 : set->cap * 2;
        newIds = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        if (!newIds)
            return 0;
        if (set->count > 0)
            MSVCRT$memcpy(newIds, set->ids,
                          (SIZE_T)set->count * sizeof(char *));
        if (set->ids)
            HFree(set->ids);
        set->ids = newIds;
        set->cap = newCap;
    }

    copy = (char *)HAlloc(MSVCRT$strlen(id) + 1);
    if (!copy)
        return 0;
    MSVCRT$memcpy(copy, id, MSVCRT$strlen(id) + 1);
    set->ids[set->count++] = copy;
    return 1;
}

static void FoundrySetFree(FoundryStringSet *set) {
    int i;
    for (i = 0; i < set->count; i++)
        HFree(set->ids[i]);
    if (set->ids)
        HFree(set->ids);
    FoundrySetInit(set);
}

static void FoundryJsonString(BarkBuf *b, const char *value) {
    size_t i;
    char escaped[8];

    BarkBufAppend(b, "\"", 1);
    if (value) {
        for (i = 0; value[i]; i++) {
            unsigned char c = (unsigned char)value[i];
            if (c == '"' || c == '\\') {
                BarkBufAppend(b, "\\", 1);
                BarkBufAppend(b, (const char *)&value[i], 1);
            } else if (c == '\n') {
                BarkBufAppend(b, "\\n", 2);
            } else if (c == '\r') {
                BarkBufAppend(b, "\\r", 2);
            } else if (c == '\t') {
                BarkBufAppend(b, "\\t", 2);
            } else if (c < 0x20) {
                MSVCRT$sprintf_s(escaped, sizeof(escaped), "\\u%04x", c);
                BarkBufAppend(b, escaped, MSVCRT$strlen(escaped));
            } else {
                BarkBufAppend(b, (const char *)&value[i], 1);
            }
        }
    }
    BarkBufAppend(b, "\"", 1);
}

static void FoundryProperty(BarkBuf *b, int *first, const char *name,
                            const char *value) {
    if (!value || MSVCRT$strlen(value) == 0)
        return;
    if (!*first)
        BarkBufAppend(b, ",", 1);
    FoundryJsonString(b, name);
    BarkBufAppend(b, ":", 1);
    FoundryJsonString(b, value);
    *first = 0;
}

static char *FoundryExtractPrimitiveValue(const char *obj, const char *objEnd,
                                          const char *keyWithQuotes) {
    const char *key = JsonFindKey(obj, objEnd, keyWithQuotes);
    const char *p;
    const char *vStart;
    const char *vEnd;
    char *result;
    size_t len;

    if (!key) return NULL;
    p = key + MSVCRT$strlen(keyWithQuotes);
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
           *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != ':') return NULL;
    p++;
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
           *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p == '"' || *p == '{' || *p == '[')
        return NULL;

    vStart = p;
    while (p < objEnd && *p != ',' && *p != '}' && *p != ']' &&
           *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r')
        p++;
    vEnd = p;
    if (vEnd <= vStart)
        return NULL;

    len = (size_t)(vEnd - vStart);
    result = (char *)HAlloc(len + 1);
    if (!result)
        return NULL;
    MSVCRT$memcpy(result, vStart, len);
    result[len] = '\0';
    return result;
}

static int FoundryJsonBoolIsTrue(const char *obj, const char *objEnd,
                                 const char *keyWithQuotes) {
    char *value = FoundryExtractPrimitiveValue(obj, objEnd, keyWithQuotes);
    int result = 0;
    if (value) {
        if (MSVCRT$strcmp(value, "true") == 0 ||
            MSVCRT$strcmp(value, "True") == 0 ||
            MSVCRT$strcmp(value, "1") == 0)
            result = 1;
        HFree(value);
    }
    return result;
}

static int FoundryJsonArrayHasValue(const char *obj, const char *objEnd,
                                    const char *keyWithQuotes) {
    const char *key = JsonFindKey(obj, objEnd, keyWithQuotes);
    const char *p;
    const char *arrEnd;

    if (!key) return 0;
    p = key + MSVCRT$strlen(keyWithQuotes);
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
           *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != ':') return 0;
    p++;
    while (p < objEnd && (*p == ' ' || *p == '\t' ||
           *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != '[') return 0;
    arrEnd = JsonSkipBalanced(p, objEnd);
    if (!arrEnd) return 0;
    p++;
    while (p < arrEnd - 1 && (*p == ' ' || *p == '\t' ||
           *p == '\n' || *p == '\r' || *p == ','))
        p++;
    return (p < arrEnd - 1);
}

static void FoundryPropertyFromJson(BarkBuf *b, int *first,
                                    const char *item, const char *itemEnd,
                                    const char *name, const char *jsonKey) {
    char *value = JsonExtractStringValueUtf8(item, itemEnd, jsonKey);
    FoundryProperty(b, first, name, value);
    if (value) HFree(value);
}

static void FoundryPropertyPrimitiveFromJson(BarkBuf *b, int *first,
                                             const char *item,
                                             const char *itemEnd,
                                             const char *name,
                                             const char *jsonKey) {
    char *value = FoundryExtractPrimitiveValue(item, itemEnd, jsonKey);
    FoundryProperty(b, first, name, value);
    if (value) HFree(value);
}

static void FoundryAppendNodeStart(FoundryGraph *graph, const char *nodeId,
                                   const char *kind) {
    if (graph->nodeCount > 0)
        BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    FoundryJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    FoundryJsonString(&graph->nodes, kind);
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));
}

static void FoundryAppendNodeEnd(FoundryGraph *graph) {
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
}

static void FoundryAddAccountNode(FoundryGraph *graph,
                                  const char *item, const char *itemEnd,
                                  const char *signal) {
    int first = 1;
    char *id = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    char *name = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    char subId[128] = {0};
    char rgId[512] = {0};

    if (!id || MSVCRT$strlen(id) == 0) {
        if (id) HFree(id);
        if (name) HFree(name);
        return;
    }

    BarkParseArmId(item, itemEnd, subId, sizeof(subId), rgId, sizeof(rgId));
    FoundryAppendNodeStart(graph, id, "AZFoundryAccount");
    FoundryProperty(&graph->nodes, &first, "name", name);
    FoundryProperty(&graph->nodes, &first, "displayname", name);
    FoundryProperty(&graph->nodes, &first, "armid", id);
    FoundryProperty(&graph->nodes, &first, "subscriptionid", subId);
    FoundryProperty(&graph->nodes, &first, "resourcegroupid", rgId);
    FoundryProperty(&graph->nodes, &first, "foundrysignal", signal);
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "resourcetype", "\"type\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "location", "\"location\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "kind", "\"kind\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "endpoint", "\"endpoint\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "provisioningstate", "\"provisioningState\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "customsubdomainname", "\"customSubDomainName\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "publicnetworkaccess", "\"publicNetworkAccess\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "defaultproject", "\"defaultProject\"");
    FoundryPropertyPrimitiveFromJson(&graph->nodes, &first, item, itemEnd,
                                     "allowprojectmanagement",
                                     "\"allowProjectManagement\"");
    FoundryPropertyPrimitiveFromJson(&graph->nodes, &first, item, itemEnd,
                                     "disablelocalauth",
                                     "\"disableLocalAuth\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "principalid", "\"principalId\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "tenantid", "\"tenantId\"");
    FoundryAppendNodeEnd(graph);
    graph->accountCount++;

    HFree(id);
    if (name) HFree(name);
}

static void FoundryAddProjectNode(FoundryGraph *graph,
                                  const char *accountId,
                                  const char *item,
                                  const char *itemEnd) {
    int first = 1;
    char *id = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    char *name = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    char *displayName = JsonExtractStringValueUtf8(item, itemEnd,
                                               "\"displayName\"");
    char subId[128] = {0};
    char rgId[512] = {0};

    if (!id || MSVCRT$strlen(id) == 0) {
        if (id) HFree(id);
        if (name) HFree(name);
        if (displayName) HFree(displayName);
        return;
    }

    BarkParseArmId(item, itemEnd, subId, sizeof(subId), rgId, sizeof(rgId));
    FoundryAppendNodeStart(graph, id, "AZFoundryProject");
    FoundryProperty(&graph->nodes, &first, "name", name);
    FoundryProperty(&graph->nodes, &first, "displayname",
                    displayName ? displayName : name);
    FoundryProperty(&graph->nodes, &first, "armid", id);
    FoundryProperty(&graph->nodes, &first, "accountid", accountId);
    FoundryProperty(&graph->nodes, &first, "subscriptionid", subId);
    FoundryProperty(&graph->nodes, &first, "resourcegroupid", rgId);
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "resourcetype", "\"type\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "location", "\"location\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "description", "\"description\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "principalid", "\"principalId\"");
    FoundryPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                            "tenantid", "\"tenantId\"");
    FoundryAppendNodeEnd(graph);
    graph->projectCount++;

    HFree(id);
    if (name) HFree(name);
    if (displayName) HFree(displayName);
}

static void FoundryAddPrincipalNode(FoundryGraph *graph,
                                    FoundryStringSet *principals,
                                    const char *principalId,
                                    const char *principalType) {
    /* Role edges intentionally use the raw Entra object ID so they join the
     * existing AZUser/AZGroup/AZServicePrincipal graph.  Do not emit a
     * duplicate generic node with the same ID and a conflicting kind. */
    (void)graph;
    (void)principalType;
    if (!principalId || MSVCRT$strlen(principalId) == 0)
        return;
    if (FoundrySetHas(principals, principalId))
        return;
    FoundrySetAdd(principals, principalId);
}

static void FoundryEdge(FoundryGraph *graph, const char *kind,
                        const char *start, const char *end,
                        const char *roleAssignmentId,
                        const char *roleDefinitionId,
                        const char *principalType,
                        const char *scope) {
    int first = 1;
    if (!start || !end || MSVCRT$strlen(start) == 0 ||
        MSVCRT$strlen(end) == 0)
        return;

    if (graph->edgeCount > 0)
        BarkBufAppend(&graph->edges, ",", 1);
    BarkBufAppend(&graph->edges, "{\"kind\":",
                  MSVCRT$strlen("{\"kind\":"));
    FoundryJsonString(&graph->edges, kind);
    BarkBufAppend(&graph->edges, ",\"start\":{\"value\":",
                  MSVCRT$strlen(",\"start\":{\"value\":"));
    FoundryJsonString(&graph->edges, start);
    BarkBufAppend(&graph->edges,
                  ",\"match_by\":\"id\"},\"end\":{\"value\":",
                  MSVCRT$strlen(",\"match_by\":\"id\"},\"end\":{\"value\":"));
    FoundryJsonString(&graph->edges, end);
    BarkBufAppend(&graph->edges, ",\"match_by\":\"id\"}",
                  MSVCRT$strlen(",\"match_by\":\"id\"}"));

    if (roleAssignmentId || roleDefinitionId || principalType || scope) {
        BarkBufAppend(&graph->edges, ",\"properties\":{",
                      MSVCRT$strlen(",\"properties\":{"));
        FoundryProperty(&graph->edges, &first, "roleassignmentid",
                        roleAssignmentId);
        FoundryProperty(&graph->edges, &first, "roledefinitionid",
                        roleDefinitionId);
        FoundryProperty(&graph->edges, &first, "principaltype",
                        principalType);
        FoundryProperty(&graph->edges, &first, "scope", scope);
        BarkBufAppend(&graph->edges, "}", 1);
    }
    BarkBufAppend(&graph->edges, "}", 1);
    graph->edgeCount++;
}

static int FoundryIsFoundryCapable(const char *item, const char *itemEnd,
                                   const char **signal) {
    char *kind;
    char *defaultProject;

    if (FoundryJsonBoolIsTrue(item, itemEnd, "\"allowProjectManagement\"")) {
        *signal = "allowProjectManagement";
        return 1;
    }

    defaultProject = JsonExtractStringValueUtf8(item, itemEnd, "\"defaultProject\"");
    if (defaultProject && MSVCRT$strlen(defaultProject) > 0) {
        HFree(defaultProject);
        *signal = "defaultProject";
        return 1;
    }
    if (defaultProject) HFree(defaultProject);

    if (FoundryJsonArrayHasValue(item, itemEnd, "\"associatedProjects\"")) {
        *signal = "associatedProjects";
        return 1;
    }

    kind = JsonExtractStringValueUtf8(item, itemEnd, "\"kind\"");
    if (kind) {
        if (MSVCRT$strcmp(kind, "AIServices") == 0 ||
            MSVCRT$strcmp(kind, "OpenAI") == 0) {
            HFree(kind);
            *signal = "kind";
            return 1;
        }
        HFree(kind);
    }

    *signal = NULL;
    return 0;
}

static int FoundryForEachValueItem(const char *response,
                                   int (*cb)(const char *, const char *,
                                             void *),
                                   void *ctx) {
    const char *end = response + MSVCRT$strlen(response);
    const char *valueKey = JsonFindKey(response, end, "\"value\"");
    const char *colon;
    const char *arrayEnd;
    const char *item;
    int count = 0;

    if (!valueKey) return 0;
    colon = JsonFindKey(valueKey, end, ":");
    if (!colon) return 0;
    colon++;
    while (colon < end && (*colon == ' ' || *colon == '\t' ||
           *colon == '\n' || *colon == '\r')) colon++;
    if (colon >= end || *colon != '[') return 0;
    arrayEnd = JsonSkipBalanced(colon, end);
    if (!arrayEnd) return 0;

    item = colon + 1;
    while (item < arrayEnd - 1) {
        const char *itemEnd;
        while (item < arrayEnd - 1 && (*item == ' ' || *item == '\t' ||
               *item == '\n' || *item == '\r' || *item == ','))
            item++;
        if (item >= arrayEnd - 1 || *item != '{') break;
        itemEnd = JsonSkipBalanced(item, arrayEnd - 1);
        if (!itemEnd) break;
        if (cb(item, itemEnd, ctx))
            count++;
        item = itemEnd;
    }
    return count;
}

typedef struct {
    FoundryGraph *graph;
    FoundryStringSet *principals;
    const char *accountId;
} FoundryProjectCtx;

static int FoundryProjectItemCb(const char *item, const char *itemEnd,
                                void *ctxPtr) {
    FoundryProjectCtx *ctx = (FoundryProjectCtx *)ctxPtr;
    char *projectId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");

    if (!projectId || MSVCRT$strlen(projectId) == 0) {
        if (projectId) HFree(projectId);
        return 0;
    }

    FoundryAddProjectNode(ctx->graph, ctx->accountId, item, itemEnd);
    FoundryEdge(ctx->graph, "AZFoundry_HasProject",
                ctx->accountId, projectId, NULL, NULL, NULL, NULL);
    HFree(projectId);
    return 1;
}

typedef struct {
    FoundryGraph *graph;
    FoundryStringSet *principals;
    const char *accountId;
} FoundryRoleCtx;

static int FoundryRoleAssignmentItemCb(const char *item, const char *itemEnd,
                                       void *ctxPtr) {
    FoundryRoleCtx *ctx = (FoundryRoleCtx *)ctxPtr;
    char *assignmentId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    char *principalId = JsonExtractStringValueUtf8(item, itemEnd, "\"principalId\"");
    char *principalType = JsonExtractStringValueUtf8(item, itemEnd,
                                                 "\"principalType\"");
    char *roleDefinitionId = JsonExtractStringValueUtf8(item, itemEnd,
                                                    "\"roleDefinitionId\"");
    char *scope = JsonExtractStringValueUtf8(item, itemEnd, "\"scope\"");
    int emitted = 0;

    if (principalId && MSVCRT$strlen(principalId) > 0) {
        FoundryAddPrincipalNode(ctx->graph, ctx->principals,
                                principalId, principalType);
        FoundryEdge(ctx->graph, "AZFoundry_AccountRoleAssignment",
                    principalId, ctx->accountId, assignmentId,
                    roleDefinitionId, principalType, scope);
        ctx->graph->roleAssignmentCount++;
        emitted = 1;
    }

    if (assignmentId) HFree(assignmentId);
    if (principalId) HFree(principalId);
    if (principalType) HFree(principalType);
    if (roleDefinitionId) HFree(roleDefinitionId);
    if (scope) HFree(scope);
    return emitted;
}

static int FoundryCollectPaged(const char *token, const char *initialPath,
                               int (*cb)(const char *, const char *, void *),
                               void *ctx, int *failedPages) {
    LPWSTR headers;
    LPWSTR path;
    int total = 0;

    headers = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");
    path = MbsToWcs(initialPath);
    if (!headers || !path) {
        if (headers) HFree(headers);
        if (path) HFree(path);
        if (failedPages) (*failedPages)++;
        return 0;
    }

    while (1) {
        DWORD status = 0;
        char *response = HttpRequestWithRetry(
            L"GET", FOUNDRY_ARM_HOST, path, headers, NULL, 0, &status);
        char *nextUrl;
        LPWSTR nextPath;

        if (!response || status >= 400) {
            if (response) HFree(response);
            if (failedPages) (*failedPages)++;
            break;
        }

        total += FoundryForEachValueItem(response, cb, ctx);
        nextUrl = JsonExtractNextLink(response,
                                      response + MSVCRT$strlen(response));
        HFree(response);
        if (!nextUrl) break;

        nextPath = BarkResolveNextLink(nextUrl, FOUNDRY_ARM_HOST, NULL);
        HFree(nextUrl);
        if (!nextPath) {
            if (failedPages) (*failedPages)++;
            break;
        }
        HFree(path);
        path = nextPath;
    }

    HFree(headers);
    HFree(path);
    return total;
}

static void FoundryCollectProjects(const char *token,
                                   const char *accountId,
                                   FoundryGraph *graph,
                                   FoundryStringSet *principals) {
    char *path;
    size_t pathSize;
    FoundryProjectCtx ctx;

    if (!accountId || MSVCRT$strlen(accountId) == 0)
        return;

    pathSize = MSVCRT$strlen(accountId) +
               MSVCRT$strlen("/projects?api-version=") +
               MSVCRT$strlen(FOUNDRY_ACCOUNTS_API_VERSION) + 1;
    path = (char *)HAlloc(pathSize);
    if (!path) {
        graph->failedPages++;
        return;
    }
    MSVCRT$sprintf_s(path, pathSize, "%s/projects?api-version=%s",
                     accountId, FOUNDRY_ACCOUNTS_API_VERSION);

    ctx.graph = graph;
    ctx.principals = principals;
    ctx.accountId = accountId;
    FoundryCollectPaged(token, path, FoundryProjectItemCb, &ctx,
                        &graph->failedPages);
    HFree(path);
}

static void FoundryCollectRoleAssignments(const char *token,
                                          const char *accountId,
                                          FoundryGraph *graph,
                                          FoundryStringSet *principals) {
    char *path;
    size_t pathSize;
    FoundryRoleCtx ctx;

    if (!accountId || MSVCRT$strlen(accountId) == 0)
        return;

    pathSize = MSVCRT$strlen(accountId) +
               MSVCRT$strlen("/providers/Microsoft.Authorization/roleAssignments?api-version=") +
               MSVCRT$strlen(FOUNDRY_ROLE_ASSIGNMENTS_API_VERSION) +
               MSVCRT$strlen("&$filter=atScope()") + 1;
    path = (char *)HAlloc(pathSize);
    if (!path) {
        graph->failedRolePages++;
        return;
    }
    MSVCRT$sprintf_s(path, pathSize,
        "%s/providers/Microsoft.Authorization/roleAssignments?api-version=%s&$filter=atScope()",
        accountId, FOUNDRY_ROLE_ASSIGNMENTS_API_VERSION);

    ctx.graph = graph;
    ctx.principals = principals;
    ctx.accountId = accountId;
    FoundryCollectPaged(token, path, FoundryRoleAssignmentItemCb, &ctx,
                        &graph->failedRolePages);
    HFree(path);
}

typedef struct {
    const char *token;
    FoundryGraph *graph;
    FoundryStringSet *principals;
} FoundryAccountCtx;

static int FoundryAccountItemCb(const char *item, const char *itemEnd,
                                void *ctxPtr) {
    FoundryAccountCtx *ctx = (FoundryAccountCtx *)ctxPtr;
    const char *signal = NULL;
    char *accountId;

    if (!FoundryIsFoundryCapable(item, itemEnd, &signal)) {
        ctx->graph->skippedAccounts++;
        return 0;
    }

    accountId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
    if (!accountId || MSVCRT$strlen(accountId) == 0) {
        if (accountId) HFree(accountId);
        return 0;
    }

    FoundryAddAccountNode(ctx->graph, item, itemEnd,
                          signal ? signal : "unknown");
    FoundryCollectProjects(ctx->token, accountId, ctx->graph,
                           ctx->principals);
    FoundryCollectRoleAssignments(ctx->token, accountId, ctx->graph,
                                  ctx->principals);
    HFree(accountId);
    return 1;
}

static int FoundryCollectSubscriptionAccounts(const char *token,
                                              const char *subscriptionId,
                                              FoundryGraph *graph,
                                              FoundryStringSet *principals) {
    char path[512];
    FoundryAccountCtx ctx;

    MSVCRT$sprintf_s(path, sizeof(path),
        "/subscriptions/%s/providers/Microsoft.CognitiveServices/accounts?api-version=%s",
        subscriptionId, FOUNDRY_ACCOUNTS_API_VERSION);
    ctx.token = token;
    ctx.graph = graph;
    ctx.principals = principals;
    return FoundryCollectPaged(token, path, FoundryAccountItemCb, &ctx,
                               &graph->failedPages);
}

static void FoundryWriteGraph(FoundryGraph *graph) {
    BarkBuf output = { NULL, 0, 0, 1 };
    SYSTEMTIME st;
    char filename[300];

    BarkBufAppend(&output, "{\"graph\":{\"nodes\":[",
                  MSVCRT$strlen("{\"graph\":{\"nodes\":["));
    if (graph->nodes.buf)
        BarkBufAppend(&output, graph->nodes.buf, graph->nodes.len);
    BarkBufAppend(&output, "],\"edges\":[",
                  MSVCRT$strlen("],\"edges\":["));
    if (graph->edges.buf)
        BarkBufAppend(&output, graph->edges.buf, graph->edges.len);
    BarkBufAppend(&output, "]}}", 3);

    if (!output.ok || !output.buf) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Foundry OpenGraph output exceeded available memory\n");
        BarkBufFree(&output);
        return;
    }

    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZFoundryOpenGraph_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
    BarkWriteOutput(filename, output.buf, (DWORD)output.len);
    BarkBufFree(&output);
}

void go(char *args, int alen) {
    datap parser;
    char *token;
    int downloadMode;
    BarkIdList subscriptions;
    FoundryStringSet principals;
    FoundryGraph graph = {
        { NULL, 0, 0, 1 },
        { NULL, 0, 0, 1 },
        0, 0, 0, 0, 0, 0, 0, 0
    };
    int i;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    downloadMode = BeaconDataInt(&parser);
    g_use_download = downloadMode ? 1 : 0;

    FoundrySetInit(&principals);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_foundry_opengraph <armToken> [downloadMode]\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Collecting Azure AI Foundry ARM inventory (control plane only)\n");

    BarkHttpMetricsReset();
    subscriptions = BarkEnumEntityIds(
        FOUNDRY_ARM_HOST,
        "/subscriptions?api-version=2020-01-01",
        token, "\"subscriptionId\"");

    if (subscriptions.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No subscriptions returned by /subscriptions; nothing to collect\n");
        FoundrySetFree(&principals);
        return;
    }

    for (i = 0; i < subscriptions.count; i++) {
        FoundryCollectSubscriptionAccounts(token, subscriptions.ids[i],
                                           &graph, &principals);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Foundry OpenGraph: subscriptions=%d accounts=%d projects=%d roleAssignments=%d nodes=%d edges=%d skippedAccounts=%d failedPages=%d failedRolePages=%d requests=%ld retries=%ld 429s=%ld\n",
        subscriptions.count, graph.accountCount, graph.projectCount,
        graph.roleAssignmentCount, graph.nodeCount, graph.edgeCount,
        graph.skippedAccounts, graph.failedPages, graph.failedRolePages,
        (long)BarkHttpRequestCount, (long)BarkHttpRetryCount,
        (long)BarkHttp429Count);

    FoundryWriteGraph(&graph);

    BarkIdListFree(&subscriptions);
    FoundrySetFree(&principals);
    BarkBufFree(&graph.nodes);
    BarkBufFree(&graph.edges);
}
