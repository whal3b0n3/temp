/*
 * get_all_azurerm_container_app_role_assignments_bh.c — BARK BOF
 * Get-AllAzureRMContainerAppRoleAssignmentsBH — Get role assignments for Container Apps
 *
 * Args : token, containerAppId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *containerAppId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    containerAppId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <containerAppId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMContainerAppRoleAssignmentsBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, "Microsoft.App/containerApps", roleDefLookup, tenantId,
        (containerAppId && MSVCRT$strlen(containerAppId) > 0) ? containerAppId : NULL, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
