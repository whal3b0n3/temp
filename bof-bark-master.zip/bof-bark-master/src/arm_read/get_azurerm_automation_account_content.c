/*
 * get_azurerm_automation_account_content.c — BARK BOF
 * Get-AzureRMAutomationAccountContent — Fetch runbook content or job output/runbookContent
 *
 * Args : token, contentPath
 *
 * contentPath examples (full ARM path including terminal segment):
 *   /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Automation/automationAccounts/<name>/runbooks/<rbName>/content
 *   /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Automation/automationAccounts/<name>/jobs/<jobId>/output
 *   /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Automation/automationAccounts/<name>/jobs/<jobId>/runbookContent
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token       = NULL;
    char  *contentPath = NULL;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    contentPath = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_automation_account_content <token> <contentPath>\n");
        return;
    }
    contentPath = SAFE_STR(contentPath);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AzureRMAutomationAccountContent: %s\n", contentPath);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s?api-version=2023-11-01", contentPath);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
