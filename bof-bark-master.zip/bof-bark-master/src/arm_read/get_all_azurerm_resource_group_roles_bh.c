/*
 * get_all_azurerm_resource_group_roles_bh.c — BARK BOF
 * Get-AllAzureRMResourceGroupRolesBH — Get role assignments for a resource group
 *
 * Args : token, subscriptionId, resourceGroupName
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   scopeBuf[512];
    char  *token = NULL;
    char  *subscriptionId = NULL;
    char  *resourceGroupName = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    resourceGroupName = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <subscriptionId> <resourceGroupName>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMResourceGroupRolesBH\n");
    char *roleDefLookup = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    char *subscriptionSnapshot = BeaconDataExtract(&parser, NULL);
    char *tenantId = BarkExtractTidFromJWT(token);
    const char *scope = NULL;
    if (subscriptionId && MSVCRT$strlen(subscriptionId) > 0 &&
        resourceGroupName && MSVCRT$strlen(resourceGroupName) > 0) {
        MSVCRT$sprintf_s(scopeBuf, sizeof(scopeBuf),
            "/subscriptions/%s/resourceGroups/%s", subscriptionId, resourceGroupName);
        scope = scopeBuf;
    }
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(token, NULL, roleDefLookup,
        tenantId, scope, subscriptionSnapshot);
    if (tenantId) HFree(tenantId);
}
