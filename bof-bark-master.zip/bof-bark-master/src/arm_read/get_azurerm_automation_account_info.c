/*
 * get_azurerm_automation_account_info.c — BARK BOF
 * Get-AzureRMAutomationAccountInfo — Query details, credentials, runbooks, or jobs
 *
 * Args : token, accountPath, infoType
 *
 * accountPath  : full ARM path, e.g.
 *   /subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.Automation/automationAccounts/<name>
 *
 * infoType     : details | credentials | runbooks | jobs
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token       = NULL;
    char  *accountPath = NULL;
    char  *infoType    = NULL;
    const char *subPath   = "";
    const char *apiVersion = "2024-10-23";

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    accountPath = BeaconDataExtract(&parser, NULL);
    infoType    = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azurerm_automation_account_info <token> <accountPath> <details|credentials|runbooks|jobs>\n");
        return;
    }
    accountPath = SAFE_STR(accountPath);
    infoType    = SAFE_STR(infoType);

    if (MSVCRT$strcmp(infoType, "credentials") == 0) {
        subPath    = "/credentials";
        apiVersion = "2023-11-01";
    } else if (MSVCRT$strcmp(infoType, "runbooks") == 0) {
        subPath = "/runbooks";
    } else if (MSVCRT$strcmp(infoType, "jobs") == 0) {
        subPath = "/jobs";
    } else {
        infoType = "details";
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AzureRMAutomationAccountInfo (%s): %s\n", infoType, accountPath);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s%s?api-version=%s", accountPath, subPath, apiVersion);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
