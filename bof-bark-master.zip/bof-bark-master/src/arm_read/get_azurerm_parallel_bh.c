/*
 * get_azurerm_parallel_bh.c - retired BARK compatibility BOF
 *
 * Loading every ARM collector into one COFF object creates an unnecessarily
 * large in-process Beacon task. The current CNA dispatches each existing ARM
 * collector separately and places a target-return marker after it. Keep this
 * small object at the historical path so an old CNA fails safely and tells the
 * operator to reload instead of loading the former aggregate implementation.
 */
#include <windows.h>
#include "../../include/beacon.h"

void go(char *args, int alen)
{
    BeaconPrintf(CALLBACK_ERROR,
        "[-] The aggregate ARM wrapper is retired. Reload the current bark.cna; "
        "ARM collection now dispatches one collector per check-in.\n");
}
