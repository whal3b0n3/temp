/*
 * get_all_azurerm_vms.c — BARK BOF
 * Get-AllAzureRMVirtualMachines — Get all virtual machines in a subscription
 *
 * Args : token, subscriptionId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *subscriptionId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    subscriptionId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <subscriptionId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAzureRMVirtualMachines\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/subscriptions/%s/providers/Microsoft.Compute/virtualMachines?api-version=2022-03-01", subscriptionId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"management.azure.com", widePath, token);
    HFree(widePath);
}
