/*
 * get_conditional_access_policies.c — BARK BOF
 * Get-ConditionalAccessPolicies — Enumerate Conditional Access Policies via legacy AAD Graph,
 * identify users/groups excluded from MFA or Block controls, and emit a BloodHound graph file.
 *
 * Args : token (AAD Graph Bearer - scope: https://graph.windows.net/), [tenantId]
 * API  : GET graph.windows.net/{tenantId}/policies?api-version=1.61-internal
 *
 * Output: .\AZConditionalAccessPolicy_yyyyMMdd_HHmmss.json
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* ================================================================
 * Constants
 * ================================================================ */
#define CAP_MAX_ENTITIES    512
#define CAP_DISPLAYNAME     256
#define CAP_APPIDS          512
#define CAP_PLATFORM        256
#define CAP_OBJECTID        64
#define CAP_PROPVAL         800
#define CAP_MAX_USERS       16384
#define CAP_USERID_LEN      48
#define CAP_USER_DISPLAY_LEN 256
#define CAP_USER_UPN_LEN     320

#define ENTITY_USER  0
#define ENTITY_GROUP 1

/* ================================================================
 * ExcludedEntity — one (objectId, kind, policyDisplayName, propValue)
 *
 * Kept small so the heap-allocated array stays reasonable.
 * ================================================================ */
typedef struct {
    char objectId[CAP_OBJECTID];
    int  kind;
    char policyName[CAP_DISPLAYNAME];
    char propValue[CAP_PROPVAL];
} ExcludedEntity;

/* Heap-allocated entity list — set up in go(), used by helpers. */
static ExcludedEntity *g_entities   = NULL;
static int             g_entityCount = 0;
static int             g_entityCap   = 0;

static char           *g_allUserIds   = NULL;
static char           *g_allUserDisplayNames = NULL;
static char           *g_allUserPrincipalNames = NULL;
static int             g_allUserCount = 0;

static int AsciiEqualsIgnoreCase(const char *left, const char *right)
{
    int i = 0;
    if (!left || !right) return 0;
    while (left[i] && right[i]) {
        char lc = left[i];
        char rc = right[i];
        if (lc >= 'a' && lc <= 'z') lc = (char)(lc - ('a' - 'A'));
        if (rc >= 'a' && rc <= 'z') rc = (char)(rc - ('a' - 'A'));
        if (lc != rc) return 0;
        i++;
    }
    return left[i] == '\0' && right[i] == '\0';
}

static int FindAllUserIndex(const char *objectId)
{
    int i;
    if (!objectId || !g_allUserIds) return -1;
    for (i = 0; i < g_allUserCount; i++) {
        const char *candidate = g_allUserIds + (i * CAP_USERID_LEN);
        if (AsciiEqualsIgnoreCase(candidate, objectId)) return i;
    }
    return -1;
}

/* ================================================================
 * UnescapeJsonString
 * ================================================================ */
static int UnescapeJsonString(const char *src, int srcLen,
                               char *dst, int dstLen)
{
    int si = 0, di = 0;
    while (si < srcLen && di < dstLen - 1) {
        if (src[si] == '\\' && si + 1 < srcLen) {
            char next = src[si + 1];
            si += 2;
            if      (next == '"')  dst[di++] = '"';
            else if (next == '\\') dst[di++] = '\\';
            else if (next == '/')  dst[di++] = '/';
            else if (next == 'n')  dst[di++] = '\n';
            else if (next == 'r')  dst[di++] = '\r';
            else if (next == 't')  dst[di++] = '\t';
            else {
                if (di + 1 < dstLen - 1) {
                    dst[di++] = '\\';
                    dst[di++] = next;
                }
            }
        } else {
            dst[di++] = src[si++];
        }
    }
    dst[di] = '\0';
    return di;
}

/* ================================================================
 * ExtractJsonIntValue
 * ================================================================ */
static int ExtractJsonIntValue(const char *obj, const char *objEnd,
                               const char *keyWithQuotes, int defaultVal)
{
    const char *k = JsonFindKey(obj, objEnd, keyWithQuotes);
    if (!k) return defaultVal;
    const char *p = k + MSVCRT$strlen(keyWithQuotes);
    while (p < objEnd && (*p == ' ' || *p == ':' || *p == '\t')) p++;
    if (p >= objEnd) return defaultVal;
    int neg = 0;
    if (*p == '-') { neg = 1; p++; }
    if (p >= objEnd || *p < '0' || *p > '9') return defaultVal;
    int val = 0;
    while (p < objEnd && *p >= '0' && *p <= '9')
        val = val * 10 + (*p++ - '0');
    return neg ? -val : val;
}

/* ================================================================
 * CollectStringArrayInto
 * ================================================================ */
static int CollectStringArrayInto(const char *obj, const char *objEnd,
                                  const char *keyWithQuotes,
                                  char *out, int outSize)
{
    out[0] = '\0';
    const char *k = JsonFindKey(obj, objEnd, keyWithQuotes);
    if (!k) return 0;
    const char *p = k + MSVCRT$strlen(keyWithQuotes);
    while (p < objEnd && (*p == ' ' || *p == ':' || *p == '\t' ||
                           *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != '[') return 0;

    const char *arrEnd = JsonSkipBalanced(p, objEnd);
    if (!arrEnd) return 0;

    int first = 1;
    p++;
    while (p < arrEnd - 1) {
        while (p < arrEnd - 1 && *p != '"' && *p != ']') p++;
        if (p >= arrEnd - 1 || *p == ']') break;
        const char *strEnd = JsonSkipString(p, arrEnd);
        if (!strEnd) break;
        int vLen = (int)((strEnd - 1) - (p + 1));
        if (vLen > 0) {
            if (!first) {
                int curLen = (int)MSVCRT$strlen(out);
                if (curLen + 2 < outSize) {
                    out[curLen]   = ',';
                    out[curLen+1] = '\0';
                }
            }
            int curLen = (int)MSVCRT$strlen(out);
            int room   = outSize - curLen - 1;
            if (room > 0) {
                int copy = vLen < room ? vLen : room;
                MSVCRT$memcpy(out + curLen, p + 1, (size_t)copy);
                out[curLen + copy] = '\0';
            }
            first = 0;
        }
        p = strEnd;
    }
    return 1;
}

/* ================================================================
 * AddEntity
 * ================================================================ */
static void AddEntity(const char *objectId, int kind,
                      const char *policyName, const char *propValue)
{
    if (g_entityCount >= g_entityCap) {
        int newCap = g_entityCap * 2;
        if (newCap < 1024) newCap = 1024;
        ExcludedEntity *newList = (ExcludedEntity *)HAlloc(
            (SIZE_T)newCap * sizeof(ExcludedEntity));
        if (!newList) return;
        MSVCRT$memcpy(newList, g_entities,
                      (size_t)g_entityCount * sizeof(ExcludedEntity));
        HFree(g_entities);
        g_entities = newList;
        g_entityCap = newCap;
    }
    int i;
    for (i = 0; i < g_entityCount; i++) {
        if (MSVCRT$strcmp(g_entities[i].objectId, objectId) == 0 &&
            MSVCRT$strcmp(g_entities[i].policyName, policyName) == 0)
            return;
    }
    ExcludedEntity *e = &g_entities[g_entityCount++];
    MSVCRT$strncpy(e->objectId,   objectId,   CAP_OBJECTID - 1);
    e->objectId[CAP_OBJECTID - 1] = '\0';
    e->kind = kind;
    MSVCRT$strncpy(e->policyName, policyName, CAP_DISPLAYNAME - 1);
    e->policyName[CAP_DISPLAYNAME - 1] = '\0';
    MSVCRT$strncpy(e->propValue,  propValue,  CAP_PROPVAL - 1);
    e->propValue[CAP_PROPVAL - 1] = '\0';
}

/* ================================================================
 * ProcessExcludeArray
 * ================================================================ */
static void ProcessExcludeArray(const char *arrBody, const char *arrEnd,
                                 const char *policyName, const char *propValue)
{
    const char *p = arrBody;
    while (p < arrEnd) {
        while (p < arrEnd && *p != '{') p++;
        if (p >= arrEnd) break;
        const char *objEnd = JsonSkipBalanced(p, arrEnd);
        if (!objEnd) break;

        /* BSS, not stack */
        static char ids[2048];
        static char idBuf[CAP_OBJECTID];

        if (CollectStringArrayInto(p, objEnd, "\"Users\"", ids, sizeof(ids))) {
            char *cur = ids;
            while (*cur) {
                char *comma = MSVCRT$strstr(cur, ",");
                int len = comma ? (int)(comma - cur) : (int)MSVCRT$strlen(cur);
                if (len > 0 && len < CAP_OBJECTID) {
                    MSVCRT$strncpy(idBuf, cur, (size_t)len);
                    idBuf[len] = '\0';
                    AddEntity(idBuf, ENTITY_USER, policyName, propValue);
                }
                if (!comma) break;
                cur = comma + 1;
            }
        }

        if (CollectStringArrayInto(p, objEnd, "\"Groups\"", ids, sizeof(ids))) {
            char *cur = ids;
            while (*cur) {
                char *comma = MSVCRT$strstr(cur, ",");
                int len = comma ? (int)(comma - cur) : (int)MSVCRT$strlen(cur);
                if (len > 0 && len < CAP_OBJECTID) {
                    MSVCRT$strncpy(idBuf, cur, (size_t)len);
                    idBuf[len] = '\0';
                    AddEntity(idBuf, ENTITY_GROUP, policyName, propValue);
                }
                if (!comma) break;
                cur = comma + 1;
            }
        }

        p = objEnd;
    }
}

/* ================================================================
 * BuildPropValue
 * ================================================================ */
static void BuildPropValue(const char *detail, const char *detailEnd,
                            char *out, int outSize)
{
    /* BSS, not stack — BOF threads have a small stack. */
    static char apps[CAP_APPIDS];
    static char platforms[CAP_PLATFORM];
    static char locations[CAP_PLATFORM];
    static char suffix[CAP_PROPVAL];

    out[0]       = '\0';
    apps[0]      = '\0';
    platforms[0] = '\0';
    locations[0] = '\0';
    suffix[0]    = '\0';

    /* --- Applications Include --- */
    const char *appsKey = JsonFindKey(detail, detailEnd, "\"Applications\"");
    if (appsKey) {
        const char *colon = JsonFindKey(appsKey, detailEnd, ":");
        if (colon) {
            colon++;
            while (colon < detailEnd && (*colon == ' ' || *colon == '\t' ||
                   *colon == '\n' || *colon == '\r')) colon++;
            if (colon < detailEnd && *colon == '{') {
                const char *appsObjEnd = JsonSkipBalanced(colon, detailEnd);
                if (appsObjEnd) {
                    const char *incKey = JsonFindKey(colon, appsObjEnd, "\"Include\"");
                    if (incKey) {
                        const char *ic = JsonFindKey(incKey, appsObjEnd, ":");
                        if (ic) {
                            ic++;
                            while (ic < appsObjEnd && (*ic == ' ' || *ic == '\t' ||
                                   *ic == '\n' || *ic == '\r')) ic++;
                            if (ic < appsObjEnd && *ic == '[') {
                                const char *incArrEnd = JsonSkipBalanced(ic, appsObjEnd);
                                if (incArrEnd) {
                                    const char *p2 = ic + 1;
                                    while (p2 < incArrEnd - 1 && *p2 != '{') p2++;
                                    if (p2 < incArrEnd - 1) {
                                        const char *subEnd = JsonSkipBalanced(p2, incArrEnd);
                                        if (subEnd)
                                            CollectStringArrayInto(p2, subEnd, "\"Applications\"",
                                                                   apps, sizeof(apps));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (MSVCRT$strlen(apps) == 0 || MSVCRT$strcmp(apps, "All") == 0 ||
        MSVCRT$strcmp(apps, "None") == 0)
        MSVCRT$strcpy(apps, "All Apps");

    MSVCRT$strncpy(out, apps, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';

    /* --- Platforms (optional) --- */
    const char *platKey = JsonFindKey(detail, detailEnd, "\"Platforms\"");
    if (platKey) {
        const char *pc = JsonFindKey(platKey, detailEnd, ":");
        if (pc) {
            pc++;
            while (pc < detailEnd && (*pc == ' ' || *pc == '\t' ||
                   *pc == '\n' || *pc == '\r')) pc++;
            if (pc < detailEnd && *pc == '{') {
                const char *platObjEnd = JsonSkipBalanced(pc, detailEnd);
                if (platObjEnd)
                    CollectStringArrayInto(pc, platObjEnd, "\"Include\"",
                                          platforms, sizeof(platforms));
            }
        }
    }

    /* --- Locations (optional) --- */
    const char *locKey = JsonFindKey(detail, detailEnd, "\"Locations\"");
    if (locKey) {
        const char *lc = JsonFindKey(locKey, detailEnd, ":");
        if (lc) {
            lc++;
            while (lc < detailEnd && (*lc == ' ' || *lc == '\t' ||
                   *lc == '\n' || *lc == '\r')) lc++;
            if (lc < detailEnd && *lc == '{') {
                const char *locObjEnd = JsonSkipBalanced(lc, detailEnd);
                if (locObjEnd)
                    CollectStringArrayInto(lc, locObjEnd, "\"Include\"",
                                          locations, sizeof(locations));
            }
        }
    }

    /* --- SignInRiskLevels / UserRiskLevels (optional) --- */
    static char signInRisk[CAP_PLATFORM];
    static char userRisk[CAP_PLATFORM];
    static char clientTypes[CAP_PLATFORM];
    signInRisk[0]  = '\0';
    userRisk[0]    = '\0';
    clientTypes[0] = '\0';

    CollectStringArrayInto(detail, detailEnd, "\"SignInRiskLevels\"",
                           signInRisk, sizeof(signInRisk));
    CollectStringArrayInto(detail, detailEnd, "\"UserRiskLevels\"",
                           userRisk, sizeof(userRisk));
    CollectStringArrayInto(detail, detailEnd, "\"ClientAppTypes\"",
                           clientTypes, sizeof(clientTypes));

    /* Build conditions suffix from all non-empty condition fields */
    suffix[0] = '\0';
    int hasCond = 0;
    if (MSVCRT$strlen(platforms) > 0 || MSVCRT$strlen(locations) > 0 ||
        MSVCRT$strlen(signInRisk) > 0 || MSVCRT$strlen(userRisk) > 0 ||
        MSVCRT$strlen(clientTypes) > 0) {
        MSVCRT$strcpy(suffix, " (for ");
        if (MSVCRT$strlen(platforms) > 0) {
            MSVCRT$strcat(suffix, hasCond ? ", platform: " : "platform: ");
            MSVCRT$strcat(suffix, platforms);
            hasCond = 1;
        }
        if (MSVCRT$strlen(locations) > 0) {
            MSVCRT$strcat(suffix, hasCond ? ", location: " : "location: ");
            MSVCRT$strcat(suffix, locations);
            hasCond = 1;
        }
        if (MSVCRT$strlen(signInRisk) > 0) {
            MSVCRT$strcat(suffix, hasCond ? ", sign-in risk: " : "sign-in risk: ");
            MSVCRT$strcat(suffix, signInRisk);
            hasCond = 1;
        }
        if (MSVCRT$strlen(userRisk) > 0) {
            MSVCRT$strcat(suffix, hasCond ? ", user risk: " : "user risk: ");
            MSVCRT$strcat(suffix, userRisk);
            hasCond = 1;
        }
        if (MSVCRT$strlen(clientTypes) > 0) {
            MSVCRT$strcat(suffix, hasCond ? ", client: " : "client: ");
            MSVCRT$strcat(suffix, clientTypes);
            hasCond = 1;
        }
        MSVCRT$strcat(suffix, ")");
    }

    if (suffix[0]) {
        int curLen = (int)MSVCRT$strlen(out);
        int room   = outSize - curLen - 1;
        int sLen   = (int)MSVCRT$strlen(suffix);
        if (room > 0) {
            MSVCRT$strncpy(out + curLen, suffix, (size_t)(room < sLen ? room : sLen));
            out[curLen + (room < sLen ? room : sLen)] = '\0';
        }
    }
}

/* ================================================================
 * IsIdInList — check if id appears in a comma-separated list
 * ================================================================ */
static int IsIdInList(const char *id, const char *commaList)
{
    if (!id || !commaList || !*commaList) return 0;
    int idLen = (int)MSVCRT$strlen(id);
    const char *p = commaList;
    while (*p) {
        if (MSVCRT$strncmp(p, id, (size_t)idLen) == 0 &&
            (p[idLen] == ',' || p[idLen] == '\0'))
            return 1;
        const char *next = MSVCRT$strstr(p, ",");
        if (!next) break;
        p = next + 1;
    }
    return 0;
}

/* ================================================================
 * CollectExcludedUserIds — gather Users.Exclude IDs into a
 * comma-separated buffer for fast lookup with IsIdInList().
 * ================================================================ */
static void CollectExcludedUserIds(const char *usersObj,
                                   const char *usersObjEnd,
                                   char *out, int outSize)
{
    out[0] = '\0';
    const char *exK = JsonFindKey(usersObj, usersObjEnd, "\"Exclude\"");
    if (!exK) return;
    const char *ec = JsonFindKey(exK, usersObjEnd, ":");
    if (!ec) return;
    ec++;
    while (ec < usersObjEnd && (*ec == ' ' || *ec == '\t' ||
           *ec == '\n' || *ec == '\r')) ec++;
    if (ec >= usersObjEnd || *ec != '[') return;
    const char *eae = JsonSkipBalanced(ec, usersObjEnd);
    if (!eae) return;

    const char *ep = ec + 1;
    while (ep < eae - 1) {
        while (ep < eae - 1 && *ep != '{') ep++;
        if (ep >= eae - 1) break;
        const char *eoe = JsonSkipBalanced(ep, eae);
        if (!eoe) break;

        static char tmpIds[2048];
        tmpIds[0] = '\0';
        CollectStringArrayInto(ep, eoe, "\"Users\"", tmpIds, sizeof(tmpIds));
        if (tmpIds[0]) {
            int curLen = (int)MSVCRT$strlen(out);
            if (curLen > 0 && curLen + 1 < outSize) {
                out[curLen] = ',';
                out[curLen + 1] = '\0';
                curLen++;
            }
            int tl  = (int)MSVCRT$strlen(tmpIds);
            int room = outSize - curLen - 1;
            if (room > 0) {
                int cp = tl < room ? tl : room;
                MSVCRT$memcpy(out + curLen, tmpIds, (size_t)cp);
                out[curLen + cp] = '\0';
            }
        }
        ep = eoe;
    }
}

/* ================================================================
 * FetchAllUserIds — enumerate tenant users via legacy AAD Graph.  Names are
 * collected in the same request so Conditional Access OpenGraph updates can
 * merge cleanly with native AZUser nodes and remain readable on their own.
 * ================================================================ */
static void FetchAllUserIds(const char *tenantId, LPCWSTR hdrWide)
{
    static char pathBuf[2048];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/users?api-version=1.61-internal&$select=objectId,displayName,userPrincipalName&$top=999",
        tenantId);

    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) return;

    LPCWSTR pathArg = widePath;
    LPWSTR nextWide = NULL;
    int pageNum = 0;

    while (1) {
        pageNum++;
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.windows.net", pathArg,
                                  hdrWide, NULL, 0, &status);
        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] User fetch page %d failed (HTTP %lu)\n",
                pageNum, status);
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] User fetch HTTP %lu: %.200s\n", status, resp);
            HFree(resp);
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;

        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (!vKey) { HFree(resp); break; }

        const char *bracket = JsonFindKey(vKey, end, ":");
        if (!bracket) { HFree(resp); break; }
        bracket++;
        while (bracket < end && (*bracket == ' ' || *bracket == '\t' ||
               *bracket == '\n' || *bracket == '\r')) bracket++;
        if (bracket >= end || *bracket != '[') { HFree(resp); break; }

        const char *arrEnd = JsonSkipBalanced(bracket, end);
        if (!arrEnd) { HFree(resp); break; }

        const char *p = bracket + 1;
        int pageUsers = 0;
        while (p < arrEnd - 1) {
            while (p < arrEnd - 1 && *p != '{') p++;
            if (p >= arrEnd - 1) break;
            const char *objEnd = JsonSkipBalanced(p, arrEnd);
            if (!objEnd) break;

            char *oid = JsonExtractStringValueUtf8(p, objEnd, "\"objectId\"");
            if (oid) {
                if (g_allUserCount < CAP_MAX_USERS) {
                    char *displayName = JsonExtractStringValueUtf8(
                        p, objEnd, "\"displayName\"");
                    char *userPrincipalName = JsonExtractStringValueUtf8(
                        p, objEnd, "\"userPrincipalName\"");
                    char *slot = g_allUserIds +
                                 (g_allUserCount * CAP_USERID_LEN);
                    MSVCRT$strncpy(slot, oid, CAP_USERID_LEN - 1);
                    slot[CAP_USERID_LEN - 1] = '\0';
                    if (g_allUserDisplayNames) {
                        slot = g_allUserDisplayNames +
                               (g_allUserCount * CAP_USER_DISPLAY_LEN);
                        MSVCRT$strncpy(slot, SAFE_STR(displayName),
                            CAP_USER_DISPLAY_LEN - 1);
                        slot[CAP_USER_DISPLAY_LEN - 1] = '\0';
                    }
                    if (g_allUserPrincipalNames) {
                        slot = g_allUserPrincipalNames +
                               (g_allUserCount * CAP_USER_UPN_LEN);
                        MSVCRT$strncpy(slot, SAFE_STR(userPrincipalName),
                            CAP_USER_UPN_LEN - 1);
                        slot[CAP_USER_UPN_LEN - 1] = '\0';
                    }
                    g_allUserCount++;
                    pageUsers++;
                    if (displayName) HFree(displayName);
                    if (userPrincipalName) HFree(userPrincipalName);
                }
                HFree(oid);
            }

            p = objEnd;
        }

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] User fetch page %d: %d users (total %d)\n",
            pageNum, pageUsers, g_allUserCount);

        char *nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);

        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!nextUrl) break;

        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
        else if (MSVCRT$strncmp(np, "https://", 8) == 0) np += 8;
        char *slash = MSVCRT$strstr(np, "/");
        nextWide = MbsToWcs(slash ? slash : nextUrl);
        HFree(nextUrl);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    if (widePath) HFree(widePath);
    if (nextWide) HFree(nextWide);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Fetched %d user IDs for scope expansion\n", g_allUserCount);
}

/* ================================================================
 * ProcessPolicy
 * ================================================================ */
static void ProcessPolicy(const char *item, const char *itemEnd)
{
    int ptype = ExtractJsonIntValue(item, itemEnd, "\"policyType\"", -1);
    if (ptype != 18) return;

    /* BSS, not stack — BOF threads have a small stack. */
    static char displayName[CAP_DISPLAYNAME];
    static char stateVal[32];
    static char controlTypes[256];
    static char propValue[CAP_PROPVAL];

    displayName[0]  = '\0';
    stateVal[0]     = '\0';
    controlTypes[0] = '\0';
    propValue[0]    = '\0';

    char *dn = JsonExtractStringValueUtf8(item, itemEnd, "\"displayName\"");
    if (dn) {
        MSVCRT$strncpy(displayName, dn, CAP_DISPLAYNAME - 1);
        displayName[CAP_DISPLAYNAME - 1] = '\0';
        HFree(dn);
    }
    if (displayName[0] == '\0')
        MSVCRT$strcpy(displayName, "UnnamedPolicy");

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*]   Found CA policy (policyType=18): %s\n", displayName);

    /* Extract policyDetail: array of escaped-JSON strings */
    const char *pdKey = JsonFindKey(item, itemEnd, "\"policyDetail\"");
    if (!pdKey) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     No policyDetail key found, skipping\n");
        return;
    }
    const char *pdColon = JsonFindKey(pdKey, itemEnd, ":");
    if (!pdColon) return;
    pdColon++;
    while (pdColon < itemEnd && (*pdColon == ' ' || *pdColon == '\t' ||
           *pdColon == '\n' || *pdColon == '\r')) pdColon++;
    if (pdColon >= itemEnd || *pdColon != '[') {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     policyDetail is not an array, skipping\n");
        return;
    }

    const char *pdArrEnd = JsonSkipBalanced(pdColon, itemEnd);
    if (!pdArrEnd) return;

    const char *p = pdColon + 1;
    while (p < pdArrEnd - 1 && *p != '"') p++;
    if (p >= pdArrEnd - 1) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     policyDetail array has no string element, skipping\n");
        return;
    }

    const char *strEnd = JsonSkipString(p, pdArrEnd);
    if (!strEnd) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     Failed to parse policyDetail string, skipping\n");
        return;
    }

    int escapedLen = (int)((strEnd - 1) - (p + 1));
    if (escapedLen <= 0) return;

    char *detail = (char *)HAlloc((SIZE_T)(escapedLen * 2 + 8));
    if (!detail) return;

    int detailLen = UnescapeJsonString(p + 1, escapedLen, detail, escapedLen * 2 + 8);
    if (detailLen <= 0) { HFree(detail); return; }

    const char *detailEnd = detail + detailLen;

    /* Check State */
    if (ExtractJsonStr(detail, "State", stateVal, sizeof(stateVal))) {
        if (MSVCRT$strcmp(stateVal, "Enabled") != 0) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*]     State=%s (not Enabled), skipping\n", stateVal);
            HFree(detail);
            return;
        }
    }

    /* Determine control type */
    const char *ctrlKey = JsonFindKey(detail, detailEnd, "\"Controls\"");
    if (ctrlKey) {
        const char *cc = JsonFindKey(ctrlKey, detailEnd, ":");
        if (cc) {
            cc++;
            while (cc < detailEnd && (*cc == ' ' || *cc == '\t' ||
                   *cc == '\n' || *cc == '\r')) cc++;
            if (cc < detailEnd && *cc == '[') {
                const char *ctrlArrEnd = JsonSkipBalanced(cc, detailEnd);
                if (ctrlArrEnd) {
                    const char *cp = cc + 1;
                    while (cp < ctrlArrEnd - 1) {
                        while (cp < ctrlArrEnd - 1 && *cp != '{') cp++;
                        if (cp >= ctrlArrEnd - 1) break;
                        const char *ceEnd = JsonSkipBalanced(cp, ctrlArrEnd);
                        if (!ceEnd) break;
                        static char ctrlVals[128];
                        ctrlVals[0] = '\0';
                        CollectStringArrayInto(cp, ceEnd, "\"Control\"",
                                              ctrlVals, sizeof(ctrlVals));

                        /* AuthStrengthIds-based MFA controls:
                         * "AuthStrengthIds":["00000000-..."] (plural, array) or
                         * "AuthStrengthId":"00000000-..."   (singular, string) */
                        if (!ctrlVals[0]) {
                            static char asids[256];
                            asids[0] = '\0';
                            CollectStringArrayInto(cp, ceEnd, "\"AuthStrengthIds\"",
                                                   asids, sizeof(asids));
                            if (!asids[0]) {
                                char *asid = JsonExtractStringValueUtf8(cp, ceEnd, "\"AuthStrengthId\"");
                                if (asid) {
                                    MSVCRT$strncpy(asids, asid, sizeof(asids) - 1);
                                    asids[sizeof(asids) - 1] = '\0';
                                    HFree(asid);
                                }
                            }
                            if (MSVCRT$strstr(asids, "00000000-0000-0000-0000-000000000002") ||
                                MSVCRT$strstr(asids, "00000000-0000-0000-0000-000000000003") ||
                                MSVCRT$strstr(asids, "00000000-0000-0000-0000-000000000004")) {
                                MSVCRT$strcpy(ctrlVals, "Mfa");
                            }
                        }

                        if (ctrlVals[0]) {
                            if (controlTypes[0]) {
                                int l = (int)MSVCRT$strlen(controlTypes);
                                if (l + 2 < (int)sizeof(controlTypes)) {
                                    controlTypes[l] = ',';
                                    MSVCRT$strncpy(controlTypes + l + 1, ctrlVals,
                                        sizeof(controlTypes) - l - 2);
                                }
                            } else {
                                MSVCRT$strncpy(controlTypes, ctrlVals,
                                               sizeof(controlTypes) - 1);
                            }
                        }
                        cp = ceEnd;
                    }
                }
            }
        }
    }

    int hasMfa   = MSVCRT$strstr(controlTypes, "Mfa")   != NULL;
    int hasBlock = MSVCRT$strstr(controlTypes, "Block") != NULL;
    if (!hasMfa && !hasBlock) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*]     Controls=[%s] (no Mfa/Block), skipping\n", controlTypes);
        HFree(detail);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*]     Controls=[%s], State=Enabled — scanning exclusions\n", controlTypes);

    /* Build the condition description (apps, platforms, risk, clients) */
    BuildPropValue(detail, detailEnd, propValue, sizeof(propValue));

    /* Navigate to Conditions object (shared by user-excl and app-excl paths) */
    const char *condKey = JsonFindKey(detail, detailEnd, "\"Conditions\"");
    if (!condKey) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     No Conditions block\n");
        HFree(detail);
        return;
    }
    const char *condColon = JsonFindKey(condKey, detailEnd, ":");
    if (!condColon) { HFree(detail); return; }
    condColon++;
    while (condColon < detailEnd && (*condColon == ' ' || *condColon == '\t' ||
           *condColon == '\n' || *condColon == '\r')) condColon++;
    if (condColon >= detailEnd || *condColon != '{') { HFree(detail); return; }
    const char *condEnd = JsonSkipBalanced(condColon, detailEnd);
    if (!condEnd) { HFree(detail); return; }

    /* Locate Users object */
    const char *usersObj    = NULL;
    const char *usersObjEnd = NULL;
    {
        const char *uk = JsonFindKey(condColon, condEnd, "\"Users\"");
        if (uk) {
            const char *uc = JsonFindKey(uk, condEnd, ":");
            if (uc) {
                uc++;
                while (uc < condEnd && (*uc == ' ' || *uc == '\t' ||
                       *uc == '\n' || *uc == '\r')) uc++;
                if (uc < condEnd && *uc == '{') {
                    const char *ue = JsonSkipBalanced(uc, condEnd);
                    if (ue) { usersObj = uc; usersObjEnd = ue; }
                }
            }
        }
    }
    if (!usersObj) {
        BeaconPrintf(CALLBACK_OUTPUT, "[!]     No Users block in Conditions\n");
        HFree(detail);
        return;
    }

    int beforeCount = g_entityCount;

    /* ---- Path A: users excluded from the policy ----
     * These users bypass MFA/Block entirely for everything the policy
     * covers. Prefix propValue to make the bypass clear. */
    {
        const char *exclKey = JsonFindKey(usersObj, usersObjEnd, "\"Exclude\"");
        if (exclKey) {
            const char *ec = JsonFindKey(exclKey, usersObjEnd, ":");
            if (ec) {
                ec++;
                while (ec < usersObjEnd && (*ec == ' ' || *ec == '\t' ||
                       *ec == '\n' || *ec == '\r')) ec++;
                if (ec < usersObjEnd && *ec == '[') {
                    const char *eae = JsonSkipBalanced(ec, usersObjEnd);
                    if (eae) {
                        static char userExclVal[CAP_PROPVAL];
                        MSVCRT$sprintf_s(userExclVal, sizeof(userExclVal),
                            "Excluded from MFA for %s", propValue);
                        ProcessExcludeArray(ec + 1, eae - 1,
                                            displayName, userExclVal);
                    }
                }
            }
        }
    }

    /* ---- Path B: condition exclusions ----
     * Collect all Exclude blocks (apps, platforms, locations) from the
     * policy's Conditions.  Included users don't need MFA under these
     * excluded conditions. */
    {
        static char exclApps[CAP_APPIDS];
        static char exclPlat[CAP_PLATFORM];
        static char exclLoc[CAP_PLATFORM];
        exclApps[0] = '\0';
        exclPlat[0] = '\0';
        exclLoc[0]  = '\0';

        /* Helper macro: find "outerKey" object inside [condColon,condEnd),
         * then collect "Exclude" → first sub-object → "innerKey" array. */
        #define COLLECT_EXCL(outerKey, innerKey, dst, dstSz) do {          \
            const char *_ok = JsonFindKey(condColon, condEnd, outerKey);    \
            if (_ok) {                                                     \
                const char *_oc = JsonFindKey(_ok, condEnd, ":");          \
                if (_oc) { _oc++;                                          \
                    while (_oc < condEnd && (*_oc==' '||*_oc=='\t'||       \
                           *_oc=='\n'||*_oc=='\r')) _oc++;                 \
                    if (_oc < condEnd && *_oc == '{') {                    \
                        const char *_oe = JsonSkipBalanced(_oc, condEnd);  \
                        if (_oe) {                                         \
                            const char *_ek = JsonFindKey(_oc, _oe,        \
                                                         "\"Exclude\"");   \
                            if (_ek) {                                     \
                                const char *_ec = JsonFindKey(_ek,_oe,":");\
                                if (_ec) { _ec++;                          \
                                    while (_ec<_oe&&(*_ec==' '||*_ec=='\t'\
                                      ||*_ec=='\n'||*_ec=='\r')) _ec++;    \
                                    if (_ec<_oe && *_ec=='[') {            \
                                        const char *_ea =                  \
                                            JsonSkipBalanced(_ec, _oe);    \
                                        if (_ea) {                         \
                                            const char *_p2 = _ec + 1;    \
                                            while (_p2<_ea-1&&*_p2!='{')   \
                                                _p2++;                     \
                                            if (_p2 < _ea - 1) {          \
                                                const char *_se =          \
                                                  JsonSkipBalanced(_p2,_ea);\
                                                if (_se)                   \
                                                  CollectStringArrayInto(  \
                                                    _p2, _se, innerKey,    \
                                                    dst, dstSz);           \
                                            }                              \
                                        }                                  \
                                    }                                      \
                                }                                          \
                            }                                              \
                        }                                                  \
                    }                                                      \
                }                                                          \
            }                                                              \
        } while(0)

        COLLECT_EXCL("\"Applications\"",    "\"Applications\"",    exclApps, sizeof(exclApps));
        COLLECT_EXCL("\"DevicePlatforms\"", "\"DevicePlatforms\"", exclPlat, sizeof(exclPlat));
        COLLECT_EXCL("\"Locations\"",       "\"Locations\"",       exclLoc,  sizeof(exclLoc));

        #undef COLLECT_EXCL

        /* Devices.Exclude uses "DeviceRule" (string), not an array.
         * Structure: "Devices":{"Exclude":[{"DeviceRule":"..."}]}  */
        static char exclDev[CAP_PLATFORM];
        exclDev[0] = '\0';
        {
            const char *devKey = JsonFindKey(condColon, condEnd, "\"Devices\"");
            if (devKey) {
                const char *dc = JsonFindKey(devKey, condEnd, ":");
                if (dc) {
                    dc++;
                    while (dc < condEnd && (*dc==' '||*dc=='\t'||
                           *dc=='\n'||*dc=='\r')) dc++;
                    if (dc < condEnd && *dc == '{') {
                        const char *de = JsonSkipBalanced(dc, condEnd);
                        if (de) {
                            const char *ek = JsonFindKey(dc, de, "\"Exclude\"");
                            if (ek) {
                                const char *ec2 = JsonFindKey(ek, de, ":");
                                if (ec2) {
                                    ec2++;
                                    while (ec2<de&&(*ec2==' '||*ec2=='\t'||
                                           *ec2=='\n'||*ec2=='\r')) ec2++;
                                    if (ec2 < de && *ec2 == '[') {
                                        const char *ea2 = JsonSkipBalanced(ec2, de);
                                        if (ea2) {
                                            const char *dp = ec2 + 1;
                                            while (dp < ea2 - 1) {
                                                while (dp < ea2-1 && *dp != '{') dp++;
                                                if (dp >= ea2 - 1) break;
                                                const char *doe = JsonSkipBalanced(dp, ea2);
                                                if (!doe) break;
                                                char *dr = JsonExtractStringValueUtf8(dp, doe, "\"DeviceRule\"");
                                                if (dr) {
                                                    if (exclDev[0]) MSVCRT$strcat(exclDev, ", ");
                                                    MSVCRT$strcat(exclDev, dr);
                                                    HFree(dr);
                                                }
                                                dp = doe;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        /* Build a combined exclusion value if any exclusion exists */
        int hasAnyExcl = (MSVCRT$strlen(exclApps) > 0 ||
                          MSVCRT$strlen(exclPlat) > 0 ||
                          MSVCRT$strlen(exclLoc)  > 0 ||
                          MSVCRT$strlen(exclDev)  > 0);

        if (hasAnyExcl) {
            static char condExclVal[CAP_PROPVAL];
            condExclVal[0] = '\0';

            /* Extract apps portion from propValue (before " (for " suffix) */
            static char appsOnly[CAP_APPIDS];
            MSVCRT$strncpy(appsOnly, propValue, sizeof(appsOnly) - 1);
            appsOnly[sizeof(appsOnly) - 1] = '\0';
            {
                char *fs = MSVCRT$strstr(appsOnly, " (for ");
                if (fs) *fs = '\0';
            }

            /* Format: "[apps] ([controls]): no enforcement (excl [conditions])" */
            MSVCRT$sprintf_s(condExclVal, sizeof(condExclVal),
                "%s (%s): no enforcement (excl", appsOnly, controlTypes);
            int parts = 0;

            if (MSVCRT$strlen(exclApps) > 0) {
                MSVCRT$strcat(condExclVal, parts ? "; app: " : " app: ");
                MSVCRT$strcat(condExclVal, exclApps);
                parts++;
            }
            if (MSVCRT$strlen(exclPlat) > 0) {
                MSVCRT$strcat(condExclVal, parts ? "; platform: " : " platform: ");
                MSVCRT$strcat(condExclVal, exclPlat);
                parts++;
            }
            if (MSVCRT$strlen(exclLoc) > 0) {
                MSVCRT$strcat(condExclVal, parts ? "; location: " : " location: ");
                MSVCRT$strcat(condExclVal, exclLoc);
                parts++;
            }
            if (MSVCRT$strlen(exclDev) > 0) {
                MSVCRT$strcat(condExclVal, parts ? "; device: " : " device: ");
                MSVCRT$strcat(condExclVal, exclDev);
                parts++;
            }
            MSVCRT$strcat(condExclVal, ")");

            /* Emit for each included user/group */
            const char *incKey = JsonFindKey(usersObj, usersObjEnd, "\"Include\"");
            if (incKey) {
                const char *ic = JsonFindKey(incKey, usersObjEnd, ":");
                if (ic) {
                    ic++;
                    while (ic < usersObjEnd && (*ic == ' ' || *ic == '\t' ||
                           *ic == '\n' || *ic == '\r')) ic++;
                    if (ic < usersObjEnd && *ic == '[') {
                        const char *incArrEnd = JsonSkipBalanced(ic, usersObjEnd);
                        if (incArrEnd) {
                            const char *ip = ic + 1;
                            while (ip < incArrEnd - 1) {
                                while (ip < incArrEnd - 1 && *ip != '{') ip++;
                                if (ip >= incArrEnd - 1) break;
                                const char *ie = JsonSkipBalanced(ip, incArrEnd);
                                if (!ie) break;

                                static char incIds[2048];
                                static char idBuf[CAP_OBJECTID];

                                incIds[0] = '\0';
                                CollectStringArrayInto(ip, ie, "\"Users\"",
                                    incIds, sizeof(incIds));
                                if (MSVCRT$strlen(incIds) > 0) {
                                    if (MSVCRT$strcmp(incIds, "All") == 0 &&
                                        g_allUserIds && g_allUserCount > 0) {
                                        /* Expand "All" to individual users,
                                         * skipping those in Users.Exclude */
                                        static char exclBuf[8192];
                                        exclBuf[0] = '\0';
                                        CollectExcludedUserIds(usersObj,
                                            usersObjEnd, exclBuf,
                                            sizeof(exclBuf));
                                        int k;
                                        for (k = 0; k < g_allUserCount; k++) {
                                            char *uid = g_allUserIds +
                                                        (k * CAP_USERID_LEN);
                                            if (!IsIdInList(uid, exclBuf))
                                                AddEntity(uid, ENTITY_USER,
                                                    displayName, condExclVal);
                                        }
                                    } else {
                                        char *cur = incIds;
                                        while (*cur) {
                                            char *comma = MSVCRT$strstr(cur, ",");
                                            int len = comma ? (int)(comma - cur)
                                                            : (int)MSVCRT$strlen(cur);
                                            if (len > 0 && len < CAP_OBJECTID) {
                                                MSVCRT$strncpy(idBuf, cur, (size_t)len);
                                                idBuf[len] = '\0';
                                                AddEntity(idBuf, ENTITY_USER,
                                                          displayName, condExclVal);
                                            }
                                            if (!comma) break;
                                            cur = comma + 1;
                                        }
                                    }
                                }

                                incIds[0] = '\0';
                                CollectStringArrayInto(ip, ie, "\"Groups\"",
                                    incIds, sizeof(incIds));
                                if (MSVCRT$strlen(incIds) > 0) {
                                    char *cur = incIds;
                                    while (*cur) {
                                        char *comma = MSVCRT$strstr(cur, ",");
                                        int len = comma ? (int)(comma - cur) : (int)MSVCRT$strlen(cur);
                                        if (len > 0 && len < CAP_OBJECTID) {
                                            MSVCRT$strncpy(idBuf, cur, (size_t)len);
                                            idBuf[len] = '\0';
                                            AddEntity(idBuf, ENTITY_GROUP,
                                                      displayName, condExclVal);
                                        }
                                        if (!comma) break;
                                        cur = comma + 1;
                                    }
                                }

                                ip = ie;
                            }
                        }
                    }
                }
            }
        }
    }

    int added = g_entityCount - beforeCount;
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+]     Extracted %d entit%s\n",
        added, added == 1 ? "y" : "ies");

    HFree(detail);
}

/* ================================================================
 * EscapeJsonString
 * ================================================================ */
static void EscapeJsonString(const char *src, char *dst, int dstSize)
{
    int si = 0, di = 0;
    static const char hex[] = "0123456789abcdef";
    while (src[si] && di < dstSize - 1) {
        unsigned char c = (unsigned char)src[si++];
        char shortEscape = '\0';

        if      (c == '"')  shortEscape = '"';
        else if (c == '\\') shortEscape = '\\';
        else if (c == '\b') shortEscape = 'b';
        else if (c == '\f') shortEscape = 'f';
        else if (c == '\n') shortEscape = 'n';
        else if (c == '\r') shortEscape = 'r';
        else if (c == '\t') shortEscape = 't';

        if (shortEscape) {
            if (di + 2 >= dstSize) break;
            dst[di++] = '\\';
            dst[di++] = shortEscape;
        } else if (c < 0x20) {
            if (di + 6 >= dstSize) break;
            dst[di++] = '\\';
            dst[di++] = 'u';
            dst[di++] = '0';
            dst[di++] = '0';
            dst[di++] = hex[(c >> 4) & 0x0f];
            dst[di++] = hex[c & 0x0f];
        } else {
            dst[di++] = (char)c;
        }
    }
    dst[di] = '\0';
}

/* ================================================================
 * WriteOutputFile
 *
 * Merges entities that share the same objectId into a single node.
 * Policy findings are stored in the native principal cap_policies array.
 * Value format:
 *   User exclusion  -> "PolicyName: Excluded from MFA for All Apps (...)"
 *   Condition excl  -> "PolicyName: no MFA for app: X; platform: Y"
 * ================================================================ */
static void WriteOutputFile(void)
{
    BarkBuf b = { NULL, 0, 0, 1 };
    /* BSS, not stack */
    static char escId[CAP_OBJECTID * 2];
    static char escKind[32];
    static char escVal[CAP_PROPVAL * 2];
    static char frag[4096];

    /* Track which entities have already been emitted (by index). */
    char *emitted = (char *)HAlloc((SIZE_T)g_entityCount);
    if (!emitted) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] ConditionalAccessPolicies: out of memory for output tracking\n");
        BarkBufFree(&b);
        return;
    }
    MSVCRT$memset(emitted, 0, (size_t)g_entityCount);

    #define NODES_OPEN "{\"graph\":{\"nodes\":["
    BarkBufAppend(&b, NODES_OPEN, (SIZE_T)(sizeof(NODES_OPEN) - 1));

    int nodeIdx = 0;
    int staleUserIds = 0;
    int i, j;
    for (i = 0; i < g_entityCount; i++) {
        if (emitted[i]) continue;
        emitted[i] = 1;
        ExcludedEntity *e = &g_entities[i];
        int userIndex = e->kind == ENTITY_USER
            ? FindAllUserIndex(e->objectId) : -1;

        /* A complete user enumeration makes stale CA references
         * distinguishable from live users. Deleted users cannot sign in and
         * have no name to resolve, so do not create permanent ID-only nodes
         * for them. If enumeration failed, retain the old best-effort output. */
        if (e->kind == ENTITY_USER && g_allUserCount > 0 && userIndex < 0) {
            for (j = i + 1; j < g_entityCount; j++) {
                if (!emitted[j] &&
                    AsciiEqualsIgnoreCase(g_entities[j].objectId,
                                          e->objectId))
                    emitted[j] = 1;
            }
            staleUserIds++;
            continue;
        }

        EscapeJsonString(e->objectId, escId, sizeof(escId));
        EscapeJsonString(e->kind == ENTITY_USER ? "AZUser" : "AZGroup",
                         escKind, sizeof(escKind));

        /* CAP-only property update. Import after the full native snapshot.
         * No name/displayname/source_kind or custom native labels are emitted. */
        int n = MSVCRT$sprintf_s(frag, sizeof(frag),
            "%s{\"id\":\"", (nodeIdx > 0) ? "," : "");
        if (n > 0) BarkBufAppend(&b, frag, (SIZE_T)n);
        BarkBufAppendAsciiUpper(&b, escId, MSVCRT$strlen(escId));
        n = MSVCRT$sprintf_s(frag, sizeof(frag),
            "\",\"kinds\":[\"%s\"],\"properties\":{\"cap_policies\":[", escKind);
        if (n > 0) BarkBufAppend(&b, frag, (SIZE_T)n);

        /* One string per finding; replace the array on subsequent imports. */
        static char rawVal[CAP_PROPVAL];
        MSVCRT$sprintf_s(rawVal, sizeof(rawVal), "%s: %s",
                         e->policyName, e->propValue);
        EscapeJsonString(rawVal, escVal, sizeof(escVal));
        n = MSVCRT$sprintf_s(frag, sizeof(frag), "\"%s\"", escVal);
        if (n > 0) BarkBufAppend(&b, frag, (SIZE_T)n);

        for (j = i + 1; j < g_entityCount; j++) {
            if (emitted[j]) continue;
            if (!AsciiEqualsIgnoreCase(g_entities[j].objectId, e->objectId)) continue;
            emitted[j] = 1;
            MSVCRT$sprintf_s(rawVal, sizeof(rawVal), "%s: %s",
                             g_entities[j].policyName, g_entities[j].propValue);
            EscapeJsonString(rawVal, escVal, sizeof(escVal));
            n = MSVCRT$sprintf_s(frag, sizeof(frag), ",\"%s\"", escVal);
            if (n > 0) BarkBufAppend(&b, frag, (SIZE_T)n);
        }
        BarkBufAppend(&b, "]}}", 3);
        nodeIdx++;
    }
    #define NODES_CLOSE "],\"edges\":[]}}"
    BarkBufAppend(&b, NODES_CLOSE, (SIZE_T)(sizeof(NODES_CLOSE) - 1));

    if (!b.ok || !b.buf) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] ConditionalAccessPolicies: out of memory building output\n");
        HFree(emitted);
        BarkBufFree(&b);
        return;
    }

    SYSTEMTIME st;
    KERNEL32$GetLocalTime(&st);
    static char filename[300];
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZConditionalAccessPolicy_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear,  (unsigned)st.wMonth,  (unsigned)st.wDay,
        (unsigned)st.wHour,  (unsigned)st.wMinute, (unsigned)st.wSecond);

    BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] BARK ConditionalAccessPolicy: %d node%s (%d total exclusion%s)"
        " across all enabled CA policies; %d stale user ID%s skipped\n",
        nodeIdx, nodeIdx == 1 ? "" : "s",
        g_entityCount, g_entityCount == 1 ? "" : "s",
        staleUserIds, staleUserIds == 1 ? "" : "s");

    HFree(emitted);
    BarkBufFree(&b);
}

/* ================================================================
 * go — BOF entry point
 * ================================================================ */
void go(char *args, int alen)
{
    datap  parser;
    char  *token    = NULL;
    char  *tenantId = NULL;
    char  *autoTid  = NULL;
    char  *resp     = NULL;
    char  *nextUrl  = NULL;
    LPWSTR hdrWide  = NULL;
    LPWSTR widePath = NULL;
    LPWSTR nextWide = NULL;
    /* BSS, not stack — BOF threads have a small stack. */
    static char pathBuf[2048];

    BeaconDataParse(&parser, args, alen);
    token    = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_conditional_access_policies <token> [tenantId]\n"
            "    token   : AAD Graph Bearer (scope: https://graph.windows.net/)\n"
            "    tenantId: optional; auto-extracted from JWT if omitted\n");
        return;
    }

    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Enumerating Conditional Access Policies (tenantId=%s)...\n", tenantId);

    /* Allocate entity list on the heap */
    g_entityCount = 0;
    g_entityCap   = CAP_MAX_ENTITIES;
    g_entities    = (ExcludedEntity *)HAlloc(
                        (SIZE_T)g_entityCap * sizeof(ExcludedEntity));
    if (!g_entities) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to allocate entity list\n");
        goto done;
    }

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/policies?api-version=1.61-internal", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
        goto done;
    }

    hdrWide = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Header conversion failed\n");
        goto done;
    }

    /* Fetch all user IDs for "All" scope expansion */
    g_allUserCount = 0;
    g_allUserIds = (char *)HAlloc((SIZE_T)CAP_MAX_USERS * CAP_USERID_LEN);
    g_allUserDisplayNames = (char *)HAlloc(
        (SIZE_T)CAP_MAX_USERS * CAP_USER_DISPLAY_LEN);
    g_allUserPrincipalNames = (char *)HAlloc(
        (SIZE_T)CAP_MAX_USERS * CAP_USER_UPN_LEN);
    if (g_allUserIds) {
        FetchAllUserIds(tenantId, hdrWide);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] Could not allocate user buffer;"
            " \"All\" scope will use literal ID\n");
    }

    /* Accumulate raw API responses for a separate output file */
    BarkBuf rawBuf = { NULL, 0, 0, 1 };

    LPCWSTR pathArg = widePath;
    int pageNum = 0;
    int totalPolicies = 0;

    while (1) {
        pageNum++;

        DWORD status = 0;
        resp = HttpRequestWithRetry(L"GET", L"graph.windows.net", pathArg,
                           hdrWide, NULL, 0, &status);

        if (!resp) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Request to graph.windows.net failed (HTTP %lu)\n", status);
            break;
        }
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] HTTP %lu from graph.windows.net:\n    %s\n", status, resp);
            HFree(resp);
            resp = NULL;
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Page %d: received %lu bytes (HTTP %lu)\n",
            pageNum, (unsigned long)respLen, (unsigned long)status);

        /* Accumulate raw response */
        if (rawBuf.ok) {
            if (pageNum > 1) BarkBufAppend(&rawBuf, "\n", 1);
            BarkBufAppend(&rawBuf, resp, respLen);
        }

        /* Locate the policy array. Try "value" first (standard OData),
         * then fall back to bare top-level array. */
        const char *arrStart = NULL;
        const char *arrEnd   = NULL;

        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *bracket = JsonFindKey(vKey, end, ":");
            if (bracket) {
                bracket++;
                while (bracket < end && (*bracket == ' ' || *bracket == '\t' ||
                       *bracket == '\n' || *bracket == '\r')) bracket++;
                if (bracket < end && *bracket == '[') {
                    arrEnd = JsonSkipBalanced(bracket, end);
                    if (arrEnd) arrStart = bracket + 1;
                }
            }
        }

        /* Fallback: response itself is a bare array */
        if (!arrStart) {
            const char *t = resp;
            while (t < end && (*t == ' ' || *t == '\t' || *t == '\n' || *t == '\r')) t++;
            if (t < end && *t == '[') {
                arrEnd = JsonSkipBalanced(t, end);
                if (arrEnd) arrStart = t + 1;
            }
        }

        if (!arrStart) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[!] No \"value\" array or top-level array found in response."
                " First 200 chars:\n    %.200s\n", resp);
            HFree(resp);
            resp = NULL;
            break;
        }

        /* Iterate policy objects in the array */
        const char *p = arrStart;
        int pagePolicies = 0;
        while (p < arrEnd - 1) {
            while (p < arrEnd - 1 && (*p == ' ' || *p == '\n' ||
                   *p == '\r' || *p == '\t' || *p == ',')) p++;
            if (p >= arrEnd - 1 || *p != '{') break;
            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
            if (!itemEnd) break;
            ProcessPolicy(p, itemEnd);
            pagePolicies++;
            p = itemEnd;
        }
        totalPolicies += pagePolicies;
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Page %d: processed %d polic%s\n",
            pageNum, pagePolicies, pagePolicies == 1 ? "y" : "ies");

        /* Pagination */
        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        resp = NULL;

        if (nextWide) { HFree(nextWide); nextWide = NULL; }

        if (!nextUrl) break;

        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
        else if (MSVCRT$strncmp(np, "https://", 8) == 0) np += 8;
        char *slash = MSVCRT$strstr(np, "/");
        nextWide = MbsToWcs(slash ? slash : nextUrl);
        HFree(nextUrl);
        nextUrl = NULL;
        if (!nextWide) break;
        pathArg = nextWide;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Total: %d polic%s scanned, %d excluded entit%s found\n",
        totalPolicies, totalPolicies == 1 ? "y" : "ies",
        g_entityCount, g_entityCount == 1 ? "y" : "ies");

    /* Write raw API response to disk */
    if (rawBuf.ok && rawBuf.buf && rawBuf.len > 0) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        static char rawFn[300];
        MSVCRT$sprintf_s(rawFn, sizeof(rawFn),
            ".\\AZConditionalAccessPolicyRaw_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear,  (unsigned)st.wMonth,  (unsigned)st.wDay,
            (unsigned)st.wHour,  (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(rawFn, rawBuf.buf, (DWORD)rawBuf.len);
    }
    BarkBufFree(&rawBuf);

    if (g_entityCount == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No excluded users or groups found in enabled MFA/Block CA policies.\n");
        BeaconPrintf(CALLBACK_OUTPUT,
            "[BARK/v5] all-info collector complete: conditional_access\n");
        goto done;
    }

    WriteOutputFile();
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: conditional_access\n");

done:
    if (g_entities) { HFree(g_entities); g_entities = NULL; }
    g_entityCount = 0;
    g_entityCap   = 0;
    if (g_allUserIds) { HFree(g_allUserIds); g_allUserIds = NULL; }
    if (g_allUserDisplayNames) {
        HFree(g_allUserDisplayNames);
        g_allUserDisplayNames = NULL;
    }
    if (g_allUserPrincipalNames) {
        HFree(g_allUserPrincipalNames);
        g_allUserPrincipalNames = NULL;
    }
    g_allUserCount = 0;
    if (hdrWide)  HFree(hdrWide);
    if (widePath) HFree(widePath);
    if (nextWide) HFree(nextWide);
    if (autoTid)  HFree(autoTid);
}
