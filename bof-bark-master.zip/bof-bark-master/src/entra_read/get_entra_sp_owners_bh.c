/*
 * get_entra_sp_owners_bh.c — BARK BOF
 * Get-EntraServicePrincipalOwnersBH — Get owners of a service principal (BH format)
 *
 * Args : token, servicePrincipalId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *servicePrincipalId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    servicePrincipalId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <servicePrincipalId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraServicePrincipalOwnersBH\n");
    BarkGetBHGraphGrouped(token, "servicePrincipals",
        (servicePrincipalId && MSVCRT$strlen(servicePrincipalId) > 0) ? servicePrincipalId : NULL,
        "owners", "AZServicePrincipalOwner",
        "servicePrincipalId", "owners", "owner");
}
