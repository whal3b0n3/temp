/*
 * get_all_entra_roles_bh.c — BARK BOF
 * Get-AllEntraRolesBH — Get every Entra directory role definition (BH format)
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/edge_collection.h"

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_entra_roles_bh <token>\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllEntraRolesBH\n");

    char *tenantId = BarkExtractTidFromJWT(token);
    char *tenantName = BarkFetchTenantDisplayName(token);
    char suffix[512];

    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId ? tenantId : "", tenantName ? tenantName : "");

    /* directoryRoles contains only activated roles.  The roleDefinitions
     * collection contains all built-in and custom definitions, including
     * definitions that currently have no assignment. */
    BarkGetBHInner(L"graph.microsoft.com",
        /* Match AzureHound's unqualified list request and let Graph provide
         * the paging cursor for the complete role-definition collection. */
        L"/v1.0/roleManagement/directory/roleDefinitions",
        token, "AZRole", suffix);

    BarkCollectEntraPIM(token, tenantId);

    if (tenantId) HFree(tenantId);
    if (tenantName) HFree(tenantName);
}
