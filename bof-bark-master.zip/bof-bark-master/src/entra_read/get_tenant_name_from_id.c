/*
 * get_tenant_name_from_id.c — BARK BOF
 * Get-TenantNameFromId — Get tenant display name by tenant ID
 *
 * Args : token, tenantId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *tenantId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <tenantId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-TenantNameFromId\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/tenantRelationships/findTenantInformationByTenantId(tenantId='%s')", tenantId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"graph.microsoft.com", widePath, token);
    HFree(widePath);
}
