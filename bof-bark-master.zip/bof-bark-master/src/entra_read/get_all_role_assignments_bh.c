/*
 * get_all_role_assignments_bh.c — BARK BOF
 * Get-AllRoleAssignmentsBH — Get all Entra role assignments grouped by roleDefinitionId
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

/* The standalone role collector is the canonical source of AZRole nodes.
 * Keeping this collector relationship-only is important: a failed optional
 * role-definition lookup must never emit an "unresolved" node with the same
 * ID and overwrite a correctly named AZRole during BloodHound ingest. */
typedef struct {
    char *roleDefId;
    BarkBuf assignments;
    int assignmentCount;
} BarkEntraRoleGroup;

typedef struct {
    BarkEntraRoleGroup *items;
    int count;
    int cap;
} BarkEntraRoleGroups;

static int BarkRoleIdEquals(const char *left, const char *right)
{
    SIZE_T i;
    SIZE_T leftLen;
    SIZE_T rightLen;

    if (!left || !right) return 0;
    leftLen = MSVCRT$strlen(left);
    rightLen = MSVCRT$strlen(right);
    if (leftLen != rightLen) return 0;

    for (i = 0; i < leftLen; i++) {
        char l = left[i];
        char r = right[i];
        if (l >= 'a' && l <= 'z') l = (char)(l - ('a' - 'A'));
        if (r >= 'a' && r <= 'z') r = (char)(r - ('a' - 'A'));
        if (l != r) return 0;
    }
    return 1;
}

static BarkEntraRoleGroup *BarkFindRoleGroup(
    BarkEntraRoleGroups *groups, const char *roleDefId)
{
    int i;

    if (!groups || !roleDefId) return NULL;
    for (i = 0; i < groups->count; i++) {
        if (BarkRoleIdEquals(groups->items[i].roleDefId, roleDefId))
            return &groups->items[i];
    }
    return NULL;
}

static BarkEntraRoleGroup *BarkFindOrAddRoleGroup(
    BarkEntraRoleGroups *groups, const char *roleDefId)
{
    BarkEntraRoleGroup *group;
    char *idCopy;
    SIZE_T idLen;

    group = BarkFindRoleGroup(groups, roleDefId);
    if (group) return group;

    if (groups->count >= groups->cap) {
        int newCap = groups->cap == 0 ? 64 : groups->cap * 2;
        BarkEntraRoleGroup *newItems = (BarkEntraRoleGroup *)HAlloc(
            (SIZE_T)newCap * sizeof(BarkEntraRoleGroup));
        if (!newItems) return NULL;
        if (groups->count > 0) {
            MSVCRT$memcpy(newItems, groups->items,
                (SIZE_T)groups->count * sizeof(BarkEntraRoleGroup));
        }
        if (groups->items) HFree(groups->items);
        groups->items = newItems;
        groups->cap = newCap;
    }

    idLen = MSVCRT$strlen(roleDefId);
    idCopy = (char *)HAlloc(idLen + 1);
    if (!idCopy) return NULL;
    MSVCRT$memcpy(idCopy, roleDefId, idLen + 1);

    group = &groups->items[groups->count++];
    group->roleDefId = idCopy;
    group->assignments.buf = NULL;
    group->assignments.cap = 0;
    group->assignments.len = 0;
    group->assignments.ok = 1;
    group->assignmentCount = 0;
    return group;
}

static void BarkFreeRoleGroups(BarkEntraRoleGroups *groups)
{
    int i;

    if (!groups) return;
    for (i = 0; i < groups->count; i++) {
        HFree(groups->items[i].roleDefId);
        BarkBufFree(&groups->items[i].assignments);
    }
    if (groups->items) HFree(groups->items);
    groups->items = NULL;
    groups->count = 0;
    groups->cap = 0;
}

static int BarkAppendRoleAssignment(BarkEntraRoleGroup *group,
                                    const char *item,
                                    const char *itemEnd)
{
    BarkBuf normalized = { NULL, 0, 0, 1 };
    const char *assignmentKeys[] = {
        "\"principalId\"",
        "\"directoryScopeId\""
    };

    if (!group || !item || !itemEnd) return 0;
    if (group->assignmentCount > 0)
        BarkBufAppend(&group->assignments, ",", 1);

    /* Keep roleDefinitionId in the raw assignment object. BloodHound's role
     * converter uses that value for case-sensitive role-constant matching;
     * normalize the endpoint IDs that are matched to Entra nodes. */
    if (BarkBufAppendUppercaseJsonStringFields(&normalized,
            item, itemEnd, assignmentKeys,
            (int)(sizeof(assignmentKeys) / sizeof(assignmentKeys[0])))) {
        BarkBufAppend(&group->assignments, normalized.buf, normalized.len);
    } else {
        BarkBufAppend(&group->assignments, item,
            (SIZE_T)(itemEnd - item));
    }
    BarkBufFree(&normalized);
    if (!group->assignments.ok) return 0;
    group->assignmentCount++;
    return 1;
}

static void BarkEmitRoleAssignmentGroup(BarkBuf *output,
                                        const BarkEntraRoleGroup *group,
                                        const char *tenantId,
                                        int isFirst)
{
    const char *prefix =
        "{\"kind\":\"AZRoleAssignment\",\"data\":{\"roleAssignments\":[";

    if (!isFirst) BarkBufAppend(output, ",", 1);
    BarkBufAppend(output, prefix, MSVCRT$strlen(prefix));
    if (group->assignments.buf) {
        BarkBufAppend(output, group->assignments.buf,
            group->assignments.len);
    }
    BarkBufAppend(output, "],\"tenantId\":\"",
        MSVCRT$strlen("],\"tenantId\":\""));
    BarkBufAppendAsciiUpper(output, SAFE_STR(tenantId),
        MSVCRT$strlen(SAFE_STR(tenantId)));
    BarkBufAppend(output, "\",\"roleDefinitionId\":\"",
        MSVCRT$strlen("\",\"roleDefinitionId\":\""));
    BarkBufAppendAsciiUpper(output, group->roleDefId,
        MSVCRT$strlen(group->roleDefId));
    BarkBufAppend(output, "\"}}", 3);
}

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *tenantId = NULL;
    LPWSTR hdrWide = NULL;
    LPCWSTR pathArg =
        L"/v1.0/roleManagement/directory/roleAssignments?$top=999";
    char *nextUrl = NULL;
    LPWSTR nextWide = NULL;
    BarkEntraRoleGroups groups = { NULL, 0, 0 };
    int totalAssignments = 0;
    int collectionFailed = 0;
    int i;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_role_assignments_bh <token>\n");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllRoleAssignmentsBH\n");

    tenantId = BarkExtractTidFromJWT(token);
    hdrWide = BarkMakeAuthHeader(token,
        "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) goto cleanup;

    /* One paginated parent list replaces the old one-request-per-role wave. */
    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);

        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Get-AllRoleAssignmentsBH: HTTP %lu%s%s\n",
                status, resp ? "\n    " : "", resp ? resp : "");
            if (resp) HFree(resp);
            collectionFailed = 1;
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *vKey = JsonFindKey(resp, end, "\"value\"");
            if (vKey) {
                const char *colon = JsonFindKey(vKey, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end &&
                           (*colon == ' ' || *colon == '\t' ||
                            *colon == '\n' || *colon == '\r'))
                        colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrEnd = JsonSkipBalanced(colon, end);
                        if (arrEnd) {
                            const char *p = colon + 1;
                            while (p < arrEnd - 1) {
                                const char *itemEnd;
                                char *roleDefId;
                                BarkEntraRoleGroup *group;

                                while (p < arrEnd - 1 &&
                                       (*p == ' ' || *p == '\t' ||
                                        *p == '\n' || *p == '\r' ||
                                        *p == ','))
                                    p++;
                                if (p >= arrEnd - 1 || *p != '{') break;
                                itemEnd = JsonSkipBalanced(p, arrEnd);
                                if (!itemEnd) break;

                                roleDefId = JsonExtractStringValue(p, itemEnd,
                                    "\"roleDefinitionId\"");
                                if (roleDefId && roleDefId[0] != '\0') {
                                    group = BarkFindOrAddRoleGroup(&groups,
                                        roleDefId);
                                    if (group && BarkAppendRoleAssignment(
                                            group, p, itemEnd)) {
                                        totalAssignments++;
                                    }
                                }
                                if (roleDefId) HFree(roleDefId);
                                p = itemEnd;
                            }
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;

        {
            char *np = nextUrl;
            char *slash;
            if (MSVCRT$strncmp(np, "http://", 7) == 0) np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0) np += 8;
            slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : nextUrl);
        }
        if (!nextWide) {
            collectionFailed = 1;
            break;
        }
        pathArg = nextWide;
    }

    HFree(hdrWide);
    hdrWide = NULL;
    if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
    if (nextWide) { HFree(nextWide); nextWide = NULL; }

    if (collectionFailed) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Role-assignment collection failed; no partial BloodHound file was written\n");
        goto complete;
    }

    if (groups.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] No role assignments found\n");
        goto complete;
    }

    {
        BarkBuf output = { NULL, 0, 0, 1 };
        char tail[128];
        int tailLen;

        BarkBufAppend(&output, "{\"data\":[", 9);
        for (i = 0; i < groups.count; i++) {
            BarkEmitRoleAssignmentGroup(&output, &groups.items[i],
                tenantId, i == 0);
        }

        tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}",
            groups.count);
        if (tailLen > 0)
            BarkBufAppend(&output, tail, (SIZE_T)tailLen);

        if (output.ok && output.buf) {
            SYSTEMTIME st;
            char filename[300];
            KERNEL32$GetLocalTime(&st);
            MSVCRT$sprintf_s(filename, sizeof(filename),
                ".\\AZRoleAssignment_%04u%02u%02u_%02u%02u%02u.json",
                (unsigned)st.wYear, (unsigned)st.wMonth,
                (unsigned)st.wDay, (unsigned)st.wHour,
                (unsigned)st.wMinute, (unsigned)st.wSecond);
            BarkWriteOutput(filename, output.buf, (DWORD)output.len);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK AZRoleAssignment found %d assignment(s) across %d role definition(s)\n",
                totalAssignments, groups.count);
            BeaconPrintf(CALLBACK_OUTPUT,
                "[+] Reused the parent assignment list; skipped %d per-role refetch request(s)\n",
                groups.count);
        }
        BarkBufFree(&output);
    }

complete:
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: role_assignments\n");

cleanup:
    if (hdrWide) HFree(hdrWide);
    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    if (tenantId) HFree(tenantId);
    BarkFreeRoleGroups(&groups);
}
