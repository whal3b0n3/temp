/*
 * get_entra_device_registered_users.c — BARK BOF
 * Get-EntraDeviceRegisteredUsers — Get registered users of an Entra device
 *
 * Args : token, deviceId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *deviceId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    deviceId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <deviceId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraDeviceRegisteredUsers\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/devices/%s/registeredUsers", deviceId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"graph.microsoft.com", widePath, token);
    HFree(widePath);
}
