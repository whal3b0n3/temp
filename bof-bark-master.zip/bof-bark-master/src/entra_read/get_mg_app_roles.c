/*
 * get_mg_app_roles.c — BARK BOF
 * Get-MGAppRoles — Get app role assignments for a service principal
 *
 * Args : token, servicePrincipalId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *servicePrincipalId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    servicePrincipalId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <servicePrincipalId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-MGAppRoles\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/servicePrincipals/%s/appRoleAssignments", servicePrincipalId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"graph.microsoft.com", widePath, token);
    HFree(widePath);
}
