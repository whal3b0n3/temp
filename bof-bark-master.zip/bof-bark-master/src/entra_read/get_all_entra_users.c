/*
 * get_all_entra_users.c — BARK BOF
 * Get-AllEntraUsers — Get all Entra users
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllEntraUsers\n");
    BarkGet(L"graph.microsoft.com", L"/v1.0/users?$select=id,displayName,userPrincipalName,mail,jobTitle,department,accountEnabled,createdDateTime", token);
}
