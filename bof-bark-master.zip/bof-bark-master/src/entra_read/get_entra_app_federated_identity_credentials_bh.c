/*
 * get_entra_app_federated_identity_credentials_bh.c — BARK BOF
 * Get-EntraAppFederatedIdentityCredentialsBH — Get federated identity credentials of an app registration (BH format)
 *
 * Args : token, appObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *appObjectId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    appObjectId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <appObjectId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraAppFederatedIdentityCredentialsBH\n");

    {
        BarkIdList objectIds;
        BarkIdList appIds;
        BarkHttpMetricsReset();
        objectIds = BarkEnumApplicationIds(token,
            (appObjectId && MSVCRT$strlen(appObjectId) > 0) ?
                appObjectId : NULL,
            &appIds);
        if (objectIds.count == 0) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] No applications found for federatedIdentityCredentials enumeration\n");
        } else {
            char *tenantId = BarkExtractTidFromJWT(token);
            char *tenantName = BarkFetchTenantDisplayName(token);
            char dataSuffix[1024];
            MSVCRT$sprintf_s(dataSuffix, sizeof(dataSuffix),
                "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
                tenantId ? tenantId : "",
                tenantName ? tenantName : "");
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Found %d applications, enumerating federatedIdentityCredentials with %d workers...\n",
                objectIds.count, BARK_GRAPH_PARENT_WORKERS);
            BarkGetBHGraphGroupedExFromIdMap(token, "applications",
                &objectIds, &appIds, "federatedIdentityCredentials",
                "AZFederatedIdentityCredential", "appId", "fics", "fic",
                dataSuffix);
            if (tenantId) HFree(tenantId);
            if (tenantName) HFree(tenantName);
        }
        BarkIdListFree(&objectIds);
        BarkIdListFree(&appIds);
    }
}
