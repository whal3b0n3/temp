/*
 * get_entra_app_owners_bh.c — BARK BOF
 * Get-EntraAppOwnersBH — Get owners of an app registration (BH format)
 *
 * Args : token, appObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *appObjectId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    appObjectId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <appObjectId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraAppOwnersBH\n");
    {
        BarkIdList objectIds;
        BarkIdList appIds;
        BarkHttpMetricsReset();
        objectIds = BarkEnumApplicationIds(token,
            (appObjectId && MSVCRT$strlen(appObjectId) > 0) ?
                appObjectId : NULL,
            &appIds);
        if (objectIds.count == 0) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] No applications found for owners enumeration\n");
        } else {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] Found %d applications, enumerating owners with %d workers...\n",
                objectIds.count, BARK_GRAPH_PARENT_WORKERS);
            BarkGetBHGraphGroupedFromIdMap(token, "applications",
                &objectIds, &appIds, "owners", "AZAppOwner",
                "appId", "owners", "owner");
        }
        BarkIdListFree(&objectIds);
        BarkIdListFree(&appIds);
    }
}
