/*
 * get_intune_role_definitions.c — BARK BOF
 * Get-IntuneRoleDefinitions — Get Intune role definitions
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-IntuneRoleDefinitions\n");
    BarkGet(L"graph.microsoft.com", L"/beta/deviceManagement/roleDefinitions", token);
}
