/*
 * get_entra_group_owner_bh.c — BARK BOF
 * Get-EntraGroupOwnerBH — Get owners of an Entra group (BH format)
 *
 * The shared Graph grouped collector handles pagination, bounded parent
 * concurrency, throttling, metrics, and chunked BloodHound output.
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *groupId = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    groupId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_group_owner_bh <token> [groupId]\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraGroupOwnerBH\n");
    BarkGetBHGraphGrouped(token, "groups",
        (groupId && MSVCRT$strlen(groupId) > 0) ? groupId : NULL,
        "owners", "AZGroupOwner",
        "groupId", "owners", "owner");
}
