/*
 * get_entra_agents_opengraph.c — BARK BOF
 *
 * Collect the read-only Microsoft Entra Agent ID graph and emit a generic
 * BloodHound OpenGraph payload.  This BOF intentionally stays on the
 * Microsoft Graph control plane: it does not request agent credentials,
 * connection secrets, Key Vault data, or agent runtime data.
 *
 * Args: graphToken, downloadMode
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define AGENT_PAGE_TOP 100

typedef struct {
    char **objectIds;
    char **nodeIds;
    int count;
    int cap;
} AgentRefs;

typedef struct {
    BarkBuf nodes;
    BarkBuf edges;
    int nodeCount;
    int edgeCount;
    int failedPages;
} AgentGraph;

static void AgentRefsInit(AgentRefs *refs) {
    refs->objectIds = NULL;
    refs->nodeIds = NULL;
    refs->count = 0;
    refs->cap = 0;
}

static int AgentRefsHas(const AgentRefs *refs, const char *objectId) {
    int i;
    for (i = 0; i < refs->count; i++) {
        if (MSVCRT$strcmp(refs->objectIds[i], objectId) == 0)
            return 1;
    }
    return 0;
}

static int AgentRefsAdd(AgentRefs *refs, const char *objectId,
                        const char *nodeId) {
    char **newObjectIds;
    char **newNodeIds;
    char *objectCopy;
    char *nodeCopy;

    if (!objectId || !nodeId || MSVCRT$strlen(objectId) == 0 ||
        AgentRefsHas(refs, objectId))
        return 1;

    if (refs->count >= refs->cap) {
        int newCap = refs->cap == 0 ? 32 : refs->cap * 2;
        newObjectIds = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        newNodeIds = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        if (!newObjectIds || !newNodeIds) {
            if (newObjectIds) HFree(newObjectIds);
            if (newNodeIds) HFree(newNodeIds);
            return 0;
        }
        if (refs->count > 0) {
            MSVCRT$memcpy(newObjectIds, refs->objectIds,
                         (SIZE_T)refs->count * sizeof(char *));
            MSVCRT$memcpy(newNodeIds, refs->nodeIds,
                         (SIZE_T)refs->count * sizeof(char *));
        }
        if (refs->objectIds) HFree(refs->objectIds);
        if (refs->nodeIds) HFree(refs->nodeIds);
        refs->objectIds = newObjectIds;
        refs->nodeIds = newNodeIds;
        refs->cap = newCap;
    }

    objectCopy = (char *)HAlloc(MSVCRT$strlen(objectId) + 1);
    nodeCopy = (char *)HAlloc(MSVCRT$strlen(nodeId) + 1);
    if (!objectCopy || !nodeCopy) {
        if (objectCopy) HFree(objectCopy);
        if (nodeCopy) HFree(nodeCopy);
        return 0;
    }
    MSVCRT$memcpy(objectCopy, objectId, MSVCRT$strlen(objectId) + 1);
    MSVCRT$memcpy(nodeCopy, nodeId, MSVCRT$strlen(nodeId) + 1);
    refs->objectIds[refs->count] = objectCopy;
    refs->nodeIds[refs->count] = nodeCopy;
    refs->count++;
    return 1;
}

static void AgentRefsFree(AgentRefs *refs) {
    int i;
    for (i = 0; i < refs->count; i++) {
        HFree(refs->objectIds[i]);
        HFree(refs->nodeIds[i]);
    }
    HFree(refs->objectIds);
    HFree(refs->nodeIds);
    AgentRefsInit(refs);
}

static void AgentJsonString(BarkBuf *b, const char *value) {
    size_t i;
    char escaped[8];

    BarkBufAppend(b, "\"", 1);
    if (value) {
        for (i = 0; value[i]; i++) {
            unsigned char c = (unsigned char)value[i];
            if (c == '"' || c == '\\') {
                BarkBufAppend(b, "\\", 1);
                BarkBufAppend(b, (const char *)&value[i], 1);
            } else if (c == '\n') {
                BarkBufAppend(b, "\\n", 2);
            } else if (c == '\r') {
                BarkBufAppend(b, "\\r", 2);
            } else if (c == '\t') {
                BarkBufAppend(b, "\\t", 2);
            } else if (c < 0x20) {
                MSVCRT$sprintf_s(escaped, sizeof(escaped), "\\u%04x", c);
                BarkBufAppend(b, escaped, MSVCRT$strlen(escaped));
            } else {
                BarkBufAppend(b, (const char *)&value[i], 1);
            }
        }
    }
    BarkBufAppend(b, "\"", 1);
}

static void AgentProperty(BarkBuf *b, int *first, const char *name,
                          const char *value) {
    if (!value || MSVCRT$strlen(value) == 0) return;
    if (!*first) BarkBufAppend(b, ",", 1);
    AgentJsonString(b, name);
    BarkBufAppend(b, ":", 1);
    AgentJsonString(b, value);
    *first = 0;
}

static void AgentPropertyFromJson(BarkBuf *b, int *first,
                                  const char *item, const char *itemEnd,
                                  const char *name, const char *jsonKey) {
    char *value = JsonExtractStringValueUtf8(item, itemEnd, jsonKey);
    AgentProperty(b, first, name, value);
    if (value) HFree(value);
}

static void AgentNode(AgentGraph *graph, const char *nodeId,
                      const char *kind, const char *item,
                      const char *itemEnd) {
    int first = 1;
    char *displayName;

    if (graph->nodeCount > 0) BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    AgentJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    AgentJsonString(&graph->nodes, kind);
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));

    displayName = JsonExtractStringValueUtf8(item, itemEnd, "\"displayName\"");
    if (!displayName)
        displayName = JsonExtractStringValueUtf8(item, itemEnd, "\"name\"");
    AgentProperty(&graph->nodes, &first, "name", displayName);
    AgentProperty(&graph->nodes, &first, "displayname", displayName);
    if (displayName) HFree(displayName);
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "appid", "\"appId\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "blueprintid", "\"agentIdentityBlueprintId\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "identityparentid", "\"identityParentId\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "userprincipalname", "\"userPrincipalName\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "servicetype", "\"servicePrincipalType\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "createddatetime", "\"createdDateTime\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "description", "\"description\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "originatingstore", "\"originatingStore\"");
    AgentPropertyFromJson(&graph->nodes, &first, item, itemEnd,
                          "sourceagentid", "\"sourceAgentId\"");
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
}

static void AgentEdge(AgentGraph *graph, const char *kind,
                      const char *start, const char *end) {
    if (!start || !end || MSVCRT$strlen(start) == 0 ||
        MSVCRT$strlen(end) == 0)
        return;
    if (graph->edgeCount > 0) BarkBufAppend(&graph->edges, ",", 1);
    BarkBufAppend(&graph->edges, "{\"kind\":",
                  MSVCRT$strlen("{\"kind\":"));
    AgentJsonString(&graph->edges, kind);
    BarkBufAppend(&graph->edges, ",\"start\":{\"value\":",
                  MSVCRT$strlen(",\"start\":{\"value\":"));
    AgentJsonString(&graph->edges, start);
    BarkBufAppend(&graph->edges,
                  ",\"match_by\":\"id\"},\"end\":{\"value\":",
                  MSVCRT$strlen(",\"match_by\":\"id\"},\"end\":{\"value\":"));
    AgentJsonString(&graph->edges, end);
    BarkBufAppend(&graph->edges, ",\"match_by\":\"id\"}}",
                  MSVCRT$strlen(",\"match_by\":\"id\"}}"));
    graph->edgeCount++;
}

static int AgentGraphHasNode(const AgentGraph *graph, const char *nodeId) {
    /* Nodes are serialized incrementally, so use a bounded duplicate check
     * through the serialized id field.  Agent IDs are tenant GUIDs and the
     * synthetic IDs below are short enough for this scan. */
    const char *p;
    size_t idLen;
    if (!graph || !graph->nodes.buf || !nodeId) return 0;
    idLen = MSVCRT$strlen(nodeId);
    p = graph->nodes.buf;
    while (p < graph->nodes.buf + graph->nodes.len) {
        if (MSVCRT$strncmp(p, "{\"id\":\"", 8) == 0 &&
            MSVCRT$strncmp(p + 8, nodeId, idLen) == 0 &&
            p[8 + idLen] == '"')
            return 1;
        p++;
    }
    return 0;
}

static void AgentSyntheticNode(AgentGraph *graph, const char *nodeId,
                               const char *kind, const char *name,
                               const char *key1, const char *value1,
                               const char *key2, const char *value2,
                               const char *key3, const char *value3) {
    int first = 1;
    if (!nodeId || !kind || AgentGraphHasNode(graph, nodeId)) return;
    if (graph->nodeCount > 0) BarkBufAppend(&graph->nodes, ",", 1);
    BarkBufAppend(&graph->nodes, "{\"id\":",
                  MSVCRT$strlen("{\"id\":"));
    AgentJsonString(&graph->nodes, nodeId);
    BarkBufAppend(&graph->nodes, ",\"kinds\":[",
                  MSVCRT$strlen(",\"kinds\":["));
    AgentJsonString(&graph->nodes, kind);
    BarkBufAppend(&graph->nodes, "],\"properties\":{",
                  MSVCRT$strlen("],\"properties\":{"));
    AgentProperty(&graph->nodes, &first, "name", name);
    AgentProperty(&graph->nodes, &first, key1, value1);
    AgentProperty(&graph->nodes, &first, key2, value2);
    AgentProperty(&graph->nodes, &first, key3, value3);
    BarkBufAppend(&graph->nodes, "}}", 2);
    graph->nodeCount++;
}

static char *AgentCompositeId(const char *prefix, const char *a,
                              const char *b, const char *c) {
    size_t size;
    char *result;
    if (!prefix || !a || !b || !c) return NULL;
    size = MSVCRT$strlen(prefix) + MSVCRT$strlen(a) + MSVCRT$strlen(b) +
           MSVCRT$strlen(c) + 3;
    result = (char *)HAlloc(size);
    if (!result) return NULL;
    MSVCRT$sprintf_s(result, size, "%s%s:%s:%s", prefix, a, b, c);
    return result;
}

static char *AgentNodeId(const char *prefix, const char *id) {
    size_t size;
    char *result;
    if (!prefix || !id) return NULL;
    size = MSVCRT$strlen(prefix) + MSVCRT$strlen(id) + 1;
    result = (char *)HAlloc(size);
    if (!result) return NULL;
    MSVCRT$sprintf_s(result, size, "%s%s", prefix, id);
    return result;
}

static int AgentCollectPageItems(const char *response, AgentGraph *graph,
                                 int itemType, AgentRefs *refs) {
    const char *end = response + MSVCRT$strlen(response);
    const char *valueKey = JsonFindKey(response, end, "\"value\"");
    const char *colon;
    const char *arrayEnd;
    const char *item;
    int count = 0;

    if (!valueKey) return 0;
    colon = JsonFindKey(valueKey, end, ":");
    if (!colon) return 0;
    colon++;
    while (colon < end && (*colon == ' ' || *colon == '\t' ||
           *colon == '\r' || *colon == '\n')) colon++;
    if (colon >= end || *colon != '[') return 0;
    arrayEnd = JsonSkipBalanced(colon, end);
    if (!arrayEnd) return 0;

    item = colon + 1;
    while (item < arrayEnd - 1) {
        const char *itemEnd;
        char *objectId;
        char *appId;
        char *blueprintId;
        char *identityParentId;
        char *nodeId = NULL;
        char *targetId = NULL;

        while (item < arrayEnd - 1 && (*item == ' ' || *item == '\t' ||
               *item == '\r' || *item == '\n' || *item == ',')) item++;
        if (item >= arrayEnd - 1 || *item != '{') break;
        itemEnd = JsonSkipBalanced(item, arrayEnd - 1);
        if (!itemEnd) break;
        objectId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
        if (!objectId || MSVCRT$strlen(objectId) == 0) {
            if (objectId) HFree(objectId);
            item = itemEnd;
            continue;
        }
        appId = JsonExtractStringValueUtf8(item, itemEnd, "\"appId\"");
        blueprintId = JsonExtractStringValueUtf8(item, itemEnd,
                                             "\"agentIdentityBlueprintId\"");
        identityParentId = JsonExtractStringValueUtf8(item, itemEnd,
                                                  "\"identityParentId\"");

        if (itemType == 1) {
            nodeId = AgentNodeId("agent-blueprint:", appId ? appId : objectId);
            if (nodeId) AgentRefsAdd(refs, objectId, nodeId);
            if (nodeId) AgentNode(graph, nodeId, "AZAgentIdentityBlueprint", item, itemEnd);
        } else if (itemType == 2) {
            nodeId = AgentNodeId("agent-blueprint-principal:", objectId);
            if (nodeId) AgentRefsAdd(refs, objectId, nodeId);
            if (nodeId) AgentNode(graph, nodeId, "AZAgentIdentityBlueprintPrincipal", item, itemEnd);
            if (appId) {
                targetId = AgentNodeId("agent-blueprint:", appId);
                if (nodeId && targetId)
                    AgentEdge(graph, "AZAgent_Represents", nodeId, targetId);
            }
        } else if (itemType == 3) {
            nodeId = AgentNodeId("agent-identity:", objectId);
            if (nodeId) AgentRefsAdd(refs, objectId, nodeId);
            if (nodeId) AgentNode(graph, nodeId, "AZAgentIdentity", item, itemEnd);
            if (blueprintId) {
                targetId = AgentNodeId("agent-blueprint:", blueprintId);
                if (nodeId && targetId)
                    AgentEdge(graph, "AZAgent_Controls", targetId, nodeId);
                if (targetId) HFree(targetId);
                targetId = NULL;
            }
            /* The agent identity is also a service principal.  This edge
             * lets the OpenGraph node join the existing Entra/Azure graph
             * without copying or reclassifying the service principal. */
            if (nodeId)
                AgentEdge(graph, "AZAgent_MapsTo", nodeId, objectId);
        } else if (itemType == 4) {
            nodeId = AgentNodeId("agent-user:", objectId);
            if (nodeId) AgentNode(graph, nodeId, "AZAgentUser", item, itemEnd);
            if (identityParentId) {
                targetId = AgentNodeId("agent-identity:", identityParentId);
                if (nodeId && targetId)
                    AgentEdge(graph, "AZAgent_UsesUser", targetId, nodeId);
            }
        }

        if (targetId) HFree(targetId);
        if (nodeId) HFree(nodeId);
        HFree(objectId);
        if (appId) HFree(appId);
        if (blueprintId) HFree(blueprintId);
        if (identityParentId) HFree(identityParentId);
        count++;
        item = itemEnd;
    }
    return count;
}

static int AgentCollectCollection(const char *token, const char *initialPath,
                                  AgentGraph *graph, int itemType,
                                  AgentRefs *refs) {
    LPWSTR headers;
    LPWSTR path;
    int total = 0;

    headers = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");
    path = MbsToWcs(initialPath);
    if (!headers || !path) {
        if (headers) HFree(headers);
        if (path) HFree(path);
        return 0;
    }

    while (1) {
        DWORD status = 0;
        char *response = HttpRequestWithRetry(
            L"GET", L"graph.microsoft.com", path, headers, NULL, 0, &status);
        char *nextUrl;
        LPWSTR nextPath;

        if (!response || status >= 400) {
            if (response) HFree(response);
            graph->failedPages++;
            break;
        }
        total += AgentCollectPageItems(response, graph, itemType, refs);
        nextUrl = JsonExtractNextLink(response,
                                      response + MSVCRT$strlen(response));
        HFree(response);
        if (!nextUrl) break;
        nextPath = BarkResolveNextLink(nextUrl, L"graph.microsoft.com", NULL);
        HFree(nextUrl);
        if (!nextPath) {
            graph->failedPages++;
            break;
        }
        HFree(path);
        path = nextPath;
    }

    HFree(headers);
    HFree(path);
    return total;
}

static void AgentCollectRelationships(const char *token,
                                      const AgentRefs *refs,
                                      const char *pathPrefix,
                                      const char *pathSuffix,
                                      const char *edgeKind,
                                      AgentGraph *graph) {
    int i;
    LPWSTR headers = BarkMakeAuthHeader(token,
        "ConsistencyLevel: eventual\r\n");
    if (!headers) return;

    for (i = 0; i < refs->count; i++) {
        size_t pathSize = MSVCRT$strlen(pathPrefix) +
                          MSVCRT$strlen(refs->objectIds[i]) +
                          MSVCRT$strlen(pathSuffix) + 32;
        char *pathText = (char *)HAlloc(pathSize);
        LPWSTR path;
        if (!pathText) continue;
        MSVCRT$sprintf_s(pathText, pathSize, "%s%s%s?$select=id",
                         pathPrefix, refs->objectIds[i], pathSuffix);
        path = MbsToWcs(pathText);
        HFree(pathText);
        if (!path) continue;

        while (1) {
            DWORD status = 0;
            char *response = HttpRequestWithRetry(
                L"GET", L"graph.microsoft.com", path, headers, NULL, 0, &status);
            const char *end;
            const char *valueKey;
            const char *colon;
            const char *arrayEnd;
            const char *item;
            char *nextUrl;
            LPWSTR nextPath;

            if (!response || status >= 400) {
                if (response) HFree(response);
                graph->failedPages++;
                break;
            }
            end = response + MSVCRT$strlen(response);
            valueKey = JsonFindKey(response, end, "\"value\"");
            colon = valueKey ? JsonFindKey(valueKey, end, ":") : NULL;
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\r' || *colon == '\n')) colon++;
                arrayEnd = (colon < end && *colon == '[') ?
                    JsonSkipBalanced(colon, end) : NULL;
                item = colon + 1;
                if (arrayEnd) {
                    while (item < arrayEnd - 1) {
                        const char *itemEnd;
                        char *relatedId;
                        while (item < arrayEnd - 1 && (*item == ' ' ||
                               *item == '\t' || *item == '\r' ||
                               *item == '\n' || *item == ',')) item++;
                        if (item >= arrayEnd - 1 || *item != '{') break;
                        itemEnd = JsonSkipBalanced(item, arrayEnd - 1);
                        if (!itemEnd) break;
                        relatedId = JsonExtractStringValueUtf8(item, itemEnd, "\"id\"");
                        if (relatedId) {
                            AgentEdge(graph, edgeKind, relatedId,
                                      refs->nodeIds[i]);
                            HFree(relatedId);
                        }
                        item = itemEnd;
                    }
                }
            }
            nextUrl = JsonExtractNextLink(response, end);
            HFree(response);
            if (!nextUrl) break;
            nextPath = BarkResolveNextLink(nextUrl,
                                           L"graph.microsoft.com", NULL);
            HFree(nextUrl);
            if (!nextPath) {
                graph->failedPages++;
                break;
            }
            HFree(path);
            path = nextPath;
        }
        HFree(path);
    }
    HFree(headers);
}

static void AgentCollectServicePrincipalPermissions(const char *token,
                                                    const AgentRefs *refs,
                                                    const char *suffix,
                                                    const char *nodeKind,
                                                    const char *edgeKind,
                                                    const char *permissionType,
                                                    AgentGraph *graph) {
    int i;
    LPWSTR headers = BarkMakeAuthHeader(token,
        "ConsistencyLevel: eventual\r\n");
    if (!headers) return;

    for (i = 0; i < refs->count; i++) {
        const char *select = MSVCRT$strstr(suffix, "oauth2PermissionGrants") ?
            "resourceId,scope,consentType" : "resourceId,appRoleId";
        size_t pathSize = MSVCRT$strlen("/v1.0/servicePrincipals/") +
                          MSVCRT$strlen(refs->objectIds[i]) +
                          MSVCRT$strlen(suffix) + MSVCRT$strlen(select) + 32;
        char *pathText = (char *)HAlloc(pathSize);
        LPWSTR path;
        if (!pathText) continue;
        MSVCRT$sprintf_s(pathText, pathSize,
            "/v1.0/servicePrincipals/%s%s?$select=%s",
            refs->objectIds[i], suffix, select);
        path = MbsToWcs(pathText);
        HFree(pathText);
        if (!path) continue;

        while (1) {
            DWORD status = 0;
            char *response = HttpRequestWithRetry(
                L"GET", L"graph.microsoft.com", path, headers, NULL, 0, &status);
            const char *end;
            const char *valueKey;
            const char *colon;
            const char *arrayEnd;
            const char *item;
            char *nextUrl;
            LPWSTR nextPath;
            if (!response || status >= 400) {
                if (response) HFree(response);
                graph->failedPages++;
                break;
            }
            end = response + MSVCRT$strlen(response);
            valueKey = JsonFindKey(response, end, "\"value\"");
            colon = valueKey ? JsonFindKey(valueKey, end, ":") : NULL;
            arrayEnd = NULL;
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\r' || *colon == '\n')) colon++;
                if (colon < end && *colon == '[')
                    arrayEnd = JsonSkipBalanced(colon, end);
            }
            item = colon ? colon + 1 : end;
            if (arrayEnd) {
                while (item < arrayEnd - 1) {
                    const char *itemEnd;
                    char *resourceId;
                    char *appRoleId;
                    char *scope;
                    char *consentType;
                    char *permissionId;
                    while (item < arrayEnd - 1 && (*item == ' ' ||
                           *item == '\t' || *item == '\r' ||
                           *item == '\n' || *item == ',')) item++;
                    if (item >= arrayEnd - 1 || *item != '{') break;
                    itemEnd = JsonSkipBalanced(item, arrayEnd - 1);
                    if (!itemEnd) break;
                    resourceId = JsonExtractStringValueUtf8(item, itemEnd,
                                                        "\"resourceId\"");
                    appRoleId = JsonExtractStringValueUtf8(item, itemEnd,
                                                       "\"appRoleId\"");
                    scope = JsonExtractStringValueUtf8(item, itemEnd, "\"scope\"");
                    consentType = JsonExtractStringValueUtf8(item, itemEnd,
                                                         "\"consentType\"");
                    permissionId = AgentCompositeId(
                        nodeKind, refs->objectIds[i],
                        resourceId ? resourceId : "none",
                        appRoleId ? appRoleId : (scope ? scope : "none"));
                    if (permissionId) {
                        AgentSyntheticNode(graph, permissionId,
                            "AZAgentPermission", permissionType,
                            "resourceid", resourceId,
                            "approleid", appRoleId,
                            "scope", scope ? scope : consentType);
                        AgentEdge(graph, edgeKind, refs->nodeIds[i], permissionId);
                        if (resourceId)
                            AgentEdge(graph, "AZAgent_Targets", permissionId,
                                      resourceId);
                        HFree(permissionId);
                    }
                    if (resourceId) HFree(resourceId);
                    if (appRoleId) HFree(appRoleId);
                    if (scope) HFree(scope);
                    if (consentType) HFree(consentType);
                    item = itemEnd;
                }
            }
            nextUrl = JsonExtractNextLink(response, end);
            HFree(response);
            if (!nextUrl) break;
            nextPath = BarkResolveNextLink(nextUrl,
                                           L"graph.microsoft.com", NULL);
            HFree(nextUrl);
            if (!nextPath) {
                graph->failedPages++;
                break;
            }
            HFree(path);
            path = nextPath;
        }
        HFree(path);
    }
    HFree(headers);
}

static void AgentCollectDirectoryRoles(const char *token,
                                       const AgentRefs *refs,
                                       AgentGraph *graph) {
    int i;
    LPWSTR headers = BarkMakeAuthHeader(token,
        "ConsistencyLevel: eventual\r\n");
    if (!headers) return;
    for (i = 0; i < refs->count; i++) {
        size_t pathSize = MSVCRT$strlen(refs->objectIds[i]) + 160;
        char *pathText = (char *)HAlloc(pathSize);
        LPWSTR path;
        if (!pathText) continue;
        MSVCRT$sprintf_s(pathText, pathSize,
            "/v1.0/roleManagement/directory/roleAssignments?$filter=principalId%%20eq%%20'%s'&$select=roleDefinitionId,directoryScopeId",
            refs->objectIds[i]);
        path = MbsToWcs(pathText);
        HFree(pathText);
        if (!path) continue;
        while (1) {
            DWORD status = 0;
            char *response = HttpRequestWithRetry(
                L"GET", L"graph.microsoft.com", path, headers, NULL, 0, &status);
            const char *end;
            const char *valueKey;
            const char *colon;
            const char *arrayEnd;
            const char *item;
            char *nextUrl;
            LPWSTR nextPath;
            if (!response || status >= 400) {
                if (response) HFree(response);
                graph->failedPages++;
                break;
            }
            end = response + MSVCRT$strlen(response);
            valueKey = JsonFindKey(response, end, "\"value\"");
            colon = valueKey ? JsonFindKey(valueKey, end, ":") : NULL;
            arrayEnd = NULL;
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\r' || *colon == '\n')) colon++;
                if (colon < end && *colon == '[')
                    arrayEnd = JsonSkipBalanced(colon, end);
            }
            item = colon ? colon + 1 : end;
            if (arrayEnd) {
                while (item < arrayEnd - 1) {
                    const char *itemEnd;
                    char *roleId;
                    char *scope;
                    char *roleNode;
                    while (item < arrayEnd - 1 && (*item == ' ' ||
                           *item == '\t' || *item == '\r' ||
                           *item == '\n' || *item == ',')) item++;
                    if (item >= arrayEnd - 1 || *item != '{') break;
                    itemEnd = JsonSkipBalanced(item, arrayEnd - 1);
                    if (!itemEnd) break;
                    roleId = JsonExtractStringValueUtf8(item, itemEnd,
                                                    "\"roleDefinitionId\"");
                    scope = JsonExtractStringValueUtf8(item, itemEnd,
                                                   "\"directoryScopeId\"");
                    roleNode = AgentCompositeId("agent-directory-role:",
                        refs->objectIds[i], roleId ? roleId : "unknown",
                        scope ? scope : "/");
                    if (roleNode) {
                        AgentSyntheticNode(graph, roleNode,
                            "AZAgentDirectoryRole", "Entra directory role",
                            "roledefinitionid", roleId,
                            "directoryscopeid", scope,
                            "principalid", refs->objectIds[i]);
                        AgentEdge(graph, "AZAgent_HasDirectoryRole",
                                  refs->nodeIds[i], roleNode);
                        HFree(roleNode);
                    }
                    if (roleId) HFree(roleId);
                    if (scope) HFree(scope);
                    item = itemEnd;
                }
            }
            nextUrl = JsonExtractNextLink(response, end);
            HFree(response);
            if (!nextUrl) break;
            nextPath = BarkResolveNextLink(nextUrl,
                                           L"graph.microsoft.com", NULL);
            HFree(nextUrl);
            if (!nextPath) {
                graph->failedPages++;
                break;
            }
            HFree(path);
            path = nextPath;
        }
        HFree(path);
    }
    HFree(headers);
}

static void AgentWriteGraph(AgentGraph *graph) {
    BarkBuf output = { NULL, 0, 0, 1 };
    SYSTEMTIME st;
    char filename[300];

    BarkBufAppend(&output, "{\"graph\":{\"nodes\":[",
                  MSVCRT$strlen("{\"graph\":{\"nodes\":["));
    if (graph->nodes.buf)
        BarkBufAppend(&output, graph->nodes.buf, graph->nodes.len);
    BarkBufAppend(&output, "],\"edges\":[",
                  MSVCRT$strlen("],\"edges\":["));
    if (graph->edges.buf)
        BarkBufAppend(&output, graph->edges.buf, graph->edges.len);
    BarkBufAppend(&output, "]}}", 3);

    if (!output.ok || !output.buf) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Agent OpenGraph output exceeded available memory\n");
        BarkBufFree(&output);
        return;
    }
    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZEntraAgents_%04u%02u%02u_%02u%02u%02u.json",
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
    BarkWriteOutput(filename, output.buf, (DWORD)output.len);
    BarkBufFree(&output);
}

void go(char *args, int alen) {
    datap parser;
    char *token;
    AgentGraph graph = { { NULL, 0, 0, 1 }, { NULL, 0, 0, 1 }, 0, 0, 0 };
    AgentRefs blueprints;
    AgentRefs identities;
    AgentRefs principals;
    int downloadMode;
    int blueprintsCount;
    int principalsCount;
    int identitiesCount;
    int usersCount;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    downloadMode = BeaconDataInt(&parser);
    g_use_download = downloadMode ? 1 : 0;
    AgentRefsInit(&blueprints);
    AgentRefsInit(&identities);
    AgentRefsInit(&principals);

    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_agents_opengraph <graphToken> [downloadMode]\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Collecting Entra Agent ID objects (Graph control plane only)\n");
    blueprintsCount = AgentCollectCollection(token,
        "/v1.0/applications/microsoft.graph.agentIdentityBlueprint?$top=100&$select=id,appId,displayName,description,createdDateTime",
        &graph, 1, &blueprints);
    principalsCount = AgentCollectCollection(token,
        "/v1.0/servicePrincipals/microsoft.graph.agentIdentityBlueprintPrincipal?$top=100&$select=id,appId,displayName,description,createdDateTime",
        &graph, 2, &principals);
    identitiesCount = AgentCollectCollection(token,
        "/v1.0/servicePrincipals/microsoft.graph.agentIdentity?$top=100&$select=id,appId,displayName,agentIdentityBlueprintId,servicePrincipalType,createdDateTime,description",
        &graph, 3, &identities);
    usersCount = AgentCollectCollection(token,
        "/v1.0/users/microsoft.graph.AgentUser?$top=999&$select=id,displayName,userPrincipalName,identityParentId,createdDateTime",
        &graph, 4, NULL);

    AgentCollectRelationships(token, &blueprints,
        "/v1.0/applications/",
        "/microsoft.graph.agentIdentityBlueprint/owners",
        "AZAgent_Owns", &graph);
    AgentCollectRelationships(token, &blueprints,
        "/v1.0/applications/",
        "/microsoft.graph.agentIdentityBlueprint/sponsors",
        "AZAgent_Sponsors", &graph);
    AgentCollectRelationships(token, &identities,
        "/v1.0/servicePrincipals/",
        "/microsoft.graph.agentIdentity/owners",
        "AZAgent_Owns", &graph);

    AgentCollectServicePrincipalPermissions(token, &principals,
        "/appRoleAssignments", "agent-app-role:",
        "AZAgent_HasAppRole", "application", &graph);
    AgentCollectServicePrincipalPermissions(token, &identities,
        "/appRoleAssignments", "agent-app-role:",
        "AZAgent_HasAppRole", "application", &graph);
    AgentCollectServicePrincipalPermissions(token, &principals,
        "/oauth2PermissionGrants", "agent-oauth:",
        "AZAgent_HasDelegatedPermission", "delegated", &graph);
    AgentCollectServicePrincipalPermissions(token, &identities,
        "/oauth2PermissionGrants", "agent-oauth:",
        "AZAgent_HasDelegatedPermission", "delegated", &graph);
    AgentCollectDirectoryRoles(token, &principals, &graph);
    AgentCollectDirectoryRoles(token, &identities, &graph);
    /* Agent identity sponsors currently require AgentIdentity.ReadWrite.All
     * for application access. Keep this MVP read-only; blueprint sponsors
     * above are available with Application.Read.All. */

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Entra Agent ID: blueprints=%d principals=%d identities=%d users=%d nodes=%d edges=%d failedPages=%d\n",
        blueprintsCount, principalsCount, identitiesCount, usersCount,
        graph.nodeCount, graph.edgeCount, graph.failedPages);
    AgentWriteGraph(&graph);

    AgentRefsFree(&blueprints);
    AgentRefsFree(&identities);
    AgentRefsFree(&principals);
    BarkBufFree(&graph.nodes);
    BarkBufFree(&graph.edges);
}
