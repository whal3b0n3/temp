/*
 * get_entra_app_owner.c — BARK BOF
 * Get-EntraAppOwner — Get owners of an app registration
 *
 * Args : token, appObjectId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;
    char  *token = NULL;
    char  *appObjectId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    appObjectId = BeaconDataExtract(&parser, NULL);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <appObjectId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraAppOwner\n");
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/v1.0/applications/%s/owners", appObjectId);
    widePath = MbsToWcs(pathBuf);
    if (!widePath) { BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n"); return; }
    BarkGet(L"graph.microsoft.com", widePath, token);
    HFree(widePath);
}
