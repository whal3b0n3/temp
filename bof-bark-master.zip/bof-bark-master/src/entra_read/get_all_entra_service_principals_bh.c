/*
 * get_all_entra_service_principals_bh.c — BARK BOF
 * Get-AllEntraServicePrincipalsBH — Get all Entra service principals (BH format)
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllEntraServicePrincipalsBH\n");

    char  *tenantId   = BarkExtractTidFromJWT(token);
    char  *tenantName = BarkFetchTenantDisplayName(token);

    char suffix[512];
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId   ? tenantId   : "",
        tenantName ? tenantName : "");

    BarkGetBHInner(L"graph.microsoft.com",
        L"/beta/servicePrincipals?$count=true", token, "AZServicePrincipal", suffix);

    if (tenantId)   HFree(tenantId);
    if (tenantName) HFree(tenantName);
}
