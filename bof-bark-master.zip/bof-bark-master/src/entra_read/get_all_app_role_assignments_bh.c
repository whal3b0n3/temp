/*
 * get_all_app_role_assignments_bh.c — BARK BOF
 * Get-AllAppRoleAssignmentsBH — Get all Entra app-role assignments
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

#define BARK_APP_ROLE_WORKERS 8

typedef struct {
    const char *token;
    const char *resourceId;
    const char *resourceAppId;
    const char *tenantSuffix;
    BarkBuf output;
    int emitted;
} BarkAppRoleJob;

/* appRoleAssignedTo is resource-centric and returns assignments whose
 * principals can be users, groups, or service principals.  Enumerating this
 * relationship for every resource service principal therefore covers every
 * principal type without maintaining separate user and client snapshots. */
static DWORD WINAPI BarkAppRoleWorker(LPVOID parameter)
{
    BarkAppRoleJob *job = (BarkAppRoleJob *)parameter;
    char path[1024];
    char dataSuffix[1024];
    LPWSTR widePath;
    LPCWSTR pathArg;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    int isArray = 0;

    job->output.buf = NULL;
    job->output.cap = 0;
    job->output.len = 0;
    job->output.ok = 1;
    job->emitted = 0;

    MSVCRT$sprintf_s(path, sizeof(path),
        "/v1.0/servicePrincipals/%s/appRoleAssignedTo?$top=999",
        job->resourceId);
    MSVCRT$sprintf_s(dataSuffix, sizeof(dataSuffix),
        "\"appId\":\"%s\",%s",
        job->resourceAppId ? job->resourceAppId : "",
        job->tenantSuffix ? job->tenantSuffix : "");
    widePath = MbsToWcs(path);
    if (!widePath) {
        job->output.ok = 0;
        return 0;
    }
    pathArg = widePath;

    while (1) {
        char *next = BarkGetBHPageBuf(L"graph.microsoft.com", pathArg,
            job->token, "AZAppRoleAssignment", &job->output,
            &job->emitted, &isArray, dataSuffix, 0);

        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!next) break;

        nextWide = BarkResolveNextLink(next, L"graph.microsoft.com", "");
        nextUrl = next;
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(widePath);
    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    return 0;
}

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;
    char *tenantId;
    char *tenantName;
    char suffix[512];
    BarkIdList resourceIds;
    BarkIdList resourceAppIds;
    BarkBuf output = { NULL, 0, 0, 1 };
    int totalEmitted = 0;
    int offset = 0;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_app_role_assignments_bh <token>\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-AllAppRoleAssignmentsBH\n");
    tenantId = BarkExtractTidFromJWT(token);
    tenantName = BarkFetchTenantDisplayName(token);
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId ? tenantId : "", tenantName ? tenantName : "");

    resourceIds = BarkEnumAppRoleResourceIds(token, &resourceAppIds);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d resource service principal(s) with app roles; enumerating grants...\n",
        resourceIds.count);

    BarkBufAppend(&output, "{\"data\":[", 9);
    while (offset < resourceIds.count) {
        BarkAppRoleJob jobs[BARK_APP_ROLE_WORKERS];
        HANDLE threads[BARK_APP_ROLE_WORKERS];
        int wave = resourceIds.count - offset;
        int wi;

        if (wave > BARK_APP_ROLE_WORKERS) wave = BARK_APP_ROLE_WORKERS;
        MSVCRT$memset(jobs, 0, sizeof(jobs));
        MSVCRT$memset(threads, 0, sizeof(threads));

        for (wi = 0; wi < wave; wi++) {
            jobs[wi].token = token;
            jobs[wi].resourceId = resourceIds.ids[offset + wi];
            jobs[wi].resourceAppId = resourceAppIds.ids[offset + wi];
            jobs[wi].tenantSuffix = suffix;
            threads[wi] = KERNEL32$CreateThread(
                NULL, 0, BarkAppRoleWorker, &jobs[wi], 0, NULL);
            if (!threads[wi]) BarkAppRoleWorker(&jobs[wi]);
        }

        for (wi = 0; wi < wave; wi++) {
            if (threads[wi]) {
                KERNEL32$WaitForSingleObject(threads[wi], INFINITE);
                KERNEL32$CloseHandle(threads[wi]);
            }
            if (jobs[wi].emitted > 0 && jobs[wi].output.buf) {
                if (totalEmitted > 0) BarkBufAppend(&output, ",", 1);
                BarkBufAppend(&output, jobs[wi].output.buf,
                    jobs[wi].output.len);
                totalEmitted += jobs[wi].emitted;
            }
            BarkBufFree(&jobs[wi].output);
        }
        offset += wave;
    }

    {
        char tail[128];
        int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}",
            totalEmitted);
        if (tailLen > 0) BarkBufAppend(&output, tail, (SIZE_T)tailLen);
    }

    if (output.ok && output.buf) {
        SYSTEMTIME st;
        char filename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZAppRoleAssignment_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, output.buf, (DWORD)output.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZAppRoleAssignment found %d objects\n",
            totalEmitted);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: app_role_assignments\n");

    BarkBufFree(&output);
    BarkIdListFree(&resourceIds);
    BarkIdListFree(&resourceAppIds);
    if (tenantId) HFree(tenantId);
    if (tenantName) HFree(tenantName);
}
