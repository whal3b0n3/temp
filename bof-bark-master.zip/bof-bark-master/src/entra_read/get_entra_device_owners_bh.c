/*
 * get_entra_device_owners_bh.c — BARK BOF
 * Get-EntraDeviceOwnersBH — Get registered owners of an Entra device
 *
 * Args : token, deviceId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *deviceId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    deviceId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <deviceId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraDeviceOwnersBH\n");
    BarkGetBHGraphGrouped(token, "devices",
        (deviceId && MSVCRT$strlen(deviceId) > 0) ? deviceId : NULL,
        "registeredOwners", "AZDeviceOwner",
        "deviceId", "owners", "owner");
}
