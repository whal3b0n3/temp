/*
 * get_entra_parallel_bh.c - BARK BOF
 *
 * Run the four independent MS Graph collection families in one Beacon
 * execution. Beacon serializes top-level inline BOFs, so keeping these as
 * separate CNA calls makes role assignments, app-role assignments, and
 * relationships wait behind the core snapshot. The included collectors
 * already own their worker pools; this wrapper only joins the four families.
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#define BARK_PARALLEL_OUTPUT 1
#include "../../include/http_utils.h"

#define go BarkParallelCoreGo
#include "get_entra_core_bh.c"
#undef go

#define go BarkParallelRoleAssignmentsGo
#include "get_all_role_assignments_bh.c"
#undef go

#define go BarkParallelAppRoleAssignmentsGo
#include "get_all_app_role_assignments_bh.c"
#undef go

#define go BarkParallelRelationshipsGo
#include "get_entra_relationships_bh.c"
#undef go

typedef void (*BarkParallelEntry)(char *args, int alen);

typedef struct {
    BarkParallelEntry entry;
    char *args;
    int alen;
} BarkParallelJob;

static DWORD WINAPI BarkParallelWorker(LPVOID parameter)
{
    BarkParallelJob *job = (BarkParallelJob *)parameter;
    job->entry(job->args, job->alen);
    return 0;
}

void go(char *args, int alen)
{
    datap parser;
    char *token;
    int downloadMode;
    BarkParallelJob jobs[4];
    HANDLE threads[4];
    int i;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    downloadMode = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_parallel_bh <token> [downloadMode]\n");
        return;
    }

    jobs[0].entry = BarkParallelCoreGo;
    jobs[1].entry = BarkParallelRoleAssignmentsGo;
    jobs[2].entry = BarkParallelAppRoleAssignmentsGo;
    jobs[3].entry = BarkParallelRelationshipsGo;
    for (i = 0; i < 4; i++) {
        jobs[i].args = args;
        jobs[i].alen = alen;
        threads[i] = KERNEL32$CreateThread(NULL, 0, BarkParallelWorker,
            &jobs[i], 0, NULL);
        if (!threads[i]) {
            /* Preserve correctness if the process refuses another thread. */
            BarkParallelWorker(&jobs[i]);
        }
    }
    for (i = 0; i < 4; i++) {
        if (threads[i]) {
            KERNEL32$WaitForSingleObject(threads[i], INFINITE);
            KERNEL32$CloseHandle(threads[i]);
        }
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] BARK Entra parallel collection complete (core, role assignments, app roles, relationships)\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: core\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: role_assignments\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: app_role_assignments\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: relationships\n");
    (void)downloadMode;
}
