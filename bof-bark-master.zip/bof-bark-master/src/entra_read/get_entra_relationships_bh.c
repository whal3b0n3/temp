/*
 * get_entra_relationships_bh.c — BARK BOF
 *
 * Combined Graph relationship collector used by get_all_info.  Each parent
 * collection is enumerated once and the immutable ID list is reused for all
 * relationship kinds belonging to that collection.
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

static BarkIdList EnumGraphParentsWithStatus(
    const char *token, const char *collection, int *collectionComplete)
{
    BarkIdList ids;
    char path[512];
    BarkIdListInit(&ids);
    MSVCRT$sprintf_s(path, sizeof(path),
        "/v1.0/%s?$top=999&$select=id", collection);
    return BarkEnumEntityIdsWithStatus(
        L"graph.microsoft.com", path, token, "\"id\"",
        collectionComplete);
}

static BarkIdList EnumGraphParents(const char *token, const char *collection)
{
    return EnumGraphParentsWithStatus(token, collection, NULL);
}

static void CollectGroupRelationships(const char *token)
{
    BarkIdList ids;
    int parentEnumerationComplete = 0;
    BarkHttpMetricsReset();
    ids = EnumGraphParentsWithStatus(
        token, "groups", &parentEnumerationComplete);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Graph relationship snapshot: groups=%d\n", ids.count);
    BarkGetBHGraphGroupedFromIdsWithStatus(token, "groups", &ids,
        "members", "AZGroupMember", "groupId", "members", "member",
        parentEnumerationComplete);
    if (ids.count > 0) {
        BarkHttpMetricsReset();
        BarkGetBHGraphGroupedFromIds(token, "groups", &ids,
            "owners", "AZGroupOwner", "groupId", "owners", "owner");
    }
    BarkIdListFree(&ids);
}

static void CollectDeviceRelationships(const char *token)
{
    BarkIdList ids;
    BarkHttpMetricsReset();
    ids = EnumGraphParents(token, "devices");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Graph relationship snapshot: devices=%d\n", ids.count);
    if (ids.count > 0)
        BarkGetBHGraphGroupedFromIds(token, "devices", &ids,
            "registeredOwners", "AZDeviceOwner", "deviceId",
            "registeredOwners", "registeredOwner");
    BarkIdListFree(&ids);
}

static void CollectApplicationRelationships(const char *token)
{
    BarkIdList objectIds;
    BarkIdList appIds;
    char *tenantId;
    char *tenantName;
    char dataSuffix[1024];
    BarkHttpMetricsReset();
    objectIds = BarkEnumApplicationIds(token, NULL, &appIds);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Graph relationship snapshot: applications=%d\n",
        objectIds.count);
    if (objectIds.count > 0) {
        BarkGetBHGraphGroupedFromIdMap(token, "applications",
            &objectIds, &appIds,
            "owners", "AZAppOwner", "appId", "owners", "owner");
        BarkHttpMetricsReset();
        tenantId = BarkExtractTidFromJWT(token);
        tenantName = BarkFetchTenantDisplayName(token);
        MSVCRT$sprintf_s(dataSuffix, sizeof(dataSuffix),
            "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
            tenantId ? tenantId : "", tenantName ? tenantName : "");
        BarkGetBHGraphGroupedExFromIdMap(token, "applications",
            &objectIds, &appIds,
            "federatedIdentityCredentials", "AZFederatedIdentityCredential",
            "appId", "fics", "fic", dataSuffix);
        if (tenantId) HFree(tenantId);
        if (tenantName) HFree(tenantName);
    }
    BarkIdListFree(&objectIds);
    BarkIdListFree(&appIds);
}

static void CollectServicePrincipalRelationships(const char *token)
{
    BarkIdList ids;
    BarkHttpMetricsReset();
    ids = EnumGraphParents(token, "servicePrincipals");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Graph relationship snapshot: servicePrincipals=%d\n", ids.count);
    if (ids.count > 0)
        BarkGetBHGraphGroupedFromIds(token, "servicePrincipals", &ids,
            "owners", "AZServicePrincipalOwner", "servicePrincipalId",
            "owners", "owner");
    BarkIdListFree(&ids);
}

typedef struct {
    const char *token;
    int kind;
} RelationshipJob;

static DWORD WINAPI RelationshipWorker(LPVOID parameter)
{
    RelationshipJob *job = (RelationshipJob *)parameter;
    switch (job->kind) {
    case 0: CollectGroupRelationships(job->token); break;
    case 1: CollectDeviceRelationships(job->token); break;
    case 2: CollectApplicationRelationships(job->token); break;
    case 3: CollectServicePrincipalRelationships(job->token); break;
    }
    return 0;
}

void go(char *args, int alen)
{
    datap parser;
    char *token = NULL;

    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_relationships_bh <token>\n");
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-EntraRelationshipsBH (one parent snapshot per collection)\n");
    /* These four relationship families are independent. Run them in
     * parallel, matching AzureHound's stream-worker model, then wait before
     * emitting the completion line so the all-info queue has a real barrier. */
    RelationshipJob jobs[4];
    HANDLE threads[4];
    int i;
    for (i = 0; i < 4; i++) {
        jobs[i].token = token;
        jobs[i].kind = i;
        threads[i] = KERNEL32$CreateThread(NULL, 0, RelationshipWorker,
            &jobs[i], 0, NULL);
        if (!threads[i]) RelationshipWorker(&jobs[i]);
    }
    for (i = 0; i < 4; i++) {
        if (threads[i]) {
            KERNEL32$WaitForSingleObject(threads[i], INFINITE);
            KERNEL32$CloseHandle(threads[i]);
        }
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Get-EntraRelationshipsBH complete\n");
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: relationships\n");
}
