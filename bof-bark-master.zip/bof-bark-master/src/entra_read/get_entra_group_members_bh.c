/*
 * get_entra_group_members_bh.c — BARK BOF
 * Get-EntraGroupMembersBH — Get members of an Entra group (BH format)
 *
 * Args : token, groupId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    char  *groupId = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    groupId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token> <groupId>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraGroupMembersBH\n");
    BarkGetBHGraphGrouped(token, "groups",
        (groupId && MSVCRT$strlen(groupId) > 0) ? groupId : NULL,
        "members", "AZGroupMember",
        "groupId", "members", "member");
}
