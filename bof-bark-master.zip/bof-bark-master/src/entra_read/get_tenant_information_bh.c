/*
 * get_tenant_information_bh.c — BARK BOF
 * Get-TenantInformationBH — Get Entra tenant information (BH format)
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-TenantInformationBH\n");

    char *tenantId = BarkExtractTidFromJWT(token);

    char suffix[512];
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"id\":\"/tenants/%s\",\"tenantId\":\"%s\",\"tenantType\":\"AAD\",\"collected\":true",
        tenantId ? tenantId : "", tenantId ? tenantId : "");

    BarkGetBHInner(L"graph.microsoft.com",
        L"/v1.0/organization?$select=displayName,verifiedDomains,countryLetterCode,createdDateTime",
        token, "AZTenant", suffix);

    if (tenantId) HFree(tenantId);
}
