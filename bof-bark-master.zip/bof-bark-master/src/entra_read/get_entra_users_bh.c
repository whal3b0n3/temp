/*
 * get_entra_users_bh.c — BARK BOF
 * Get-EntraUsersBH — Get all Entra users (BH format)
 *
 * Args : token
 *
 * Author : BARK BOF project
 * License: GPLv3
 */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token = NULL;
    BeaconDataParse(&parser, args, alen);
    token = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);
    if (!token || MSVCRT$strlen(token) == 0) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Usage: bark_{}" "\n", "<token>");
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT, "[*] Get-EntraUsersBH\n");

    char  *tenantId   = BarkExtractTidFromJWT(token);
    char  *tenantName = BarkFetchTenantDisplayName(token);

    char suffix[512];
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId   ? tenantId   : "",
        tenantName ? tenantName : "");

    /* lastPasswordChangeDateTime is not part of Graph's default user
     * projection.  Keep Bark's existing broad beta projection explicit and
     * add the attack-path-relevant password-change timestamp. */
    BarkGetBHUsersWithPassword(token,
        /* Keep the broad beta projection for Bark's richer schema.  The
         * helper enriches it from the v1.0 projection used by AzureHound so
         * lastPasswordChangeDateTime is present for every user. */
        L"/beta/users?$top=999&$select="
        L"id,deletedDateTime,accountEnabled,ageGroup,businessPhones,city,"
        L"createdDateTime,creationType,companyName,consentProvidedForMinor,"
        L"country,department,displayName,employeeId,employeeHireDate,"
        L"employeeLeaveDateTime,employeeType,faxNumber,givenName,imAddresses,"
        L"infoCatalogs,isHardDeleteProtectionEnabled,isLicenseReconciliationNeeded,"
        L"isManagementRestricted,isResourceAccount,jobTitle,"
        L"lastPasswordChangeDateTime,legalAgeGroupClassification,mail,"
        L"mailNickname,mobilePhone,onPremisesDistinguishedName,officeLocation,"
        L"onPremisesDomainName,onPremisesImmutableId,onPremisesLastSyncDateTime,"
        L"onPremisesObjectIdentifier,onPremisesSecurityIdentifier,"
        L"onPremisesSamAccountName,onPremisesSyncEnabled,"
        L"onPremisesUserPrincipalName,otherMails,passwordPolicies,postalCode,"
        L"preferredDataLocation,preferredLanguage,proxyAddresses,"
        L"refreshTokensValidFromDateTime,securityIdentifier,showInAddressList,"
        L"signInSessionsValidFromDateTime,state,streetAddress,surname,"
        L"usageLocation,userPrincipalName,externalUserConvertedOn,"
        L"externalUserState,externalUserStateChangeDateTime,userType,"
        L"identityParentId,agentIdentityBlueprintId,isProvisionedToOnPremises,"
        L"identityProfileIds,employeeOrgData,inviteTicket,passwordProfile,"
        L"assignedLicenses,assignedPlans,authorizationInfo,"
        L"cloudRealtimeCommunicationInfo,deviceKeys,identities,"
        L"onPremisesExtensionAttributes,onPremisesProvisioningErrors,"
        L"onPremisesSipInfo,provisionedPlans,serviceProvisioningErrors",
        suffix);

    if (tenantId)   HFree(tenantId);
    if (tenantName) HFree(tenantName);
}
