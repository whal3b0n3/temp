/*
 * get_entra_device_owners_legacy_bh.c — BARK BOF
 * Get-EntraDeviceOwnersLegacyBH — Enumerate registered owners of a device via legacy AAD Graph (BloodHound)
 *
 * Args : token (AAD Graph Bearer), tenantId, deviceId
 * API  : GET graph.windows.net/{tenantId}/devices/{deviceId}/registeredOwners?api-version=1.6
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *tenantId = NULL;
    char  *deviceId = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    deviceId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_entra_device_owners_legacy_bh <token> [tenantId] [deviceId]\n");
        return;
    }

    /* Auto-extract tenantId from JWT if not provided */
    char *autoTid = NULL;
    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Enumerating device owners via legacy AAD Graph (tenantId=%s)\n", tenantId);
    BarkGetBHGraphGroupedLegacy(token, tenantId, "devices",
        (deviceId && MSVCRT$strlen(deviceId) > 0) ? deviceId : NULL,
        "registeredOwners", "AZDeviceOwner", "deviceId", "owners", "owner");

    if (autoTid) HFree(autoTid);
}
