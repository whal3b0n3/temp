/*
 * get_tenant_information_legacy_bh.c — BARK BOF
 * Get-TenantInformationLegacyBH — Retrieve tenant details via legacy AAD Graph API (BloodHound)
 *
 * Args : token (AAD Graph Bearer - scope: https://graph.windows.net/), tenantId
 * API  : GET graph.windows.net/{tenantId}/tenantDetails?api-version=1.6
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *tenantId = NULL;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_tenant_information_legacy_bh <token> [tenantId]\n");
        return;
    }

    /* Auto-extract tenantId from JWT if not provided */
    char *autoTid = NULL;
    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Retrieving tenant information (legacy AAD Graph): %s\n", tenantId);

    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/tenantDetails?api-version=1.6",
        tenantId);

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
        return;
    }

    char suffix[512];
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"id\":\"/tenants/%s\",\"tenantId\":\"%s\",\"tenantType\":\"AAD\",\"collected\":true",
        tenantId, tenantId);
    BarkGetBHInner(L"graph.windows.net", widePath, token, "AZTenant", suffix);
    HFree(widePath);
    if (autoTid) HFree(autoTid);
}
