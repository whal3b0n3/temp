/*
 * get_all_entra_roles_legacy_bh.c — BARK BOF
 * Get-AllEntraRolesLegacyBH — Enumerate Entra ID directory roles via legacy AAD Graph (BloodHound)
 *
 * Args : token (AAD Graph Bearer - scope: https://graph.windows.net/), tenantId
 * API  : GET graph.windows.net/{tenantId}/directoryRoles?api-version=1.6
 *
 * Renames "roleTemplateId" to "id" in output so it matches the MS Graph
 * roleDefinitions format that BloodHound expects.
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *tenantId = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_entra_roles_legacy_bh <token> [tenantId]\n");
        return;
    }

    char *autoTid = NULL;
    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Enumerating directory roles via legacy AAD Graph: %s\n", tenantId);

    char *tenantName = BarkFetchTenantDisplayNameLegacy(token, tenantId);

    char sfx[512];
    MSVCRT$sprintf_s(sfx, sizeof(sfx),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId, tenantName ? tenantName : "");

    LPWSTR hdrWide = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) { goto done; }

    char initPath[512];
    MSVCRT$sprintf_s(initPath, sizeof(initPath),
        "/%s/directoryRoles?api-version=1.6", tenantId);
    LPWSTR widePath = MbsToWcs(initPath);
    if (!widePath) { HFree(hdrWide); goto done; }

    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;

    char tenantBase[256];
    MSVCRT$sprintf_s(tenantBase, sizeof(tenantBase), "/%s/", tenantId);
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.windows.net",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] directoryRoles: HTTP %lu\n    %s\n", status, resp);
                HFree(resp);
            }
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 &&
                                   (*p == ' ' || *p == '\n' || *p == '\r' ||
                                    *p == '\t' || *p == ','))
                                p++;
                            if (p >= arrEnd - 1 || *p != '{') break;
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) break;

                            /* Emit: {"kind":"AZRole","data":{...}} */
                            static char pre[256];
                            int pn;
                            if (emitted == 0)
                                pn = MSVCRT$sprintf_s(pre, sizeof(pre),
                                    "{\"kind\":\"AZRole\",\"data\":");
                            else
                                pn = MSVCRT$sprintf_s(pre, sizeof(pre),
                                    ",{\"kind\":\"AZRole\",\"data\":");
                            if (pn > 0) BarkBufAppend(&b, pre, (SIZE_T)pn);

                            /* Copy the role object, renaming "roleTemplateId" to "id" */
                            const char *rtKey = JsonFindKey(p, itemEnd, "\"roleTemplateId\"");
                            if (rtKey) {
                                BarkBufAppend(&b, p, (SIZE_T)(rtKey - p));
                                BarkBufAppend(&b, "\"id\"", 4);
                                const char *afterKey = rtKey + 16; /* len("\"roleTemplateId\"") */
                                BarkBufAppend(&b, afterKey, (SIZE_T)(itemEnd - 1 - afterKey));
                            } else {
                                BarkBufAppend(&b, p, (SIZE_T)(itemEnd - p - 1));
                            }

                            /* Append suffix before closing } */
                            BarkBufAppend(&b, ",", 1);
                            BarkBufAppend(&b, sfx, MSVCRT$strlen(sfx));
                            BarkBufAppend(&b, "}}", 2);

                            emitted++;
                            p = itemEnd;
                        }
                    }
                }
            }
        }
        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"graph.windows.net", tenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZRole_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZRole found %d objects\n", emitted);
    }
    BarkBufFree(&b);

done:
    if (tenantName) HFree(tenantName);
    if (autoTid) HFree(autoTid);
}
