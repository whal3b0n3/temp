/*
 * get_all_app_role_assignments_legacy_bh.c — BARK BOF
 * Get-AllAppRoleAssignmentsLegacyBH — Enumerate app role assignments for a service principal via legacy AAD Graph (BloodHound)
 *
 * Args : token (AAD Graph Bearer), tenantId, servicePrincipalId
 * API  : GET graph.windows.net/{tenantId}/servicePrincipals/{servicePrincipalId}/appRoleAssignments?api-version=1.6
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

/* Pull in Win32 base types first, then WinHTTP types so that
 * HINTERNET / INTERNET_PORT are defined before http_utils.h uses them. */
#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

void go(char *args, int alen)
{
    datap  parser;
    char  *token  = NULL;
    char  *tenantId = NULL;
    char  *servicePrincipalId = NULL;
    char   pathBuf[2048];
    LPWSTR widePath = NULL;

    BeaconDataParse(&parser, args, alen);
    token  = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    servicePrincipalId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_app_role_assignments_legacy_bh <token> [tenantId] [servicePrincipalId]\n");
        return;
    }

    /* Auto-extract tenantId from JWT if not provided */
    char *autoTid = NULL;
    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    char *tenantName = BarkFetchTenantDisplayNameLegacy(token, tenantId);
    char suffix[512];
    MSVCRT$sprintf_s(suffix, sizeof(suffix),
        "\"tenantId\":\"%s\",\"tenantName\":\"%s\"",
        tenantId, tenantName ? tenantName : "");

    if (servicePrincipalId && MSVCRT$strlen(servicePrincipalId) > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Enumerating app role assignments via legacy AAD Graph: servicePrincipalId=%s (tenantId=%s)\n", servicePrincipalId, tenantId);

        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/%s/servicePrincipals/%s/appRoleAssignments?api-version=1.6",
            tenantId, servicePrincipalId);

        widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Failed to convert path to wide string\n");
            if (tenantName) HFree(tenantName);
            if (autoTid) HFree(autoTid);
            return;
        }

        BarkGetBHInnerEx(L"graph.windows.net", widePath, token, "AZAppRoleAssignment", suffix, 1);
        HFree(widePath);
    } else {
        BarkGetBHLegacyAutoEnum(token, tenantId, "servicePrincipals", "appRoleAssignments", "AZAppRoleAssignment", 1, suffix);
    }

    if (tenantName) HFree(tenantName);
    if (autoTid) HFree(autoTid);
}
