/*
 * get_all_role_assignments_legacy_bh.c — BARK BOF
 * Get-AllRoleAssignmentsLegacyBH — Enumerate all role assignments via legacy AAD Graph (BloodHound)
 *
 * Uses two-phase approach:
 *   1. GET graph.windows.net/{tenantId}/directoryRoles?api-version=1.6
 *      — list activated roles, collect objectId
 *   2. GET graph.windows.net/{tenantId}/directoryRoles/{objectId}/members?api-version=1.6
 *      — fetch members per role
 *
 * Args : token (AAD Graph Bearer - scope: https://graph.windows.net/), tenantId
 *
 * Author : BARK BOF project
 * License: GPLv3
 */

#include <windows.h>
#include <winhttp.h>
#include "../../include/beacon.h"
#include "../../include/http_utils.h"

static void EmitRoleMembersLegacy(BarkBuf *b, const char *bearerToken,
                                   const char *tenantId,
                                   const char *roleObjectId,
                                   const char *roleTemplateId,
                                   const char *tenantName,
                                   int *emitted)
{
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return;

    static char pathBuf[2048];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/directoryRoles/%s/members?api-version=1.6",
        tenantId, roleObjectId);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) { HFree(hdrWide); return; }

    static char prefix[512];
    int n;
    if (*emitted == 0)
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "{\"kind\":\"AZRoleAssignment\",\"data\":{\"roleAssignments\":[");
    else
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            ",{\"kind\":\"AZRoleAssignment\",\"data\":{\"roleAssignments\":[");
    if (n > 0) BarkBufAppend(b, prefix, (SIZE_T)n);

    char tenantBase[256];
    MSVCRT$sprintf_s(tenantBase, sizeof(tenantBase), "/%s/", tenantId);
    int memberCount = 0;
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.windows.net",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) { if (resp) HFree(resp); break; }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 &&
                                   (*p == ' ' || *p == '\n' || *p == '\r' ||
                                    *p == '\t' || *p == ','))
                                p++;
                            if (p >= arrEnd - 1 || *p != '{') break;
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) break;

                            if (memberCount > 0) BarkBufAppend(b, ",", 1);

                            {
                                char *memberId = JsonExtractStringValue(p, itemEnd, "\"objectId\"");
                                static char entry[512];
                                int en = MSVCRT$sprintf_s(entry, sizeof(entry),
                                    "{\"principalId\":\"%s\","
                                    "\"directoryScopeId\":\"/\","
                                    "\"roleDefinitionId\":\"%s\"}",
                                    SAFE_STR(memberId), roleTemplateId);
                                if (en > 0) BarkBufAppend(b, entry, (SIZE_T)en);
                                if (memberId) HFree(memberId);
                            }
                            memberCount++;
                            p = itemEnd;
                        }
                    }
                }
            }
        }
        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"graph.windows.net", tenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    static char sfx[1024];
    int sn = MSVCRT$sprintf_s(sfx, sizeof(sfx),
        "],\"roleDefinitionId\":\"%s\",\"tenantId\":\"%s\",\"tenantName\":\"%s\"}}",
        roleTemplateId, tenantId, SAFE_STR(tenantName));
    if (sn > 0) BarkBufAppend(b, sfx, (SIZE_T)sn);
    (*emitted)++;

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);
}

void go(char *args, int alen)
{
    datap  parser;
    char  *token    = NULL;
    char  *tenantId = NULL;

    BeaconDataParse(&parser, args, alen);
    token    = BeaconDataExtract(&parser, NULL);
    tenantId = BeaconDataExtract(&parser, NULL);
    g_use_download = BeaconDataInt(&parser);

    if (!token) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Usage: bark_get_all_role_assignments_legacy_bh <token> [tenantId]\n");
        return;
    }

    char *autoTid = NULL;
    if (!tenantId || MSVCRT$strlen(tenantId) == 0) {
        autoTid = BarkExtractTidFromJWT(token);
        if (!autoTid) {
            BeaconPrintf(CALLBACK_ERROR, "[-] Could not extract tenantId from JWT. Provide it explicitly.\n");
            return;
        }
        tenantId = autoTid;
        BeaconPrintf(CALLBACK_OUTPUT, "[*] Auto-extracted tenantId: %s\n", tenantId);
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Enumerating role assignments via legacy AAD Graph: %s\n", tenantId);

    LPWSTR hdrWide = BarkMakeAuthHeader(token, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) { if (autoTid) HFree(autoTid); return; }

    BarkIdList roleObjIds;
    BarkIdList roleTplIds;
    BarkIdListInit(&roleObjIds);
    BarkIdListInit(&roleTplIds);

    char initPath[512];
    MSVCRT$sprintf_s(initPath, sizeof(initPath),
        "/%s/directoryRoles?api-version=1.6", tenantId);
    LPWSTR widePath = MbsToWcs(initPath);
    if (!widePath) { HFree(hdrWide); if (autoTid) HFree(autoTid); return; }

    char goTenantBase[256];
    MSVCRT$sprintf_s(goTenantBase, sizeof(goTenantBase), "/%s/", tenantId);
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.windows.net",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] directoryRoles: HTTP %lu\n    %s\n", status, resp);
                HFree(resp);
            }
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 && *p != '{') p++;
                            if (p >= arrEnd - 1) break;
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) break;
                            char *oid = JsonExtractStringValue(p, itemEnd, "\"objectId\"");
                            char *rtid = JsonExtractStringValue(p, itemEnd, "\"roleTemplateId\"");
                            if (oid && MSVCRT$strlen(oid) > 0 &&
                                rtid && MSVCRT$strlen(rtid) > 0) {
                                BarkIdListAppend(&roleObjIds, oid);
                                BarkIdListAppend(&roleTplIds, rtid);
                            } else {
                                if (oid) HFree(oid);
                                if (rtid) HFree(rtid);
                            }
                            p = itemEnd;
                        }
                    }
                }
            }
        }
        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"graph.windows.net", goTenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);

    if (roleObjIds.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] No activated directoryRoles found\n");
        BarkIdListFree(&roleObjIds);
        BarkIdListFree(&roleTplIds);
        if (autoTid) HFree(autoTid);
        return;
    }

    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d activated roles, fetching members...\n", roleObjIds.count);

    char *tenantName = BarkFetchTenantDisplayNameLegacy(token, tenantId);

    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int ri;

    for (ri = 0; ri < roleObjIds.count; ri++) {
        EmitRoleMembersLegacy(&b, token, tenantId,
            roleObjIds.ids[ri], roleTplIds.ids[ri], tenantName, &emitted);
    }

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZRoleAssignment_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZRoleAssignment found %d role definitions\n", emitted);
    }
    BarkBufFree(&b);
    BarkIdListFree(&roleObjIds);
    BarkIdListFree(&roleTplIds);
    if (tenantName) HFree(tenantName);
    if (autoTid) HFree(autoTid);
}
