#ifndef BARK_EDGE_COLLECTION_H
#define BARK_EDGE_COLLECTION_H
/* Read-only collection helpers. Included after http_utils.h. */
typedef int (*BarkEdgeItemFn)(const char *, const char *, void *);

static const char *BarkEdgeSpace(const char *p, const char *end) {
    while (p < end && (*p==' ' || *p=='\r' || *p=='\n' || *p=='\t')) ++p;
    return p;
}
static const char *BarkEdgeValueEnd(const char *p, const char *end) {
    if (p >= end) return NULL;
    if (*p=='{' || *p=='[') return JsonSkipBalanced(p,end);
    if (*p=='"') return JsonSkipString(p,end);
    while (p < end && *p!=',' && *p!='}' && *p!=']') ++p;
    return p;
}
/* Only inspect direct fields: nested nextLink/id fields must never win. */
static const char *BarkEdgeField(const char *p, const char *end,
                                  const char *key, const char **valueEnd) {
    p=BarkEdgeSpace(p,end);
    if (p>=end || *p!='{') return NULL;
    p++;
    while ((p=BarkEdgeSpace(p,end))<end && *p!='}') {
        const char *keyEnd=JsonSkipString(p,end), *value, *stop;
        if (!keyEnd) return NULL;
        value=BarkEdgeSpace(keyEnd,end);
        if (value>=end || *value++!=':') return NULL;
        value=BarkEdgeSpace(value,end);
        stop=BarkEdgeValueEnd(value,end);
        if (!stop) return NULL;
        if ((SIZE_T)(keyEnd-p)==MSVCRT$strlen(key) &&
            MSVCRT$strncmp(p,key,(SIZE_T)(keyEnd-p))==0) {
            if (valueEnd) *valueEnd=stop;
            return value;
        }
        p=BarkEdgeSpace(stop,end);
        if (p<end && *p==',') p++; else break;
    }
    return NULL;
}
static char *BarkEdgeString(const char *p,const char *end,const char *key) {
    const char *stop=NULL, *value=BarkEdgeField(p,end,key,&stop);
    char *out; SIZE_T n;
    if (!value || *value!='"' || stop-value<2) return NULL;
    n=(SIZE_T)(stop-value-2);out=(char *)HAlloc(n+1);
    if (out) { MSVCRT$memcpy(out,value+1,n);out[n]=0; }
    return out;
}
static char *BarkEdgeGet(LPCWSTR host,LPCWSTR path,const char *token) {
    LPWSTR headers=BarkMakeAuthHeader(token,NULL);
    DWORD status=0;
    char *response;
    if (!headers) return NULL;
    response=HttpRequestWithRetry(L"GET",host,path,headers,NULL,0,&status);
    HFree(headers);
    if (!response || status<200 || status>=300) {
        BeaconPrintf(CALLBACK_ERROR,"[-] Edge collection: HTTP %lu\n",status);
        if (response) HFree(response);
        return NULL;
    }
    return response;
}
static int BarkEdgeList(LPCWSTR host,const char *path,const char *token,
                         BarkEdgeItemFn visit,void *context) {
    BarkIdList seen;int complete=1;
    char *url=(char *)HAlloc(MSVCRT$strlen(path)+1);
    BarkIdListInit(&seen);
    if (!url) return 0;
    MSVCRT$strcpy(url,path);
    while (url) {
        LPWSTR wide;char *response,*next=NULL;int i;
        const char *end,*array,*arrayEnd,*p,*stop,*cursor;
        for (i=0;i<seen.count;i++) if (MSVCRT$strcmp(seen.ids[i],url)==0) break;
        if (i<seen.count) { HFree(url);complete=0;break; }
        if (BarkIdListAppend(&seen,url)!=0) { HFree(url);complete=0;break; }
        wide=BarkResolveNextLink(url,host,"/");
        if (!wide) { complete=0;break; }
        response=BarkEdgeGet(host,wide,token);HFree(wide);
        if (!response) { complete=0;break; }
        end=response+MSVCRT$strlen(response);
        array=BarkEdgeField(response,end,"\"value\"",&arrayEnd);
        if (!array || *array!='[') { HFree(response);complete=0;break; }
        p=BarkEdgeSpace(array+1,arrayEnd);
        while (p<arrayEnd && *p!=']') {
            stop=(*p=='{') ? JsonSkipBalanced(p,arrayEnd) : NULL;
            if (!stop) { complete=0;break; }
            if (!visit(p,stop,context)) complete=0;
            p=BarkEdgeSpace(stop,arrayEnd);
            if (p<arrayEnd && *p==',') {
                p=BarkEdgeSpace(p+1,arrayEnd);
                if (p>=arrayEnd || *p==']') { complete=0;break; }
            }
            else if (p>=arrayEnd || *p!=']') { complete=0;break; }
        }
        cursor=BarkEdgeField(response,end,"\"@odata.nextLink\"",&stop);
        if (!cursor) cursor=BarkEdgeField(response,end,"\"nextLink\"",&stop);
        if (cursor && *cursor=='"') {
            /* Decode escaped slashes using the shared URL parser, bounded to
             * the direct nextLink property instead of searching child rules. */
            /* Construct a small object to reuse the decoder. */
            BarkBuf tmp={NULL,0,0,1};
            BarkBufAppend(&tmp,"{\"@odata.nextLink\":",sizeof("{\"@odata.nextLink\":")-1);
            BarkBufAppend(&tmp,cursor,(SIZE_T)(stop-cursor));
            BarkBufAppend(&tmp,"}",sizeof("}")-1);
            if (tmp.ok) next=JsonExtractNextLink(tmp.buf,tmp.buf+tmp.len);
            if (!next) complete=0;
            BarkBufFree(&tmp);
        } else if (cursor) complete=0;
        HFree(response);url=next;
    }
    BarkIdListFree(&seen);
    if (!complete) BeaconPrintf(CALLBACK_ERROR,"[-] Edge collection incomplete; retained partial evidence\n");
    return complete;
}
typedef struct {
    BarkBuf output;
    int count;
    int complete;
    const char *kind;
    const char *tenant;
    const char *token;
} BarkEdgeOutput;

static void BarkEdgeFinish(BarkEdgeOutput *out) {
    char tail[192],filename[300];SYSTEMTIME st;
    int n=MSVCRT$sprintf_s(tail,sizeof(tail),
        "],\"meta\":{\"type\":\"azure\",\"version\":5,\"count\":%d,\"collection\":{\"complete\":%s}}}",
        out->count,out->complete?"true":"false");
    BarkBufAppend(&out->output,tail,(SIZE_T)n);
    KERNEL32$GetLocalTime(&st);
    MSVCRT$sprintf_s(filename,sizeof(filename),".\\%s_%04u%02u%02u_%02u%02u%02u.json",
        out->kind,st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
    if (out->output.ok) BarkWriteOutput(filename,out->output.buf,(DWORD)out->output.len);
    else BeaconPrintf(CALLBACK_ERROR,"[-] Edge collection: output allocation failed\n");
    BarkBufFree(&out->output);
}
static int BarkEdgeRawItem(const char *item,const char *end,void *context) {
    BarkEdgeOutput *out=(BarkEdgeOutput *)context;
    char suffix[128];
    MSVCRT$sprintf_s(suffix,sizeof(suffix),"\"tenantId\":\"%s\"",SAFE_STR(out->tenant));
    BarkBufPrintBHItem(&out->output,out->kind,item,end,out->count==0,suffix,0);
    ++out->count;return out->output.ok;
}
static int BarkEdgeRuleItem(const char *item,const char *end,void *context) {
    BarkEdgeOutput *out=(BarkEdgeOutput *)context;
    if (out->count++) BarkBufAppend(&out->output,",",sizeof(",")-1);
    BarkBufAppend(&out->output,item,(SIZE_T)(end-item));return out->output.ok;
}
static int BarkEdgePolicyItem(const char *item,const char *end,void *context) {
    BarkEdgeOutput *out=(BarkEdgeOutput *)context;
    const char *policyEnd=NULL,*policy=BarkEdgeField(item,end,"\"policy\"",&policyEnd);
    const char *rules=policy ? BarkEdgeField(policy,policyEnd,"\"rules\"",NULL) : NULL;
    if (!rules || *rules!='[' ||
        BarkEdgeField(policy,policyEnd,"\"rules@odata.nextLink\"",NULL) ||
        BarkEdgeField(policy,policyEnd,"\"@odata.nextLink\"",NULL)) {
        char *id=BarkEdgeString(item,end,"\"policyId\"");
        char path[1024];BarkBuf replacement={NULL,0,0,1};
        BarkEdgeOutput collected={{NULL,0,0,1},0,1,NULL,NULL,NULL};
        int ok;
        if (!id || MSVCRT$strlen(id)>700 || MSVCRT$strchr(id,'/') || MSVCRT$strchr(id,'?')) {
            if (id) HFree(id);
            BarkEdgeRawItem(item,end,context);return 0;
        }
        MSVCRT$sprintf_s(path,sizeof(path),"/v1.0/policies/roleManagementPolicies/%s/rules",id);
        HFree(id);
        ok=BarkEdgeList(L"graph.microsoft.com",path,out->token,BarkEdgeRuleItem,&collected);
        if (!ok) {
            BarkBufFree(&collected.output);
            BarkEdgeRawItem(item,end,context);return 0;
        }
        if (policy) BarkBufAppend(&replacement,item,(SIZE_T)(policy-item));
        else {
            BarkBufAppend(&replacement,item,(SIZE_T)(end-item-1));
            BarkBufAppend(&replacement,",\"policy\":",sizeof(",\"policy\":")-1);
        }
        BarkBufAppend(&replacement,"{\"rules\":[",sizeof("{\"rules\":[")-1);
        if (collected.output.buf) BarkBufAppend(&replacement,collected.output.buf,collected.output.len);
        BarkBufAppend(&replacement,"]}",sizeof("]}")-1);
        if (policy) BarkBufAppend(&replacement,policyEnd,(SIZE_T)(end-policyEnd));
        else BarkBufAppend(&replacement,"}",sizeof("}")-1);
        if (replacement.ok) ok=BarkEdgeRawItem(replacement.buf,replacement.buf+replacement.len,context);
        else ok=0;
        BarkBufFree(&replacement);BarkBufFree(&collected.output);return ok;
    }
    return BarkEdgeRawItem(item,end,context);
}
static void BarkCollectEntraPIM(const char *token,const char *tenant) {
    const char *kinds[]={"AZEntraRoleEligibilityScheduleInstance","AZEntraRoleManagementPolicyAssignment"};
    const char *paths[]={
        "/v1.0/roleManagement/directory/roleEligibilityScheduleInstances",
        "/v1.0/policies/roleManagementPolicyAssignments?$filter=scopeId%20eq%20%27/%27%20and%20scopeType%20eq%20%27Directory%27&$expand=policy($expand=rules)"
    };
    int i;
    for (i=0;i<2;i++) {
        BarkEdgeOutput out={{NULL,0,0,1},0,1,kinds[i],tenant,token};
        BarkBufAppend(&out.output,"{\"data\":[",sizeof("{\"data\":[")-1);
        out.complete=BarkEdgeList(L"graph.microsoft.com",paths[i],token,
            i==0?BarkEdgeRawItem:BarkEdgePolicyItem,&out);
        BarkEdgeFinish(&out);
    }
}
#endif
