/* Shared helpers for Azure Blob Storage data-plane list BOFs. */
#ifndef BARK_STORAGE_BLOB_UTILS_H
#define BARK_STORAGE_BLOB_UTILS_H

#define BARK_STORAGE_API_VERSION "2021-04-10"
#define BARK_STORAGE_PAGE_SIZE   5000

static int BarkStorageIsAccountName(const char *name) {
    size_t i;
    size_t len;

    if (!name) return 0;
    len = MSVCRT$strlen(name);
    if (len < 3 || len > 24) return 0;
    for (i = 0; i < len; i++) {
        if (name[i] < 'a' || name[i] > 'z') {
            if (name[i] < '0' || name[i] > '9') return 0;
        }
    }
    return 1;
}

static int BarkStorageIsContainerName(const char *name) {
    size_t i;
    size_t len;

    if (!name) return 0;
    len = MSVCRT$strlen(name);
    if (len < 3 || len > 63 || name[0] == '-' || name[len - 1] == '-')
        return 0;

    for (i = 0; i < len; i++) {
        char c = name[i];
        if ((c < 'a' || c > 'z') && (c < '0' || c > '9') && c != '-')
            return 0;
        if (c == '-' && i + 1 < len && name[i + 1] == '-')
            return 0;
    }
    return 1;
}

static char *BarkStorageBuildListPath(const char *container,
                                      const char *marker) {
    size_t containerLen;
    size_t markerLen;
    size_t encodedContainerSize;
    size_t encodedMarkerSize;
    char *encodedContainer = NULL;
    char *encodedMarker = NULL;
    char *path = NULL;
    size_t pathSize;

    if (container && !BarkStorageIsContainerName(container)) return NULL;
    if (marker && MSVCRT$strlen(marker) == 0) marker = NULL;

    containerLen = container ? MSVCRT$strlen(container) : 0;
    markerLen = marker ? MSVCRT$strlen(marker) : 0;
    encodedContainerSize = containerLen * 3 + 1;
    encodedMarkerSize = markerLen * 3 + 1;

    if (container) {
        encodedContainer = (char *)HAlloc(encodedContainerSize);
        if (!encodedContainer) goto cleanup;
        UrlEncode(container, encodedContainer, encodedContainerSize);
    }
    if (marker) {
        encodedMarker = (char *)HAlloc(encodedMarkerSize);
        if (!encodedMarker) goto cleanup;
        UrlEncode(marker, encodedMarker, encodedMarkerSize);
    }

    pathSize = 96 + (container ? MSVCRT$strlen(encodedContainer) : 0) +
               (marker ? MSVCRT$strlen(encodedMarker) : 0);
    path = (char *)HAlloc(pathSize);
    if (!path) goto cleanup;

    if (container) {
        if (marker) {
            MSVCRT$sprintf_s(path, pathSize,
                "/%s?restype=container&comp=list&maxresults=%d&marker=%s",
                encodedContainer, BARK_STORAGE_PAGE_SIZE, encodedMarker);
        } else {
            MSVCRT$sprintf_s(path, pathSize,
                "/%s?restype=container&comp=list&maxresults=%d",
                encodedContainer, BARK_STORAGE_PAGE_SIZE);
        }
    } else if (marker) {
        MSVCRT$sprintf_s(path, pathSize,
            "/?comp=list&maxresults=%d&marker=%s",
            BARK_STORAGE_PAGE_SIZE, encodedMarker);
    } else {
        MSVCRT$sprintf_s(path, pathSize,
            "/?comp=list&maxresults=%d", BARK_STORAGE_PAGE_SIZE);
    }

cleanup:
    if (encodedContainer) HFree(encodedContainer);
    if (encodedMarker) HFree(encodedMarker);
    return path;
}

static char *BarkStorageBuildBlobPath(const char *container,
                                      const char *blobName) {
    size_t containerLen;
    size_t blobLen;
    size_t encodedContainerSize;
    size_t encodedBlobSize;
    char *encodedContainer = NULL;
    char *encodedBlob = NULL;
    char *path = NULL;
    size_t pathSize;

    if (!BarkStorageIsContainerName(container) || !blobName ||
        MSVCRT$strlen(blobName) == 0)
        return NULL;

    containerLen = MSVCRT$strlen(container);
    blobLen = MSVCRT$strlen(blobName);
    encodedContainerSize = containerLen * 3 + 1;
    encodedBlobSize = blobLen * 3 + 1;
    encodedContainer = (char *)HAlloc(encodedContainerSize);
    encodedBlob = (char *)HAlloc(encodedBlobSize);
    if (!encodedContainer || !encodedBlob) goto cleanup;

    UrlEncode(container, encodedContainer, encodedContainerSize);
    UrlEncode(blobName, encodedBlob, encodedBlobSize);
    pathSize = MSVCRT$strlen(encodedContainer) +
               MSVCRT$strlen(encodedBlob) + 3;
    path = (char *)HAlloc(pathSize);
    if (path) {
        MSVCRT$sprintf_s(path, pathSize, "/%s/%s",
                         encodedContainer, encodedBlob);
    }

cleanup:
    if (encodedContainer) HFree(encodedContainer);
    if (encodedBlob) HFree(encodedBlob);
    return path;
}

/* Decode the XML entities commonly returned in blob/container names. */
static char *BarkStorageXmlDecode(const char *start, size_t len) {
    char *out;
    size_t i;
    size_t j = 0;

    out = (char *)HAlloc(len + 1);
    if (!out) return NULL;

    for (i = 0; i < len; i++) {
        if (start[i] == '&') {
            if (i + 5 < len && MSVCRT$strncmp(start + i, "&amp;", 5) == 0) {
                out[j++] = '&'; i += 4; continue;
            }
            if (i + 4 < len && MSVCRT$strncmp(start + i, "&lt;", 4) == 0) {
                out[j++] = '<'; i += 3; continue;
            }
            if (i + 4 < len && MSVCRT$strncmp(start + i, "&gt;", 4) == 0) {
                out[j++] = '>'; i += 3; continue;
            }
            if (i + 6 < len && MSVCRT$strncmp(start + i, "&quot;", 6) == 0) {
                out[j++] = '"'; i += 5; continue;
            }
            if (i + 6 < len && MSVCRT$strncmp(start + i, "&apos;", 6) == 0) {
                out[j++] = '\''; i += 5; continue;
            }
        }
        out[j++] = start[i];
    }
    out[j] = '\0';
    return out;
}

/* Extract <tag>value</tag> from [start,end), returning decoded heap text. */
static char *BarkStorageXmlValue(const char *start, const char *end,
                                 const char *tag) {
    char open[48];
    char close[52];
    int openLen;
    int closeLen;
    const char *valueStart;
    const char *valueEnd;

    if (!start || !end || start >= end || !tag) return NULL;
    openLen = MSVCRT$sprintf_s(open, sizeof(open), "<%s>", tag);
    closeLen = MSVCRT$sprintf_s(close, sizeof(close), "</%s>", tag);
    if (openLen <= 0 || closeLen <= 0) return NULL;

    valueStart = MSVCRT$strstr(start, open);
    if (!valueStart || valueStart >= end) return NULL;
    valueStart += openLen;
    valueEnd = MSVCRT$strstr(valueStart, close);
    if (!valueEnd || valueEnd > end) return NULL;
    return BarkStorageXmlDecode(valueStart, (size_t)(valueEnd - valueStart));
}

static const char *BarkStorageXmlNextItem(const char *cursor,
                                          const char *end,
                                          const char *tag,
                                          const char **itemEnd) {
    char open[48];
    char close[52];
    int openLen;
    int closeLen;
    const char *itemStart;
    const char *closeStart;

    if (!cursor || !end || cursor >= end || !tag || !itemEnd) return NULL;
    openLen = MSVCRT$sprintf_s(open, sizeof(open), "<%s>", tag);
    closeLen = MSVCRT$sprintf_s(close, sizeof(close), "</%s>", tag);
    if (openLen <= 0 || closeLen <= 0) return NULL;

    itemStart = MSVCRT$strstr(cursor, open);
    if (!itemStart || itemStart >= end) return NULL;
    closeStart = MSVCRT$strstr(itemStart + openLen, close);
    if (!closeStart || closeStart > end) return NULL;
    *itemEnd = closeStart + closeLen;
    return itemStart;
}

static char *BarkStorageXmlNextMarker(const char *xml) {
    const char *end;
    char *marker;

    if (!xml) return NULL;
    end = xml + MSVCRT$strlen(xml);
    marker = BarkStorageXmlValue(xml, end, "NextMarker");
    if (!marker || MSVCRT$strlen(marker) == 0) {
        if (marker) HFree(marker);
        return NULL;
    }
    return marker;
}

#endif /* BARK_STORAGE_BLOB_UTILS_H */
