#ifndef BARK_OAUTH_SCOPE_H
#define BARK_OAUTH_SCOPE_H

#include <stddef.h>

/* No CRT dependencies: usable from a BOF and from the offline native harness. */
static int BarkScopeEqual(const char *value, size_t len, const char *literal) {
    size_t i;
    for (i = 0; i < len && literal[i]; ++i) {
        char a = value[i], b = literal[i];
        if (a >= 'A' && a <= 'Z') a += 'a' - 'A';
        if (b >= 'A' && b <= 'Z') b += 'a' - 'A';
        if (a != b) return 0;
    }
    return i == len && literal[i] == '\0';
}

/* Resource URL -> v2 scope. Existing explicit scopes remain accepted.
 * ARM's resource identifier ends in /, so its default scope has //.
 * Preserve trailing slashes for custom API identifiers.
 */
static int BarkNormalizeV2Scope(const char *input, char *output, size_t capacity) {
    size_t len = 0, base, i;
    int append = 0, arm = 0, hasSpace = 0;
    const char suffix[] = "/.default";
    if (!input || !output || !capacity) return 0;
    output[0] = '\0';
    while (input[len]) {
        if (input[len] == ' ' || input[len] == '\t') hasSpace = 1;
        ++len;
    }
    if (!len) return 0;
    base = len;
    if (!hasSpace && ((len >= 8 && BarkScopeEqual(input, 8, "https://")) ||
                     (len >= 6 && BarkScopeEqual(input, 6, "api://"))) &&
        !(len >= 9 && BarkScopeEqual(input + len - 9, 9, suffix))) {
        append = 1;
        while (base > 0 && input[base - 1] == '/') --base;
        arm = BarkScopeEqual(input, base, "https://management.azure.com") ||
              BarkScopeEqual(input, base, "https://management.core.windows.net");
        if (!arm &&
            !BarkScopeEqual(input, base, "https://graph.microsoft.com") &&
            !BarkScopeEqual(input, base, "https://graph.windows.net") &&
            !BarkScopeEqual(input, base, "https://storage.azure.com") &&
            !BarkScopeEqual(input, base, "https://vault.azure.net") &&
            !BarkScopeEqual(input, base, "https://api.powerplatform.com"))
            base = len;
    }
    if (!append) base = len;
    if (base + (append ? 9 : 0) + (arm ? 1 : 0) + 1 > capacity) return 0;
    for (i = 0; i < base; ++i) output[i] = input[i];
    if (arm) output[i++] = '/';
    if (append) {
        size_t j;
        for (j = 0; suffix[j]; ++j) output[i++] = suffix[j];
    }
    output[i] = '\0';
    return 1;
}

#endif
